﻿LiberLive MDS Player V2.3.20m - PerformanceSlots + LeadIntro + AutoMap (VS2019)

V2.3.20m 本版重点（直接基于 V2.3.20l）：
- “全部轨道”最前面固定插入 4 个演奏槽：A拨片和弦、B拨片和弦、A鼓、B鼓。每行显示中文资源名/精确资源码、当前主谱节拍、当前主谱 BPM、当前音量。
- 4 个演奏槽均带复选框：勾选=恢复原音量；取消勾选=通过 C2 Mixer 09/0A/0B/0C 写 0 静音。首次静音前会优先记住设备当前非零音量，恢复时回写该值；未连接 C2 时不伪装成功。
- 演奏槽来自 baseConfig.configPack 的 chords/drums pickType 0/1；中文名来自 data/C2_Resource_Catalog.csv。节拍/BPM 显示主谱运行值，不把资源试听 BPM 当成歌曲 BPM。
- 修复多轨歌曲主旋律漏显示：不再因为 section type=0（前奏）或 type=4（间奏）而隐藏 tk0。只要该段实际存在 beat.notes，主旋律就显示并参与 PC MIDI 播放。《红日（进阶版）》前奏 type0 实际有 29 个 tk0 notes。
- 根据 2026-09-04 真机差分更新 SET_AUTO_PLAY UI/日志：01=主自动播放/演奏模式，02=鼓机自动挂挡许可，03=自动转调，05=Solo/演奏模式相关，06=聪明模式，04 保留为未标定。C2 多档换挡本次抓包经 set_pre_level 执行；不要把 SET_AUTO_PLAY type 与 JSON extensions.type 混为同一编号空间。
- V2.3.20l 的鼓 Cue、主谱 BPM、每轨 PC MIDI 音色、460B WR-Pack、6/8 MeterTimingFix、INT25/INT26 等全部保留。

以下为 V2.3.20l 历史记录（20m 在其上继续修改；冲突时以上面的 20m 说明为准）。

LiberLive MDS Player V2.3.20l - DrumCue + MasterBPM + PerTrackMIDI (VS2019)

V2.3.20l 本版重点（直接基于 V2.3.20k）：
- 主时间轴按官方《红日（进阶版）》截图/JSON/蓝牙日志补齐鼓提示：type7 显示“用A/B拨片”；type3 switchType=1 + pick=0/1 显示“进A鼓/进B鼓”；type3 switchType=0 显示“关鼓机”。相邻提示使用两行防重叠。
- 明确 SET_AUTO_PLAY 03 00/03 01 是“鼓机自动挂挡许可”而不是每拍硬开/关鼓：03 00 时 JSON 显式鼓事件仍可工作；03 01 允许按曲谱自动挂挡。
- BPM 主从彻底分离：打开 JSON 后 tempo（其次 baseConfig.bpm）是主谱 BPM；资源库 BPM/拍号只作为试听/参考元数据。设备中心改 A/B 拨片/鼓资源时，set_*_v2basic 使用当前主谱/设备运行 BPM，不再把资源试听 BPM 写成主运行 BPM。多轨 SET_TRACK_INS/INT26 音色修改不触碰 BPM。
- PC“播放”不再把全部音轨强制成 GM Piano。主旋律根据 melodicNote 及活动的 type13/type14 音色，extraTracks 根据 trackConfigs[].assetNotes/noteCode，映射到最接近的 General MIDI Program；同时应用每轨 JSON volume。
- 《红日》附件日志实测基线：JSON/上传主 BPM=120；GET_AUTO 在演奏前 type3=0，但之后仍出现 noti_drum，进一步证明 type3 auto-play 状态不是“鼓机硬静音”；日志随后可见 SET_AUTO_PLAY 03 01 作为自动挂挡许可切换。
- BLE 上传 460B WR-Pack、6/8 时值、INT25/INT26、PlayPrefsFix 等 V2.3.20k 功能全部保留。

以下为 V2.3.20k 的历史记录（20l 在其上继续修改；冲突时以上面的 20l 说明为准）。

LiberLive MDS Player V2.3.20k - PlayPrefsFix (VS2019)

V2.3.20k PlayPrefsFix 重点：
- 实体演奏推进改为“同根和弦即推进”：F/Fm、A/Am 等大小调/type/trans 不再卡红线；A/B/A+B 拨片继续等价。
- “风格配置 Type1~Type6”改为“演奏偏好 / Style Settings”；raw value 使用数值编辑，保留 2/3 等非 boolean 值，并显示 STAR_A/STAR_B/PREVIEW_C/PREVIEW_D/ABASS_EN/BPMLOCK/PREV_BPMLOCK 候选语义。
- AUTO_PLAY UI 改按功能显示：主旋律=01，自动鼓机=03（真机实测），自动转调=04，Solo=05，自动换挡=06，Smart=07；type02=AUTO_PLAY_NONE 不再做按钮。
- 主旋律提示明确：type01 仅在 type05=0 时有效；type05=1 时，实测 type01 开/关主旋律都无声。
- 保留 V2.3.20j 的 460B WR-Pack、UIProgress50、超大 FILL 拆分、6/8 MeterTimingFix、启动/关闭鼓标记和日志。

以下为 V2.3.20j 的历史变更记录（20k 在其上继续修改；与上面的 20k 说明冲突时，以上面的 20k 说明为准）。

V2.3.20j was based directly on V2.3.20i1_UIProgress50. BLE upload transport was intentionally unchanged.

Playback/UI changes:
1) C2 chord transport ignores score pick direction: a correct chord/key advances for A, B or A+B physical pick. Pick A/B/A+B remains visible as a cue only.
2) Timeline + beat detail now show extension type=12 drum cues as 启动鼓 / 关闭鼓 (switchType 1/0).
3) Device Center style settings keeps raw type1..6 read/write and adds the APK StyleSettingType semantic legend without inventing a wire mapping.
4) Device Center GET_AUTO_PLAY/SET_AUTO_PLAY now exposes raw type1..6, reads current state via 0x0F and writes 0x10 [type][state].
5) UI upload progress throttling from V2.3.20i1 remains; detailed log remains complete.

Evidence notes:
- get_style_settings is [count][type][value]... and current C2 captures return raw types 1..6.
- APK source contains STAR_A, STAR_B, PREVIEW_C, PREVIEW_D, A-BASS, BPMLOCK and PREV_BPMLOCK; exact enum-to-wire-number binding is not claimed here.
- GET_AUTO_PLAY/SET_AUTO_PLAY uses raw type/state. Capture/source evidence supports Type1=AUTO_PLAY_MAIN (main/trigger, exact product wording still qualified), Type3=AUTO_PLAY_DRUM, Type4=AUTO_PLAY_KEY (auto key-change), Type5=APLAY_TYPE_SOLO, Type6=APLAY_TYPE_STYLE_LEVEL; Type2 remains intentionally qualified.

LiberLive MDS Player V2.3.20i1 - UIProgress50 (VS2019)

V2.3.20i1 is a UI-only follow-up to V2.3.20i. BLE upload behavior, 460B WR-Pack, oversized FILL splitting, and 6/8 MeterTimingFix are unchanged.

UI change:
- The on-screen one-line "C2 上传进度" is throttled to roughly every 50 logical FILLs (first/final always shown).
- Packed uploads may jump across an exact 50 boundary, so the latest real progress value is displayed when a new 50-FILL bucket is crossed.
- The per-upload c2_upload_*.log and rolling c2_ble.log still retain every progress callback and all diagnostics.

LiberLive MDS Player V2.3.20i - 460B WR-Pack + OversizeSplit TEST (VS2019)

Baseline:
- Directly derived from V2.3.20h, which itself preserves V2.3.20d 6/8 MeterTimingFix.
- No changes to MDSParser / PlayerCore / C2MusicEncoder timing semantics.

Why this version:
1. Real logs show this Windows stack reports A103 WriteWithoutResponse=NO, WriteWithResponse=YES.
2. Therefore V2.3.20h incorrectly disabled both 460B MTU batching and Pipeline2.
3. Successful INT25 pages already use 469B data under MaxPduSize=500, proving large WriteWithResponse transfers work.
4. Some songs contain a single original FILL > MTU budget (observed maxData=517B / packet 514B failure).

Changes:
- 460B FILL batching is enabled whenever MaxPduSize is sufficient, regardless of WNR.
- Pipeline2 remains WNR-only. On the current Windows stack it will correctly remain OFF.
- A single oversized generated FILL is split at item boundaries into legal <=460B FILL payloads.
- Adjacent normal FILL payloads can still be greedily merged up to 460B.
- Item bytes, order, absolute beat and duration are unchanged.
- CREATE / GET / Verify / Notify29 / SET_BEAT and first-stage control ordering are unchanged.
- Per-upload log is retained.

Expected log on current PC:
A103 WNR=NO, MaxPduSize=500
FILL尾段：动态MTU合包=ON，Pipeline2=OFF
...
V2.3.20i ... packedWrites>0 ...
splitOriginals may be >0 for dense songs.

Important:
- This environment cannot run VS2019 + Windows BLE + a physical C2. Compile/run validation must be done on the target Windows machine.
