﻿# V2.3.18d 双主旋律时间轴修复

## 现象
V2.3.18c 左侧“全部轨道”已显示主旋律01/02，但中间钢琴卷帘两行为空。

## 根因
物理曲谱只有 tk0 LEAD。`AllTrackIndexes()` 在双主旋律模式下用虚拟 ID -1001/-1002 替代 tk0。
绘图循环仍然用 `n.trackIndex == 0` 在 laneTracks 中查找，必然找不到，因此跳过全部 tk0 note。

## 修复
绘图前对每个 tk0 note 根据 `SegmentUsesLeadVirtual()` 映射为：
- -1001 主旋律01 / Violin
- -1002 主旋律02 / PianoStudio

之后用虚拟 ID 查 lane、检查 checkbox enable 状态并绘制；真正取 MIDI note 数据仍来自物理 tk0。

## 月亮代表我的心预期
- 主旋律01 小提琴：57 notes
- 主旋律02 大钢琴：213 notes
- 合计 270，与物理 tk0 noteCount 一致。
