# V2.3.20f StableMTUFillBatch

Baseline: `V2.3.20d_6_8_MeterTimingFix`.

## Goal
Accelerate the long `C2 上传进度 x / N` FILL tail while preserving the proven control-command ordering and all 6/8 timing code.

## Stability-first policy
- `CREATE / GET / Verify / Notify29 / SET_BEAT / AUTO / volume / track setup` are unchanged.
- First-stage FILLs that are interleaved with control commands remain individual packets.
- Exact official flow profiles remain individual FILL packets; no cross-beat packing is applied there.
- Generic bulk tail only: at most **two adjacent generated FILL payloads** are merged.
- Merge does not rewrite any item body. Item type order and raw item bytes are preserved; beat/duration are already absolute inside each item.
- Even when ATT MTU is 500, FILL data is capped at **223B**. With the 21B integer TLVC envelope this is a 244B GATT value. This matches the largest successful official FILL evidence and also fits MTU 247.
- Combined FILL packets use **18ms start-to-start** pacing. A two-FILL combined packet therefore targets roughly 9ms per original FILL without driving the receiver at 9ms packet cadence.
- `INT25` remains on its existing proven application-level paging; no new fragmentation or coalescing is introduced.

## Why MTU=500 alone does not help
The existing score encoder already emits one FILL containing all items from a score beat. If these FILLs remain separate, a 500-byte MTU does not reduce the number of A103 writes. The speed gain comes from using FILL's multi-item format to reduce GATT write count in the generic tail, not from concatenating multiple TLVC frames into one ATT Write.

## Expected example
For a song with 272 original FILL packets, the first ~10 remain unchanged. If most tail pairs fit <=223B, the remaining 262 FILLs become about 131 A103 writes. The UI progress still reports original FILL completion (`done/272`) so semantics are unchanged.
