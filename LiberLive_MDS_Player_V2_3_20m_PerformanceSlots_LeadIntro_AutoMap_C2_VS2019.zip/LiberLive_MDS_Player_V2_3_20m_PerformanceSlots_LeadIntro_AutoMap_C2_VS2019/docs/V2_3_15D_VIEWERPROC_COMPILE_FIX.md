# V2.3.15d ViewerProc compile fix

VS2019 reported C2065/E0020 at App.cpp around ViewerProc::WM_CLOSE because V2.3.15c accidentally contained:

```cpp
if (st && st->taskRunning) { ... }
```

`ViewerProc` is the generic read-only text viewer and has no `DeviceCenterState* st`. The background-task close guard already exists in `DeviceCenterProc::WM_CLOSE`, where it belongs. V2.3.15d removes the accidental block from `ViewerProc` and leaves the correct DeviceCenterProc guard unchanged.

No BLE protocol/upload logic changed.
