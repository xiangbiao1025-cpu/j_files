# V2.3.15 C2 Device Center / Style / Tone

## 实机结论修正

`set_volume ch05` 读写/回读正确，但 C2 当前 MDS sheet 演奏中即使写 0 仍有 tk0 主旋律，因此 V2.3.15 不再把 ch05 描述为 sheet 主旋律实时音量，也不在上传流程自动写 05 64。曲谱运行态的 tk0 音量/音色继续按 INT25/INT26 处理。

## 设备中心可验证项

- get/set volume ch01..ch0D
- set_key
- set_bpm
- set_fret_instru（sound_c2 五种抓包确认音色）
- get/set_style_settings type1..6
- set_config_v2pack（从当前 JSON 重新编码）
- StylePack 候选只读：get_style_pack_mode / get_style_pack_seq / get_style_pack0
- 版本、功能、basic/v2basic、midi、灯光、人性化、sys_onoff 原始查询

## 注意

设备中心是协议验证面板；未知固件/未知 StylePack payload 不自动写入。
