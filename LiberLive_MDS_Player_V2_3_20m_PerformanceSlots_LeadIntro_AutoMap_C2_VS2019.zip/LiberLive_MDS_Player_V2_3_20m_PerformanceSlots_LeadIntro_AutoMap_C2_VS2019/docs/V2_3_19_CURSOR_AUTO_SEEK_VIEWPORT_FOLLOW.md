﻿# V2.3.19 Cursor / Viewport / C2 seek update

1. Bottom trackbar controls only `g_timelineViewStart`; it never writes `g_positionBeat`.
2. Score click/drag release writes the red cursor. If C2 is connected and the current sheet is uploaded, it automatically runs `ArmKeyPlayFromBeat()` (SET_SHEET_BEAT + cue + A102 verify).
3. Segment list uses single-click `LBN_SELCHANGE`; it jumps to the selected segment start and automatically performs the same C2 seek.
4. Playback follow: after the cursor passes 82% of the visible span, viewport start becomes `beat - span/3`, placing the cursor near 1/3 and leaving ~2/3 future score visible.
5. C2 late-reply anti-rewind: `StartC2ChordFlow()` uses `visualStart=max(currentRedLine,chordStart)` so accepted device synchronization cannot move the rendered cursor backward during an armed performance.
6. Existing V2.3.18e dual logical tk0 melody, bilingual timbre names, and track mute/restore behavior are unchanged.
