# V2.3.20g 460B FILL Pack TEST

基线：V2.3.20d_6_8_MeterTimingFix，沿用 V2.3.20f 的稳定 bulk 发送框架。

## 只修改慢速 FILL 尾段
- 前 10 个 FILL 与 CREATE / SET_BEAT / AUTO / Track 配置等交错时序保持不变。
- 仅最终连续 FILL 尾段做动态贪心合包。
- 单个合并 FILL `data <= min(460, MaxGattWriteValueBytes-21)`。
- MTU=500 时：ATT value 上限 497B；460B FILL data + 21B TLVC = 481B，保留 16B 余量。
- 合包后 itemCount 仍限制 <=255；item 原始字节及顺序不改变。
- 聚合大包固定先按 18ms start-to-start；失败仍退速到 25ms。
- INT25 不改，继续使用原 469B data/page。
- 6/8 MeterTimingFix、MDSParser、PlayerCore、C2MusicEncoder 逻辑不改。

## 日志
上传前打印预计 A103 写次数、聚合写次数、最多一次合并多少个原 FILL、最大聚合 data。
上传后打印 packedWrites / packedOriginals / maxPackedOriginals / maxPackedData。

## 注意
这是 460B 实机测试版。当前已有官方 INT25 469B 大页证据，但 FILL 460B 是协议结构推导 + MTU 余量测试，不应在实机确认前作为正式稳定上限。
