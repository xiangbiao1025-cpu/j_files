# C2 Main Melody Test V2.3.3

## Purpose

V2.3.2 proved the C2 sheet transport: upload handshake, key-trigger wait, device beat notify, and GUI red-line synchronization. V2.3.3 isolates the next question: why the primary LEAD track can be resident in C2 but silent.

## Evidence

Captured device-control traffic defines `set_pre_lead` as:

```text
[mode:1][preBeat:float32 little-endian][toneNameLen:1][toneName UTF-8]
mode 00 = melody off
mode 01 = melody on
mode 02 = melody Auto/intelligent
```

Captured live examples switched mode at beat 24 and beat 34 with `PianoStudio`, proving this is a runtime control rather than a JSON-upload command.

The 2026-08-20 sheet-play capture does not itself send `set_pre_lead` in the successful song upload sessions. Therefore the official App may have relied on an already-persisted device melody state. A PC controller must not assume that state. V2.3.3 explicitly requests melody ON after the known-good sheet beat has been verified.

## Why command is sent after VerifySheetBeat

Do not insert experimental melody configuration into the verified CREATE/FILL handshake. The order is:

1. Run the unchanged V2.3.2 btsnoop handshake.
2. `GET_SHETT_BEAT` / A102 confirms the C2 is truly at the initial playable beat.
3. Set `uploaded=true`, `armed=true`.
4. Send `set_pre_lead mode=1` with the verified starting beat and `PianoStudio`.
5. Wait for physical C2 trigger.

This keeps red-line synchronization and main-melody activation as separate variables.

## Ulaan test facts

`02_乌兰巴托的夜_进阶版_.json` encodes:

- 10 descriptors
- tk0 = type1 LEAD, 234 notes
- tk1 = type2 CHORD, 90 items
- tk2 = type5 EVENT, 7 items
- 171 FILL packets
- first primary LEAD note at absolute beat 3

Thus a silent melody cannot be explained by an empty tk0. The first physical trigger at beat 0 may not yet cover the first lead note; continue into the beat-2/beat-4 transition when listening.

## GUI A/B controls

- **旋律开**: `set_pre_lead mode=1`
- **旋律Auto**: `set_pre_lead mode=2`
- **旋律关**: `set_pre_lead mode=0`

For manual changes V2.3.3 first issues `GET_SHETT_BEAT`, then uses the returned beat as `preBeat`, so toggling does not reset the song position.

## Not enabled automatically yet

`SET_AUTO_PLAY 02 01/00` has appeared in earlier control captures and is suspected to relate to automatic/main-melody state, but its semantic mapping is not as strong as `set_pre_lead`. V2.3.3 deliberately does **not** send it automatically. If mode 1 and mode 2 of `set_pre_lead` both remain silent while the red line advances, the next isolated experiment should be `SET_AUTO_PLAY type=2`, not another rewrite of the upload handshake.
