﻿# LiberLive MDS Player V2.3.20c — Resource Master Catalog

## 目标

把 `LiberLive_C2_Resource_Master_Evidence.xlsx` 的当前实机验证结果接入 V2.3.20b 四槽设备中心。

- A/B 和弦：`set_chord_v2basic`, slot 0/1。
- A/B 鼓：`set_drums_v2basic`, slot 0/1。
- 四槽回读：`get_config_v2basic -> A102`。
- 写入后仍立即回读并要求 `readback == request`。

## 运行资源表

程序不直接解析 XLSX，而读取 `data/C2_Resource_Catalog.csv`。该 CSV 由当前主表导出，仅包含 `ACCEPTED_EXACT` / `supported=1` 项。

当前导出：429 项：

- Chord 296
- Drum 133
- 具有精确中文 Pattern 名 46 项（GS 32 + 流行鼓 14）

下拉框显示：

`nameCode | 中文名 | BPM | 拍号`

回读信息区额外标记参数来源。

## BPM / 拍号使用原则

- `BLE_exact_*` / `*_btsnoop_exact`：原厂抓包参数，可用于 V2Basic 写入。
- `BLE_multilevel*`：官方多档包 ResourceRecord 参数，可用于 V2Basic 写入实验。
- `curve476`：3674 首曲库的常用/参考参数，只展示，不当作资源固有原始参数写入。
- `auto_probe`：存在性短测发送参数，只展示，不当作资源原始参数写入。

后两类写入时继续采用 V2.3.20b 的安全规则：保留当前槽 `get_config_v2basic` 回读到的 BPM/meter；若尚未读回，则要求先“读取/回读四槽”。

## 文件定位

运行时依次寻找：

1. `EXE\data\C2_Resource_Catalog.csv`
2. `EXE\C2_Resource_Catalog.csv`
3. VS2019 输出目录回溯到工程根目录 `data`
4. 当前工作目录 `data`

PostBuild 会把 CSV 和 Excel 证据表复制到 `$(OutDir)\data`。
