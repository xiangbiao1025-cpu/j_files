﻿# V2.3.20j PlaybackUI

Base: V2.3.20i1_UIProgress50. No BLE bulk/MTU/pacing changes in this release.

## Playback gate
A/B/A+B pick direction is no longer a transport gate. Correct chord/root (and the existing capture-confirmed major/minor gate) advances the PC UI regardless of pick direction.

## Drum cue
Timeline cue lane and beat detail render JSON extension type=12 as:
- switchType=1 -> 启动鼓
- switchType=0 -> 关闭鼓
Unknown values are shown as 鼓切换(n).

## Style settings
The device center still writes raw `set_style_settings [type][0/1]` only after `get_style_settings` readback. APK semantic names are shown as a legend, not force-bound to raw type numbers.

## AUTO_PLAY
Device center exposes types 1..6. Refresh sends GET_AUTO_PLAY (0x0F) and caches `[count][type][state]...`. Manual buttons send SET_AUTO_PLAY (0x10) `[type][state]`, then best-effort readback. UI labels use the evidence-supported semantics where available: T1 AUTO_PLAY_MAIN, T3 AUTO_PLAY_DRUM, T4 AUTO_PLAY_KEY, T5 APLAY_TYPE_SOLO, T6 APLAY_TYPE_STYLE_LEVEL; T2 remains qualified as `旋律/子状态?`.
