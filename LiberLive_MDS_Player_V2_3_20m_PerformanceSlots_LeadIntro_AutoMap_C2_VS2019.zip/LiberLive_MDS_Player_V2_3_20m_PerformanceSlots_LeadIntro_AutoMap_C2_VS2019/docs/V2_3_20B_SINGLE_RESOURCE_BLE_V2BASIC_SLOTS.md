# LiberLive MDS Player V2.3.20b

## 目标

本版针对 V2.3.20a 在真机上出现的四槽“未读回”问题，以及不同 C2 名称/固件下连接兼容性问题。

## 1. 四槽读回改为 C2SingleResourceAuditioner 已实机验证链路

V2.3.20a 曾错误地围绕 `get_config_basic` 做 A/B 四槽读取。

V2.3.20b 改为：

1. A103 发送 `get_config_v2basic`
2. 等待设备更新 A102
3. 通过 A102 Uncached Read 读取
4. TLVC 解密后必须得到 `get_config_v2basic`
5. 按 `ConfigV2Basic` 结构解析四槽

结构：

```text
[LP cardCode]
[LP cardName]
[count]
repeat count:
    [slot]
    [kind]
    [flag]
    [len]
    [fullResourceCode]
    [bpm]
    [meter]
```

槽位：

```text
slot=0 kind=1 -> AChord
slot=1 kind=1 -> BChord
slot=0 kind=2 -> ADrum
slot=1 kind=2 -> BDrum
```

UI 中的“读取/回读四槽”只执行这条路径，不再通过完整设备刷新间接读取。

## 2. A/B 单槽写入同步升级为 V2Basic

和弦/拨片：

```text
set_chord_v2basic
```

鼓：

```text
set_drums_v2basic
```

payload：

```text
[slot][kind][01][len][sound_c2:resource][bpm][meter]
```

写完立即使用 `get_config_v2basic` 回读，并验证目标槽的 resource code。

如果 PC 资源证据表中已经有该资源自身的原始 BPM/拍号，则写入时使用该参数。
如果没有资源自身证据，则沿用 C2 当前槽回读到的 BPM/拍号；UI 仍把“原始 BPM/拍号”标为“待补测”，不会用歌曲 BPM 冒充资源原始参数。

## 3. BLE 扫描/连接改用 C2SingleResourceAuditioner 模型

连接核心已按 C2SingleResourceAuditioner 重构：

- Active BLE Advertisement Scan
- 不把固定设备名作为唯一过滤条件
- 保留有名称的 BLE 广播以及带 Service `000000FF` 的设备
- 优先级：Service FF > LiberLive 名称 > C2 名称 > RSSI
- 合并 Windows `DeviceInformation` 已知 BLE 设备作为 fallback
- 支持 Bluetooth Address 或 Windows DeviceInformation ID 连接
- Service/Characteristic 全部使用 Uncached GATT discovery
- A103 写入按 characteristic property 自动选择 WriteWithoutResponse / WriteWithResponse
- A102 使用 Uncached Read

播放器比 SingleResourceAuditioner 多一项演奏需求，因此最终连接判定必须同时具备：

```text
Service FF
A101 Notify
A102 Read
A103 Write
```

成功日志示例：

```text
BLE scan done: 3
Connected: LiberLiveC2-xxxx (A101+A102+A103 ready)
```

这样不会只靠某个固定 C2 广播名称判断型号；最终由真实 GATT 能力判定是否是可用 C2。

## 4. 保持不变

本版不改：

- V2.3.20 Strict Trigger 演奏推进状态机
- 连续相同和弦/拨片的重复触发逻辑
- tk0 双逻辑主旋律
- INT25 / INT26 多轨音色与音量
- “全部轨道”复选框静音/恢复
- 红线自动定位、视野滚动与回跳过滤

