# V2.3.16 C2 Shortcut Monitor Test

Purpose: verify whether the physical shortcut **hold Arpeggio Pad + flick Pick A/B** toggles the device main melody state and whether a stuck arpeggio touch explains silent tk0 melody.

## Notify selectors used

- `set_notify_param 02 0A` -> enable `noti_frets` (real-device observed)
- `set_notify_param 02 00` -> disable frets stream
- `set_notify_param 03 01` -> enable `noti_picks` (real-device observed)
- `set_notify_param 03 00` -> disable picks stream

The existing `01 0A` basic stream is left unchanged.

## Decoding

`noti_frets` accepts payload >=44 bytes and decodes:

- `[0]` key
- `[1..36]` keyboard matrix (not shown in this focused test)
- `[37] <= 240` BPM touch pressed
- `[38..43] <= 240` six arpeggio touch sensors pressed

`noti_event` decodes first two bytes as `type,value` and displays known DEX mapping:

- type 1: MAIN_TRACK_AUTO
- type 2: MIC_VOL
- type 3: DOUBLE_PICK
- type 4: BATTERY_SHOW

`noti_chord` retains `pickId` and the GUI annotates the chord event with `[ARPEGGIO_HELD: Pn]` when any arpeggio sensor is still down at that moment.

## Expected decisive trace

```text
RX noti_frets ... Pads=[...,DOWN/xxx,...]
RX noti_chord ... pickId=0 [ARPEGGIO_HELD: Pn]
RX noti_event ... type=1 value=0 [MAIN_TRACK_AUTO=OFF]
```

Repeating the shortcut should ideally produce type=1 value=1 and `MAIN_TRACK_AUTO=ON`.
