# C2 official key-trigger flow reconstructed from 2026-08-20 capture

## Reference song: 我们的时光（进阶版）

The capture session for songId `1924713742236749826` proves that official C2
playback is a staged upload plus a device-master trigger state machine. It is not
a PC timer-based playback loop.

### Start sequence

1. `set_remind_chord 09 01 00`
2. integer `06` CREATE_SHEET
3. integer `22` SET_SECTION_RANGE
4. `get_midi_info`
5. `get_config_v2basic`
6. `get_volume`
7. `set_config_v2pack` (100 bytes generated from JSON baseConfig.configPack)
8. `set_volume 09 64`, FILL1
9. `set_volume 0A 64`, FILL2
10. SET_BEAT 0, indexes `[0,0,0]`
11. `set_volume 0B 64`, FILL3
12. `set_volume 0C 64`, FILL4
13. configuration polls
14. SET_BEAT 4, indexes `[0,0,0]`
15. GET_AUTO_PLAY
16. `set_remind_chord 09 01 00`
17. FILL5
18. `set_guitar_mode 02`
19. `set_pre_level 04 01`
20. FILL6
21. SET_AUTO_PLAY `01 01`
22. FILL7
23. SET_BEAT 4
24. FILL8, FILL9, FILL10
25. integer `0x1C` data `01`
26. remaining FILL packets through FILL292

### Device-master progress

The performance window contains noti_chord beats approximately:
`4, 6, 8, 10, ...`. At a failed/repeated physical action the device can report
the same beat repeatedly. A captured example stays at beat 100 for several
notifications before advancing to 102. Therefore the PC must never synthesize
progress from wall-clock time.

### Dynamic pre-level

JSON extension type `10` maps directly to the string command `set_pre_level`.
Advanced Our Time cues are:

| JSON beat | level |
|---:|---:|
| 4 | 4 |
| 48 | 3 |
| 80 | 5 |
| 112 | 4 |
| 144 | 5 |
| 176 | 3 |
| 240 | 4 |

The capture shows the next cue is prepared about one chord block (2 beats) in
advance: after noti_chord beat 46 the app sends level 3 for beat 48, etc.

### Restart

A real restart in this session sends SET_BEAT 4 followed by `set_pre_level 04 01`.
It does not recreate the sheet or set beat 0.

## Encoder validation

After correcting the lead guide-note bit7 rule:
- advanced Our Time: 292/292 FILL payloads exact
- normal Our Time: 162/162 FILL payloads exact
- advanced CREATE and SECTION_RANGE exact
- JSON-derived `set_config_v2pack` exact 100-byte match

The special mixed lyric case at advanced beat 102 is important: the first note
is attached to a blank/stretch lyric and carries bit7, while the later note on
that same beat is attached to a visible lyric character and does not.
