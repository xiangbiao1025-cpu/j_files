# V2.3.20i1 UIProgress50

Baseline: V2.3.20i 460B WR-Pack + OversizeSplit.

Only the on-screen upload progress is throttled. The BLE transport is unchanged.

- UI shows first progress, then when another 50-FILL bucket is crossed, and final progress.
- Because MTU packing can jump logical progress, a crossing may show e.g. `54 / 469` rather than exactly `50 / 469`.
- `c2_upload_*.log` and `c2_ble.log` continue to record every progress callback.
- 460B packing, oversized-FILL item-boundary splitting, control handshakes, and 6/8 timing are unchanged.
