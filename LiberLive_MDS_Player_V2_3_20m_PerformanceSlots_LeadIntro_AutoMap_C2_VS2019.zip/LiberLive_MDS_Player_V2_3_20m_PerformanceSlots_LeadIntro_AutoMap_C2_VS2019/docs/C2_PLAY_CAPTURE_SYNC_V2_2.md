# C2 按键演奏抓包同步 — V2.2

本版以 `newtest_c2_att_decoded.csv` 的真实演奏通信为准。PC 不按 BPM 驱动 C2 连续演奏；C2 实体按键/和弦/拨片是触发源。

## 1. 抓包确认的启动流程

真实演奏会话中可见以下核心顺序：

```text
SET_SHETT_BEAT = 0
GET_AUTO_PLAY
...
set_guitar_mode 02
SET_AUTO_PLAY 01 01
set_remind_chord <root> <type> <trans12>
SET_SHETT_BEAT = 0
...
等待实体按键
A101 noti_chord -> current beat
```

因此 `SET_AUTO_PLAY 01 01` 在这个上下文中应理解为 **arm 主伴奏/按键触发引擎**。它并没有让曲谱按时间自动从 0 连续跑到结尾。

`set_remind_chord` 也不能写死：抓包中 `05 00 00` 与首个 F major 对应，另一会话的 `09 01 00` 与 A minor 对应。V2.2 从当前 JSON 第一条 chord 自动生成 `[root,type,trans12]`。

抓包中还出现 `set_pre_level 03 01` 和整数命令 `28 01`。它们的完整业务语义目前未定稿，V2.2 不凭单个样本把未知命令写死；先实现已经能够与 JSON/已知协议字段明确对应的部分。

## 2. noti_chord 10-byte 演奏结构

旧分析只使用前 6 bytes：

```text
[row][col][level][type][trans12][pickId]
```

真实曲谱演奏抓包中，本次文件的 157 条 `noti_chord` 全部为 10-byte payload：

```text
offset 0     row
offset 1     col
offset 2     level
offset 3     type
offset 4     trans12
offset 5     pickId
offset 6..9  current sheet beat (float32 little-endian)
```

样例：

```text
05 01 05 00 00 00 00 00 00 00 -> beat 0.0
05 01 05 00 00 00 62 13 00 40 -> beat ~2.0012
05 01 05 00 00 00 06 01 80 40 -> beat ~4.0002
07 01 07 00 00 00 43 A3 BF 40 -> beat ~5.9887
09 01 09 01 00 00 08 00 00 41 -> beat ~8.0000
```

## 3. GUI 同步策略

```text
A101 raw packet
  -> TLVC $A decode
  -> cmd == noti_chord
  -> parse row/col/level/type/trans12/pickId
  -> parse float32 LE currentBeat
  -> only for display: snap to nearest 1/16 beat
  -> stop PC TIMER_PLAY/MIDI preview
  -> g_positionBeat = C2 currentBeat
  -> refresh red cursor / segment / words / current JSON beat
```

C2 是按键演奏模式下的 master clock。按错键如果 C2 不推进，PC 也不会自行把红线推到下一拍。

## 4. GET_SHETT_BEAT

`GET_SHETT_BEAT (cmd 9)` 已保留在协议常量中，后续可用于诊断或 fallback。当前不需要每次按键都额外查询，因为 `noti_chord` 本身已经携带设备实际 beat。若后续发现某类动作只产生 `noti_note/noti_drum` 而没有带 beat 的 `noti_chord`，再使用 cmd 9 作为补偿。
