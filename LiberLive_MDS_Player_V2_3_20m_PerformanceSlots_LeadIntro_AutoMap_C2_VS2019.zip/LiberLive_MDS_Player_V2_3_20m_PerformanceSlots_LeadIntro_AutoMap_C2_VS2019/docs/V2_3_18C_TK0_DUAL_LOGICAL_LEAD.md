﻿# V2.3.18c tk0 双逻辑主旋律

依据官方 App《月亮代表我的心》截图：
- 前奏：主旋律01 = 小提琴
- 主歌：主旋律02 = 大钢琴
二者都属于主旋律 UI 条目；底层均由 tk0 LEAD 的分段 schedule 表达。

本版 PC UI 将 tk0 拆为两个“逻辑主旋律”行：
- 主旋律01 / Violin（匹配 tk0 的 Violin/Viola schedule 段）
- 主旋律02 / PianoStudio（匹配 tk0 的 PianoStudio schedule 段）

复选框：
- 取消主旋律01：只对 tk0 中 Violin/Viola 的 section 发送 INT26 volume=0。
- 重新勾选：只恢复这些 section 原音量，不修改 PianoStudio section。
- 主旋律02同理，只操作 PianoStudio section。
- 其它铺底/加花轨仍按各自 tkid 全段静音/恢复。

PC MIDI 预览也按当前 segment 属于哪个 tk0 音色组分别响应两个复选框。
