> V2.2 update: real performance capture corrected one V2.1 assumption. Official key-trigger play DOES send SET_AUTO_PLAY 01 01 before waiting for the physical key. The command arms the accompaniment engine; it does not make the sheet advance by time. See C2_PLAY_CAPTURE_SYNC_V2_2.md.

# C2 BLE integration V2.1

## 1. GATT

- C2 Service: `000000FF-0000-1000-8000-00805F9B34FB`
- Write characteristic: `0000A103-0000-1000-8000-00805F9B34FB`
- Notify characteristic known from reverse engineering: A101 (notification routing is not yet required by the V2.1 write pipeline)
- V2.1 uses the Windows Bluetooth LE GATT Win32 API and expects the C2 to have been paired/connected in Windows first.

## 2. TLVC

`C2Protocol` implements the captured C2 TLVC wrapper:

- App->C2 header: `24 4D`
- 12-byte IV
- XOR stream: fixed 12-byte key + IV
- CRC8 on the 16-byte header
- CRC16-CCITT on encrypted body
- integer command encoding

A fixed real-capture SET_AUTO_PLAY packet is included in `C2Protocol::SelfTest()`.

## 3. Score commands used

- `0x06` CREATE sheet
- `0x16` SET_SECTION_RANGE
- `0x0B` SET_TRACK_VOLUME
- `0x0D` SET_TRACK_INSTRUMENT
- `0x07` SET_SHETT_FILL
- `0x08` SET_SHETT_BEAT
- `0x10` SET_AUTO_PLAY

## 4. JSON -> C2 score tracks

C2 base tracks:

- tkid 0 / type 1: main melody/lead
- tkid 1 / type 2: chord
- tkid 2 / type 5: event

For JSON `trackConfigs[index]`, C2 `tkid = index + 2`.

Track type mapping currently used from the decoded official transformer:

- JSON type 1 -> C2 PAD/type 4
- JSON type 2 -> C2 SUBLEAD/type 3
- JSON type 3 -> C2 EFFECT/type 6

## 5. Pitch/timing

For notes:

`pitch = (note - originalToneLevel0) + 59 + upOctave*12`

For main melody, bit 7 is set when the Beat contains no non-empty lyric character. This rule was derived from and verified against the Ulaanbaatar capture.

Timing:

- 4/4 JSON unit = 4 JSON length units per C2 beat
- `C2 beat = globalBeat + start / unit`
- `duration = length / unit`

## 6. SET_SECTION_RANGE

V2.1 also implements the decoded 11-byte segment record:

- `segment type` u8
- `start beat` float32 LE
- `end beat` float32 LE
- `min lead pitch` u8
- `max lead pitch` u8

The payload starts with segment count u8. For 乌兰巴托的夜 this produces exactly 67 bytes and matches the real captured packet byte-for-byte.

## 7. Upload sequence

V2.1 sends:

1. SET_SHETT_CLOSE old sheet (best effort)
2. CREATE_SHEET
3. SET_SECTION_RANGE
4. track volume/tone
5. every FILL_SHEET packet
6. SET_SHEET_BEAT = 0
7. SET_AUTO_PLAY type=1 state=1 to arm the main key-trigger accompaniment engine (confirmed by later real play capture).
8. SET_SHETT_BEAT=0, then wait for physical C2 key/chord/pick trigger. This is still NOT time-driven whole-song auto play.

The UI performs this on a worker thread so the score window remains responsive.

## 8. Current known limitations

The official app sends some additional style/device configuration around uploads. In particular command 25/config-pack data is not yet fully decoded and is deliberately not fabricated in V2.1. A101 notification/ACK routing is also not yet implemented. Windows GATT write completion plus pacing is used for the first hardware verification.

Use 乌兰巴托的夜 for the first C2 test because its CREATE, SET_SECTION_RANGE, and all 171 FILL payloads are validated against an actual capture.
