# V2.3.20m PerformanceSlots / LeadIntro / AutoMap

日期：2026-09-04  
基线：V2.3.20l

## 1. “全部轨道”前 4 行演奏槽

新增 4 个虚拟 UI 行，但它们不是 Note Track，因此不加入时间轴 lane：

| 行 | JSON 来源 | C2 Mixer | 复选框行为 |
|---|---|---:|---|
| A拨片和弦 | `baseConfig.configPack.chords[pickType=0]` | `0x09` | 勾选恢复原音量；取消=0 |
| B拨片和弦 | `baseConfig.configPack.chords[pickType=1]` | `0x0A` | 同上 |
| A鼓 | `baseConfig.configPack.drums[pickType=0]` | `0x0B` | 同上 |
| B鼓 | `baseConfig.configPack.drums[pickType=1]` | `0x0C` | 同上 |

资源名称显示“中文名 / nameCode”。中文优先读取 `data/C2_Resource_Catalog.csv` 的已核对名称；未知资源保留 code。节拍和 BPM 显示曲谱运行值 `content.beat/content.tempo`，其次 `baseConfig.beat/baseConfig.bpm`；不会使用资源目录的试听/参考 BPM 替代歌曲 BPM。

音量恢复值优先级：首次取消勾选时若 C2 当前 Mixer 通道为非零值，记住该值；否则使用 JSON 的 `pickVolume`；缺字段时默认 100。未连接 C2 时复选框会恢复，不产生“已静音”的假状态。

## 2. 主旋律前奏/间奏漏显示修复

旧逻辑在“存在 extraTracks 的多轨曲”中使用 segment type 判断主旋律：type0 前奏和 type4 间奏会被隐藏，即使 JSON 的 `beat.notes[]` 实际有音符。

V2.3.20m 改为：`SegmentUsesMainMelodyAt(segmentIndex)` 只看该段 tk0 实际音符数，`SegmentTrackNoteCount(segmentIndex, 0) > 0` 即显示/播放。这样 UI、PC MIDI 和活动轨判断都与 JSON 实际数据一致。

《红日（进阶版）》回归：type0 前奏共 11 bars，实际 tk0 `beat.notes[]` 共 29 notes；歌曲 BPM=120，拍号=4/4。此前 C2 真机能演奏而 PC “全部轨道”不显示，就是这一旧条件造成的。

## 3. 2026-09-04 SET_AUTO_PLAY 映射修订

`SET_AUTO_PLAY` wire type 与 JSON `extensions.type` 是两个独立编号空间。

当前工程 UI/日志按真机差分使用：
- `01` 主自动播放/演奏模式
- `02` 鼓机自动挂挡许可
- `03` 自动转调（本次真机 `03 00 / 03 01`）
- `04` 未标定/实验保留
- `05` Solo/演奏模式相关
- `06` 聪明模式（本次真机 `06 00 / 06 01` 重复确认）

C2 多档换挡在本次会话中直接观察到 `set_pre_level 02 01` 等运行命令，暂不把某个未确认的 SET_AUTO_PLAY type 写死为“自动换挡”。

## 4. Extension 语义同步

播放器仍保留/显示完整 `extensions[]`。当前工作语义：3=鼓机运行 Cue，4=鼓相关单点/段落动作待精标，6=自动转调 Cue，7=拨片 Cue，10=Level 换挡 Cue，12=Drum Pattern/鼓资源配置，13=音色 Program 区间，14=轨道/分组自动化区间，15=高级区间/段落 Envelope 待标定。

## 5. 兼容与构建

工程维持 VS2019 / v142 / Unicode / C++17。Linux 环境只能做源代码静态检查；最终 Windows MFC/BLE 真机编译运行请在目标 VS2019 环境完成。
