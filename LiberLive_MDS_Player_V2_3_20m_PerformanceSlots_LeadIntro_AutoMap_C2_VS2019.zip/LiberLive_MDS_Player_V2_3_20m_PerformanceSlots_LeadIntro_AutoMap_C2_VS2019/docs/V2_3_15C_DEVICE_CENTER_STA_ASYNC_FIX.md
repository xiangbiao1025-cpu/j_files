# V2.3.15c Device Center STA / Async BLE Fix

## Symptom
VS2019 Debug shows:

- `Windows.Foundation.h`, around line 2941
- `Expression: !is_sta()`

while using Device Center (for example Refresh Device Info).

## Root cause
`C2BleClient::WritePacket()` and `ReadPacket()` deliberately use synchronous waits on WinRT async BLE APIs:

- `WriteValueAsync(...).get()`
- `ReadValueAsync(...).get()`

This is valid from the MTA worker threads already used by the main C2 upload/connect path, but C++/WinRT refuses a blocking `.get()` from an STA UI thread. V2.3.15b called Device Center controller functions directly inside `DeviceCenterProc/WM_COMMAND`, so a BLE operation that did not complete synchronously hit the `!is_sta()` debug assertion.

## Fix
Every Device Center BLE transaction is moved to an MTA worker:

```cpp
std::thread([] {
    winrt::init_apartment(winrt::apartment_type::multi_threaded);
    // C2 controller / BLE operations here
}).detach();
```

The UI thread only:

1. reads Edit/Combo/Checkbox values;
2. copies them into plain C++ values;
3. launches the worker;
4. receives `WM_DEVICECENTER_STATUS` / `WM_DEVICECENTER_DONE`;
5. refreshes HWND controls.

No HWND is accessed by the BLE worker.

## Covered operations
- Refresh all device info / StylePack query
- Mixer writes + get_volume verification
- set_key
- set_bpm
- set_fret_instru
- set_style_settings + verification
- apply current JSON set_config_v2pack

V2.3.15b's WM_COMMAND re-entry guard remains in place.
