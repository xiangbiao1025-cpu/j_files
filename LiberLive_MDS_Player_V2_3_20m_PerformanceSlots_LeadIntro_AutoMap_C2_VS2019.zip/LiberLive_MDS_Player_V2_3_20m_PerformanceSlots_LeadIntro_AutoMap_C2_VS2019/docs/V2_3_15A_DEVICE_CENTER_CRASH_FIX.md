# V2.3.15a Device Center Crash Fix

## Symptom
Opening Device Center under VS2019 Debug breaks inside xmemory / std::_Get_size_of_n<72>, with the call stack allocating/copying `std::_Tree_node<std::pair<std::string const,std::wstring>>`.

## Fix
1. Replace `C2DeviceState::rawReplies` (`std::map`) with bounded `std::wstring rawRepliesText`.
2. Do not build/copy the full device snapshot inside `WM_CREATE`; post `WM_DEVICECENTER_INIT` and refresh after CreateWindowEx returns.
3. Make all remaining `std::max/std::min` calls explicit-template calls for VS2019.

## Scope
No CREATE/FILL/INT25 upload protocol changes. Device Center controls from V2.3.15 are retained.
