# V2.3.13 主旋律音量 + 设备 Beat 权威同步

## 修正 1：主旋律 tk0 不再依赖 set_pre_lead
官方成功 btsnoop 的曲谱主旋律由 CREATE/FILL 的 tk0 音符和 INT25/INT26 的 section/音色/值/区间调度组成。V2.3.13 删除上传完成、重新待按键、从红线定位后的自动 set_pre_lead。三个“旋律开/Auto/关”按钮保留，仅作为协议实验。

## 修正 2：启动时诊断并修复 ch05 主旋律音量
读取 get_volume，解析 count+(channel,value)。已知 ch01=总音量、ch05=主旋律、ch0D=琶音。若固件回包存在 ch05 且不是 100，则发送 set_volume 05 64，再次 get_volume 复核。

## 修正 3：通用 3 轨 INT25 前移
有 configV2Pack 的三轨通用路径改为：vol09 -> INT25 -> vol0A/F0 -> vol0B/F1 -> SET_BEAT0 -> vol0C/F2。避免 tk0 LEAD FILL 早于 section/tk0 schedule。

## 修正 4：红线只认 C2 已推进的 sheet beat
noti_chord 10B 的最后 4B float beat 是设备实际位置。beat 未变时红线不走；beat 已增加时立即接受，PC 本地和弦 root/type/trans 判断只记日志，不再否决设备已经推进的事实。

## 修正 5：6B noti_chord 查询合并
旧固件/状态只回 6B noti_chord 时仍通过 GET_SHEET_BEAT/A102。若查询正在进行，新触发设置 pending，当前查询结束后立即再查一次，不再直接丢弃。

## 修正 6：红线优先绘制
收到设备新 beat 后先 UpdateProgress + InvalidateTimeline + UpdateWindow，再刷新详情框；日志附带 BLE->UI=xx ms。
