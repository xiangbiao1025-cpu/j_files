# C2Controller.cpp CP_UTF8 compile fix

VS2019 errors C2065 CP_UTF8 and C3861 MultiByteToWideChar were caused by C2Controller.cpp using Win32 UTF-8 conversion APIs without including windows.h.

Fix:
```cpp
#include <windows.h>
```

No BLE/protocol behavior changed.
