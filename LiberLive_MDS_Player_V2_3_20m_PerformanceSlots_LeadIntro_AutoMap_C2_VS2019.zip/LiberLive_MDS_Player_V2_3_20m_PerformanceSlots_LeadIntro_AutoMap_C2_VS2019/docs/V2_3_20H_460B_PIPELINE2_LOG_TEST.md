﻿# V2.3.20h 460B + Pipeline2 + LOG TEST

基线：V2.3.20g 460B FILL Pack TEST；其 460B FILL 已由用户实机确认可正常上传并完整弹完。

## 本版只测试 Windows WNR 提交流水
- 460B FILL 合包算法不改。
- 6/8 MeterTimingFix 不改。
- 通用连续 FILL 尾段最多保留 2 个 `WriteValueAsync(..., WriteWithoutResponse)` 在途。
- 提交第 3 包前只等待最老的一包完成。Pipeline2 活跃时不再额外 Sleep。
- `BeginWritePacket` 若在真正提交前失败：先排空已提交窗口，之后安全退回串行 18ms。
- 已提交异步写若完成失败：不盲目重发，因为无法证明 C2 是否已经消费该帧；为避免重复 FILL/乱序，停止上传并记录错误。
- CREATE/GET/Verify/Notify29/SET_BEAT/Track 控制保持同步握手。
- INT25 本版保持原有发送，不加入 Pipeline2，避免同时改变两个变量。

## 日志
运行时自动建立：
- `EXE\logs\c2_ble.log`：跨运行滚动日志。
- `EXE\logs\c2_upload_YYYYMMDD_HHMMSS_mmm.log`：每次“上传到 C2 / 上传并待按键”单独文件。

每个上传日志包含：
- MaxPduSize / A103 WNR
- FILL 尾段预计物理写次数
- 前 4 次 Pipeline2 submit / complete 以及每 16 次完成采样
- GUI 上传进度
- 最终：total、bulkWrites、packedWrites、pipeSubmitted、pipeCompleted、pipePeak、pipeBeginCall、pipeWaitCall、pipeLatencySum、pipeMaxWait、失败/回退。

## 判读
如果 `pipeBeginCall` 很小而 `pipeWaitCall` 较大，但总时间明显下降，说明旧瓶颈主要是每包立即 `.get()`。
如果 `pipeBeginCall` 本身就很大，说明 Windows GATT API 在 Begin 阶段已经串行化，Pipeline2 收益会有限。
如果 `pipePeak=2` 且 `pipeWaitCall` 很小、总时间仍慢，下一瓶颈更可能在 BLE 空口/控制器而不是应用层等待。
