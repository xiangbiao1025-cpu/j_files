# V2.3.20j evidence notes

## Pick transport
This is an intentional playback-UX change requested from real-device behavior: C2 can continue when the score cue changes A/B but the performer uses the other pick. The PC transport therefore gates on the expected chord/key, not pick direction. A/B/A+B remain visible and logged.

## Drum cues
JSON extension `type=12` is rendered in the cue lane and beat details. `switchType=1` is labeled `启动鼓`; `switchType=0` is labeled `关闭鼓`. This release only changes visualization; it does not change C2MusicEncoder event packing.

## Style settings
`get_style_settings` is parsed as `[count][type][value]...`. APK source exposes semantic StyleSettingType names `STAR_A`, `STAR_B`, `PREVIEW_C`, `PREVIEW_D`, `A-BASS`, `BPMLOCK`, `PREV_BPMLOCK`. Exact semantic-name to raw wire-number binding is not forced in this build, so Device Center shows Raw1..Raw6 plus the semantic legend.

## AUTO_PLAY
GET_AUTO_PLAY is int command 0x0F and SET_AUTO_PLAY is int command 0x10. SET payload is `[type][state]` (state 0/1). Device Center reads raw type 1..6 and exposes on/off buttons for each. Evidence-supported labels are used for T1/T3/T4/T5/T6; T2 remains qualified.
