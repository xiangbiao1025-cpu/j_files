# V2.3.20k PlayPrefsFix

本版直接基于 V2.3.20j PlaybackUI 修改，目标是完善实体演奏推进与设备中心的“演奏偏好 / Auto Play”测试界面；不修改 V2.3.20j 已保留的 BLE 上传链、460B WR-Pack、超大 FILL 拆分、UIProgress50、6/8 MeterTimingFix、启动/关闭鼓标记和曲谱轨道 INT26 编辑逻辑。

## 1. 实体演奏：同根和弦即可推进

V2.3.20j 已取消 A/B/A+B 拨片方向作为推进硬条件，但仍把 Major/Minor 作为硬条件，因此 F -> Fm 时如果继续保持同一个 F 实体按键，C2 可以继续演奏，而 PC 红线会卡住。

V2.3.20k 的硬门槛只保留“和弦根音/实体按键”匹配：

- F 与 Fm：根音都为 F，允许推进。
- A 与 Am：根音都为 A，允许推进。
- A/B/A+B 拨片方向继续只作提示，不阻塞推进。
- type / Major-Minor / trans12 仍保留在日志诊断中，但不再作为红线推进否决条件。

因此 `ValidateC2ChordRootGateAt()` 只比较 expected root 与 C2 `event.level`；完整 type/trans 检查仍由 `ValidateC2ChordTriggerAt()` 生成诊断文本。

## 2. 演奏偏好 / Style Settings

原“风格配置 Type1~Type6”改名为“演奏偏好 / Style Settings”。

APK 侧已明确存在：

- `PICKSLOT_SET_STAR_A`
- `PICKSLOT_SET_STAR_B`
- `PICKSLOT_SET_PREVIEW_C`
- `PICKSLOT_SET_PREVIEW_D`
- `PICKSLOT_SET_ABASS_EN`
- `PICKSLOT_SET_BPMLOCK`
- `PICKSLOT_SET_PREV_BPMLOCK`

其中 BPM 锁定的调用路径已确认：`BpmLockFragment` 构造 `StyleSettingChildBean(PICKSLOT_SET_BPMLOCK, 0/1)` -> `setStyleSetting2()` -> `set_style_settings`。

但 enum 语义与实际 wire type 数字仍未逐项闭环，因此 20k 不把候选编号伪装成“已确认”。UI 显示候选语义，同时使用数值 EDIT 保留 raw value；空白表示不写。这样 `get_style_settings` 中出现的 2/3 等非 boolean 值不会再被 checkbox 强制压成 0/1。

当前测试标签：

- T1：A细节增强 [候选]
- T2：B细节增强 [候选]
- T3：PREVIEW_C
- T4：PREVIEW_D
- T5：ABASS_EN
- T6：BPM锁定 [wire编号待验]
- T7：试听BPM锁定 [wire编号待验]

## 3. SET_AUTO_PLAY 0x10：按功能显示，不再把 UI 序号当 wire type

官方 `AutoPlayType` 顺序按当前开发依据：

- 1 `AUTO_PLAY_MAIN`
- 2 `AUTO_PLAY_NONE`
- 3 `AUTO_PLAY_DRUM`
- 4 `AUTO_PLAY_KEY`
- 5 `APLAY_TYPE_SOLO`
- 6 `APLAY_TYPE_STYLE_LEVEL`
- 7 `APLAY_TYPE_SMART`

结合 C2 真机测试，设备中心改成以下功能按钮：

| UI 功能 | SET_AUTO_PLAY payload |
|---|---|
| 主旋律输出 | `01 00 / 01 01` |
| 自动鼓机 | `03 00 / 03 01` |
| 自动转调 | `04 00 / 04 01` |
| Solo/演奏模式 | `05 00 / 05 01` |
| 自动换挡 | `06 00 / 06 01` |
| Smart 模式（待继续确认） | `07 00 / 07 01` |

`02=AUTO_PLAY_NONE` 不再显示成一个独立功能按钮。

特别注意：播放器中的第二个功能项“自动鼓机”发送的是协议 `03 00/01`，不是 `02 xx`。

主旋律的真机依赖也直接显示在 UI：

- type05=0 时：`01 00` 关主旋律，`01 01` 开主旋律。
- type05=1 时：实测不论 `01 00` 还是 `01 01`，主旋律都无声。

## 4. 未修改范围

以下核心文件/逻辑不因本版功能改动而重写：

- `C2MusicEncoder.cpp`
- `MDSParser.cpp`
- `PlayerCore.cpp`
- `C2BleClient.cpp`
- 460B WR-Pack / OversizeSplit
- UIProgress50
- 6/8 MeterTimingFix
- type=12 启动鼓/关闭鼓时间轴标识
- 曲谱轨道 INT26 音色/音量编辑

## 5. 建议真机测试

1. 找到连续 F -> Fm 或 Fm -> F 的位置，全程保持同一个 F 实体按键，A/B 任意拨片，确认红线继续推进。
2. 设备中心刷新后记录 Style Settings T1~T7 raw 值；逐项只改一个值，回读并观察 APK 页面变化，用于闭环 enum↔wire 映射。
3. Auto Play 第二个功能项“自动鼓机”分别点关/开，确认日志必须是 `03 00 / 03 01`。
4. 验证主旋律依赖：type05=0 时测试 type01 关/开；再把 type05=1，确认 type01 两种状态均无主旋律。
