# V2.3.9 红线定位播放 + BLE 快速连接

## 1. 红线可以移动

时间线内按下鼠标并左右拖动红线；释放时停在 1/4 beat 网格。底部进度条、谱段双击也会更新同一个红线位置。PC MIDI 的“播放”本来就按当前 `g_positionBeat` 开始，本版保留该行为。

## 2. C2 从红线开始

新增 C2 操作“从红线待按键”。曲谱已经上传后，程序按红线 beat 重新构造 `SET_SHEET_BEAT`，随后通过 A102 `GET_SHEET_BEAT` 校验设备是否真正接受该位置。

“上传并待按键”有兼容策略：
- 用户没有移动红线：继续使用 V2.3.8a 真机已验证的首个可演奏 beat 上传/arm 流程。
- 用户已移动红线：先完成原有上传流程，再执行一次红线定位。

### 2.1 为什么不能只改 float beat

官方 3.7.6 DEX `C2MusicCmdDataTransformer.findPosition(beatNo)` 明确不是只发送目标 beat。它对每个 C2 track 找到第一个 `item.beat >= beatNo` 的条目，取该条目的 `noteid`，再构造 `CmdMusicPositionBean(beat, trackCount, noteIndexes)`。`MusicSenderV2.setRemindNotes()` 随后调用 `setRemindNotesV2(positionBean)`。

因此 V2.3.9 在编码阶段建立 `positionTables`：

```text
tkid -> [(itemBeat, noteIndex), ...]
```

红线跳转时，对每条 CREATE descriptor 计算对应 noteIndex，然后构造：

```text
float32 beat
u8 trackCount
u16 noteIndex[trackCount]
```

若某轨在目标位置之后没有条目，按 DEX 的 fallback 使用 noteIndex=0。

## 3. BLE 快速连接

V2.3.8a 首次连接路径存在固定长等待：主动扫描后再进行 uncached GATT 枚举。V2.3.9 改为两级路径：

1. **快速重连**：记住上一次成功 C2 的 Bluetooth address 到 `c2_last_device.txt`，下次直接 `FromBluetoothAddressAsync()`。
2. **扫描 fallback**：缓存地址不可用时主动扫描，发现 Service `000000FF` 后提前结束；最长扫描约 5 秒。

GATT Service/A101/A102/A103 先读取 Windows Cached 表；找不到或失败时才回退 Uncached，以兼容首次连接和固件变化。

## 4. 断开蓝牙

新增“断开蓝牙”按钮，只关闭 PC 侧 Notify/GATT/Device 对象。它**不假设** C2 已经清除 resident sheet，所以 `deviceSheetResident_` 保留；重新连接后若再次上传，仍会先执行 V2.3.8a 已验证的 CrossSongReset，避免第二首 WAIT 状态回归。

## 5. 建议真机测试

1. 连接 C2，观察首次连接耗时。断开后立即重连一次，第二次应优先看到“快速重连：先尝试上次设备”。
2. 打开任意成功曲谱，上传并待按键，正常推进几次。
3. 在时间线拖红线到中段，例如 beat 50 左右，点击“从红线待按键”；日志应显示目标 beat、trackCount，并由 A102 确认同一 beat。
4. 实体触发，第一条/后续 `noti_chord` 的 authoritative beat 应从红线附近继续，而不是回到开头。
5. 再换第二首并上传，确认 V2.3.8a CrossSongReset 仍生效。

## 6. 本地静态自检

在 Linux/g++ 对可移植编码器执行 `-std=c++17 -Wall -Wextra -Werror` 编译通过。使用项目内《乌兰巴托的夜（进阶版）》和《我们的时光》JSON 建立位置表并生成多个 beat 的 SET_SHEET_BEAT payload，payload 长度分别与 11-track/3-track 结构一致。Windows C++/WinRT BLE 与 Win32 GUI 最终仍需 VS2019 + 真机验收。
