# V2.3.20a get_config_basic active-read fix

- Fixes Device Center A/B chord/drum four-slot readback error `A102 回包不是期望命令 get_config_basic`.
- `get_config_basic` is treated as an active-read query: write request, wait ~250 ms, then read A102.
- A102 can temporarily retain the previous reply, so polling is extended.
- For `get_config_basic` only, a reply is also accepted by payload structure when four valid style resource codes are present, even if the returned string label differs.
- Single-slot `set_chord_basic` / `set_drums_basic` still writes the exact factory payload, then performs the same proven `get_config_basic` readback verification.
- Other V2.3.20 strict-trigger and multitrack logic is unchanged.
