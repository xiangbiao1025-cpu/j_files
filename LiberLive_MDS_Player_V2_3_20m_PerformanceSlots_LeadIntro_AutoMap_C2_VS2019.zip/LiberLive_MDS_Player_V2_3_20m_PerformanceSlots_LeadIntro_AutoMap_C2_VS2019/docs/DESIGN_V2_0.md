# LiberLive MDS Player V2.0

## Stop semantics
`Stop` halts transport and MIDI output but preserves `g_positionBeat`. Rewind is no longer implied by Stop.

## JSON source mapping
`jsonlite::Value` stores `sourceStart/sourceEnd` for every parsed value. `CMDSParser` copies the exact source range of each beat object into `MDSBeat`, together with array indices and line range. UTF-8 BOM length is added back so displayed offsets are physical file byte offsets.

The current-position pane displays:
- content.lyrics[segment].bars[barArray].beats[beatArray]
- bar and beat field values
- decimal/hex byte offsets
- line range
- original beat JSON object

## Melody scheduling
Every `MDSNote` in `beat.notes[]` becomes one `MDSScheduledNote`; `stretch` is retained as metadata but never filters scheduling.

When a same channel/pitch onset occurs while an older voice is still active, the older voice is explicitly stopped immediately before the new Note-On. This gives deterministic repeated-note articulation and prevents an old future Note-Off from terminating the newly-triggered voice.

On resume from a stopped position, sustained notes crossing the current position are restored before transport advances.
