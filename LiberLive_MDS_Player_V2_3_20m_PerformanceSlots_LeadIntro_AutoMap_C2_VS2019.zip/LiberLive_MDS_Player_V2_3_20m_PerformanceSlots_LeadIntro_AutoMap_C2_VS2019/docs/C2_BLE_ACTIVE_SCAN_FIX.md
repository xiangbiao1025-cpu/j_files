# C2 BLE Active Scan Fix

This build replaces the old SetupDi / BluetoothGATTGetServices cached-service-interface connection path with the exact connection strategy used by the verified-working C2PcController VS2019 v5.1 project:

1. BluetoothLEAdvertisementWatcher active scan
2. Prefer advertisements containing Service UUID 000000FF
3. Connect with BluetoothLEDevice::FromBluetoothAddressAsync(address)
4. Uncached GATT lookup for service 000000FF
5. Uncached characteristic lookup: A101 Notify / A102 Read / A103 Write
6. Enable A101 Notify
7. Write C2 TLVC packets through A103 using GattWriteOption::WriteWithoutResponse

No Windows pairing/GATT device-interface enumeration is required for discovery.

VS2019 settings are aligned to the working reference project:
- Windows 10 SDK 10.0.19041.0
- C++17
- windowsapp.lib
- /Zc:twoPhase-
- ConformanceMode=false

Before testing, disconnect the official phone app and other BLE tools from C2.
