﻿# V2.3.18b Dual Lead + Track Checkbox

- 双主旋律曲（例如月亮代表我的心）不再把 PianoStudio 与 type13 Violin 合并成一个显示。
- 主旋律01：设备基础 lead（通常 PianoStudio）；主旋律02：INT25/26 tk0 调度 lead（例如 Violin）。
- 全部轨道复选框默认全部勾选。
- 取消：C2 真机对应轨全部段音量写 0。
- 重勾：恢复第一次静音前保存的运行时音量。
- 主旋律01 基础 lead 使用 mixer ch05 静音/恢复；主旋律02 与其它调度轨使用 INT26 全段 patch。
- PC MIDI 试听也同步受复选框控制。
