# V2.3.18 MultiTrack INT26 Test

## 目标
验证每条 MDS/C2 schedule 轨道可以独立修改音色和音量，并明确区分设备全局旋律音色与曲谱 tk0 主旋律。

## UI
设备中心分两层：
- 设备全局旋律音色：`set_fret_instru + set_lead_preview + get_config_v2basic`，对应设备页/试听状态。
- 当前曲谱轨道编辑器：选择 tkid，使用 `INT26 / 0x1A / SET_AMEND_TRACK` 修改驻留 sheet。

## 主旋律关闭
选择 tk0，volume=0，应用全部段：所有含 tk0 的 schedule section 都写入 0。此操作是曲谱层静音。
`MAIN_TRACK_AUTO` 则是实体快捷键产生的运行状态，两者应分别观察。

## 多轨测试矩阵
1. tk0 LEAD：换音色 + 改音量。换音色应看到 set_lead_preview + INT26。
2. PAD：换音色 + 改音量。应只针对该 tkid 发 INT26。
3. SUBLEAD：同上。
4. 任一轨只改 volume：不应额外发送主旋律 preview。
5. 当前段：只修改 GET_SHEET_BEAT 所在 section。
6. 全部段：修改所有包含该 tkid 的 section。

## 回传日志重点
请保留 `c2_ble.log` 中每次操作前后约 3~5 秒，重点看：trackId、section count、page count、card:tone、volume、是否出现 set_lead_preview。
