# V2.3.20i 460B WR-Pack + OversizeSplit TEST

## Evidence from V2.3.20h real-device logs

- Windows reports A103 `WriteWithoutResponse=NO`, `WriteWithResponse=YES`.
- `GattSession MaxPduSize=500`, so ATT value budget is 497 bytes.
- V2.3.20h mistakenly gated MTU FILL batching on WNR, therefore `动态MTU合包=OFF` and `Pipeline2=OFF` on the user's PC.
- Successful 287-FILL run spent about 15.16 s inside serial WriteValueAsync waits.
- Successful 552-FILL run spent about 31.51 s inside serial WriteValueAsync waits.
- A dense 367-FILL song contains original FILL data up to 517 B and V2.3.20h aborted at logical 52 with packet=514 B > ATT 497 B.

## V2.3.20i changes

1. 460B FILL batching no longer depends on WNR. If MTU/PDU is sufficient, adjacent generated FILL payloads are greedily merged up to 460 B even when Windows uses WriteWithResponse.
2. Pipeline2 still requires true WNR. On the current Windows stack it remains OFF by design.
3. One original FILL larger than the 460B data budget is decoded and split at item boundaries into multiple legal FILL payloads <=460 B. Item bytes/order/absolute beat/duration are unchanged.
4. First-stage control ordering, CREATE/GET/Verify/Notify29/SET_BEAT, INT25 pagination, and 6/8 MeterTimingFix are unchanged.
5. Per-upload logging remains enabled and adds `splitOriginals` / `splitWrites` statistics.

Expected log on the current PC:

```
A103 WNR=NO, MaxPduSize=500
FILL尾段：动态MTU合包=ON，Pipeline2=OFF
FILL尾段预计：... 聚合写>0 ...
...
V2.3.20i ... packedWrites>0 ... splitOriginals=...
```

This environment cannot run VS2019 + Windows BLE + physical C2, so real-device validation is required on the target PC.
