# C2 key-trigger play correction — superseded by V2.2 capture analysis

The musical behavior is still **key-triggered**, not time-driven auto play.

However, the earlier V2.1 statement “do not send SET_AUTO_PLAY 01 01” was corrected after inspecting the real performance capture `newtest_c2_att_decoded.csv`.

The capture proves the official flow does send:

```
SET_AUTO_PLAY 01 01
SET_SHETT_BEAT 0
(wait for physical C2 key)
A101 noti_chord beat=0
(wait for next physical key)
A101 noti_chord beat≈2
...
```

Therefore `AUTO_PLAY_MAIN` is treated in V2.2 as an **enable/arm switch for the main key-trigger accompaniment engine**, not as permission for the PC to time-drive the whole song.

See `C2_PLAY_CAPTURE_SYNC_V2_2.md`.
