﻿# V2.3.20d — 6/8 meter/timing fix

## Reproduction: 《同桌的你》

Source JSON states `beat="6/8"`, `tempo=92`, contains 113 bars × 6 beat cells = 678 score beats.
Each half-bar chord is `length=6`; common melody/word durations are `length=2`.

LiberLive raw timing unit follows `unit = 16 / denominator`:
- 4/4: unit=4 raw units per quarter-note score beat.
- 6/8: unit=2 raw units per eighth-note score beat.

V2.3.20c incorrectly hard-coded `/4.0` in the PC model/UI. For 6/8 this made:
- chord length 6 => 1.5 displayed beats instead of 3, leaving false blank gaps;
- word/note length 2 => 0.5 displayed beat instead of 1;
- PC transport treat each eighth-note JSON beat as a quarter note, making 678 beats at BPM92 about 442 s instead of about 221 s.

V2.3.20d uses meter-aware conversions in PlayerCore and App. BPM is treated as quarter-note BPM; x/8 therefore advances `denominator/4 = 2` score beats per quarter.

The C2 encoder already used `BeatLengthUnit(beat)=16/denominator` for FILL item timing. Its CREATE `bnum` mapping is intentionally not changed here: 4/4=>1 is captured; 6/8=>2 remains experimental in the current protocol evidence.
