# V2.3.11 — Chord Check + base-score Lead INT25

## 1. C2 演奏推进

DEX `MusicPlayV2Activity` 的顺序是：取得当前 `horizontalView.getCurrentChordLre().getName()` -> `ChordUtils.chordCheck(entity,currentChord,isStart)` -> 只有 pass 后才 `onPlayProgress(true)` / `drumSendChords()`。

本版 PC 端按同一状态机：

- 红线正在当前和弦节内滑动时，任何重复/提前拨弦不重启、不跳段。
- 到达下一和弦节边界后，只接受当前曲谱目标根音/major-minor + A/B pick。
- 上一和弦继续按住时，即使再次拨 A/B，只要与下一目标和弦不同就显示 `CHORD FAIL`，红线不动。
- `GET_SHEET_BEAT` / A102 只允许确认一条刚刚已经通过和弦验证的 legacy 6-byte noti_chord；裸 beat 回包不能推进。

## 2. 单主旋律 C2 无声根因

V2.3.10 已正确把 `beat.notes` 显示为前奏开始的主旋律，但 `BuildGenericInt25()` 原先只有 `melodicNote` 非空或 type14/extraTrack 时才生成 tk0 调度。大量 `01_mds_base` / `02_mds_multilevel_style` 的 `melodicNote=null`，因此 CREATE/FILL 有 LEAD notes，但 C2 没有 tk0 的运行时音色/区间 INT25。

V2.3.11 改为：

1. 实际存在任何 `beat.notes` 即认为存在 tk0 LEAD。
2. `melodicNote` 为空时，优先取 extension type13 中首个 C2 资源（`sound_c2:*` / `scard_*`）作为默认主旋律音色。
3. 再没有则使用 `sound_c2:PianoStudio`。
4. 没有 type14 权威 mute/volume 调度时，为每个自然 section 建 tk0 INT25 range，默认 volume=80。
5. type14 存在时仍保持原有权威调度逻辑，不改变已验证的多轨曲。

《虫儿飞（进阶版）》正好是典型样本：`melodicNote=null`、无 extra track，但有 `beat.notes`，且 type13 给出 `sound_c2:PianoStudio`。
