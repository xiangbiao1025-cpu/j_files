# V2.3.20l DrumCue / MasterBPM / PerTrackMIDI

基线：`LiberLive_MDS_Player_V2_3_20k_PlayPrefsFix_C2_VS2019`

本版依据 2026-09-04 提供的《红日（进阶版）》官方 APK 截图、下载 JSON 以及 `btsnoop_hci红日下载及演奏和鼓机设置` 真机 BLE 日志修正四项行为。

## 1. 主屏幕拨片 / A鼓 / B鼓 / 关鼓机提示

《红日》开头 JSON 与 APK 截图可逐拍对齐：

| 绝对 beat | 和弦 | JSON extension | 主屏幕提示 |
|---:|---|---|---|
| 0.0 | G (5) | type7, pickType=0 | 用A拨片 |
| 2.0 | G (5) | type3, switchType=1, pick=1, position=2 | 进B鼓 |
| 4.0 | C (1) | type3, switchType=1, pick=1, position=3 | 进B鼓 |
| 4.5 | C (1) | type3, switchType=0, pick=0, position=5 | 关鼓机 |
| 6.0 | G/B (5/7) | type3, switchType=1, pick=1, position=3 | 进B鼓 |
| 6.5 | G/B (5/7) | type3, switchType=0, pick=0, position=5 | 关鼓机 |

因此当前 UI 映射定为：

- type7 `pickType=0/1/2` -> `用A拨片 / 用B拨片 / 用A+B拨片`
- type3 `switchType=1,pick=0` -> `进A鼓`
- type3 `switchType=1,pick=1` -> `进B鼓`
- type3 `switchType=1,pick=2` -> `进A+B鼓`
- type3 `switchType=0` -> `关鼓机`
- type12 仍保留为旧格式/显式鼓段落提示，不与上述 type3 映射互斥。

为了复现 APK 同一和弦块内“进B鼓 + 关鼓机”的显示，提示区由 30px 加高到 46px，并采用两行避让。

## 2. SET_AUTO_PLAY 03 00 / 03 01 的正确语义

本次真机日志进一步说明 `SET_AUTO_PLAY type=3` 不是鼓机硬静音：

- 44451.905：GET_AUTO_PLAY
- 44451.948：返回 `{1=1,2=1,3=0,4=0,5=0,6=1}`，即 type3=0
- 随后 44581.832 / 44582.237 / 44583.468 仍出现 `noti_drum`
- 第二段会话 45767.281 再次读回 type3=0，随后 45779.071 / 45779.521 仍有 `noti_drum`
- 45789.302 才看到 `SET_AUTO_PLAY 03 01`

所以本版统一命名为“鼓机自动挂挡许可”：

- `03 00`：不允许鼓机自动挂挡；不是硬关鼓，JSON 显式 A/B 鼓事件仍可执行。
- `03 01`：允许演奏时依据曲谱鼓事件进行自动挂挡。

这与主时间轴 type3 的“进A鼓/进B鼓/关鼓机”是两个层次，不能混为一条命令。

## 3. 主 BPM 与资源试听 BPM 分离

《红日》JSON：

- `tempo=120`
- `baseConfig.bpm=120`
- `beat=4/4`
- A拨片 `GS_6`
- B拨片 `GED1_3`
- A鼓 `Metal_Chapman_4`
- B鼓 `METAL_Fender_1`

官方日志 44451.351 的 `set_config_v2pack` 头部为 `00 78 04`，其中 `0x78=120`。四个运行槽内也使用 120 的运行拍速。资源目录中保存的 BPM/拍号因此只作为资源试听/参考数据，不能在选择资源时反向覆盖曲谱主 BPM。

本版规则：

1. 打开 JSON 时，主 BPM 优先使用根 `tempo`，其次 `baseConfig.bpm`。
2. 设备中心选择 A/B 拨片或 A/B 鼓资源时，资源目录 BPM/拍号只显示为“试听/参考 BPM/拍号”。
3. `set_chord_v2basic / set_drums_v2basic` 的运行 BPM 使用当前主谱 BPM（有谱时）或当前设备 BPM（无谱时），不会采用资源目录试听 BPM。
4. 多轨 `SET_TRACK_INS / INT26` 修改音色/音量不调用 `set_bpm`，因此不改变主谱 BPM。

## 4. PC 本地“播放”按 JSON 轨道音色

20k 原实现打开 Windows MIDI Mapper 后，把全部非鼓 MIDI channel 统一 Program Change 为 0（Acoustic Grand Piano），所以即使 JSON 轨道定义 Organ / EGsolo / Bell，PC 预览仍全部听成钢琴。

20l 改为每个 scheduled note 播放前，根据 JSON 音轨选择 GM Program：

- 主旋律：`melodicNote`，并允许活动的 type13/type14 音色事件覆盖。
- extraTrack：优先 `trackConfigs[index].assetNotes[0].noteCode`，其次 `noteCode/name`。
- 轨道音量：使用 `trackConfigs[].volume` 映射 MIDI CC7。
- 只做 PC 预览映射，不改写 JSON，也不改变 C2 音色定义。

《红日》对应：

| JSON轨 | 定义音色 | JSON Vol | PC GM近似 |
|---|---|---:|---|
| 主旋律 | PianoStudio | 100 | Acoustic Grand Piano (0) |
| extra index1 / PA | PianoStudio | 61 | Acoustic Grand Piano (0) |
| extra index2 / Organ | Organ | 49 | Drawbar Organ (16) |
| extra index3 / DSGT | EGsolo1 | 82 | Overdriven Guitar (29) |
| extra index4 / Bells | SummerBell | 61 | Tubular Bells (14) |

注意：Windows MIDI Mapper 是 General MIDI，无法 1:1 复刻 C2 的 `sound_c2/scard_01` 专有采样；本版目标是“按轨道使用不同、最接近的音色”，而不是让所有轨都退化成钢琴。

## 5. 本版修改文件

- `src/App.cpp`
  - type7/type3 主时间轴提示
  - 两行 cue lane
  - 主 BPM / 资源试听 BPM UI 分离
  - PC MIDI 每轨 Program/CC7
- `src/C2Controller.cpp`
  - A/B资源写入时的运行 BPM 语义说明
  - SET_AUTO_PLAY type3 状态日志明确“自动挂挡许可”
- `include/C2Controller.h`
  - type3 AutoPlay 语义修正
- `README.txt`
  - 版本说明

附件解析摘要：`docs/RED_SUN_BTSNOOP_KEY_EVENTS_20260904.tsv`
JSON 时间轴映射：`docs/RED_SUN_JSON_CUE_MAP_20260904.tsv`
