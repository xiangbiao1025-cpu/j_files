# C2 V2.3.6 — 乌兰巴托的夜 / 我们的时光 真机抓包校正版

## 1. 本版目的
本版以用户 2026-08-21 上传的《乌兰巴托的夜（进阶版）》真实 btsnoop 为最高优先级基准，修复：
1. 红线能走但 LEAD / PAD / SUBLEAD 不发声；
2. 播放乌兰巴托后再载入《我们的时光》，实体按键后红线不推进；
3. V2.3.4a 对多轨只补 SET_TRACK_INS / SET_TRACK_VOLUME，仍未复现官方完整多轨事务的问题。

## 2. 新抓包的决定性结论
### 2.1 官方乌兰巴托是 11 轨，不是 10 轨
官方 CREATE：songId=1924380410093330434，key=3，capture BPM=84，bnum=1，tknum=11。

| tkid | type | 含义 | count | maxBeat | 音色/配置 |
|---:|---:|---|---:|---:|---|
|0|1|LEAD|234|180|主旋律|
|1|2|CHORD|94|180|和弦|
|2|5|EVENT|9|164|事件|
|3|3|SUBLEAD|16|180|SummerBell|
|4|4|PAD|101|100|PianoStudio|
|5|4|PAD|304|180|PerfectPad|
|6|4|PAD|10|19.945833|Pad2|
|7|3|SUBLEAD|98|180|EGsolo2|
|8|3|SUBLEAD|44|180|Key2|
|9|3|SUBLEAD|55|163|Guzheng|
|10|3|SUBLEAD|679|180|EGsolo2，官方生成/隐藏轨|

当前数据库 JSON 的 trackConfigs 只能直接解释 tk3..tk9，因此以前通用 encoder 得到 10 轨。tk10 是官方流程里真实存在、但当前 JSON 快照无法直接重建的生成轨。

### 2.2 官方 FILL 为 175 包
旧 PC 通用编码只有 171 FILL。新抓包官方会话为 175 包；因此即使补足轨音色/音量，少了官方生成轨对应的 Note/FILL 仍不可能完整发声。

### 2.3 INT25 / 0x19 是多轨正式事务
乌兰巴托官方发送 8 个 int25 页面：7×469B + 1×25B；page body 总长 3212B。
头部结构在本抓包中稳定为：
- byte0 pageCount=8
- byte1..4 totalBodyLen=3212 LE
- byte5 pageIndex=0..7
- byte6..9 pageDataLen（457，末页13）LE
- byte10..11 reserved=0
- byte12.. page data

页面内容直接包含 sound_c2 / scard_01 音色字符串及大量 float beat 区间，因此不能再当作可选 ACK。官方名称仍未知，代码继续保守称 INT25_CAPTURE_BLOCK。

### 2.4 官方轨设置
官方依次设置 tk3..tk10 的音色和音量。关键值：
- tk3 SummerBell / 72
- tk4 PianoStudio / 64
- tk5 PerfectPad / 25
- tk6 Pad2 / 15
- tk7 EGsolo2 / 58
- tk8 Key2 / 36
- tk9 Guzheng / 43
- tk10 EGsolo2 / 50

注意这些是本次实际播放状态，不完全等于 JSON 中原始 volume；PC 不应简单把 JSON volume 原值照搬成最终 runtime volume。

## 3. 跨歌曲状态污染
乌兰巴托官方 GET_AUTO_PLAY 返回：type1=1, type2=1, type3=0, type4=0, type5=1, type6=0。
《我们的时光（进阶版）》及普通版的成功抓包均要求 type2=0。

V2.3.4a 为多轨尝试打开 type2 后，切歌时没有可靠恢复，可能让下一首《我们的时光》仍处于乌兰巴托的调度状态，造成 C2 transport/实体按键状态异常，表现为红线不推进。

V2.3.6 对每个已确认 profile 显式规范化：
- Ulaan Advanced：type2=1；使用 11-track/175-FILL/8-page INT25 精确 profile。
- Our Time Advanced：进入 CREATE 前先 type2=0，并按 292-FILL + 321B INT25 成功流程。
- Our Time Normal：进入 CREATE 前先 type2=0，并按 162-FILL + 189B INT25 成功流程。

## 4. V2.3.6 的实现策略
这是一个“先证明设备端完整播放”的校正版：对已识别 songId 使用抓包精确 profile；其它歌曲仍走通用 encoder。

重要限制：乌兰巴托 profile 中 CREATE / FILL / INT25 是本次官方抓包的精确 payload。如果用户修改了这首 JSON 的音符内容，而 songId 不变，本版仍会发送精确抓包 profile；因此它不是最终 JSON 编辑器的通用实现。下一阶段需要反推 tk10 的生成规则和 INT25 body 的通用编码算法，才能让修改后的多轨 JSON 动态生成完全一致的设备数据。

## 5. 测试顺序
1. 清理/重新生成 VS2019 Win32。
2. 先打开 `02_乌兰巴托的夜_进阶版_.json`，上传并待按键；确认日志显示 Official Ulaan profile、11 tracks、175 FILL、8 INT25 pages。
3. 连续实体按键，验证主旋律/PAD/SUBLEAD 与红线。
4. 不重启 C2，直接载入 `13_我们的时光_进阶版.json`，上传；确认日志先发送 AUTO type2=0，C2 初始位置=4，然后实体按键推进。
5. 再测试 `14_我们的时光.json`，初始位置=0。
