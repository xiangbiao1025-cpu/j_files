# V2.3.12 — Device Beat Sync + C2 LEAD runtime mode

## 1. Main melody
V2.3.11 proved that adding tk0 INT25 alone is insufficient on the tested C2: all JSON categories can still have silent LEAD.
V2.3.12 therefore restores the separate C2 runtime command `set_pre_lead` after `GET_SHEET_BEAT` verification.
Payload: `[mode][preBeat f32 LE][toneLen][tone UTF-8]`; mode 0=off, 1=on, 2=Auto.
The upload handshake itself is unchanged before beat verification.

## 2. Red line
V2.3.11 could stop while C2 LEDs continued because it hard-gated progress through a simplified local chord checker and ignored new noti_chord while `g_c2FlowRunning`.
V2.3.12 uses C2's reported sheet beat as the authoritative synchronization signal, but direct `noti_chord` still has a physical hard gate:
- expected chord ROOT must match the reported `level`;
- `pickId` must be A/B (0/1);
- chord type/trans are diagnostic only because those mappings are not fully decoded;
- first accepted beat may equal the armed start beat;
- later beat must advance by >0.20;
- same/stale beat never restarts the red line;
- an advanced, root-valid beat is accepted even while the previous visual segment is still moving.

This keeps the user's required “correct left-hand chord + A/B pick” rule while removing the incomplete chord-type hard gate that could strand the PC behind a C2 that is visibly progressing.
