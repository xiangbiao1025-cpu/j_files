# V2.3.17 Tone Studio / INT26

## 目标

把 2026-08-28 原厂 C2 设备页截图和连续 BLE 抓包确认的“旋律音色”与 sheet tk0 运行时修改链路纳入 Windows 设备中心。

## 完整音色库

共 66 项：

- 吉他 2：GuitarN / GuitarS
- 钢琴 3：PianoMKS20 / PianoRhodesWarm / PianoStudio
- 键盘类 8：MK80 / Accordion / EP1 / EP2 / Organ / PianoDance / PianoEDM / PianoStrings
- 弓弦类 6：Cello / Erhu1 / StringSet1 / StringSet2 / Viola / Violin
- 吹奏类 6：Dizi / PanFlute / Recorder / Saxophone / Shakuhachi / Trumpet
- 拨弦类 10：AGsolo1 / AGsolo2 / EGsolo1 / EGsolo2 / Guzheng / LGsolo1 / LGsolo2 / Pipa / Shamisen / Zither
- 合成器 31：Synth3 / 80sPolySynth / 80sSynthBrass / AlivePluck / BlindingLead / JeDanseSynth / KettlePluck / Key1 / Key2 / Lead1 / Lead2 / MarimbaPluck / MoonSailor / NeoSoulPad / OrganBass / Pad1 / Pad2 / PerfectPad / PolyRecPad / SavannahPluck / SawLead / SolinaPad / StayKey / SummerBell / Synth1 / Synth2 / Synth4 / SynthLead / ViolinsFlutePad / VocoderLead / WobbleSynth

`sound_c2` 用于前 5 个内置音色，其余使用 `scard_01`。

## 设备页音色

选择后发送：

```text
set_fret_instru(card,tone,8xf32-tail)
set_lead_preview(card,tone,8xf32-tail)
get_config_v2basic
```

8 个 float32 LE 固定尾部：

```text
0.0, 1.0, 0.0, 1.0, 4.0, 1.0, 0.05, 0.0
```

`get_config_v2basic` 开头 `[cardLen][card][toneLen][tone]` 用于回读当前设备页旋律音色。

## 已上传 sheet 的主旋律 tk0

运行时使用 int command `0x1A / SET_AMEND_TRACK / INT26`。INT26 复用 INT25 的 section/track/range schema，只把 tk0 的 card/tone/value 改成目标值。

- 当前段：先 `GET_SHEET_BEAT`，找到 INT25 schedule 中包含该 beat 的 tk0 section，只发一个 section。
- 全部段：把所有含 tk0 的 schedule section 放入一个 INT26 body。
- 音色变化：`set_lead_preview` + INT26。
- 纯 volume 变化：只发 INT26，匹配原厂抓包。

《虫儿飞》抓包结构可复现：

- 当前段 scard_01:Cello：body 39B。
- 7 段全部 Cello：body 267B。
- current sound_c2:GuitarS：body 41B。

## pickVolume=0 修正

以前编码器把 `pickVolume <= 0` 都强制变成 100，导致 JSON 明确写 0 仍有声音。现在：

```text
字段存在且为 0 -> set_volume xx 00
字段存在 1..100 -> 原值
字段缺失 -> 兼容默认 100
```

因此“缺字段”和“明确静音”已经分开。

## 仍需实机验证

- `0B/0C` 已从 configPack 顺序和抓包高度确定为 A/B 鼓音量，但标签仍保留“高可信”。
- 66 个 tone code 来自这次设备页逐项切换抓包/截图；建议至少抽测每类 1~2 个。
- Windows-only App/C2Controller 需在 VS2019 + Windows SDK 实机编译运行验证。
