# LiberLive MDS Player V2.3.14

## 本版目标

基于 V2.3.13，不改动已经验证过的 JSON -> CREATE/FILL/INT25 主流程，增加设备层 UI 与后续编辑入口。

## 1. 三个旋律按钮改为真实 Mixer 控制

旧按钮：
- 旋律开 -> set_pre_lead mode=1
- 旋律Auto -> set_pre_lead mode=2
- 旋律关 -> set_pre_lead mode=0

V2.3.14 改为：
- 旋律100 -> `set_volume 05 64`
- 旋律50  -> `set_volume 05 32`
- 旋律0   -> `set_volume 05 00`

每次写入后立即 `get_volume` / A102 回读验证。

历史实机标定：get_volume channel 05 = 全局主旋律 Mixer。该状态属于 C2 设备状态，与 JSON 的 tk0/INT25 段内轨道音量不同。

此外，每次上传 JSON 在 CrossSongReset 后都会无条件发一次 `set_volume 05 64`，防止旧 PC 测试程序把 C2 主旋律长期留在静音状态。

## 2. 顶部设备状态

第一行右侧显示：
- 总音量 ch01
- 鼓 ch02
- 贝斯 ch04
- 主旋律 ch05
- 琶音 ch0D
- C2 电量百分比及充电状态

连接后发送 `set_notify_param 01 0A` 开启常规 noti_basic。GUI 只在 key/BPM/system volume/battery/mode/chargeState 变化时刷新，避免约 100ms 周期通知淹没消息队列。

noti_basic DEX 字段：
- data[0] key
- data[1] bpm
- data[2] system volume
- data[3] battery
- data[4] low nibble guitar mode
- data[12] high nibble chargeState（2/3/4 视为充电）

## 3. 音色配置入口

增加“音色配置”按钮。当前为第一阶段只读窗口，显示：
- melodicNote
- trackConfigs index/name/type/volume/mute
- assetNotes: timbreCardCode:noteCode
- timeline extension type=13 音色事件

后续按官方 App 视频改造成轨道卡片式编辑页：音色类别、具体音色、音量、静音，并映射 INT26 / SET_TRACK_INS / SET_TRACK_VOLUME。

## 4. 风格包入口

增加“风格包”按钮。当前只读显示：
- baseConfig.model/configType/defaultLevel/beat/bpm/tone
- configPack.chords
- configPack.drums
- configPack.instrument
- type7/type10/type12 时间轴事件数量

后续按官方 App 视频增加 A/B 拨片风格、鼓组、Level、保存自定义风格配置。

## 5. 设备入口

增加“设备”按钮，点击后异步刷新：
- get_volume
- get_vers_all
- get_midi_info
- get_config_v2basic
- get_sys_onoff type=06

并在独立窗口显示：连接状态、battery/basic、全部 ch01..ch0D Mixer、版本/音源/基础配置/开关回包摘要。

