# LiberLive MDS Player V2.3.10 — Chord Flow / Playback UI

基线：`LiberLive_MDS_Player_V2_3_9a_CursorSeek_FastBLE_C2_VS2019`

## 目标

- 演奏模式时间线选择单位 = 和弦节。
- 手动点击红线不重新居中谱面。
- C2 实体触发后按 BPM 平滑推进，下一和弦节未触发则停。
- 单主旋律 JSON 的 `beat.notes` 从前奏开始生效。
- 移除 `testdata` 及自动加载测试曲目。

## 时间线模式

```cpp
enum class TimelineInteractionMode { Performance, Edit };
```

- `Performance`：`CMDSPlayerModel::SnapToChordSection()`。
- `Edit`：预留 `round(beat * 4) / 4`，即 1/4 beat。

## C2 演奏 UI 状态机

```text
ARMED / WAITING
  | 新 noti_chord(sheet beat)
  v
RUN_CURRENT_CHORD
  | position += dt * BPM / 60
  v
NEXT_CHORD_BOUNDARY
  | 无新触发 -> WAIT
  | 有新触发 -> RUN_CURRENT_CHORD
```

`g_c2PerformanceArmed` 表示已进入 C2 待按键演奏态；
`g_c2FlowRunning` 只表示当前和弦节的 UI 正在滑动。
重复 raw beat 不重新启动当前和弦节。

## 可视窗口

`g_timelineViewStart` 与 `g_positionBeat` 分离。

- 时间线内手动点击：只改变 red cursor。
- 进度条/谱段跳转越出视野：只把目标露出。
- 演奏：当 playhead 超过视野约 82% 时自动向前跟随。

## 单主旋律前奏

`CMDSPlayerModel` 在 Build 时记录是否存在任何实际 `extraTracks[].notes`。

- 无 extra note：`HasOnlyMainMelodyTrack()==true`；type 0/type 4 中的 `beat.notes` 继续作为主旋律。
- 有 extra note：维持 V2.3.9a 多轨前奏/间奏显示规则。

## 协议范围

本修改只处理 PC 播放/演奏 UI 与轨道分类，不修改 C2：
CREATE、FILL、INT25、SET_TRACK_INS/VOLUME、CrossSongReset、Fast BLE 连接链路。
