# V2.3.8a CrossSongReset

## 真机症状

V2.3.8 在同一 C2 BLE 连接中：第一首能正常实体触发；载入并上传第二首及之后，
实体按键/拨片仍大量产生 `noti_chord`，但通知中的 authoritative sheet beat 保持不变，
GUI 因而显示 `WAIT: C2 未推进，继续等待正确实体触发`。

这证明触发包本身没有丢失，问题位于 C2 的驻留 sheet / track scheduler / AUTO 状态。

## 已知历史证据

早期 V2.3.4 已确认跨歌曲 type2 状态可污染下一首：Ulaan 成功状态 type2=1，
Our Time 的校正流程需要 type2=0；不恢复时会出现 transport/实体按键异常、红线不推进。

3.7.6 DEX 又确认 int28/0x1C 是 `BLE_MSG_SET_TRACK_ENABLE`，不是单纯 READY 标志。
因此只发 CLOSE_SHEET 而不先退出 track scheduler，存在把上一首 scheduler latch 留给下一首的风险。

## V2.3.8a 修改

- 新增 `deviceSheetResident_`：与 GUI 的 `uploaded_` 分离。
- `InvalidateUploadedSheet()` 不再代表 C2 端 sheet 被清除。
- 第二首起 Upload 前：
  - int28 `SET_TRACK_ENABLE=0`
  - int16 `SET_AUTO_PLAY type2=0`
  - int10 `CLOSE_SHEET`
  - 清理本地 level/position/stage-ready 状态并给 C2 约 70 ms settling time
- 新歌 GET_AUTO 后显式设置 type2：
  - actual extra-track path -> 1
  - base/3-track path -> 0
- `CloseSheet()` 也执行相同的退出序列。
- `EnableKeyTriggerEngine()` 重入时也会重新设置本曲 type2。

## 首轮真机验收

不要重启 C2，连续测试至少 4 首：

1. 乌兰巴托（多轨）
2. 卡农（多轨纯演奏）
3. 任意基础/3-track 歌曲
4. 再次加载一首多轨歌曲

第二首开始日志应看到：

```text
CrossSongReset：检测到 C2 仍驻留上一首曲谱
CrossSongReset：SET_TRACK_ENABLE=0
CrossSongReset：SET_AUTO_PLAY type2=0 baseline
CrossSongReset：CLOSE_SHEET 完成
...
GET_AUTO type2=...；V2.3.8a 本曲目标=...
TX cmd=28 ...  // SET_TRACK_ENABLE=1
```

实体触发后应该由 `[ADVANCE]` 连续推进，而不是一直 `[WAIT]`。

如果仍 WAIT，请保存从 `CrossSongReset` 到前三次实体触发的完整程序日志；
下一步将对比 int28/type2/SET_BEAT/noti_chord 的实际顺序，而不是修改 INT25 Builder。
