# V2.3.20 Strict Trigger + A/B Style Slots

## 1. Performance gate

V2.3.19 used C2 returned sheet beat as the final transport authority. A late/newer beat could therefore advance the PC red line even when the physical chord/pick event did not match the score gate.

V2.3.20 changes transport permission to the physical `noti_chord` event:

- expected chord root must match the current waiting chord;
- major/minor type is hard-checked where the mapping is confirmed;
- when JSON type=7 supplies an A/B pick cue, the returned `pickId` must match that A/B cue;
- a mismatched event is logged as `REJECT INPUT` and cannot advance the red line;
- A102 / beat-only replies are synchronization evidence only and never advance the PC transport by themselves;
- duplicate physical events inside 80 ms are debounced.

## 2. Repeated chord early retrigger

While a chord is still visually/audio-active, the next physical trigger is validated against `g_c2FlowStopBeat`, i.e. the next score trigger boundary. Therefore a sequence such as `F F D D` behaves as follows:

1. first F pick starts F1;
2. user may pick again before F1 duration finishes;
3. if the second physical event matches F2, the playhead jumps immediately to F2 start and restarts flow from there;
4. it does not wait for F1 duration to expire.

## 3. A/B chord-pick and drum resource read/write

Device Center now exposes four factory slots from `get_config_basic`:

- A pick/chord
- B pick/chord
- A drum
- B drum

Writes use the captured factory single-slot commands:

- `set_chord_basic`: `[AB][01][01][len][resource]`
- `set_drums_basic`: `[AB][02][01][len][resource]`

Every write is followed by `get_config_basic` readback.

Resource UI accepts either `GS_1` or full `sound_c2:GS_1` syntax. C1 legacy codes are preserved.

## 4. Metadata policy

The UI shows:

`code + Chinese family/pattern + original BPM + original meter + storage`

Only BPM/meter values decoded from the BLE resource records are labeled as original resource BPM/meter. Song BPM, statistical min/max/average BPM, and a BPM observed while saving a config are NOT substituted for original resource BPM.

For older or post-added resources without decoded resource-owned BPM/meter, the UI explicitly shows `原始BPM/拍号：待补测`.
