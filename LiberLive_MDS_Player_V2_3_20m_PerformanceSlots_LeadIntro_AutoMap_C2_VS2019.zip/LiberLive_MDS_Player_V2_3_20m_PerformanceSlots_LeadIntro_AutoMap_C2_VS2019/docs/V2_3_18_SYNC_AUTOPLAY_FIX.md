# V2.3.18 MultiTrack Sync / SET_AUTO_PLAY Fix

## 2026-08-28 修订

1. 修正《月亮代表我的心》tk0 被错误显示为 scard_01:Violin：
   - extension type13 不再作为 tk0 默认音色来源。
   - content.melodicNote 有值时使用它；否则 tk0 默认 sound_c2:PianoStudio。
2. 设备中心 INT26 修改轨道音色/音量后，主窗口“全部轨道”立即刷新。
   - “当前段”优先显示当前红线所在 section 的 runtime schedule。
   - “全部段”修改后所有 section 使用新设置。
3. 主窗口删除 ch05=100 / ch05=50 / ch05=0 三个按钮。
4. 设备中心删除“物理快捷键监视”UI。
5. 新增 SET_AUTO_PLAY (0x10) 三类直接测试：
   - type1: 01 00 / 01 01（01 01 已确认用于按键触发准备）
   - type2: 02 00 / 02 01（独立子状态，语义继续标定）
   - type3: 03 00 / 03 01（AUTO_PLAY_DRUM）
6. 风格设置 UI 改用 Type1..Type6 原始编号，避免把尚未确认的业务名称写死。
   使用方法：先“刷新设备全部信息”取得 get_style_settings；修改已启用的复选框；点击“应用风格设置”。程序只发送变化项 set_style_settings [type][0/1]，随后 get_style_settings 回读核对。
