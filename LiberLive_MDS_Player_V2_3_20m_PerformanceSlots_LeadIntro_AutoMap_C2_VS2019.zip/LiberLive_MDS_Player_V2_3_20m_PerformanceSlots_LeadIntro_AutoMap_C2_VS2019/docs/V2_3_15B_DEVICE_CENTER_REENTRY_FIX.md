# V2.3.15b Device Center Re-entry / Stack Overflow Fix

## Symptom
Opening the C2 Device Center in VS2019 Debug throws `0xC00000FD: Stack overflow`.
The call stack repeats `DeviceCenterProc -> RefreshDeviceCenterControls -> user32 -> DeviceCenterProc`.

## Root cause
`RefreshDeviceCenterControls()` programmatically calls `SetWindowTextW()` for the mixer/Key/BPM EDIT controls. Win32 synchronously sends `WM_COMMAND` notifications such as `EN_UPDATE` / `EN_CHANGE` to the parent. V2.3.15a did not check `HIWORD(wParam)`, so every such notification fell through to the final `RefreshDeviceCenterControls()` call. This created an infinite synchronous recursion.

## Fix
1. Add `DeviceCenterState::refreshing` guard.
2. During refresh, ignore all `WM_COMMAND` re-entry.
3. Process only the eight explicit action button IDs and only when `HIWORD(wParam)==BN_CLICKED`.
4. Preserve the V2.3.15a flattened raw-reply storage and explicit `std::max<T>/std::min<T>` calls.

No C2 music upload protocol was changed.
