# LiberLive C2 btsnoop 命令往来流程核对（2026-08-21）

## 结论

1. **V2.3.3 的 `set_pre_lead` 三按钮不是多维谱轨道启动机制。** 官方成功的多轨曲谱上传/启动流程中，关键是 CREATE/FILL 之外的 **int 25 (0x19) 分块数据、SET_TRACK_INS(13)、SET_TRACK_VOLUME(11)、GET/SET_AUTO_PLAY、int28、SET_BEAT** 等联合事务。
2. **当前工程有一个确定的逻辑错误：只要 `baseConfig.configPack` 存在，就跳过 `trackSetup`。** 因而《乌兰巴托的夜》的 tk3..tk9 虽然已经作为 FILL 上传，但没有执行对应的音色和音量命令。
3. **int25 不能再忽略。** 3轨《我们的时光》也有 int25（PianoStudio + 多个 beat 区间）；10轨《青花瓷》则被拆成 5 个 int25 包，并包含 PianoStudio、Guzheng、Dizi、AGsolo2、LGsolo2、Cello、Violin 等音色以及大量 float beat 区间。它极像“非和弦轨的音色/区间调度描述”，但在没有新枚举/Bean 证据前仍只记作 `INT25_UNKNOWN_TRACK_SCHEDULE` 工作描述，不冒充官方命令名。
4. `GET_AUTO_PLAY` 在10轨成功会话返回 `01=1, 02=1, 03=1, 04=0, 05=0, 06=0`；其中 type2=1 与旋律/音轨自动状态高度相关，但语义仍需继续验证。

## A. 官方成功：10轨《青花瓷（进阶版）》

| 相对CREATE | 方向 | 命令 | 解析/作用 |
|---:|---|---|---|
| +0.0 ms | PC/App → C2 (A103 Write) | `int:6` | CREATE uid=1924743618775797761, key=9, bpm=58, bnum=1, tracks=10 [0:T1/n527/max208; 1:T2/n104/max208; 2:T5/n12/max204; 3:T3/n259/max207.625; 4:T4/n48/max20; 5:T4/n144/max163.867] |
| +43.0 ms | C2 → App (A102 Read response) | `int:6` |  |
| +56.0 ms | PC/App → C2 (A103 Write) | `get_volume` |  |
| +149.0 ms | C2 → App (A102 Read response) | `get_volume` |  |
| +163.0 ms | PC/App → C2 (A103 Write) | `set_remind_chord` | level=5, chordType=7, trans=0 |
| +177.0 ms | PC/App → C2 (A103 Write) | `get_midi_info` |  |
| +210.0 ms | C2 → App (A102 Read response) | `get_midi_info` |  |
| +224.0 ms | PC/App → C2 (A103 Write) | `int:22` | SET_SECTION_RANGE segments=7 |
| +237.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +330.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +345.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +405.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +420.0 ms | PC/App → C2 (A103 Write) | `set_config_v2pack` | tone=9, jsonBpm=54, entries=4 |
| +433.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +601.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +616.0 ms | PC/App → C2 (A103 Write) | `get_sys_onoff` |  |
| +658.0 ms | C2 → App (A102 Read response) | `get_sys_onoff` |  |
| +672.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x09, value=100 |
| +684.0 ms | PC/App → C2 (A103 Write) | `get_volume` |  |
| +764.0 ms | C2 → App (A102 Read response) | `get_volume` |  |
| +778.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x0A, value=100 |
| +794.0 ms | PC/App → C2 (A103 Write) | `int:25` | INT25 unknown/scheduling block len=60, header=05 60 07 00 00 00 c9 01 00 00 00 00 |
| +806.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x0B, value=100 |
| +822.0 ms | PC/App → C2 (A103 Write) | `int:25` | INT25 unknown/scheduling block len=60, header=05 60 07 00 00 01 c9 01 00 00 00 00 |
| +836.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x0C, value=100 |
| +869.0 ms | PC/App → C2 (A103 Write) | `int:25` | INT25 unknown/scheduling block len=60, header=05 60 07 00 00 02 c9 01 00 00 00 00 |
| +882.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +930.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +944.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +990.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +1007.0 ms | PC/App → C2 (A103 Write) | `int:25` | INT25 unknown/scheduling block len=60, header=05 60 07 00 00 03 c9 01 00 00 00 00 |
| +1020.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +1080.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +1094.0 ms | PC/App → C2 (A103 Write) | `int:15` | GET_AUTO_PLAY |
| +1138.0 ms | C2 → App (A102 Read response) | `int:15` | GET_AUTO response {1=1, 2=1, 3=1, 4=0, 5=0, 6=0} |
| +1167.0 ms | PC/App → C2 (A103 Write) | `int:25` | INT25 unknown/scheduling block len=60, header=05 60 07 00 00 04 3c 00 00 00 00 00 |
| +1180.0 ms | PC/App → C2 (A103 Write) | `set_pre_level` | level=2, flag=1 |
| +1193.0 ms | PC/App → C2 (A103 Write) | `set_guitar_mode` | mode=2 |
| +1207.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=9, instrument=scard_01:Violin |
| +1220.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=8, instrument=scard_01:Cello |
| +1232.0 ms | PC/App → C2 (A103 Write) | `int:16` | SET_AUTO_PLAY type=1, state=1 |
| +1244.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=7, instrument=scard_01:AGsolo2 |
| +1257.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=6, instrument=scard_01:Dizi |
| +1271.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=5, instrument=scard_01:LGsolo2 |
| +1284.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=4, instrument=scard_01:PianoDance |
| +1298.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=2, types=[2, 5] |
| +1310.0 ms | PC/App → C2 (A103 Write) | `int:13` | SET_TRACK_INS tkid=3, instrument=scard_01:Guzheng |
| +1317.0 ms | PC/App → C2 (A103 Write) | `int:28` | INT28 data=01 |
| +1327.0 ms | PC/App → C2 (A103 Write) | `int:8` | SET_BEAT beat=0, tracks=10, noteIndex=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0] |
| +1339.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=3, types=[1, 1, 3] |
| +1352.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=9, volume=60 |
| +1364.0 ms | C2 → App (A101 Notify) | `int:29` | Notify29 data=01 |
| +1365.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=8, volume=61 |
| +1378.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=8, types=[1, 1, 1, 1, 3, 3, 3, 3] |
| +1430.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=7, volume=80 |
| +1497.0 ms | PC/App → C2 (A103 Write) | `int:8` | SET_BEAT beat=0, tracks=10, noteIndex=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0] |
| +1513.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=16, types=[2, 1, 1, 1, 5, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| +1525.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=6, volume=80 |
| +1538.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=5, volume=80 |
| +1552.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=12, types=[1, 1, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| +1564.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=4, volume=80 |
| +1578.0 ms | PC/App → C2 (A103 Write) | `int:11` | SET_TRACK_VOLUME tkid=3, volume=80 |
| +1593.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=15, types=[2, 1, 1, 1, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| +1606.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=12, types=[1, 1, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| +1620.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=15, types=[2, 1, 1, 1, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| +1634.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=14, types=[1, 1, 1, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| +1647.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=11, types=[2, 1, 3, 4, 4, 4, 4, 4, 4, 4, 4] |
| … | App→C2 | `int:7` | 后续连续 FILL 共省略 6 条（CSV 保留完整窗口） |

### 10轨会话最关键的次序

- CREATE(10 tracks) → A102 `01` ACK。
- `get_volume` 回读、`set_remind_chord`、`get_midi_info` 回读、SECTION。
- `get_config_v2basic` 回读 ×2 → `set_config_v2pack` → 再回读 config。
- `set_volume 09/0A/...` 与 **5个 int25 分块**交错发送。
- `GET_AUTO_PLAY` 回包明确含 **type2=1**。
- `set_pre_level`、`set_guitar_mode`。
- **逐轨 SET_TRACK_INS：tk9→tk3**。
- `SET_AUTO_PLAY 01 01`。
- FILL、`int28 01`、`SET_BEAT`。
- **逐轨 SET_TRACK_VOLUME：tk9→tk3** 与首批 FILL 交错。
- 后续连续 FILL。

## B. 官方成功：3轨《我们的时光（进阶版）》

| 相对CREATE | 方向 | 命令 | 解析/作用 |
|---:|---|---|---|
| -24.0 ms | PC/App → C2 (A103 Write) | `set_remind_chord` | level=9, chordType=1, trans=0 |
| +0.0 ms | PC/App → C2 (A103 Write) | `int:6` | CREATE uid=1924713742236749826, key=4, bpm=58, bnum=1, tracks=3 [0:T1/n466/max370; 1:T2/n183/max370; 2:T5/n11/max362] |
| +81.0 ms | C2 → App (A102 Read response) | `int:6` |  |
| +106.0 ms | PC/App → C2 (A103 Write) | `int:22` | SET_SECTION_RANGE segments=7 |
| +119.0 ms | PC/App → C2 (A103 Write) | `get_midi_info` |  |
| +187.0 ms | C2 → App (A102 Read response) | `get_midi_info` |  |
| +202.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +246.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +261.0 ms | PC/App → C2 (A103 Write) | `get_volume` |  |
| +366.0 ms | C2 → App (A102 Read response) | `get_volume` |  |
| +380.0 ms | PC/App → C2 (A103 Write) | `set_config_v2pack` | tone=4, jsonBpm=84, entries=4 |
| +394.0 ms | PC/App → C2 (A103 Write) | `int:25` | INT25 unknown/scheduling block len=60, header=01 35 01 00 00 00 35 01 00 00 00 00 |
| +406.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x09, value=100 |
| +420.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=4, types=[2, 1, 5, 5] |
| +434.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x0A, value=100 |
| +447.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=2, types=[1, 1] |
| +459.0 ms | PC/App → C2 (A103 Write) | `int:8` | SET_BEAT beat=0, tracks=3, noteIndex=[0, 0, 0] |
| +471.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x0B, value=100 |
| +485.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=4, types=[2, 1, 1, 1] |
| +497.0 ms | PC/App → C2 (A103 Write) | `set_volume` | channel=0x0C, value=100 |
| +510.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=2, types=[1, 1] |
| +542.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +551.0 ms | C2 → App (A101 Notify) | `int:29` | Notify29 data=01 |
| +576.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +590.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +637.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +664.0 ms | PC/App → C2 (A103 Write) | `get_config_v2basic` |  |
| +711.0 ms | C2 → App (A102 Read response) | `get_config_v2basic` |  |
| +726.0 ms | PC/App → C2 (A103 Write) | `int:8` | SET_BEAT beat=4, tracks=3, noteIndex=[0, 0, 0] |
| +738.0 ms | PC/App → C2 (A103 Write) | `int:15` | GET_AUTO_PLAY |
| +815.0 ms | C2 → App (A102 Read response) | `int:15` | GET_AUTO response {1=1, 2=1, 3=1, 4=0, 5=0, 6=0} |
| +853.0 ms | PC/App → C2 (A103 Write) | `set_remind_chord` | level=9, chordType=1, trans=0 |
| +892.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=2, types=[2, 1] |
| +905.0 ms | PC/App → C2 (A103 Write) | `set_guitar_mode` | mode=2 |
| +919.0 ms | PC/App → C2 (A103 Write) | `set_pre_level` | level=4, flag=1 |
| +932.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=1, types=[1] |
| +945.0 ms | PC/App → C2 (A103 Write) | `int:16` | SET_AUTO_PLAY type=1, state=1 |
| +958.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=1, types=[2] |
| +970.0 ms | PC/App → C2 (A103 Write) | `int:28` | INT28 data=01 |
| +984.0 ms | PC/App → C2 (A103 Write) | `int:8` | SET_BEAT beat=4, tracks=3, noteIndex=[0, 0, 0] |
| +997.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=1, types=[2] |
| +1010.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=1, types=[2] |
| +1022.0 ms | PC/App → C2 (A103 Write) | `int:7` | FILL items=2, types=[2, 1] |
| … | App→C2 | `int:7` | 后续连续 FILL 共省略 10 条（CSV 保留完整窗口） |

### 3轨会话同样出现 int25

这说明 int25 **不是仅为 extraTracks 服务**。在 3 轨曲谱中它仍承载 `sound_c2 / PianoStudio` 和多个 beat 范围，因此很可能同时负责 LEAD 的区间/音色调度。

## C. 《乌兰巴托的夜（进阶版）》JSON 中已有的额外轨

| JSON index | C2 tkid | type | 角色 | volume | instrument |
|---:|---:|---:|---|---:|---|
| 1 | 3 | 2 | SUBLEAD/加花 / bell | 72 | `scard_01:SummerBell` |
| 2 | 4 | 1 | PAD/铺底 / piano | 72 | `sound_c2:PianoStudio` |
| 3 | 5 | 1 | PAD/铺底 / pad | 38 | `scard_01:PerfectPad` |
| 4 | 6 | 1 | PAD/铺底 / pad air | 23 | `scard_01:Pad2` |
| 5 | 7 | 2 | SUBLEAD/加花 / EG warm | 66 | `scard_01:EGsolo2` |
| 6 | 8 | 2 | SUBLEAD/加花 / key warm | 36 | `scard_01:Key2` |
| 7 | 9 | 2 | SUBLEAD/加花 / guzheng | 127 | `scard_01:Guzheng` |


这些 `trackConfigs` 对应的 `extraTracks` 已经存在于 JSON，PC 本地播放器直接按 JSON 调度，所以能发声；C2 端则需要设备侧轨道配置/调度事务，不能只靠 FILL。

## D. V2.3.3 与官方多轨会话差异

| 项目 | 官方10轨成功会话 | V2.3.3 | 结论 |
|---|---|---|---|
| CREATE/FILL | 有 | 有 | 数据已进入 C2 |
| SET_BEAT / beat notify | 有 | 有，已修好 | 红线能移动 |
| configV2Pack | 有 | 有 | 仅配置 chord/drum 基础包，不等价于 extra-track 配置 |
| int25 / 0x19 | **有，5个分块** | **无** | 重大缺口 |
| SET_TRACK_INS | **tk9..tk3 全发** | **有 configPack 时被代码跳过** | 确定 bug |
| SET_TRACK_VOLUME | **tk9..tk3 全发** | **有 configPack 时被代码跳过** | 确定 bug |
| GET_AUTO type2 | 返回 1 | 只读，未按状态处理 | 待验证缺口 |
| set_pre_lead | 上传关键段未使用 | V2.3.3 新增三按钮 | 方向错误，应删除 |

## E. 下一版修正原则

- 删除“旋律开 / 旋律Auto / 旋律关”三个按钮及自动 `set_pre_lead`。
- 保留 V2.3.2 已验证的 CREATE ACK、A102 query/read、Notify29、SET_BEAT、noti_chord beat 同步。
- **无论是否存在 configV2Pack，都必须发送 trackConfigs 对应的 SET_TRACK_INS / SET_TRACK_VOLUME。**
- 对多轨曲谱记录 GET_AUTO 的 type2；可做受控实验，但不把 type2 的业务名称写死。
- int25 继续作为最高优先级逆向目标；在精确构造前，不能宣称“全多轨已完成”。

> 注：本抓包没有《乌兰巴托的夜》本身的 CREATE 会话，因此多轨启动核对采用同一固件/同一协议下的官方 10 轨《青花瓷（进阶版）》成功会话；《我们的时光》3轨会话用于证明 int25 对主旋律也可能相关。
