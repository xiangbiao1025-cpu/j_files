﻿#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

// Same C++/WinRT BLE stack as the C2PcController v5.1 project that was
// physically verified to connect to LiberLive C2 on Windows.
#include <winrt/base.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Storage.Streams.h>
#include <winrt/Windows.Devices.Bluetooth.h>
#include <winrt/Windows.Devices.Bluetooth.Advertisement.h>
#include <winrt/Windows.Devices.Bluetooth.GenericAttributeProfile.h>
#include <winrt/Windows.Devices.Enumeration.h>

class C2BleClient {
public:
    using LogFn = std::function<void(const std::wstring&)>;
    using NotifyFn = std::function<void(const std::vector<std::uint8_t>&)>;

    C2BleClient();
    ~C2BleClient();

    // C2SingleResourceAuditioner-proven connection path:
    // active BLE advertisements + Windows-known BLE fallback -> connect by
    // Bluetooth address or DeviceInformation id -> uncached Service FF lookup.
    // The player additionally requires A101 Notify besides A102 Read/A103 Write.
    bool Connect(std::wstring& error, LogFn log = {}, NotifyFn notify = {});
    void Disconnect();
    bool IsConnected() const;
    std::wstring DevicePath() const;

    using AsyncWriteOperation = winrt::Windows::Foundation::IAsyncOperation<
        winrt::Windows::Devices::Bluetooth::GenericAttributeProfile::GattCommunicationStatus>;

    bool WritePacket(const std::vector<std::uint8_t>& packet, std::wstring& error);
    // V2.3.20i optional WNR pipeline path: submit WriteWithoutResponse packets without immediately
    // waiting on each IAsyncOperation.  The controller keeps a tiny depth-2
    // window only for the already-proven 460B generic FILL tail.  Control/GET
    // traffic continues to use synchronous WritePacket.
    bool BeginWritePacket(const std::vector<std::uint8_t>& packet, AsyncWriteOperation& operation, std::wstring& error);
    bool FinishWritePacket(AsyncWriteOperation& operation, std::wstring& error);
    // Upload diagnostics. WritePacket already chooses WriteWithoutResponse when
    // A103 exposes it; these accessors let the controller pace bulk FILL/INT25
    // against the real Windows GATT connection instead of assuming 20-byte BLE.
    bool SupportsWriteWithoutResponse() const { return writeWithoutResponse_.load(); }
    std::uint16_t MaxPduSize() const { return maxPduSize_.load(); }
    std::size_t MaxGattWriteValueBytes() const {
        const auto pdu=maxPduSize_.load();
        return pdu>3 ? static_cast<std::size_t>(pdu-3) : 0;
    }
    // Synchronous uncached read from A102. Used for GET-style commands such as
    // integer 0x09 GET_SHETT_BEAT.
    bool ReadPacket(std::vector<std::uint8_t>& packet, std::wstring& error);

private:
    struct Candidate {
        std::uint64_t address = 0;
        std::wstring name;
        std::wstring id; // Windows DeviceInformation fallback id (C2SingleResourceAuditioner path)
        int rssi = -127;
        bool hasC2Service = false;
    };

    bool ConnectByAddress(std::uint64_t address, std::wstring& error);
    bool ConnectById(const std::wstring& id, std::wstring& error);
    bool ResolveGattAndCharacteristics(std::wstring& error);
    bool SubscribeNotify(std::wstring& error);
    std::vector<Candidate> ScanAdvertisements(int maxMilliseconds);
    bool LoadCachedAddress(std::uint64_t& address) const;
    void SaveCachedAddress(std::uint64_t address) const;
    void CloseUnlocked();
    void Log(const std::wstring& s) const;

    static std::wstring AddressToString(std::uint64_t address);
    static bool ContainsNoCase(const std::wstring& s, const std::wstring& needle);

    mutable std::mutex mutex_;
    LogFn log_;
    NotifyFn notifyFn_;

    winrt::Windows::Devices::Bluetooth::BluetoothLEDevice device_{ nullptr };
    winrt::Windows::Devices::Bluetooth::GenericAttributeProfile::GattDeviceService service_{ nullptr };
    winrt::Windows::Devices::Bluetooth::GenericAttributeProfile::GattCharacteristic notifyChar_{ nullptr };
    winrt::Windows::Devices::Bluetooth::GenericAttributeProfile::GattCharacteristic readChar_{ nullptr };
    winrt::Windows::Devices::Bluetooth::GenericAttributeProfile::GattCharacteristic writeChar_{ nullptr };
    winrt::Windows::Devices::Bluetooth::GenericAttributeProfile::GattSession gattSession_{ nullptr };
    winrt::event_token notifyToken_{};
    bool notifyAttached_ = false;
    std::atomic<std::uint16_t> maxPduSize_{0};
    std::atomic<bool> writeWithoutResponse_{false};

    std::wstring deviceName_;
    std::wstring devicePath_;
    std::uint64_t lastAddress_ = 0;
    std::atomic<std::uint64_t> notifyCount_{0};
};
