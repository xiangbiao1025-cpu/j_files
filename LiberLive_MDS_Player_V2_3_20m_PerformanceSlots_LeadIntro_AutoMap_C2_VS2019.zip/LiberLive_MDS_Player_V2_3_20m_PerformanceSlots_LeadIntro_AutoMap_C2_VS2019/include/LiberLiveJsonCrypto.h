#pragma once
#include <string>

// Decrypts LiberLive HTTP response field data when it uses the observed
// "@_@" + Base64(AES-128-CBC/PKCS7) envelope.
// Returns false when the input is not in that form or decryption fails.
bool DecryptLiberLiveApiData(const std::string& encoded, std::string& plainUtf8, std::string& error);
