﻿#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

struct MDSAssetNote {
    std::string noteCode;
    std::string timbreCardCode;
};

struct MDSTrackConfig {
    int index = 0;
    int mute = 0;
    std::string name;
    std::string noteCode;
    int type = 0;
    int volume = 100;
    std::vector<MDSAssetNote> assetNotes;
};

struct MDSConfigEntry {
    double bpmRate = 0.0;
    std::string cardCode;
    std::string cardName;
    std::string dataType;
    std::string nameCode;
    std::string version;
    int pickAction = 0;
    int pickType = 0;
    int pickVolume = 0;
    bool hasPickVolume = false; // distinguish explicit 0 (mute) from missing field (default 100)
    int star = 0;
    int bassVolume = 0;
};

struct MDSConfigPack {
    bool parsed = false;
    std::vector<MDSConfigEntry> chords;
    std::vector<MDSConfigEntry> drums;
    std::vector<MDSConfigEntry> instrument;
};

struct MDSBaseConfig {
    std::string beat;
    int bpm = 0;
    std::string configPackRaw;
    MDSConfigPack configPack;
    std::string configType;
    int defaultLevel = 0;
    std::string model;
    std::string tone;
};

struct MDSChord {
    std::string attachKey;
    double length = 0.0;
    std::string mainKey;
    std::string transKey;
};

struct MDSNote {
    double length = 0.0;
    int note = 0;
    double start = 0.0;
    bool stretch = false;
    int upOctave = 0;
    int velocity = 0;
};

struct MDSWord {
    double length = 0.0;
    bool newLine = false;
    double start = 0.0;
    bool stretch = false;
    std::string word;
};

struct MDSExtraTrack {
    int index = 0;
    std::vector<MDSNote> notes;
};

struct MDSExtension {
    std::string type;
    double start = 0.0;

    int direction = 0;
    int pick = 0;
    int position = 0;
    int switchType = 0;

    int originKey = 0;
    int toneType = 0;

    int pickAction = 0;
    // pickType verified from C2 UI/protocol observation:
    // 0 = A pick, 1 = B pick, 2 = A+B picks.
    int pickType = 0;
    int level = 0;

    std::vector<std::string> drumCodes;
    std::string model;

    std::string cardCode;
    std::string code;
    double length = 0.0;

    // Seen in newer direct-download JSONs (notably extension type=14).
    std::string group;
    int volume = 0;
    int mute = 0;
    std::vector<MDSAssetNote> assetNotes;
};

struct MDSBeat {
    double beat = 0.0;

    // Original JSON source location for direct file comparison. Offsets are
    // zero-based byte offsets in the original UTF-8 file; lines are one-based.
    std::size_t jsonSegmentIndex = 0;
    std::size_t jsonBarArrayIndex = 0;
    std::size_t jsonBeatArrayIndex = 0;
    std::size_t jsonByteStart = 0;
    std::size_t jsonByteEnd = 0;
    std::size_t jsonLineStart = 0;
    std::size_t jsonLineEnd = 0;
    std::string jsonRaw;
    bool jsonSourceExact = true;
    bool hasChord = false;
    MDSChord chord;
    std::vector<MDSExtension> extensions;
    std::vector<MDSExtraTrack> extraTracks;
    std::vector<MDSNote> notes;
    std::vector<MDSWord> words;
};

struct MDSBar {
    int bar = 0;
    std::vector<MDSBeat> beats;
};

struct MDSLyricTrack {
    int type = 0;
    std::vector<MDSBar> bars;
};

struct MDSContent {
    std::string beat;
    int tempo = 0;
    std::string originalTone;
    std::string originalSinger;
    std::string composer;
    std::string lyricist;
    std::string productModel;
    int musicalInstrumentId = 0;
    bool isMultiTrack = false;
    bool isVideo = false;
    int leadNote = 0;
    std::string singleVoice;
    // C2 main melody instrument, e.g. "sound_c2:PianoStudio".
    std::string melodicNote;

    MDSBaseConfig baseConfig;
    std::vector<MDSTrackConfig> trackConfigs;
    std::vector<MDSLyricTrack> lyrics;
};

struct MDSSong {
    std::int64_t id = 0;
    std::string songId;
    int songType = 0;
    std::string title;
    std::string author;
    std::string createAuthor;
    std::string avatar;
    std::string cover;
    std::int64_t createTime = 0;
    std::string updateTime;

    // Parser diagnostics for the many LiberLive JSON container variants.
    // Examples: root.content, direct song detail, data.content, stringified content.
    std::string sourceFormat;
    std::string sourceContentPath;
    bool sourceOffsetsExact = true;

    MDSContent content;
};

struct MDSStats {
    std::size_t songs = 0;
    std::size_t trackConfigs = 0;
    std::size_t tracks = 0;
    std::size_t bars = 0;
    std::size_t beats = 0;
    std::size_t chords = 0;
    std::size_t notes = 0;
    std::size_t extensions = 0;
    std::size_t extraTracks = 0;
    std::size_t extraTrackNotes = 0;
    std::size_t words = 0;
};
