#pragma once
#include <cstddef>
#include <map>
#include <string>
#include <vector>

namespace jsonlite {

enum class Type { Null, Bool, Number, String, Array, Object };

struct Value {
    Type type = Type::Null;
    bool boolValue = false;
    double numberValue = 0.0;
    // Original numeric lexeme. Keeps large integer IDs exact even though numberValue is double.
    std::string numberToken;
    std::string stringValue;
    std::vector<Value> arrayValue;
    std::map<std::string, Value> objectValue;

    // Byte offsets in the parsed UTF-8 JSON text: [sourceStart, sourceEnd).
    std::size_t sourceStart = 0;
    std::size_t sourceEnd = 0;

    bool IsNull() const { return type == Type::Null; }
    bool IsBool() const { return type == Type::Bool; }
    bool IsNumber() const { return type == Type::Number; }
    bool IsString() const { return type == Type::String; }
    bool IsArray() const { return type == Type::Array; }
    bool IsObject() const { return type == Type::Object; }

    const Value* Find(const std::string& key) const;
};

bool Parse(const std::string& text, Value& out, std::string& error);
const char* TypeName(Type type);

} // namespace jsonlite
