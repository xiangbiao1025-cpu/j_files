#pragma once
#include "MDSData.h"
#include "C2MusicEncoder.h"

namespace C2OfficialCaptureProfiles {
void Apply(const MDSSong& song, C2UploadPlan& plan);
void GetUlaanInt25Golden(std::vector<std::vector<std::uint8_t>>& pages);
}
