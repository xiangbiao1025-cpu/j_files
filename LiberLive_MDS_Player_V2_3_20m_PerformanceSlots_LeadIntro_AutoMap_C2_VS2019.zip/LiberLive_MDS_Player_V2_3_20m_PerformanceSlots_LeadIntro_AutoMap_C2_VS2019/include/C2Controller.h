﻿#pragma once
#include "C2BleClient.h"
#include "C2MusicEncoder.h"
#include <atomic>
#include <array>
#include <cstdint>
#include <functional>
#include <mutex>
#include <thread>
#include <string>
#include <vector>

struct C2DecodedPacket;

struct C2DeviceState {
    int key = -1;
    int bpm = -1;
    int systemVolume = -1;
    int battery = -1;
    int mode = -1;
    int chargeState = -1;
    bool charging = false;
    std::array<int,14> mixer{}; // indexes 1..13 used; -1 = unknown
    std::wstring versions;
    std::wstring midiInfo;
    std::wstring configBasic;
    std::wstring sysOnOff;
    // get_config_v2basic exposes the four factory A/B style slots. Keep the full
    // resource identifiers (for example sound_c2:GS_1) so the UI can round-trip
    // them through set_chord_v2basic / set_drums_v2basic without guessing.
    std::string chordStyleA;
    std::string chordStyleB;
    std::string drumStyleA;
    std::string drumStyleB;
    // get_config_v2basic entry-owned parameters in slot order:
    // 0=A chord, 1=B chord, 2=A drum, 3=B drum.  These are the values
    // currently stored in C2; they are displayed separately from the PC
    // catalogue's audition/reference BPM/meter evidence. These values never define the score master BPM.
    std::array<int,4> basicStyleBpm{};
    std::array<int,4> basicStyleMeter{}; // 0=3/4, 1=4/4, 3=6/8; -1 unknown
    bool hasBasicStyleSlots = false;
    // get_config_v2basic begins with current device melody/instrument card+tone.
    std::string currentToneCard;
    std::string currentTone;
    // get_style_settings: [count][type][value]...; raw values are retained as integers
    // because some observed entries are not boolean. APK semantics include
    // STAR_A/STAR_B/PREVIEW_C/PREVIEW_D/ABASS_EN/BPMLOCK/PREV_BPMLOCK.
    // Enum-to-wire numbering is still treated as a mapping under test. -1=unknown.
    std::array<int,32> styleSettings{};
    // GET_AUTO_PLAY: [count][type][state]... . 2026-09-04 real-device differential
    // mapping: 01=main autoplay/performance, 02=drum auto-shift permission,
    // 03=auto key/transposition, 05=solo/mode, 06=smart mode; 04 remains unmarked.
    // C2 level changes observed in this session use set_pre_level rather than a
    // separately confirmed SET_AUTO_PLAY type. JSON extensions.type is unrelated numbering.
    std::array<int,32> autoPlay{};

    // V2.3.17 physical shortcut monitor. noti_frets is the authoritative
    // source for the six arpeggio-pad touch sensors; noti_event exposes the
    // device-side shortcut result (MAIN_TRACK_AUTO / DOUBLE_PICK / etc.).
    bool shortcutMonitorEnabled = false;
    int fretKey = -1;
    int bpmTouch = -1;                 // -1 unknown, 0 released, 1 pressed
    std::array<int,6> arpeggioRaw{};   // raw capacitance bytes, -1 unknown
    std::array<int,6> arpeggioPressed{}; // -1 unknown, 0 released, 1 pressed
    int lastPickId = -1;               // noti_chord: 0=A, 1=B, 2=A+B
    int pickState = -1;
    bool hasPickAngles = false;
    float pickAngleA = 0.0f;
    float pickAngleB = 0.0f;
    int mainTrackAuto = -1;            // noti_event type 1, value 0/1
    int micVolumeEvent = -1;           // noti_event type 2
    int doublePickEvent = -1;          // noti_event type 3
    int batteryShowEvent = -1;         // noti_event type 4
    int lastSystemEventType = -1;
    int lastSystemEventValue = -1;
    std::uint64_t shortcutEventCounter = 0;

    // Raw/summary cache for device-control-center queries. This deliberately
    // keeps unknown/new firmware replies visible instead of throwing them away.
    // Flattened raw reply log. V2.3.15a intentionally avoids std::map here:
    // opening the device center used to copy the map from a Win32 callback and
    // could surface a CRT heap/tree exception on VS2019 Debug builds.
    std::wstring rawRepliesText;

    C2DeviceState() {
        mixer.fill(-1);
        styleSettings.fill(-1);
        autoPlay.fill(-1);
        arpeggioRaw.fill(-1);
        arpeggioPressed.fill(-1);
        basicStyleBpm.fill(-1);
        basicStyleMeter.fill(-1);
    }
};

struct C2PlayEvent {
    enum class Kind { Basic, Chord, Note, Drum, Event, Sheet, Frets, Picks, Other };
    Kind kind = Kind::Other;
    std::string command;
    std::vector<std::uint8_t> data;

    // noti_chord capture fields.
    int row = -1;
    int col = -1;
    int level = -1;
    int type = -1;
    int trans12 = -1;
    int pickId = -1;

    // noti_basic fields (DEX-confirmed offsets).
    int basicKey = -1;
    int basicBpm = -1;
    int basicVolume = -1;
    int battery = -1;
    int guitarMode = -1;
    int chargeState = -1;
    bool charging = false;

    // noti_event shortcut/system fields. Current DEX mapping:
    // 1=MAIN_TRACK_AUTO, 2=MIC_VOL, 3=DOUBLE_PICK, 4=BATTERY_SHOW.
    int eventType = -1;
    int eventValue = -1;

    // noti_frets: [key][36 keyboard bytes][bpm][6 arpeggio bytes].
    int fretKey = -1;
    int bpmTouch = -1;
    std::array<int,6> arpeggioRaw{};
    std::array<int,6> arpeggioPressed{};

    // noti_picks: [state][angleA f32LE][angleB f32LE].
    int pickState = -1;
    bool hasPickAngles = false;
    float pickAngleA = 0.0f;
    float pickAngleB = 0.0f;

    // Real play capture shows bytes [6..9] of the 10-byte noti_chord payload
    // are float32 LE sheet beat (0, ~2, ~4, ~6 ...).
    bool hasBeat = false;
    float beat = 0.0f;

    // Host receive timestamp captured on the BLE callback thread. The GUI uses
    // this to report BLE->UI latency and to distinguish transport delay from
    // Windows painting/detail-panel delay.
    std::uint64_t receivedTickMs = 0;
};

class C2Controller {
public:
    using StatusFn = std::function<void(const std::wstring&)>;
    using ProgressFn = std::function<void(int,int)>;
    using EventFn = std::function<void(const C2PlayEvent&)>;

    void SetEventCallback(EventFn fn);

    bool Connect(std::wstring& error, StatusFn status = {});
    void Disconnect();
    bool IsConnected() const;

    bool Upload(const MDSSong& song, int bpm, bool armKeyPlayAfterUpload,
        std::wstring& error, StatusFn status = {}, ProgressFn progress = {});

    // Key-triggered sheet mode. Important: captured official traffic sends
    // SET_AUTO_PLAY [01 01] before key-trigger play. Despite the enum name
    // AUTO_PLAY_MAIN, the device still waits for physical C2 chord/key input.
    bool ArmKeyPlayFromBeginning(std::wstring& error, StatusFn status = {});
    bool ArmKeyPlayFromBeat(float beat, std::wstring& error, StatusFn status = {});

    // Manual protocol experiment only. set_pre_lead: 0=off, 1=on, 2=Auto.
    // V2.3.13 no longer sends this automatically: official successful sheet
    // playback is driven by tk0 CREATE/FILL + INT25/INT26, not set_pre_lead.
    bool SetMainMelodyMode(int mode, std::wstring& error, StatusFn status = {});

    // Device/global mixer volume. Real-device tests confirm ch01=master, ch09=A-pick,
    // ch0A=B-pick. ch05 is a persistent register but is NOT active MDS tk0 gain.
    bool SetMixerVolume(int channel, int value, std::wstring& error, StatusFn status = {});
    bool RefreshMixerVolumes(std::wstring& error, StatusFn status = {});
    // C2SingleResourceAuditioner-proven four-slot readback:
    // get_config_v2basic -> A102 -> parse AChord/BChord/ADrum/BDrum.
    bool RefreshBasicStyleSlots(std::wstring& error, StatusFn status = {});
    bool RefreshDeviceInfo(std::wstring& error, StatusFn status = {});
    bool SetDeviceKey(int key, std::wstring& error, StatusFn status = {});
    bool SetDeviceBpm(int bpm, std::wstring& error, StatusFn status = {});
    bool SetFretInstrument(const std::string& tone, std::wstring& error, StatusFn status = {});
    bool SetFretInstrument(const std::string& cardCode, const std::string& tone, std::wstring& error, StatusFn status = {});
    // Factory device-page tone selection sends set_fret_instru + set_lead_preview,
    // then reads get_config_v2basic. This is separate from a running sheet tk0 patch.
    bool SetDeviceMelodyTone(const std::string& cardCode, const std::string& tone, std::wstring& error, StatusFn status = {});
    // Factory running-sheet edit. Any scheduled track can be patched with INT26/0x1A.
    // tk0 tone changes additionally send set_lead_preview, matching factory capture.
    bool ApplyTrackToneVolume(std::uint8_t trackId, const std::string& cardCode, const std::string& tone, int volume,
        bool allSections, std::wstring& error, StatusFn status = {});
    bool ApplyTrackToneVolumeForTone(std::uint8_t trackId,
        const std::string& matchCardCode, const std::string& matchTone,
        const std::string& cardCode, const std::string& tone, int volume,
        std::wstring& error, StatusFn status = {});
    bool ApplyTrackVolumeForTone(std::uint8_t trackId,
        const std::string& matchCardCode, const std::string& matchTone, int volume,
        std::wstring& error, StatusFn status = {}) {
        return ApplyTrackToneVolumeForTone(trackId,matchCardCode,matchTone,matchCardCode,matchTone,volume,error,status);
    }
    bool ApplyLeadToneVolume(const std::string& cardCode, const std::string& tone, int volume,
        bool allSections, std::wstring& error, StatusFn status = {}) {
        return ApplyTrackToneVolume(0,cardCode,tone,volume,allSections,error,status);
    }
    bool SetStyleSetting(int type, int value, std::wstring& error, StatusFn status = {});
    // Direct SET_AUTO_PLAY (0x10) device-center control. Wire types 1..7; state 0/1.
    bool SetAutoPlayState(int type, int state, std::wstring& error, StatusFn status = {});
    bool ApplyJsonConfigPack(const MDSSong& song, int bpmOverride, std::wstring& error, StatusFn status = {});
    // V2 four-slot style editor. slotAB: 0=A, 1=B.  V2.3.20b follows the
    // C2SingleResourceAuditioner path: set_chord_v2basic/set_drums_v2basic and
    // get_config_v2basic A102 verification.  bpm/meter may be -1 to retain the
    // currently read slot parameters (or fall back to device BPM + 4/4).
    bool SetBasicStyleSlot(bool drum, int slotAB, const std::string& resourceCode,
        std::wstring& error, StatusFn status = {}, int bpm = -1, int meterEnum = -1);

    // Shortcut monitor switch retained in V2.3.17. Known-good notify selectors from
    // real C2 tests: 02 0A -> noti_frets, 03 01 -> noti_picks; 00 disables.
    bool SetShortcutMonitor(bool open, std::wstring& error, StatusFn status = {});
    C2DeviceState DeviceState() const;

    bool CloseSheet(std::wstring& error, StatusFn status = {});


    // Loading another JSON invalidates the PC-side upload handle, but does NOT
    // mean the old sheet disappeared from C2. deviceSheetResident_ deliberately
    // survives this call so the next Upload() can perform a stronger cross-song reset.
    void InvalidateUploadedSheet() { uploaded_.store(false); armed_.store(false); }
    bool HasUploadedSheet() const { return uploaded_.load(); }
    const C2UploadPlan& LastPlan() const { return plan_; }

private:
    bool Send(std::uint8_t cmd, const std::vector<std::uint8_t>& data,
        std::wstring& error, StatusFn status, int sleepMs = 22);
    bool SendString(const std::string& cmd, const std::vector<std::uint8_t>& data,
        std::wstring& error, StatusFn status, int sleepMs = 22);
    bool EnableKeyTriggerEngine(std::wstring& error, StatusFn status);
    void ResetCrossSongState(bool replacingResidentSheet, StatusFn status);
    bool SendRemindChord(std::wstring& error, StatusFn status);
    bool SendPreLevel(int level, std::wstring& error, StatusFn status);
    bool SendMainMelodyMode(int mode, float beat, std::wstring& error, StatusFn status);
    std::vector<std::uint8_t> InitialPosition() const;
    int CueLevelForBeat(float beat) const;
    void QueueCueLevel(int level);
    void CueWorker();
    void QueuePositionQuery();
    void PositionQueryWorker();
    bool ReadExpectedInt(std::uint8_t expectedCmd, C2DecodedPacket& decoded,
        std::wstring& error, StatusFn status, int attempts = 4);
    bool ReadExpectedString(const std::string& expectedCmd, C2DecodedPacket& decoded,
        std::wstring& error, StatusFn status, int attempts = 4);
    void CacheStringReply(const C2DecodedPacket& decoded);
    static std::wstring PayloadSummary(const std::vector<std::uint8_t>& data);
    bool QuerySheetBeat(float& beat, std::wstring& error, StatusFn status);
    bool VerifySheetBeat(float targetBeat, std::wstring& error, StatusFn status);
    void HandleNotify(const std::vector<std::uint8_t>& raw);
    void DispatchEvent(const C2PlayEvent& event);
    static std::wstring Widen(const std::string& s);

    C2BleClient ble_;
    C2UploadPlan plan_;
    std::atomic<bool> uploaded_{false};
    std::atomic<bool> armed_{false};
    std::atomic<int> appliedPreLevel_{-1};
    std::atomic<int> pendingPreLevel_{-1};
    std::atomic<bool> cueWorkerRunning_{false};
    std::atomic<bool> positionQueryRunning_{false};
    std::atomic<bool> positionQueryPending_{false};
    std::atomic<bool> stageReady29_{false};
    // Tracks device-side residency separately from uploaded_/armed_. The GUI calls
    // InvalidateUploadedSheet() when a new JSON is selected, while C2 may still
    // retain the previous track scheduler and AUTO type2 state.
    std::atomic<bool> deviceSheetResident_{false};
    mutable std::mutex opMutex_;

    EventFn eventFn_;
    mutable std::mutex eventMutex_;
    mutable std::mutex stateMutex_;
    C2DeviceState deviceState_;
};
