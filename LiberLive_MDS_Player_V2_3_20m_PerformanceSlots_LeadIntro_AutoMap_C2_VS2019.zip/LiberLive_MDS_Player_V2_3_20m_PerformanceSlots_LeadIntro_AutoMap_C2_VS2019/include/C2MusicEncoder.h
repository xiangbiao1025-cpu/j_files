﻿#pragma once
#include "MDSData.h"
#include <cstdint>
#include <string>
#include <vector>

struct C2TrackDescriptor {
    std::uint8_t tkid = 0;
    std::uint8_t type = 0;
    std::uint16_t noteCount = 0;
    float maxBeat = 0.0f;
};

struct C2TrackSetup {
    std::uint8_t tkid = 0;
    int volume = 100;
    std::string instrument;
};

struct C2PreLevelCue {
    float beat = 0.0f;
    std::uint8_t level = 0;
};

struct C2TrackPositionPoint {
    float beat = 0.0f;
    std::uint16_t noteIndex = 0;
};

struct C2TrackPositionTable {
    std::uint8_t tkid = 0;
    std::vector<C2TrackPositionPoint> points;
};

struct C2ScheduleRange {
    float start = 0.0f;
    float end = 0.0f;
};

struct C2ScheduleTrack {
    std::uint8_t trackId = 0;
    std::uint8_t index = 0;
    std::uint8_t mute = 0;
    std::uint8_t volume = 0;
    std::string cardCode;
    std::string noteCode;
    std::vector<C2ScheduleRange> ranges;
};

struct C2ScheduleSection {
    std::uint8_t type = 0;
    float start = 0.0f;
    float end = 0.0f;
    std::vector<C2ScheduleTrack> tracks;
};

enum class C2OfficialFlowProfile {
    None = 0,
    OurTimeAdvanced20260821,
    OurTimeNormal202607Capture,
    UlaanAdvanced20260821
};

struct C2UploadPlan {
    std::vector<std::uint8_t> createPayload;
    std::vector<std::uint8_t> sectionRangePayload;
    std::vector<std::vector<std::uint8_t>> fillPayloads;
    std::vector<C2TrackDescriptor> descriptors;
    std::vector<C2TrackSetup> trackSetup;
    // Official C2 app commands reconstructed from the 2026-08-20 capture.
    std::vector<std::uint8_t> configV2PackPayload;
    std::vector<std::vector<std::uint8_t>> channelVolumePayloads; // set_volume [09..0C, vol]
    std::vector<std::vector<std::uint8_t>> int25Payloads;          // generated SET_TRACK_CREATE (int25/0x19) pages
    std::size_t int25BodyBytes = 0;
    std::size_t int25SectionCount = 0;
    bool int25Generated = false;
    // Decoded/generated INT25 schedule retained for factory-style INT26 runtime edits.
    std::vector<C2ScheduleSection> scheduleSections;
    // LEAD resource metadata used by INT25 schedule generation and by the
    // optional manual set_pre_lead protocol-test buttons. V2.3.13 does not use
    // set_pre_lead as part of normal sheet startup.
    bool hasLeadNotes = false;
    std::string leadCard = "sound_c2";
    std::string leadTone = "PianoStudio";
    C2OfficialFlowProfile officialFlowProfile = C2OfficialFlowProfile::None;
    std::vector<C2PreLevelCue> preLevelCues;                     // JSON extension type=10
    std::vector<C2TrackPositionTable> positionTables;              // per-track noteid lookup for arbitrary SET_SHEET_BEAT seek
    std::vector<std::string> warnings;
    float totalBeats = 0.0f;
    float initialBeat = 0.0f;
    int encodedBpm = 0;
    int encodedKey = 0;
    int encodedBnum = 0;
    int firstChordLevel = -1;
    int firstChordType = -1;
    int firstChordTrans12 = 0;
};

class C2MusicEncoder {
public:
    static bool Build(const MDSSong& song, int bpmOverride, C2UploadPlan& plan, std::string& error);
    static std::vector<std::uint8_t> BuildPositionPayload(float beat, std::size_t trackCount,
        const std::vector<std::uint16_t>& noteIndexes = {});
    static std::vector<std::uint8_t> BuildPositionPayloadForPlan(float beat, const C2UploadPlan& plan);
    // Build official 0x1A / INT26 amendments for any scheduled track.
    // allSections=false patches the section containing beat; true patches the
    // selected track in every scheduled section.
    static bool BuildTrackAmendPayloads(const C2UploadPlan& plan, std::uint8_t trackId, float beat, bool allSections,
        const std::string& cardCode, const std::string& toneCode, int volume,
        std::vector<std::vector<std::uint8_t>>& payloads,
        std::vector<std::size_t>& sectionIndexes, std::string& error);
    static bool BuildTrackAmendPayloadsMatchingTone(const C2UploadPlan& plan, std::uint8_t trackId,
        const std::string& matchCardCode, const std::string& matchToneCode,
        const std::string& cardCode, const std::string& toneCode, int volume,
        std::vector<std::vector<std::uint8_t>>& payloads,
        std::vector<std::size_t>& sectionIndexes, std::string& error);
    static bool BuildLeadAmendPayloads(const C2UploadPlan& plan, float beat, bool allSections,
        const std::string& cardCode, const std::string& toneCode, int volume,
        std::vector<std::vector<std::uint8_t>>& payloads,
        std::vector<std::size_t>& sectionIndexes, std::string& error) {
        return BuildTrackAmendPayloads(plan,0,beat,allSections,cardCode,toneCode,volume,payloads,sectionIndexes,error);
    }
    static bool SelfTestUlaan(const MDSSong& song, std::string& report);
};
