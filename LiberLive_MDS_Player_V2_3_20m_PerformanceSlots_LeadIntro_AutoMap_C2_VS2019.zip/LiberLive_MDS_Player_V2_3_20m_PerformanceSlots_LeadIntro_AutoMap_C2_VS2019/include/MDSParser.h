#pragma once
#include "MDSData.h"
#include <filesystem>
#include <string>

class CMDSParser {
public:
    bool LoadFile(const std::filesystem::path& fileName, MDSSong& song, std::string& error) const;
    static MDSStats CalculateStats(const MDSSong& song);
};
