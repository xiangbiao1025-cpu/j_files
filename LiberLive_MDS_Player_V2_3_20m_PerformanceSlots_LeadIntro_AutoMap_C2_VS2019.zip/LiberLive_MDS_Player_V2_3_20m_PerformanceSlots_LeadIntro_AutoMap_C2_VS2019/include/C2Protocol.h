#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace C2CmdId {
constexpr std::uint8_t CREATE_SHEET = 0x06;
constexpr std::uint8_t FILL_SHEET = 0x07;
constexpr std::uint8_t SET_SHEET_BEAT = 0x08;
constexpr std::uint8_t GET_SHEET_BEAT = 0x09;
constexpr std::uint8_t CLOSE_SHEET = 0x0A;
constexpr std::uint8_t SET_TRACK_VOLUME = 0x0B;
constexpr std::uint8_t SET_TRACK_INSTRUMENT = 0x0D;
constexpr std::uint8_t GET_AUTO_PLAY = 0x0F;
constexpr std::uint8_t SET_AUTO_PLAY = 0x10;
constexpr std::uint8_t SET_SECTION_RANGE = 0x16;
// LiberLive 3.7.6 DEX BleMessageCmdType names, cross-checked with btsnoop:
constexpr std::uint8_t SET_TRACK_CREATE = 0x19;  // BLE_MSG_SET_TRACK_CREATE / full track sheet
constexpr std::uint8_t SET_AMEND_TRACK = 0x1A;  // BLE_MSG_SET_AMEND_TRACK / incremental patch
constexpr std::uint8_t GET_TRACK_SHEET = 0x1B;  // BLE_MSG_GET_TRACK_SHEET
constexpr std::uint8_t SET_TRACK_ENABLE = 0x1C; // BLE_MSG_SET_TRACK_ENABLE; payload 01 enables
// Device -> app integer Notify 0x1D+[01], consistently observed after the
// first four staged FILL packets / SET_BEAT=0. Official name is unknown.
constexpr std::uint8_t STAGE_READY_NOTIFY = 0x1D;
}

struct C2DecodedPacket {
    bool fromDevice = false;       // $A = C2 -> PC, $M = PC/App -> C2
    bool intCommand = false;
    std::uint8_t intCmd = 0;
    std::string stringCmd;
    std::vector<std::uint8_t> data;
};

class C2Protocol {
public:
    static std::vector<std::uint8_t> EncodeIntCommand(std::uint8_t cmd,
        const std::vector<std::uint8_t>& data);
    static std::vector<std::uint8_t> EncodeIntCommandWithIv(std::uint8_t cmd,
        const std::vector<std::uint8_t>& data,
        const std::array<std::uint8_t, 12>& iv);
    static std::vector<std::uint8_t> EncodeStringCommand(const std::string& cmd,
        const std::vector<std::uint8_t>& data);
    static std::vector<std::uint8_t> EncodeStringCommandWithIv(const std::string& cmd,
        const std::vector<std::uint8_t>& data,
        const std::array<std::uint8_t, 12>& iv);

    // Generic TLVC decoder. Accepts both $M (PC/App -> C2) and $A (C2 -> PC),
    // and both integer and UTF-8 string commands.
    static bool DecodePacket(const std::vector<std::uint8_t>& packet,
        C2DecodedPacket& decoded, std::string& error);

    // Compatibility helper retained for the uploader self-test.
    static bool DecodeIntCommand(const std::vector<std::uint8_t>& packet,
        std::uint8_t& cmd, std::vector<std::uint8_t>& data, std::string& error);

    static std::string Hex(const std::vector<std::uint8_t>& bytes);
    static bool SelfTest(std::string& report);

private:
    static std::uint8_t Crc8(const std::uint8_t* data, std::size_t len);
    static std::uint16_t Crc16(const std::uint8_t* data, std::size_t len);
    static std::array<std::uint8_t, 12> MakeIv();
};
