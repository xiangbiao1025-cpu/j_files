﻿#pragma once
#include "MDSData.h"
#include <cstddef>
#include <string>
#include <vector>

struct MDSFlatBeat {
    std::size_t segmentIndex = 0;
    int segmentType = 0;
    int bar = 0;
    double beat = 0.0;
    double absoluteBeat = 0.0;
    const MDSBeat* source = nullptr;
};

struct MDSPlaybackTrack {
    int index = 0;              // 0 = beat.notes, >0 = extraTracks[index]
    std::string name;
    int type = -1;
    int volume = 100;
    int mute = 0;
    std::size_t noteCount = 0;
    std::vector<std::size_t> segmentNoteCounts;
};

struct MDSScheduledNote {
    double startBeat = 0.0;
    double endBeat = 0.0;
    int midiNote = 60;
    int velocity = 80;
    int trackIndex = 0;
    int midiChannel = 0;
    std::size_t segmentIndex = 0;
    double sourceBeat = 0.0;
    bool stretch = false;
};

struct MDSSegmentSpan {
    std::size_t segmentIndex = 0;
    int type = 0;
    double startBeat = 0.0;
    double endBeat = 0.0;
    std::size_t bars = 0;
};

struct MDSLyricWordEvent {
    std::size_t segmentIndex = 0;
    double startBeat = 0.0;
    double endBeat = 0.0;
    std::string text;
    bool newLine = false;
    bool stretch = false;
};

struct MDSLyricLine {
    std::size_t segmentIndex = 0;
    double startBeat = 0.0;
    double endBeat = 0.0;
    std::string text;
};

// Playback/perform-mode navigation unit. A "score beat" is one JSON beat
// cell: quarter-note for x/4 meters, eighth-note for x/8 meters. Raw
// note/chord/word start/length values use unit=16/denominator, so e.g. 6/8
// has unit=2 and chord.length=6 spans 3 score beats.
struct MDSChordSection {
    double startBeat = 0.0;
    double endBeat = 0.0;
    std::size_t segmentIndex = 0;
    const MDSBeat* source = nullptr;
};

class CMDSPlayerModel {
public:
    void Build(const MDSSong& song);
    void Clear();
    double TotalBeats() const { return m_totalBeats; }
    int BeatsPerBar() const { return m_beatsPerBar; }
    int BeatDenominator() const { return m_beatDenominator; }
    const std::string& MeterText() const { return m_meterText; }
    double RawUnitsPerScoreBeat() const { return m_rawUnitsPerScoreBeat; }
    double ScoreBeatsPerQuarter() const { return m_scoreBeatsPerQuarter; }
    double RawUnitsToScoreBeats(double rawUnits) const {
        return m_rawUnitsPerScoreBeat > 0.0 ? rawUnits / m_rawUnitsPerScoreBeat : rawUnits / 4.0;
    }
    const std::vector<MDSFlatBeat>& Beats() const { return m_beats; }
    const std::vector<MDSScheduledNote>& Notes() const { return m_notes; }
    const std::vector<MDSSegmentSpan>& Segments() const { return m_segments; }
    const std::vector<MDSPlaybackTrack>& Tracks() const { return m_tracks; }
    const std::vector<MDSLyricWordEvent>& LyricWords() const { return m_lyricWords; }
    const std::vector<MDSLyricLine>& LyricLines() const { return m_lyricLines; }
    const std::vector<MDSChordSection>& ChordSections() const { return m_chordSections; }

    const MDSPlaybackTrack* FindTrack(int trackIndex) const;
    const MDSFlatBeat* FindBeat(double absoluteBeat) const;
    const MDSSegmentSpan* FindSegment(double absoluteBeat) const;
    const MDSLyricLine* FindLyricLine(double absoluteBeat) const;
    const MDSLyricLine* FindNextLyricLine(double absoluteBeat) const;
    std::size_t FindScheduledNoteIndex(double absoluteBeat) const;

    std::size_t SegmentTrackNoteCount(std::size_t segmentIndex, int trackIndex) const;
    std::vector<int> ActiveTrackIndexes(std::size_t segmentIndex) const;

    // Playback mode snaps to chord sections. Edit mode can keep using a finer
    // 1/4-beat grid independently in the UI.
    double SnapToChordSection(double absoluteBeat) const;
    double ChordSectionEnd(double absoluteBeat) const;

    // Legacy helper is retained, but SegmentUsesMainMelodyAt() now treats actual
    // tk0/beat.notes as authoritative in every score class.  Intro/interlude
    // notes are shown and played whenever they really exist in JSON.
    static bool SegmentUsesMainMelody(int segmentType);
    bool SegmentUsesMainMelodyAt(std::size_t segmentIndex) const;
    bool HasOnlyMainMelodyTrack() const { return !m_hasExtraTrackNotes; }

private:
    static int ParseBeatsPerBar(const std::string& beatText);
    static int ParseBeatDenominator(const std::string& beatText);
    static int ToMidiNote(const MDSNote& note);
    static int MidiChannelForTrack(int trackIndex);
    void EnsureTrack(int trackIndex, const std::string& name, int type, int volume, int mute, std::size_t segmentCount);
    void IncrementTrackNoteCount(int trackIndex, std::size_t segmentIndex, std::size_t segmentCount);

    int m_beatsPerBar = 4;
    int m_beatDenominator = 4;
    std::string m_meterText = "4/4";
    double m_rawUnitsPerScoreBeat = 4.0;
    double m_scoreBeatsPerQuarter = 1.0;
    double m_totalBeats = 0.0;
    std::vector<MDSFlatBeat> m_beats;
    std::vector<MDSScheduledNote> m_notes;
    std::vector<MDSSegmentSpan> m_segments;
    std::vector<MDSPlaybackTrack> m_tracks;
    std::vector<MDSLyricWordEvent> m_lyricWords;
    std::vector<MDSLyricLine> m_lyricLines;
    std::vector<MDSChordSection> m_chordSections;
    bool m_hasExtraTrackNotes = false;
};
