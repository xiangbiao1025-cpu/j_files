﻿#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <commdlg.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <fstream>
#include <functional>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cwchar>
#include <filesystem>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <utility>
#include <vector>
#include <winrt/base.h>
#include "MDSParser.h"
#include "C2Controller.h"
#include "PlayerCore.h"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "shell32.lib")

namespace fs = std::filesystem;

static const wchar_t* kClassName = L"LiberLiveMDSPlayerV2318";
static const wchar_t* kViewerClassName = L"LiberLiveMDSViewerV2318";
static const UINT_PTR TIMER_PLAY = 1;
static const UINT_PTR TIMER_PREVIEW_OFF = 2;
static const std::size_t INVALID_SEGMENT = static_cast<std::size_t>(-1);
static constexpr int kBodyTop = 112;
static constexpr UINT WM_APP_C2_STATUS = WM_APP + 41;
static constexpr UINT WM_APP_C2_PROGRESS = WM_APP + 42;
static constexpr UINT WM_APP_C2_DONE = WM_APP + 43;
static constexpr UINT WM_APP_C2_EVENT = WM_APP + 44;

enum ControlId {
    IDC_OPEN = 1001, IDC_PLAY, IDC_PAUSE, IDC_STOP,
    IDC_BPM_EDIT, IDC_BPM_APPLY, IDC_MIDI,
    IDC_SEGMENTS, IDC_TRACKS, IDC_DETAILS, IDC_PROGRESS,
    IDC_INFO, IDC_SEG_LABEL, IDC_TRACK_LABEL,
    IDC_ZOOM_OUT, IDC_ZOOM_IN, IDC_ZOOM_RESET, IDC_ZOOM_LABEL,
    IDC_C2_CONNECT, IDC_C2_DISCONNECT, IDC_C2_UPLOAD, IDC_C2_PLAY, IDC_C2_STOP,
    IDC_C2_UPLOAD_PLAY, IDC_C2_LEAD_ON, IDC_C2_LEAD_AUTO, IDC_C2_LEAD_OFF, IDC_C2_STATUS,
    IDC_C2_VOLUME_STATUS, IDC_C2_BATTERY_STATUS, IDC_TIMBRE_CONFIG, IDC_STYLE_CONFIG, IDC_DEVICE_INFO
};

static HWND g_hwnd = nullptr;
static HWND g_open = nullptr, g_play = nullptr, g_pause = nullptr, g_stop = nullptr;
static HWND g_bpmEdit = nullptr, g_bpmApply = nullptr, g_midiCheck = nullptr;
static HWND g_segments = nullptr, g_tracks = nullptr, g_details = nullptr, g_progress = nullptr, g_info = nullptr;
static HWND g_segLabel = nullptr, g_trackLabel = nullptr;
static HWND g_zoomOut = nullptr, g_zoomIn = nullptr, g_zoomReset = nullptr, g_zoomLabel = nullptr;
static HWND g_c2Connect = nullptr, g_c2Disconnect = nullptr, g_c2Upload = nullptr, g_c2Play = nullptr, g_c2Stop = nullptr, g_c2UploadPlay = nullptr;
static HWND g_c2LeadOn = nullptr, g_c2LeadAuto = nullptr, g_c2LeadOff = nullptr, g_c2Status = nullptr;
static HWND g_c2VolumeStatus = nullptr, g_c2BatteryStatus = nullptr;
static HWND g_timbreConfig = nullptr, g_styleConfig = nullptr, g_deviceInfo = nullptr;
static HFONT g_font = nullptr, g_timelineLyricFont = nullptr;
static MDSSong g_song;
static fs::path g_loadedFilePath;
static CMDSPlayerModel g_model;
static bool g_loaded = false;
static bool g_playing = false;
static bool g_populatingTracks = false;
static double g_positionBeat = 0.0;
static int g_bpm = 80;
static ULONGLONG g_lastTick = 0;
static std::size_t g_nextMidi = 0;
static std::size_t g_currentSegment = INVALID_SEGMENT;
static HMIDIOUT g_midi = nullptr;
static std::array<int,16> g_midiPrograms{}; // GM program currently assigned to each local MIDI channel; -1=unknown
static std::array<int,16> g_midiVolumes{};  // CC7 currently assigned to each local MIDI channel; -1=unknown
static std::map<int, bool> g_trackEnabled;
static std::map<int, int> g_trackOriginalVolume;
static constexpr int kLeadViolinVirtualTrack = -1001; // 逻辑主旋律01：tk0 的 Violin 段
static constexpr int kLeadPianoVirtualTrack  = -1002; // 逻辑主旋律02：tk0 的 PianoStudio 段
// V2.3.20m: four performance-slot rows shown before the note tracks.  They are
// mixer controls, not score note tracks, so they deliberately stay out of
// AllTrackIndexes()/timeline lanes.
static constexpr int kStyleAChordVirtualTrack = -2001;
static constexpr int kStyleBChordVirtualTrack = -2002;
static constexpr int kStyleADrumVirtualTrack  = -2003;
static constexpr int kStyleBDrumVirtualTrack  = -2004;
static constexpr UINT WM_TRACK_VOLUME_DONE = WM_APP + 0x319;
struct TrackVolumeDone { int trackIndex=0; bool requestedEnabled=true; bool ok=false; std::wstring error; };
static ULONGLONG g_lastTimelinePaintTick = 0;
static ULONGLONG g_lastDetailsTick = 0;
static int g_lastProgressPos = -1;

// Adjustable panes + timeline zoom (carried forward into V2.0).
static int g_leftPaneW = 550; // V2.3.20m: show four performance slots + meter/BPM without immediate horizontal scroll
static int g_rightPaneW = 270;
static constexpr int kSplitterW = 7;
static constexpr int kMinPaneW = 170;
static constexpr int kMaxPaneW = 560;
static constexpr int kMinTimelineW = 420;
static bool g_dragLeftSplitter = false;
static bool g_dragRightSplitter = false;
static bool g_dragTimelineCursor = false;
static bool g_cursorUserSelected = false;
static double g_dragTimelineViewStart = 0.0;
static double g_dragTimelineViewSpan = 24.0;
static int g_dragTimelinePlotWidth = 0;
static double g_timelineSpan = 24.0;

// Playback/performance mode selects whole chord sections.  A later editor can
// switch this to Edit without changing the player path and receive a 1/4-beat grid.
enum class TimelineInteractionMode { Performance, Edit };
static TimelineInteractionMode g_timelineMode = TimelineInteractionMode::Performance;

// The visible beat window is independent from the red cursor.  Manual clicking
// therefore moves only the cursor; it no longer recenters the whole score.
static double g_timelineViewStart = 0.0;
static bool g_timelineViewInitialized = false;

struct ActiveMidi {
    int note = 60;
    int channel = 0;
    int trackIndex = 0;
    double endBeat = 0.0;
};
static std::vector<ActiveMidi> g_activeMidi;

enum class C2Action { Connect, Disconnect, Upload, UploadArm, ArmFromCursor, CloseSheet,
    Melody100, Melody50, Melody0, DeviceInfo };
struct C2DoneMessage { bool ok = false; std::wstring error; C2Action action = C2Action::Connect; double completionBeat = -1.0; };
static C2Controller g_c2;
static std::atomic<bool> g_c2Busy{false};
static std::mutex g_c2LogMutex;
static fs::path g_c2UploadSessionLogPath;
// V2.3.20i1: keep the per-upload log detailed, but throttle the one-line UI
// progress display to roughly one update per 50 logical FILLs.
static std::atomic<int> g_c2UiProgressBucket{-1};
static bool g_hasC2Beat = false;
static double g_lastC2RawBeat = 0.0;

// C2 performance UI is trigger-gated: an accepted physical chord starts smooth
// BPM-speed travel through that chord section; the cursor stops exactly at the
// next chord section boundary until C2 reports the next accepted trigger.
static bool g_c2PerformanceArmed = false;
static bool g_c2FlowRunning = false;
static double g_c2FlowStopBeat = 0.0;
static ULONGLONG g_c2FlowLastTick = 0;

// The C2-reported sheet beat is the authoritative acceptance/synchronization
// signal. A repeated/wrong physical action normally leaves this beat unchanged;
// only a first trigger or an actually advanced beat can restart the visual flow.
// This avoids both V2.3.10's "any pick advances" bug and V2.3.11's false local
// chord-check deadlocks while C2 itself is visibly continuing.
static bool g_c2HaveAcceptedDeviceBeat = false;
static double g_c2AcceptedDeviceBeat = 0.0;
static ULONGLONG g_c2LastAcceptedTriggerTick = 0;

static int g_lastC2Row = -1, g_lastC2Col = -1, g_lastC2Level = -1;
static int g_lastC2ChordType = -1, g_lastC2Trans12 = -1, g_lastC2PickId = -1;

// Forward declarations: DeviceCenterProc is defined before the main track/details
// refresh helpers, but it needs to refresh those views after an INT26 edit completes.
static void PopulateTracksForSegment(std::size_t segmentIndex);
static void UpdateDetails();
static bool FindC2Type13Lead(std::string& card,std::string& tone);
static bool HasDualMainMelody();
static bool LeadVirtualInfo(int virtualTrack,std::string& card,std::string& tone);
static bool SegmentUsesLeadVirtual(std::size_t segmentIndex,int virtualTrack);
static bool RuntimeScheduleForModelTrack(int trackIndex,std::string& card,std::string& tone,int& volume);

static std::wstring Utf8ToWide(const std::string& s) {
    if (s.empty()) return {};
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), nullptr, 0);
    if (n <= 0) return {};
    std::wstring w(static_cast<std::size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), w.data(), n);
    return w;
}

static std::string WideToUtf8(const std::wstring& w) {
    if (w.empty()) return {};
    const int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), static_cast<int>(w.size()), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return {};
    std::string s(static_cast<std::size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), static_cast<int>(w.size()), s.data(), n, nullptr, nullptr);
    return s;
}

struct ViewerPayload {
    std::wstring title;
    std::wstring text;
};

static LRESULT CALLBACK ViewerProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        const auto* cs=reinterpret_cast<const CREATESTRUCTW*>(lp);
        std::unique_ptr<ViewerPayload> payload(reinterpret_cast<ViewerPayload*>(cs->lpCreateParams));
        if (payload) SetWindowTextW(hwnd,payload->title.c_str());
        HWND edit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",payload?payload->text.c_str():L"",
            WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL|ES_AUTOHSCROLL,
            0,0,0,0,hwnd,reinterpret_cast<HMENU>(1),GetModuleHandleW(nullptr),nullptr);
        if (edit) SendMessageW(edit,WM_SETFONT,reinterpret_cast<WPARAM>(g_font),TRUE);
        SetWindowLongPtrW(hwnd,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(edit));
        return 0;
    }
    case WM_SIZE: {
        HWND edit=reinterpret_cast<HWND>(GetWindowLongPtrW(hwnd,GWLP_USERDATA));
        if (edit) MoveWindow(edit,8,8,std::max<int>(40,LOWORD(lp)-16),std::max<int>(40,HIWORD(lp)-16),TRUE);
        return 0;
    }
    case WM_CLOSE:
        // Generic text viewer has no DeviceCenterState.  V2.3.15d accidentally
        // copied the device-center taskRunning guard into ViewerProc, which made
        // VS2019 fail to compile here because the device-center state pointer is not in scope.
        DestroyWindow(hwnd); return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}

static void ShowTextViewer(const std::wstring& title,const std::wstring& text) {
    WNDCLASSW wc{};
    if (!GetClassInfoW(GetModuleHandleW(nullptr),kViewerClassName,&wc)) {
        wc.lpfnWndProc=ViewerProc;
        wc.hInstance=GetModuleHandleW(nullptr);
        wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);
        wc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_WINDOW+1);
        wc.lpszClassName=kViewerClassName;
        RegisterClassW(&wc);
    }
    auto* payload=new ViewerPayload{title,text};
    RECT owner{}; if (g_hwnd) GetWindowRect(g_hwnd,&owner);
    const int ww=820, hh=650;
    const int x=g_hwnd ? owner.left+std::max<int>(0,(owner.right-owner.left-ww)/2) : CW_USEDEFAULT;
    const int y=g_hwnd ? owner.top+std::max<int>(0,(owner.bottom-owner.top-hh)/2) : CW_USEDEFAULT;
    HWND w=CreateWindowExW(WS_EX_TOOLWINDOW,kViewerClassName,title.c_str(),WS_OVERLAPPEDWINDOW|WS_VISIBLE,
        x,y,ww,hh,g_hwnd,nullptr,GetModuleHandleW(nullptr),payload);
    if (!w) delete payload;
}

static std::wstring AssetListText(const std::vector<MDSAssetNote>& assets) {
    std::wstring out;
    for (std::size_t i=0;i<assets.size();++i) {
        if (i) out+=L", ";
        out+=Utf8ToWide(assets[i].timbreCardCode)+L":"+Utf8ToWide(assets[i].noteCode);
    }
    return out.empty()?L"(无)":out;
}

static std::wstring BuildTimbreConfigText() {
    if (!g_loaded) return L"请先打开 JSON。";
    std::wostringstream os;
    os << L"LiberLive 音色配置查看（V2.3.18：曲谱多轨可在“设备”中用 INT26 编辑）\r\n\r\n";
    os << L"歌曲: " << Utf8ToWide(g_song.title) << L"\r\n";
    os << L"设备模型: " << Utf8ToWide(g_song.content.baseConfig.model) << L"\r\n";
    os << L"主旋律 melodicNote: " << (g_song.content.melodicNote.empty()?L"(空)":Utf8ToWide(g_song.content.melodicNote)) << L"\r\n\r\n";
    os << L"[trackConfigs]\r\n";
    if (g_song.content.trackConfigs.empty()) os << L"当前 JSON 无 trackConfigs；主旋律来自 beat.notes。\r\n";
    for (const auto& t:g_song.content.trackConfigs) {
        os << L"Track " << t.index << L"  名称=" << Utf8ToWide(t.name)
           << L"  type=" << t.type << L"  volume=" << t.volume << L"  mute=" << t.mute << L"\r\n"
           << L"    assets: " << AssetListText(t.assetNotes) << L"\r\n";
    }
    os << L"\r\n[时间轴 type13 音色事件]\r\n";
    int count=0;
    for (std::size_t si=0;si<g_song.content.lyrics.size();++si) {
        const auto& seg=g_song.content.lyrics[si];
        for (std::size_t bi=0;bi<seg.bars.size();++bi) {
            for (std::size_t bei=0;bei<seg.bars[bi].beats.size();++bei) {
                const auto& beat=seg.bars[bi].beats[bei];
                for (const auto& ex:beat.extensions) if (ex.type=="13") {
                    ++count;
                    os << L"段" << si << L" bar=" << seg.bars[bi].bar << L" beat=" << beat.beat
                       << L" start=" << ex.start << L" length=" << ex.length
                       << L"  " << Utf8ToWide(ex.cardCode) << L":" << Utf8ToWide(ex.code) << L"\r\n";
                }
            }
        }
    }
    if (!count) os << L"(无 type13)\r\n";
    os << L"\r\n下一阶段会把这里改成视频中的可编辑轨道卡片：音色类别/具体音色/音量/静音。";
    return os.str();
}

static void AppendConfigEntry(std::wostringstream& os,const wchar_t* group,std::size_t i,const MDSConfigEntry& e) {
    os << group << L"[" << i << L"] pickType=" << e.pickType << L" action=" << e.pickAction
       << L" card=" << Utf8ToWide(e.cardCode) << L" name=" << Utf8ToWide(e.nameCode)
       << L" bpmRate=" << e.bpmRate << L" pickVol=" << e.pickVolume
       << L" bassVol=" << e.bassVolume << L" star=" << e.star << L"\r\n";
}

static std::wstring BuildStyleConfigText() {
    if (!g_loaded) return L"请先打开 JSON。";
    const auto& b=g_song.content.baseConfig;
    const auto& cp=b.configPack;
    std::wostringstream os;
    os << L"LiberLive 风格包配置查看（V2.3.18：JSON详情；设备写入请进“设备”）\r\n\r\n";
    os << L"歌曲: " << Utf8ToWide(g_song.title) << L"\r\n"
       << L"model=" << Utf8ToWide(b.model) << L"  configType=" << Utf8ToWide(b.configType)
       << L"  defaultLevel=" << b.defaultLevel << L"\r\n"
       << L"beat=" << Utf8ToWide(b.beat) << L"  bpm=" << b.bpm << L"  tone=" << Utf8ToWide(b.tone) << L"\r\n"
       << L"configPack parsed=" << (cp.parsed?L"yes":L"no") << L"\r\n\r\n";
    os << L"[A/B 和弦/拨片槽]\r\n";
    for (std::size_t i=0;i<cp.chords.size();++i) AppendConfigEntry(os,L"chord",i,cp.chords[i]);
    if (cp.chords.empty()) os << L"(无)\r\n";
    os << L"\r\n[鼓组槽]\r\n";
    for (std::size_t i=0;i<cp.drums.size();++i) AppendConfigEntry(os,L"drum",i,cp.drums[i]);
    if (cp.drums.empty()) os << L"(无)\r\n";
    os << L"\r\n[instrument]\r\n";
    for (std::size_t i=0;i<cp.instrument.size();++i) AppendConfigEntry(os,L"ins",i,cp.instrument[i]);
    if (cp.instrument.empty()) os << L"(无)\r\n";
    int n3=0,n7=0,n10=0,n12=0;
    for (const auto& seg:g_song.content.lyrics) for (const auto& bar:seg.bars) for (const auto& beat:bar.beats)
        for (const auto& ex:beat.extensions) { if (ex.type=="3") ++n3; else if (ex.type=="7") ++n7; else if (ex.type=="10") ++n10; else if (ex.type=="12") ++n12; }
    os << L"\r\n时间轴风格事件: type3(A/B鼓/伴奏切换)=" << n3 << L"  type7(拨片槽)=" << n7
       << L"  type10(Level)=" << n10 << L"  type12(鼓资源/旧格式)=" << n12 << L"\r\n";
    os << L"\r\n下一阶段会按视频做成可编辑风格包页，并支持保存自定义配置。";
    return os.str();
}

static void PostC2Status(const std::wstring& text);
static void UpdateC2StateLabels();
static void UpdateC2Buttons();
static std::wstring StyleMeterName(int meterEnum);

static std::wstring BuildDeviceInfoText() {
    const C2DeviceState st=g_c2.DeviceState();
    std::wostringstream os;
    os << L"LiberLive C2 设备中心 / V2.3.20m PerformanceSlots/LeadIntro/AutoMap + DrumCue/MasterBPM/PerTrackMIDI + 460B WR-Pack + UIProgress50 + 6/8 MeterTimingFix + ResourceCatalog + V2Basic Slots + INT26\r\n\r\n";
    os << L"连接: " << (g_c2.IsConnected()?L"已连接":L"未连接") << L"\r\n";
    os << L"Battery: " << (st.battery>=0?std::to_wstring(st.battery)+L"%":L"--")
       << L"  charging=" << (st.charging?L"yes":L"no") << L"  chargeState=" << st.chargeState << L"\r\n";
    os << L"Basic: key=" << st.key << L" bpm=" << st.bpm << L" systemVol=" << st.systemVolume << L" mode=" << st.mode << L"\r\n";
    os << L"设备页旋律音色: " << (st.currentToneCard.empty()?L"--":Utf8ToWide(st.currentToneCard))
       << L":" << (st.currentTone.empty()?L"--":Utf8ToWide(st.currentTone)) << L"\r\n";
    const std::string slotCodes[4]={st.chordStyleA,st.chordStyleB,st.drumStyleA,st.drumStyleB};
    static const wchar_t* slotNames[4]={L"A拨片和弦资源",L"B拨片和弦资源",L"A鼓资源",L"B鼓资源"};
    for (int i=0;i<4;++i) {
        os << slotNames[i] << L": " << (slotCodes[i].empty()?L"--":Utf8ToWide(slotCodes[i]));
        if (st.basicStyleBpm[static_cast<std::size_t>(i)]>=0) {
            os << L"  [C2槽 BPM=" << st.basicStyleBpm[static_cast<std::size_t>(i)]
               << L" 拍号=" << StyleMeterName(st.basicStyleMeter[static_cast<std::size_t>(i)]) << L"]";
        }
        os << L"\r\n";
    }
    os << L"\r\n";
    static const wchar_t* labels[14]={L"",L"总音量",L"鼓",L"ch03",L"贝斯",L"ch05(非sheet tk0增益)",L"ch06",L"ch07",L"ch08",L"A拨片",L"B拨片",L"A鼓(高可信)",L"B鼓(高可信)",L"琶音"};
    os << L"[Mixer get_volume]\r\n";
    for (int ch=1;ch<=13;++ch) {
        os << L"0x" << std::hex << std::uppercase << ch << std::dec << L" " << labels[ch] << L" = ";
        if (st.mixer[static_cast<std::size_t>(ch)]>=0) os << st.mixer[static_cast<std::size_t>(ch)]; else os << L"--";
        os << L"\r\n";
    }
    os << L"\r\n[演奏偏好 / Style Settings：get_style_settings / set_style_settings]\r\n";
    static const wchar_t* styleWireNotes[8]={L"",L"STAR_A / A拨片细节增强?",L"STAR_B / B拨片细节增强?",L"PREVIEW_C / 变调旋钮候选",L"PREVIEW_D / 变调旋钮候选",L"ABASS_EN / 独立演奏偏好",L"BPMLOCK / BPM锁定?",L"PREV_BPMLOCK / 试听BPM锁定?"};
    for (int type=1;type<=7;++type) {
        os << L"raw type " << type << L"  " << styleWireNotes[type] << L" = ";
        const int v=st.styleSettings[static_cast<std::size_t>(type)];
        os << (v>=0?std::to_wstring(v):L"--") << L"\r\n";
    }
    os << L"证据说明: APK 已确认 StyleSettingType 含 STAR_A/STAR_B/PREVIEW_C/PREVIEW_D/ABASS_EN/BPMLOCK/PREV_BPMLOCK；BPM锁定开关确实经 setStyleSetting2 -> set_style_settings。\r\n";
    os << L"wire type 数字与上述枚举的逐项绑定仍需实机闭环；因此界面保留 raw value 数值，不再把 Type1..6 当成六个 boolean。\r\n";
    os << L"\r\n[GET/SET_AUTO_PLAY 0x0F/0x10]\r\n";
    // V2.3.20m / 2026-09-04 real-device differential captures.  SET_AUTO_PLAY
    // wire type is a separate namespace from JSON extensions.type.
    static const wchar_t* autoLabels[8]={L"",L"主自动播放/演奏模式",L"鼓机自动挂挡许可",L"自动转调（真机确认）",L"未标定/保留",L"SOLO/演奏模式相关",L"聪明模式（真机确认）",L"未确认/保留"};
    for (int type=1;type<=7;++type) {
        const int v=st.autoPlay[static_cast<std::size_t>(type)];
        os << L"type " << type << L" " << autoLabels[type] << L" = " << (v>=0?std::to_wstring(v):L"--") << L"\r\n";
    }
    os << L"2026-09-04 真机差分: SET_AUTO_PLAY 01=主自动播放/演奏模式，02=鼓机自动挂挡许可，03=自动转调，05=Solo/演奏模式相关，06=聪明模式；04 未标定。C2 多档换挡本次抓包经 set_pre_level 执行。JSON extensions.type 与这里是两个独立编号空间。\r\n";
    os << L"\r\n[get_vers_all]\r\n" << (st.versions.empty()?L"(未读取)":st.versions) << L"\r\n\r\n";
    os << L"[get_midi_info]\r\n" << (st.midiInfo.empty()?L"(未读取)":st.midiInfo) << L"\r\n\r\n";
    os << L"[get_config_v2basic]\r\n" << (st.configBasic.empty()?L"(未读取)":st.configBasic) << L"\r\n\r\n";
    os << L"[get_sys_onoff type06]\r\n" << (st.sysOnOff.empty()?L"(未读取)":st.sysOnOff) << L"\r\n\r\n";
    os << L"[原始查询回包]\r\n";
    if (st.rawRepliesText.empty()) os << L"(未读取)\r\n";
    else os << st.rawRepliesText;
    return os.str();
}

// Verified C2 tone catalogue reconstructed from the 2026-08-28 factory device-page
// capture. Each selection emitted set_fret_instru + set_lead_preview with the
// card/code below; the synthesizer Chinese labels follow the factory list order.
struct C2ToneChoice {
    const wchar_t* category;
    const wchar_t* name;
    const char* card;
    const char* code;
};

static const C2ToneChoice kC2ToneChoices[] = {
    {L"吉他",L"尼龙吉他","sound_c2","GuitarN"},
    {L"吉他",L"民谣吉他","sound_c2","GuitarS"},
    {L"钢琴",L"复古电钢琴","sound_c2","PianoMKS20"},
    {L"钢琴",L"现代电钢琴","sound_c2","PianoRhodesWarm"},
    {L"钢琴",L"大钢琴","sound_c2","PianoStudio"},
    {L"键盘类",L"80s电钢琴","scard_01","MK80"},
    {L"键盘类",L"手风琴","scard_01","Accordion"},
    {L"键盘类",L"迷离电钢琴","scard_01","EP1"},
    {L"键盘类",L"饱满电钢琴","scard_01","EP2"},
    {L"键盘类",L"管风琴","scard_01","Organ"},
    {L"键盘类",L"数字电钢琴","scard_01","PianoDance"},
    {L"键盘类",L"冷感电钢琴","scard_01","PianoEDM"},
    {L"键盘类",L"弦乐电钢琴","scard_01","PianoStrings"},
    {L"弓弦类",L"大提琴","scard_01","Cello"},
    {L"弓弦类",L"二胡","scard_01","Erhu1"},
    {L"弓弦类",L"温暖弦乐组","scard_01","StringSet1"},
    {L"弓弦类",L"治愈提琴","scard_01","StringSet2"},
    {L"弓弦类",L"中提琴","scard_01","Viola"},
    {L"弓弦类",L"小提琴","scard_01","Violin"},
    {L"吹奏类",L"笛子","scard_01","Dizi"},
    {L"吹奏类",L"排箫","scard_01","PanFlute"},
    {L"吹奏类",L"竖笛","scard_01","Recorder"},
    {L"吹奏类",L"萨克斯","scard_01","Saxophone"},
    {L"吹奏类",L"尺八","scard_01","Shakuhachi"},
    {L"吹奏类",L"小号","scard_01","Trumpet"},
    {L"拨弦类",L"明亮民谣吉他","scard_01","AGsolo1"},
    {L"拨弦类",L"指弹民谣吉他","scard_01","AGsolo2"},
    {L"拨弦类",L"硬核冲击电吉他","scard_01","EGsolo1"},
    {L"拨弦类",L"温暖摇滚电吉他","scard_01","EGsolo2"},
    {L"拨弦类",L"古筝","scard_01","Guzheng"},
    {L"拨弦类",L"古典尼龙吉他","scard_01","LGsolo1"},
    {L"拨弦类",L"爵士尼龙吉他","scard_01","LGsolo2"},
    {L"拨弦类",L"琵琶","scard_01","Pipa"},
    {L"拨弦类",L"三味线","scard_01","Shamisen"},
    {L"拨弦类",L"齐特琴","scard_01","Zither"},
    {L"合成器",L"云端疾走","scard_01","Synth3"},
    {L"合成器",L"复音合成器","scard_01","80sPolySynth"},
    {L"合成器",L"复古电铜管","scard_01","80sSynthBrass"},
    {L"合成器",L"都市跃动","scard_01","AlivePluck"},
    {L"合成器",L"刺眼灯光","scard_01","BlindingLead"},
    {L"合成器",L"扭曲弹簧","scard_01","JeDanseSynth"},
    {L"合成器",L"水滴弹跳","scard_01","KettlePluck"},
    {L"合成器",L"梦核键盘","scard_01","Key1"},
    {L"合成器",L"光晕键盘","scard_01","Key2"},
    {L"合成器",L"复古灯笼","scard_01","Lead1"},
    {L"合成器",L"紧绷回弹","scard_01","Lead2"},
    {L"合成器",L"电子马林巴","scard_01","MarimbaPluck"},
    {L"合成器",L"梦幻月亮船","scard_01","MoonSailor"},
    {L"合成器",L"新灵魂乐氛围","scard_01","NeoSoulPad"},
    {L"合成器",L"地下浴室氛围","scard_01","OrganBass"},
    {L"合成器",L"沙砾回声氛围","scard_01","Pad1"},
    {L"合成器",L"金属呼吸氛围","scard_01","Pad2"},
    {L"合成器",L"无瑕纯净氛围","scard_01","PerfectPad"},
    {L"合成器",L"千禧复古氛围","scard_01","PolyRecPad"},
    {L"合成器",L"开盖汽水","scard_01","SavannahPluck"},
    {L"合成器",L"电子派对","scard_01","SawLead"},
    {L"合成器",L"无人之境氛围","scard_01","SolinaPad"},
    {L"合成器",L"深邃穿梭","scard_01","StayKey"},
    {L"合成器",L"夏日钟琴","scard_01","SummerBell"},
    {L"合成器",L"低音浪","scard_01","Synth1"},
    {L"合成器",L"电子爆弹","scard_01","Synth2"},
    {L"合成器",L"未来弦乐","scard_01","Synth4"},
    {L"合成器",L"像素游戏","scard_01","SynthLead"},
    {L"合成器",L"弦乐木管氛围","scard_01","ViolinsFlutePad"},
    {L"合成器",L"声码器","scard_01","VocoderLead"},
    {L"合成器",L"颤晕蛙鸣","scard_01","WobbleSynth"}
};

static constexpr int kC2ToneChoiceCount=static_cast<int>(sizeof(kC2ToneChoices)/sizeof(kC2ToneChoices[0]));

static std::wstring ToneChoiceText(const C2ToneChoice& t) {
    return L"["+std::wstring(t.category)+L"] "+t.name+L" | "+Utf8ToWide(t.card)+L":"+Utf8ToWide(t.code);
}

static void FillToneCombo(HWND combo) {
    if (!combo) return;
    SendMessageW(combo,CB_RESETCONTENT,0,0);
    for (int i=0;i<kC2ToneChoiceCount;++i) {
        const std::wstring text=ToneChoiceText(kC2ToneChoices[i]);
        SendMessageW(combo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text.c_str()));
    }
}

static int FindToneChoiceIndex(const std::string& card,const std::string& code) {
    for (int i=0;i<kC2ToneChoiceCount;++i)
        if (card==kC2ToneChoices[i].card && code==kC2ToneChoices[i].code) return i;
    return -1;
}

static bool SelectedTone(HWND combo,std::string& card,std::string& code,std::wstring& label) {
    const int sel=static_cast<int>(SendMessageW(combo,CB_GETCURSEL,0,0));
    if (sel<0 || sel>=kC2ToneChoiceCount) return false;
    const auto& t=kC2ToneChoices[sel]; card=t.card; code=t.code; label=ToneChoiceText(t); return true;
}

static std::wstring C2TrackTypeName(std::uint8_t type) {
    switch (type) { case 1:return L"LEAD 主旋律"; case 2:return L"CHORD 和弦"; case 3:return L"SUBLEAD 加花"; case 4:return L"PAD 铺底"; case 5:return L"EVENT 事件"; default:return L"TYPE"+std::to_wstring(type); }
}

static bool FirstTrackScheduleState(std::uint8_t trackId,std::string& card,std::string& tone,int& volume,std::size_t& sections) {
    card.clear(); tone.clear(); volume=80; sections=0;
    if (!g_c2.HasUploadedSheet()) return false;
    const auto& plan=g_c2.LastPlan();

    // Count every section containing the track, but prefer the PC red-line's
    // current section for the displayed tone/volume. This makes a "当前段"
    // INT26 edit immediately visible both in Device Center and "全部轨道".
    for (const auto& sec:plan.scheduleSections) {
        bool have=false;
        for (const auto& t:sec.tracks) if (t.trackId==trackId) { have=true; break; }
        if (have) ++sections;
    }
    if (g_currentSegment<plan.scheduleSections.size()) {
        for (const auto& t:plan.scheduleSections[g_currentSegment].tracks) if (t.trackId==trackId) {
            card=t.cardCode; tone=t.noteCode; volume=t.volume;
            return !card.empty() && !tone.empty();
        }
    }
    for (const auto& sec:plan.scheduleSections) for (const auto& t:sec.tracks) if (t.trackId==trackId) {
        card=t.cardCode; tone=t.noteCode; volume=t.volume;
        return !card.empty() && !tone.empty();
    }
    return false;
}

static void FillTrackCombo(HWND combo) {
    if (!combo) return;
    const int oldSel=static_cast<int>(SendMessageW(combo,CB_GETCURSEL,0,0));
    int oldTrack=-9999; if (oldSel!=CB_ERR) oldTrack=static_cast<int>(SendMessageW(combo,CB_GETITEMDATA,oldSel,0));
    SendMessageW(combo,CB_RESETCONTENT,0,0);
    if (!g_c2.HasUploadedSheet()) return;
    const auto& plan=g_c2.LastPlan();

    if (HasDualMainMelody()) {
        std::uint32_t leadNoteCount=0;
        for (const auto& d:plan.descriptors) if (d.tkid==0) { leadNoteCount=d.noteCount; break; }
        for (int vtrack : {kLeadViolinVirtualTrack,kLeadPianoVirtualTrack}) {
            std::string card,tone; int vol=80;
            RuntimeScheduleForModelTrack(vtrack,card,tone,vol);
            const std::wstring role=(vtrack==kLeadViolinVirtualTrack)?L"主旋律01":L"主旋律02";
            const std::wstring text=role+L"  tk0分组  "+Utf8ToWide(card)+L":"+Utf8ToWide(tone)+L"  vol="+std::to_wstring(vol);
            const int idx=static_cast<int>(SendMessageW(combo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text.c_str())));
            SendMessageW(combo,CB_SETITEMDATA,idx,vtrack);
            if (oldTrack==vtrack) SendMessageW(combo,CB_SETCURSEL,idx,0);
        }
    }

    for (const auto& d:plan.descriptors) {
        if (HasDualMainMelody() && d.tkid==0) continue;
        std::string card,tone; int vol=80; std::size_t sections=0;
        if (!FirstTrackScheduleState(d.tkid,card,tone,vol,sections)) continue;
        const std::wstring role=C2TrackTypeName(d.type);
        std::wstring text=L"tk"+std::to_wstring(d.tkid)+L"  "+role+L"  notes="+std::to_wstring(d.noteCount)+L"  "+Utf8ToWide(card)+L":"+Utf8ToWide(tone);
        const int idx=static_cast<int>(SendMessageW(combo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(text.c_str())));
        SendMessageW(combo,CB_SETITEMDATA,idx,d.tkid);
        if (oldTrack==d.tkid) SendMessageW(combo,CB_SETCURSEL,idx,0);
    }
    if (SendMessageW(combo,CB_GETCURSEL,0,0)==CB_ERR && SendMessageW(combo,CB_GETCOUNT,0,0)>0) SendMessageW(combo,CB_SETCURSEL,0,0);
}


// -----------------------------------------------------------------------------
// V2.3.20b A/B chord-pick + drum resource catalog presentation.
// The 4.7.6 song library proves family/code usage, while only the later BLE
// resource records contain audition/reference BPM + meter metadata. Never feed these
// values into the score master BPM. Unknown/post-added resources
// are explicitly marked 待补测.
// -----------------------------------------------------------------------------
struct StyleResourceMeasuredMeta {
    const char* code;
    int bpm;
    const wchar_t* meter;
    const wchar_t* exactZh;
};

static const StyleResourceMeasuredMeta kStyleMeasuredMeta[] = {
    {"PianoStudio_84",54,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"GEC2_22",54,L"4/4",L"清音电吉他（具体Pattern名待定）"},
    {"PianoStudio_85",54,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"GS_40",54,L"4/4",L"民谣吉他（具体Pattern名待定）"},
    {"GN_19",70,L"4/4",L"尼龙吉他（具体Pattern名待定）"},
    {"GN_20",70,L"4/4",L"尼龙吉他（具体Pattern名待定）"},
    {"PianoStudio_86",70,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"PianoStudio_87",70,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"GEC1_22",70,L"4/4",L"清音电吉他（具体Pattern名待定）"},
    {"GN_21",70,L"4/4",L"尼龙吉他（具体Pattern名待定）"},
    {"PianoStudio_88",70,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"PianoStudio_89",70,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"GN_22",70,L"4/4",L"尼龙吉他（具体Pattern名待定）"},
    {"PianoStudio_90",70,L"4/4",L"大钢琴（具体Pattern名待定）"},
    {"GEC1_19",97,L"4/4",L"明亮清音电吉他·分解拍弦（强候选）"},
    {"PianoStudio_81",82,L"6/8",L"大钢琴（具体Pattern名待定）"},
    {"GS_33",82,L"6/8",L"民谣吉他（具体Pattern名待定）"},
    {"GS_34",82,L"6/8",L"民谣吉他（具体Pattern名待定）"},
    {"GS_35",82,L"6/8",L"民谣吉他（具体Pattern名待定）"},
    {"GS_36",82,L"6/8",L"民谣吉他（具体Pattern名待定）"},
    {"PianoStudio_82",82,L"6/8",L"大钢琴（具体Pattern名待定）"},
    {"GEC2_18",82,L"6/8",L"清音电吉他（具体Pattern名待定）"},
    {"GED2_7",82,L"6/8",L"过载电吉他（具体Pattern名待定）"},
    {"GS_37",82,L"6/8",L"民谣吉他（具体Pattern名待定）"},
    {"PianoStudio_83",82,L"6/8",L"大钢琴（具体Pattern名待定）"},
    {"Cajon_ChapMen_16",82,L"6/8",L"卡宏鼓（具体Pattern名待定）"},
    {"Cajon_ChapMen_17",82,L"6/8",L"卡宏鼓（具体Pattern名待定）"},
    {"POP_ChapMen_15",82,L"6/8",L"流行鼓组（具体Pattern名待定）"},
    {"POP_ChapMen_16",82,L"6/8",L"流行鼓组（具体Pattern名待定）"},
    {"POP_ChapMen_17",82,L"6/8",L"流行鼓组（具体Pattern名待定）"},
    {"POP_ChapMen_18",82,L"6/8",L"流行鼓组（具体Pattern名待定）"},
    {"POP_ChapMen_19",82,L"6/8",L"流行鼓组（具体Pattern名待定）"},
    {"GN_18",112,L"4/4",L"尼龙吉他（具体Pattern名待定）"},
    {"GEC1_20",112,L"4/4",L"清音电吉他（具体Pattern名待定）"},
    {"GS_44",112,L"4/4",L"民谣吉他（具体Pattern名待定）"},
    {"GEC2_26",112,L"4/4",L"清音电吉他（具体Pattern名待定）"},
    {"GS_45",112,L"4/4",L"民谣吉他（具体Pattern名待定）"},
    {"GEC1_21",112,L"4/4",L"清音电吉他（具体Pattern名待定）"}
};

static std::string StripStyleResourcePrefix(std::string v) {
    const std::string p="sound_c2:";
    if (v.rfind(p,0)==0) v.erase(0,p.size());
    return v;
}

static std::string FullStyleResourceCode(std::string v) {
    while (!v.empty() && (v.front()==' ' || v.front()=='\t')) v.erase(v.begin());
    while (!v.empty() && (v.back()==' ' || v.back()=='\t')) v.pop_back();
    if (!v.empty() && v.find(':')==std::string::npos) v="sound_c2:"+v;
    return v;
}


// -----------------------------------------------------------------------------
// V2.3.20c resource master catalogue.
// Runtime uses a UTF-8 CSV exported from LiberLive_C2_Resource_Master_Evidence.xlsx.
// Only ACCEPTED_EXACT resources are exported, so rejected/fallback probe numbers
// never pollute the normal A/B chord/drum resource lists.
// -----------------------------------------------------------------------------
struct StyleResourceCatalogEntry {
    bool drum=false;
    std::string family;
    int number=-1;
    std::string code;
    std::wstring familyZh;
    std::wstring uiCategory;
    std::wstring exactZh;
    std::wstring displayZh;
    std::wstring nameLevel;
    int bpm=-1;
    int meterEnum=-1;
    std::wstring paramLevel;
    std::string paramSource;
    std::wstring evidenceGrade;
    bool trustedWriteParams=false;
};

static std::vector<StyleResourceCatalogEntry> g_styleResourceCatalog;
static bool g_styleResourceCatalogLoadAttempted=false;
static fs::path g_styleResourceCatalogPath;

static fs::path ExecutableDirectory() {
    std::vector<wchar_t> buf(32768,L'\0');
    const DWORD n=GetModuleFileNameW(nullptr,buf.data(),static_cast<DWORD>(buf.size()));
    if (!n || n>=buf.size()) return fs::current_path();
    return fs::path(std::wstring(buf.data(),n)).parent_path();
}

static fs::path ResolveStyleResourceCatalogPath() {
    const fs::path exe=ExecutableDirectory();
    const fs::path cwd=fs::current_path();
    const wchar_t* fn=L"C2_Resource_Catalog.csv";
    const fs::path candidates[]={
        exe/L"data"/fn,
        exe/fn,
        exe/L".."/L".."/L".."/L"data"/fn, // $(SolutionDir)bin\\$(Platform)\\$(Configuration)
        cwd/L"data"/fn,
        cwd/fn
    };
    std::error_code ec;
    for (const auto& p:candidates) {
        const fs::path q=p.lexically_normal();
        if (fs::exists(q,ec) && !ec) return q;
        ec.clear();
    }
    return {};
}

static std::vector<std::string> ParseCsvRow(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    bool quoted=false;
    for (std::size_t i=0;i<line.size();++i) {
        const char ch=line[i];
        if (quoted) {
            if (ch=='"') {
                if (i+1<line.size() && line[i+1]=='"') { cur.push_back('"'); ++i; }
                else quoted=false;
            } else cur.push_back(ch);
        } else {
            if (ch=='"') quoted=true;
            else if (ch==',') { out.push_back(cur); cur.clear(); }
            else if (ch!='\r') cur.push_back(ch);
        }
    }
    out.push_back(cur);
    return out;
}

static int ParseCatalogInt(const std::string& s,int fallback=-1) {
    if (s.empty()) return fallback;
    try { return std::stoi(s); } catch (...) { return fallback; }
}

static int CatalogMeterEnum(const std::string& meter) {
    if (meter=="3/4") return 0;
    if (meter=="4/4") return 1;
    if (meter=="6/8") return 3;
    return -1;
}

static bool LoadStyleResourceCatalog() {
    if (g_styleResourceCatalogLoadAttempted) return !g_styleResourceCatalog.empty();
    g_styleResourceCatalogLoadAttempted=true;
    g_styleResourceCatalogPath=ResolveStyleResourceCatalogPath();
    if (g_styleResourceCatalogPath.empty()) return false;

    std::ifstream f(g_styleResourceCatalogPath,std::ios::binary);
    if (!f) return false;
    std::string line;
    if (!std::getline(f,line)) return false;
    if (line.size()>=3 && static_cast<unsigned char>(line[0])==0xEF &&
        static_cast<unsigned char>(line[1])==0xBB && static_cast<unsigned char>(line[2])==0xBF)
        line.erase(0,3);
    const auto hdr=ParseCsvRow(line);
    std::map<std::string,std::size_t> col;
    for (std::size_t i=0;i<hdr.size();++i) col[hdr[i]]=i;
    auto get=[&](const std::vector<std::string>& r,const char* name)->std::string {
        auto it=col.find(name);
        return (it!=col.end() && it->second<r.size())?r[it->second]:std::string{};
    };

    while (std::getline(f,line)) {
        if (line.empty()) continue;
        const auto r=ParseCsvRow(line);
        if (get(r,"supported")!="1") continue;
        const std::string code=StripStyleResourcePrefix(get(r,"nameCode"));
        if (code.empty()) continue;
        StyleResourceCatalogEntry e;
        e.drum=get(r,"resourceType")=="Drum";
        e.family=get(r,"family");
        e.number=ParseCatalogInt(get(r,"number"));
        e.code=code;
        e.familyZh=Utf8ToWide(get(r,"中文系列"));
        e.uiCategory=Utf8ToWide(get(r,"UI类别"));
        e.exactZh=Utf8ToWide(get(r,"中文精确名"));
        e.displayZh=Utf8ToWide(get(r,"显示中文名"));
        e.nameLevel=Utf8ToWide(get(r,"中文名级别"));
        e.bpm=ParseCatalogInt(get(r,"bpm"));
        e.meterEnum=CatalogMeterEnum(get(r,"meter"));
        e.paramLevel=Utf8ToWide(get(r,"参数级别"));
        e.paramSource=get(r,"参数来源");
        e.evidenceGrade=Utf8ToWide(get(r,"evidenceGrade"));
        // curve476 is a song-library common/reference parameter, and auto_probe
        // is merely the parameter used for existence testing. Neither may be
        // silently promoted to a resource-owned parameter when writing C2.
        e.trustedWriteParams=(e.bpm>=30 && e.bpm<=240 && e.meterEnum>=0 &&
            e.paramSource!="curve476" && e.paramSource!="auto_probe");
        g_styleResourceCatalog.push_back(std::move(e));
    }
    return !g_styleResourceCatalog.empty();
}

static const StyleResourceCatalogEntry* FindCatalogStyleMeta(const std::string& raw) {
    LoadStyleResourceCatalog();
    const std::string code=StripStyleResourcePrefix(raw);
    for (const auto& e:g_styleResourceCatalog) if (e.code==code) return &e;
    return nullptr;
}

static std::wstring CatalogParamLabel(const StyleResourceCatalogEntry& e) {
    if (e.paramSource.find("BLE_exact")!=std::string::npos || e.paramSource.find("btsnoop_exact")!=std::string::npos)
        return L"原厂抓包参数";
    if (e.paramSource.find("multilevel")!=std::string::npos)
        return L"多档包资源参数";
    if (e.paramSource=="curve476") return L"曲库常用参考";
    if (e.paramSource=="auto_probe") return L"短测发送参数(非原始)";
    return e.paramLevel.empty()?L"参考参数":e.paramLevel;
}

static std::wstring StyleResourceComboDisplay(const std::string& raw,bool drum) {
    const std::string code=StripStyleResourcePrefix(raw);
    const auto* e=FindCatalogStyleMeta(code);
    std::wstring out=Utf8ToWide(code);
    if (!e) return out;
    const std::wstring zh=!e->displayZh.empty()?e->displayZh:(!e->exactZh.empty()?e->exactZh:e->familyZh);
    if (!zh.empty()) out+=L" | "+zh;
    if (e->bpm>0) out+=L" | "+std::to_wstring(e->bpm)+L" BPM";
    if (e->meterEnum==0) out+=L" | 3/4";
    else if (e->meterEnum==1) out+=L" | 4/4";
    else if (e->meterEnum==3) out+=L" | 6/8";
    return out;
}

static std::string StyleResourceCodeFromDisplay(const std::wstring& text) {
    std::wstring w=text;
    const auto p=w.find(L" | ");
    if (p!=std::wstring::npos) w.resize(p);
    while (!w.empty() && (w.front()==L' ' || w.front()==L'\t')) w.erase(w.begin());
    while (!w.empty() && (w.back()==L' ' || w.back()==L'\t')) w.pop_back();
    return WideToUtf8(w);
}

static std::wstring StyleResourceFamilyZh(const std::string& code,bool drum) {
    const std::string c=StripStyleResourcePrefix(code);
    auto starts=[&](const char* p){ return c.rfind(p,0)==0; };
    if (!drum) {
        if (starts("GS_")) return L"民谣吉他";
        if (starts("GN_")) return L"尼龙吉他";
        if (starts("PianoStudio_")) return L"大钢琴";
        if (starts("PianoMKS20_")) return L"现代钢琴";
        if (starts("PianoRhodesWarm_") || starts("PianoRhosdesWarm_")) return L"复古电钢琴";
        if (starts("GEC1_") || starts("GEC2_")) return L"明亮/温暖清音电吉他";
        if (starts("GED1_") || starts("GED2_")) return L"过载电吉他";
    } else {
        if (starts("POP_ChapMen_") || starts("Pop_Chapman_")) return L"流行鼓组";
        if (starts("Cajon_ChapMen_")) return L"卡宏鼓";
        if (starts("Djembe_ChapMen_")) return L"非洲鼓";
        if (starts("EJB_ChapMen_")) return L"流行电鼓/R&B鼓组";
        if (starts("EMO_ChapMen_")) return L"R&B鼓组";
        if (starts("Metal_Chapman_") || starts("METAL_Fender_")) return L"摇滚鼓组";
        if (starts("Funk_ChapMen_") || starts("FUNK_Mute_")) return L"放克鼓组";
        if (starts("CityPOP_ChapMen_") || starts("CityPop_ChapMen_")) return L"复古电鼓";
        if (starts("Jazz_Mute_") || starts("JAZZ_Mute_")) return L"爵士鼓组";
        if (starts("ElcDrum01_")) return L"电子鼓组";
    }
    if (c.rfind("C1:",0)==0 || code.rfind("C1:",0)==0) return L"C1兼容资源";
    return drum?L"鼓资源（中文名待补测）":L"和弦/拨片资源（中文名待补测）";
}

static const StyleResourceMeasuredMeta* FindMeasuredStyleMeta(const std::string& raw) {
    const std::string c=StripStyleResourcePrefix(raw);
    for (const auto& m:kStyleMeasuredMeta) if (c==m.code) return &m;
    return nullptr;
}

static std::wstring StyleMeterName(int meterEnum) {
    switch (meterEnum) {
    case 0: return L"3/4";
    case 1: return L"4/4";
    case 3: return L"6/8";
    default: return L"--";
    }
}

static int StyleMeterEnumFromText(const wchar_t* meter) {
    if (!meter) return -1;
    if (wcscmp(meter,L"3/4")==0) return 0;
    if (wcscmp(meter,L"4/4")==0) return 1;
    if (wcscmp(meter,L"6/8")==0) return 3;
    return -1;
}

static std::wstring StyleResourceInfoText(const std::string& raw,bool drum) {
    if (raw.empty()) return L"-- 未读回 --";
    const std::string c=StripStyleResourcePrefix(raw);
    if (const auto* e=FindCatalogStyleMeta(c)) {
        const std::wstring zh=!e->displayZh.empty()?e->displayZh:(!e->exactZh.empty()?e->exactZh:e->familyZh);
        std::wstring out=Utf8ToWide(c);
        if (!zh.empty()) out+=L" | "+zh;
        if (!e->nameLevel.empty()) out+=L" ["+e->nameLevel+L"]";
        if (e->bpm>0) {
            out+=L" | "+CatalogParamLabel(*e)+L" BPM="+std::to_wstring(e->bpm);
            if (e->meterEnum==0) out+=L" 3/4";
            else if (e->meterEnum==1) out+=L" 4/4";
            else if (e->meterEnum==3) out+=L" 6/8";
        } else out+=L" | BPM/拍号：待补测";
        if (!e->paramSource.empty()) out+=L" | source="+Utf8ToWide(e->paramSource);
        out+=L" | 当前实机已验证支持";
        out+=(raw.rfind("C1:",0)==0?L" | C1兼容":L" | sdcard");
        return out;
    }
    const auto* m=FindMeasuredStyleMeta(c);
    std::wstring zh=m && m->exactZh ? m->exactZh : StyleResourceFamilyZh(c,drum)+L"（具体Pattern中文名待补测）";
    std::wstring out=Utf8ToWide(c)+L" | "+zh;
    if (m) out+=L" | 试听/参考BPM "+std::to_wstring(m->bpm)+L" | 参考拍号 "+m->meter;
    else out+=L" | 试听/参考BPM/拍号：待补测";
    out+=(raw.rfind("C1:",0)==0?L" | C1兼容":L" | sdcard");
    return out;
}

static void AddStyleResourceComboItem(HWND combo,const std::string& code) {
    if (!combo || code.empty()) return;
    const std::string normalized=StripStyleResourcePrefix(code);
    const int n=static_cast<int>(SendMessageW(combo,CB_GETCOUNT,0,0));
    wchar_t buf[512]{};
    for (int i=0;i<n;++i) {
        SendMessageW(combo,CB_GETLBTEXT,i,reinterpret_cast<LPARAM>(buf));
        if (StyleResourceCodeFromDisplay(buf)==normalized) return;
    }
    const bool drum=FindCatalogStyleMeta(normalized)?FindCatalogStyleMeta(normalized)->drum:false;
    const std::wstring w=StyleResourceComboDisplay(normalized,drum);
    SendMessageW(combo,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(w.c_str()));
}

static void FillStyleResourceCombo(HWND combo,bool drum) {
    if (!combo) return;
    SendMessageW(combo,CB_RESETCONTENT,0,0);
    bool catalogAdded=false;
    if (LoadStyleResourceCatalog()) {
        for (const auto& e:g_styleResourceCatalog) {
            if (e.drum==drum) { AddStyleResourceComboItem(combo,e.code); catalogAdded=true; }
        }
    }
    // Hardcoded seeds are retained only as an offline/fallback catalogue.
    if (!catalogAdded) {
        static const char* commonChord[]={"GS_1","GS_3","GS_17","GS_22","GS_25","GN_1","GN_4","GN_5","PianoStudio_1","PianoStudio_4","PianoStudio_8","PianoMKS20_1","PianoMKS20_3","GEC1_1","GEC2_1","GED1_1"};
        static const char* commonDrum[]={"POP_ChapMen_1","POP_ChapMen_2","POP_ChapMen_10","POP_ChapMen_11","Pop_Chapman_3","Pop_Chapman_4","Cajon_ChapMen_1","Cajon_ChapMen_2","Djembe_ChapMen_1","EJB_ChapMen_1","EJB_ChapMen_2","EMO_ChapMen_1","Metal_Chapman_4"};
        if (drum) for (const char* c:commonDrum) AddStyleResourceComboItem(combo,c);
        else for (const char* c:commonChord) AddStyleResourceComboItem(combo,c);
        for (const auto& meta:kStyleMeasuredMeta) {
            const std::string c=meta.code;
            const bool looksDrum=c.rfind("Cajon_",0)==0 || c.rfind("POP_",0)==0 || c.rfind("Pop_",0)==0;
            if (looksDrum==drum) AddStyleResourceComboItem(combo,c);
        }
    }
    // Current song resources remain visible even if a future/other card uses a
    // code that is not yet in the accepted-only catalogue.
    if (g_loaded) {
        const auto& pack=g_song.content.baseConfig.configPack;
        const auto& list=drum?pack.drums:pack.chords;
        for (const auto& e:list) AddStyleResourceComboItem(combo,e.nameCode);
    }
}

static std::string StyleResourceFromCombo(HWND combo) {
    wchar_t buf[512]{};
    if (combo) GetWindowTextW(combo,buf,511);
    return FullStyleResourceCode(StyleResourceCodeFromDisplay(buf));
}

// -----------------------------------------------------------------------------
// V2.3.18 C2 Device Center / Multi-track INT26 / SET_AUTO_PLAY
// A deliberately plain Win32 control panel for real-device protocol validation.
// It keeps known controls editable and unknown firmware replies visible as raw data.
// -----------------------------------------------------------------------------
static const wchar_t* kDeviceCenterClassName=L"LiberLiveC2DeviceCenterV2318";
static HWND g_deviceCenterWnd=nullptr;
static constexpr UINT WM_DEVICECENTER_INIT = WM_APP + 0x315;
static constexpr UINT WM_DEVICECENTER_STATUS = WM_APP + 0x316;
static constexpr UINT WM_DEVICECENTER_DONE = WM_APP + 0x317;
static constexpr UINT WM_DEVICECENTER_REALTIME = WM_APP + 0x318;

enum class DeviceCenterTask {
    RefreshInfo, ApplyMixer, SetKey, SetBpm, SetDeviceTone, TrackCurrent, TrackAll,
    ApplyStyle, ApplyJsonPack, AutoPlay, BasicStyleSlot
};

struct DeviceCenterDone {
    DeviceCenterTask task=DeviceCenterTask::RefreshInfo;
    bool ok=false;
    std::wstring error;
    std::wstring message;
};

enum DeviceCenterId {
    IDC_DEV_REFRESH=3001, IDC_DEV_APPLY_MIXER, IDC_DEV_KEY_EDIT, IDC_DEV_KEY_SET,
    IDC_DEV_BPM_EDIT, IDC_DEV_BPM_SET, IDC_DEV_TONE_COMBO, IDC_DEV_TONE_SET,
    IDC_DEV_TRACK_COMBO, IDC_DEV_LEAD_TONE_COMBO, IDC_DEV_LEAD_VOL_EDIT, IDC_DEV_LEAD_CURRENT, IDC_DEV_LEAD_ALL, IDC_DEV_LEAD_INFO,
    IDC_DEV_STYLE_APPLY, IDC_DEV_JSON_PACK, IDC_DEV_PACK_REFRESH, IDC_DEV_INFO_EDIT,
    IDC_DEV_AUTO_T1_OFF, IDC_DEV_AUTO_T1_ON, IDC_DEV_AUTO_T2_OFF, IDC_DEV_AUTO_T2_ON, IDC_DEV_AUTO_T3_OFF, IDC_DEV_AUTO_T3_ON,
    IDC_DEV_AUTO_T4_OFF, IDC_DEV_AUTO_T4_ON, IDC_DEV_AUTO_T5_OFF, IDC_DEV_AUTO_T5_ON, IDC_DEV_AUTO_T6_OFF, IDC_DEV_AUTO_T6_ON,
    IDC_DEV_SLOT_A_CHORD, IDC_DEV_SLOT_B_CHORD, IDC_DEV_SLOT_A_DRUM, IDC_DEV_SLOT_B_DRUM,
    IDC_DEV_SLOT_A_CHORD_SET, IDC_DEV_SLOT_B_CHORD_SET, IDC_DEV_SLOT_A_DRUM_SET, IDC_DEV_SLOT_B_DRUM_SET,
    IDC_DEV_MIXER_BASE=3100, IDC_DEV_STYLE_BASE=3200
};

struct DeviceCenterState {
    HWND mixer[14]{};
    HWND style[8]{};
    HWND autoInfo[7]{};
    HWND keyEdit=nullptr;
    HWND bpmEdit=nullptr;
    HWND toneCombo=nullptr;
    HWND trackCombo=nullptr;
    HWND leadToneCombo=nullptr;
    HWND leadVolumeEdit=nullptr;
    HWND leadInfo=nullptr;
    HWND styleSlotCombo[4]{}; // A chord, B chord, A drum, B drum
    HWND styleSlotInfo[4]{};
    HWND infoEdit=nullptr;
    HWND status=nullptr;
    // RefreshDeviceCenterControls() uses SetWindowText/BM_SETCHECK. Those Win32
    // calls synchronously send WM_COMMAND notifications (EN_UPDATE/EN_CHANGE,
    // etc.) back to the parent. Without a guard the parent re-enters refresh
    // and eventually overflows the stack.
    bool refreshing=false;
    bool taskRunning=false;
};

static HWND DevCtl(HWND parent,const wchar_t* cls,const wchar_t* text,DWORD style,int id,int x,int y,int w,int h,DWORD ex=0) {
    HWND c=CreateWindowExW(ex,cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,parent,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);
    if (c && g_font) SendMessageW(c,WM_SETFONT,reinterpret_cast<WPARAM>(g_font),TRUE);
    return c;
}

static bool ReadIntEdit(HWND h,int& value) {
    wchar_t buf[64]{};
    GetWindowTextW(h,buf,63);
    wchar_t* end=nullptr;
    const long v=wcstol(buf,&end,10);
    if (end==buf) return false;
    value=static_cast<int>(v);
    return true;
}

static void SetDeviceCenterStatus(DeviceCenterState* st,const std::wstring& text) {
    if (st && st->status) SetWindowTextW(st->status,text.c_str());
    PostC2Status(text);
}


static void UpdateStyleSlotInfo(DeviceCenterState* st,int slotIndex) {
    if (!st || slotIndex<0 || slotIndex>=4 || !st->styleSlotInfo[slotIndex]) return;
    const bool drum=slotIndex>=2;
    const std::string code=StyleResourceFromCombo(st->styleSlotCombo[slotIndex]);
    SetWindowTextW(st->styleSlotInfo[slotIndex],StyleResourceInfoText(code,drum).c_str());
}

static void RefreshBasicStyleSlotControls(DeviceCenterState* st,const C2DeviceState& ds) {
    if (!st) return;
    const std::string codes[4]={ds.chordStyleA,ds.chordStyleB,ds.drumStyleA,ds.drumStyleB};
    for (int i=0;i<4;++i) {
        if (!st->styleSlotCombo[i]) continue;
        FillStyleResourceCombo(st->styleSlotCombo[i],i>=2);
        if (!codes[i].empty()) {
            AddStyleResourceComboItem(st->styleSlotCombo[i],codes[i]);
            SetWindowTextW(st->styleSlotCombo[i],StyleResourceComboDisplay(codes[i],i>=2).c_str());
        }
        std::wstring info=StyleResourceInfoText(codes[i],i>=2);
        const int bpm=ds.basicStyleBpm[static_cast<std::size_t>(i)];
        const int meter=ds.basicStyleMeter[static_cast<std::size_t>(i)];
        if (!codes[i].empty() && bpm>=0) {
            info+=L" | C2当前槽参数 BPM="+std::to_wstring(bpm)+L" 拍号="+StyleMeterName(meter);
        }
        if (st->styleSlotInfo[i]) SetWindowTextW(st->styleSlotInfo[i],info.c_str());
    }
}

static void RefreshDeviceCenterControls(DeviceCenterState* st) {
    if (!st || st->refreshing) return;
    st->refreshing=true;
    const C2DeviceState ds=g_c2.DeviceState();
    for (int ch=1;ch<=13;++ch) {
        if (!st->mixer[ch]) continue;
        const int v=ds.mixer[static_cast<std::size_t>(ch)];
        const std::wstring t=v>=0?std::to_wstring(v):L"";
        SetWindowTextW(st->mixer[ch],t.c_str());
    }
    if (st->keyEdit) {
        const std::wstring t=ds.key>=0?std::to_wstring(ds.key):L"";
        SetWindowTextW(st->keyEdit,t.c_str());
    }
    if (st->bpmEdit) {
        const int bpm=ds.bpm>0?ds.bpm:g_bpm;
        const std::wstring t=std::to_wstring(bpm);
        SetWindowTextW(st->bpmEdit,t.c_str());
    }
    if (st->toneCombo) {
        int idx=FindToneChoiceIndex(ds.currentToneCard,ds.currentTone);
        if (idx<0) idx=FindToneChoiceIndex("sound_c2","PianoStudio");
        if (idx>=0) SendMessageW(st->toneCombo,CB_SETCURSEL,idx,0);
    }
    FillTrackCombo(st->trackCombo);
    int trackId=-1;
    if (st->trackCombo) {
        const int sel=static_cast<int>(SendMessageW(st->trackCombo,CB_GETCURSEL,0,0));
        if (sel!=CB_ERR) trackId=static_cast<int>(SendMessageW(st->trackCombo,CB_GETITEMDATA,sel,0));
    }
    std::string trackCard,trackTone; int trackVol=80; std::size_t trackSections=0;
    if (trackId==kLeadViolinVirtualTrack || trackId==kLeadPianoVirtualTrack) {
        RuntimeScheduleForModelTrack(trackId,trackCard,trackTone,trackVol);
        if (st->leadToneCombo) { const int idx=FindToneChoiceIndex(trackCard,trackTone); if (idx>=0) SendMessageW(st->leadToneCombo,CB_SETCURSEL,idx,0); }
        if (st->leadVolumeEdit) SetWindowTextW(st->leadVolumeEdit,std::to_wstring(trackVol).c_str());
        if (st->leadInfo) SetWindowTextW(st->leadInfo,((trackId==kLeadViolinVirtualTrack?L"主旋律01":L"主旋律02")+
            std::wstring(L"（tk0 音色组）: ")+Utf8ToWide(trackCard)+L":"+Utf8ToWide(trackTone)+L"  volume="+std::to_wstring(trackVol)).c_str());
    } else if (trackId>=0 && FirstTrackScheduleState(static_cast<std::uint8_t>(trackId),trackCard,trackTone,trackVol,trackSections)) {
        if (st->leadToneCombo) { const int idx=FindToneChoiceIndex(trackCard,trackTone); if (idx>=0) SendMessageW(st->leadToneCombo,CB_SETCURSEL,idx,0); }
        if (st->leadVolumeEdit) SetWindowTextW(st->leadVolumeEdit,std::to_wstring(trackVol).c_str());
        if (st->leadInfo) {
            std::wstring info=L"已上传 tk"+std::to_wstring(trackId)+L": "+Utf8ToWide(trackCard)+L":"+Utf8ToWide(trackTone)+L"  volume="+std::to_wstring(trackVol)+L"  schedule段="+std::to_wstring(trackSections);
            if (trackId==0) { info+=L"  MAIN_TRACK_AUTO="; if (ds.mainTrackAuto<0) info+=L"--"; else info+=(ds.mainTrackAuto?L"ON":L"OFF"); info+=L"；volume=0 可静音整首主旋律"; }
            SetWindowTextW(st->leadInfo,info.c_str());
        }
    } else {
        if (st->leadToneCombo && SendMessageW(st->leadToneCombo,CB_GETCURSEL,0,0)==CB_ERR) { const int idx=FindToneChoiceIndex("sound_c2","PianoStudio"); if (idx>=0) SendMessageW(st->leadToneCombo,CB_SETCURSEL,idx,0); }
        if (st->leadVolumeEdit && GetWindowTextLengthW(st->leadVolumeEdit)==0) SetWindowTextW(st->leadVolumeEdit,L"80");
        if (st->leadInfo) SetWindowTextW(st->leadInfo,L"当前没有可编辑的已上传轨道；请先在主窗口上传 JSON。 ");
    }
    for (int type=1;type<=7;++type) if (st->style[type]) {
        const int v=ds.styleSettings[static_cast<std::size_t>(type)];
        const std::wstring t=v>=0?std::to_wstring(v):L"";
        SetWindowTextW(st->style[type],t.c_str());
        // Keep unknown items editable for controlled wire-mapping tests. Blank means "do not write".
        EnableWindow(st->style[type],TRUE);
    }
    struct AutoStateView { int slot; int wireType; const wchar_t* name; };
    static const AutoStateView autoViews[6]={
        {1,1,L"主自动播放/演奏"},{2,2,L"鼓机自动挂挡许可"},{3,3,L"自动转调"},
        {4,5,L"Solo/演奏模式"},{5,6,L"聪明模式"},{6,4,L"type04 未标定"}
    };
    for (const auto& a:autoViews) if (st->autoInfo[a.slot]) {
        const int v=ds.autoPlay[static_cast<std::size_t>(a.wireType)];
        const std::wstring stateText=(v<0?L"--":(v?L"开":L"关"));
        std::wstring shown=std::wstring(a.name)+L" 当前="+stateText;
        if (a.wireType==1 && ds.autoPlay[5]==1) shown+=L" [type05=开→真机主旋律静音]";
        SetWindowTextW(st->autoInfo[a.slot],shown.c_str());
    }
    RefreshBasicStyleSlotControls(st,ds);
    if (st->infoEdit) SetWindowTextW(st->infoEdit,BuildDeviceInfoText().c_str());
    UpdateC2StateLabels();
    st->refreshing=false;
}

static bool DeviceCenterReady(DeviceCenterState* st) {
    if (!g_c2.IsConnected()) {
        SetDeviceCenterStatus(st,L"C2 未连接，请先在主窗口连接 C2。");
        MessageBoxW(g_deviceCenterWnd,L"请先连接 C2。",L"C2 设备中心",MB_ICONINFORMATION);
        return false;
    }
    if (g_c2Busy.load()) {
        SetDeviceCenterStatus(st,L"主窗口 C2 操作正在进行，请完成后再设置设备。");
        return false;
    }
    return true;
}

static void SetDeviceCenterTaskUi(HWND hwnd,DeviceCenterState* st,bool running) {
    if (!st) return;
    st->taskRunning=running;
    const int ids[]={IDC_DEV_REFRESH,IDC_DEV_APPLY_MIXER,IDC_DEV_KEY_SET,IDC_DEV_BPM_SET,
        IDC_DEV_TONE_SET,IDC_DEV_LEAD_CURRENT,IDC_DEV_LEAD_ALL,IDC_DEV_STYLE_APPLY,IDC_DEV_JSON_PACK,IDC_DEV_PACK_REFRESH,
        IDC_DEV_AUTO_T1_OFF,IDC_DEV_AUTO_T1_ON,IDC_DEV_AUTO_T2_OFF,IDC_DEV_AUTO_T2_ON,IDC_DEV_AUTO_T3_OFF,IDC_DEV_AUTO_T3_ON,
        IDC_DEV_AUTO_T4_OFF,IDC_DEV_AUTO_T4_ON,IDC_DEV_AUTO_T5_OFF,IDC_DEV_AUTO_T5_ON,IDC_DEV_AUTO_T6_OFF,IDC_DEV_AUTO_T6_ON,
        IDC_DEV_SLOT_A_CHORD_SET,IDC_DEV_SLOT_B_CHORD_SET,IDC_DEV_SLOT_A_DRUM_SET,IDC_DEV_SLOT_B_DRUM_SET};
    for (int id:ids) {
        HWND h=GetDlgItem(hwnd,id);
        if (h) EnableWindow(h,running?FALSE:TRUE);
    }
}

static void PostDeviceCenterStatus(HWND hwnd,const std::wstring& text) {
    PostC2Status(text);
    if (!hwnd || !IsWindow(hwnd)) return;
    auto* copy=new std::wstring(text);
    if (!PostMessageW(hwnd,WM_DEVICECENTER_STATUS,0,reinterpret_cast<LPARAM>(copy))) delete copy;
}

using DeviceCenterWork=std::function<bool(std::wstring&,std::wstring&,C2Controller::StatusFn)>;

static void StartDeviceCenterTask(HWND hwnd,DeviceCenterState* st,DeviceCenterTask task,DeviceCenterWork work,const std::wstring& starting) {
    if (!st || st->taskRunning) return;
    if (!DeviceCenterReady(st)) return;
    if (g_c2Busy.exchange(true)) {
        SetDeviceCenterStatus(st,L"C2 正忙，请稍后再试。");
        return;
    }
    SetDeviceCenterTaskUi(hwnd,st,true);
    SetDeviceCenterStatus(st,starting);
    UpdateC2Buttons();

    std::thread([hwnd,task,work=std::move(work)]() mutable {
        // C++/WinRT IAsyncOperation::get() is not allowed to block an STA UI
        // thread. The original V2.3.15b device-center handlers called BLE
        // ReadValueAsync()/WriteValueAsync().get() directly from WndProc,
        // which triggers Windows.Foundation.h: !is_sta() in VS2019 Debug as
        // soon as an operation does not complete synchronously. Run every BLE
        // device-center transaction on an MTA worker instead.
        winrt::init_apartment(winrt::apartment_type::multi_threaded);
        std::wstring error,message;
        const auto status=[hwnd](const std::wstring& m){ PostDeviceCenterStatus(hwnd,m); };
        bool ok=false;
        try {
            ok=work(error,message,status);
        } catch (const winrt::hresult_error& e) {
            std::wostringstream os;
            os << L"C2 WinRT 异常 HRESULT=0x" << std::hex << std::uppercase
               << static_cast<std::uint32_t>(e.code()) << L" " << e.message().c_str();
            error=os.str();
        } catch (const std::exception& e) {
            error=L"C2 设备中心异常: "+Utf8ToWide(e.what());
        } catch (...) {
            error=L"C2 设备中心发生未知异常";
        }
        auto* done=new DeviceCenterDone();
        done->task=task; done->ok=ok; done->error=std::move(error); done->message=std::move(message);
        if (!hwnd || !IsWindow(hwnd) || !PostMessageW(hwnd,WM_DEVICECENTER_DONE,0,reinterpret_cast<LPARAM>(done))) {
            delete done;
            g_c2Busy.store(false);
            PostC2Status(L"C2 设备中心后台操作结束，但窗口已关闭。");
        }
    }).detach();
}

static LRESULT CALLBACK DeviceCenterProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp) {
    auto* st=reinterpret_cast<DeviceCenterState*>(GetWindowLongPtrW(hwnd,GWLP_USERDATA));
    switch (msg) {
    case WM_CREATE: {
        auto* ns=new DeviceCenterState();
        SetWindowLongPtrW(hwnd,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(ns));
        st=ns;
        DevCtl(hwnd,L"BUTTON",L"刷新设备全部信息",BS_PUSHBUTTON,IDC_DEV_REFRESH,12,10,150,28);
        ns->status=DevCtl(hwnd,L"STATIC",L"设备中心：等待刷新",SS_LEFT|SS_NOPREFIX,0,175,15,790,22);

        DevCtl(hwnd,L"BUTTON",L"Mixer（只改变化项）",BS_GROUPBOX,0,10,45,960,105);
        static const wchar_t* ml[14]={L"",L"01总",L"02鼓",L"03",L"04贝斯",L"05*",L"06",L"07",L"08",L"09 A拨片",L"0A B拨片",L"0B A鼓",L"0C B鼓",L"0D琶音"};
        for (int ch=1;ch<=13;++ch) {
            const int col=(ch-1)%7, row=(ch-1)/7;
            const int x=22+col*128, y=67+row*36;
            DevCtl(hwnd,L"STATIC",ml[ch],SS_LEFT,0,x,y+4,72,22);
            ns->mixer[ch]=DevCtl(hwnd,L"EDIT",L"",ES_NUMBER|ES_AUTOHSCROLL,IDC_DEV_MIXER_BASE+ch,x+72,y,42,24,WS_EX_CLIENTEDGE);
        }
        DevCtl(hwnd,L"BUTTON",L"应用Mixer",BS_PUSHBUTTON,IDC_DEV_APPLY_MIXER,815,111,130,28);

        DevCtl(hwnd,L"BUTTON",L"基础设置 / 设备全局旋律音色（试听/设备页，不等于曲谱轨道）",BS_GROUPBOX,0,10,155,960,116);
        DevCtl(hwnd,L"STATIC",L"Key 0=C..11=B",SS_LEFT,0,22,184,100,22);
        ns->keyEdit=DevCtl(hwnd,L"EDIT",L"",ES_NUMBER|ES_AUTOHSCROLL,IDC_DEV_KEY_EDIT,125,180,55,24,WS_EX_CLIENTEDGE);
        DevCtl(hwnd,L"BUTTON",L"设置Key",BS_PUSHBUTTON,IDC_DEV_KEY_SET,187,178,78,28);
        DevCtl(hwnd,L"STATIC",L"BPM 40..240",SS_LEFT,0,290,184,90,22);
        ns->bpmEdit=DevCtl(hwnd,L"EDIT",L"",ES_NUMBER|ES_AUTOHSCROLL,IDC_DEV_BPM_EDIT,380,180,60,24,WS_EX_CLIENTEDGE);
        DevCtl(hwnd,L"BUTTON",L"设置BPM",BS_PUSHBUTTON,IDC_DEV_BPM_SET,448,178,82,28);
        DevCtl(hwnd,L"STATIC",L"全局音色",SS_LEFT,0,22,222,72,22);
        ns->toneCombo=DevCtl(hwnd,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL,IDC_DEV_TONE_COMBO,95,216,640,360,WS_EX_CLIENTEDGE);
        FillToneCombo(ns->toneCombo);
        const int pianoIdx=FindToneChoiceIndex("sound_c2","PianoStudio");
        if (pianoIdx>=0) SendMessageW(ns->toneCombo,CB_SETCURSEL,pianoIdx,0);
        DevCtl(hwnd,L"BUTTON",L"应用全局音色",BS_PUSHBUTTON,IDC_DEV_TONE_SET,748,215,120,28);
        DevCtl(hwnd,L"STATIC",L"原厂设备页链路：set_fret_instru + set_lead_preview + get_config_v2basic。此处不是第二条主旋律。",SS_LEFT|SS_NOPREFIX,0,22,247,925,20);

        DevCtl(hwnd,L"BUTTON",L"当前曲谱轨道编辑器（每轨独立音色/音量，INT26 / SET_AMEND_TRACK）",BS_GROUPBOX,0,10,277,960,116);
        DevCtl(hwnd,L"STATIC",L"轨道",SS_LEFT,0,22,306,42,22);
        ns->trackCombo=DevCtl(hwnd,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL,IDC_DEV_TRACK_COMBO,66,300,320,280,WS_EX_CLIENTEDGE);
        FillTrackCombo(ns->trackCombo);
        DevCtl(hwnd,L"STATIC",L"音色",SS_LEFT,0,398,306,42,22);
        ns->leadToneCombo=DevCtl(hwnd,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL,IDC_DEV_LEAD_TONE_COMBO,440,300,300,350,WS_EX_CLIENTEDGE);
        FillToneCombo(ns->leadToneCombo);
        if (pianoIdx>=0) SendMessageW(ns->leadToneCombo,CB_SETCURSEL,pianoIdx,0);
        DevCtl(hwnd,L"STATIC",L"音量",SS_LEFT,0,748,306,42,22);
        ns->leadVolumeEdit=DevCtl(hwnd,L"EDIT",L"80",ES_NUMBER|ES_AUTOHSCROLL,IDC_DEV_LEAD_VOL_EDIT,790,301,46,24,WS_EX_CLIENTEDGE);
        DevCtl(hwnd,L"BUTTON",L"当前段",BS_PUSHBUTTON,IDC_DEV_LEAD_CURRENT,844,299,52,28);
        DevCtl(hwnd,L"BUTTON",L"全部段",BS_PUSHBUTTON,IDC_DEV_LEAD_ALL,902,299,52,28);
        ns->leadInfo=DevCtl(hwnd,L"STATIC",L"当前没有已上传 sheet；tk0=主旋律，tk3+ 可为铺底/加花。音量0可静音所选轨。",SS_LEFT|SS_NOPREFIX,IDC_DEV_LEAD_INFO,22,338,925,42);

        DevCtl(hwnd,L"BUTTON",L"演奏偏好 / Style Settings（get_style_settings / set_style_settings；保留 raw 数值用于实机标定）",BS_GROUPBOX,0,10,399,960,98);
        struct StyleUiCell { int type; int x; int y; const wchar_t* label; };
        static const StyleUiCell sc[7]={
            {1,22,421,L"T1 A细节增强[候选]"},{2,240,421,L"T2 B细节增强[候选]"},{3,458,421,L"T3 PREVIEW_C"},{4,676,421,L"T4 PREVIEW_D"},
            {5,22,451,L"T5 ABASS_EN"},{6,240,451,L"T6 BPM锁定[编号待验]"},{7,458,451,L"T7 试听BPM锁定[编号待验]"}
        };
        for (const auto& c:sc) {
            DevCtl(hwnd,L"STATIC",c.label,SS_LEFT|SS_NOPREFIX,0,c.x,c.y+4,150,22);
            ns->style[c.type]=DevCtl(hwnd,L"EDIT",L"",ES_NUMBER|ES_AUTOHSCROLL,IDC_DEV_STYLE_BASE+c.type,c.x+154,c.y,48,24,WS_EX_CLIENTEDGE);
        }
        DevCtl(hwnd,L"BUTTON",L"应用演奏偏好",BS_PUSHBUTTON,IDC_DEV_STYLE_APPLY,835,449,120,28);
        DevCtl(hwnd,L"STATIC",L"T1/T2 与 A/B细节增强为高度对应候选；BPMLOCK→set_style_settings 是源码硬证据，但 enum↔wire数字仍保留“?”直到实机逐项闭环。非0/1值（如2/3）会原样保留。",SS_LEFT|SS_NOPREFIX,0,22,477,920,18);

        DevCtl(hwnd,L"BUTTON",L"风格包 / A-B拨片和弦 + A-B鼓资源（get_config_v2basic / set_*_v2basic）",BS_GROUPBOX,0,10,503,960,190);
        DevCtl(hwnd,L"BUTTON",L"应用当前JSON configV2Pack",BS_PUSHBUTTON,IDC_DEV_JSON_PACK,22,526,205,28);
        DevCtl(hwnd,L"BUTTON",L"读取/回读四槽",BS_PUSHBUTTON,IDC_DEV_PACK_REFRESH,240,526,150,28);
        LoadStyleResourceCatalog();
        int catChord=0,catDrum=0;
        for (const auto& e:g_styleResourceCatalog) (e.drum?catDrum:catChord)++;
        const std::wstring catStatus=L"资源库 "+std::to_wstring(g_styleResourceCatalog.size())+L" 项（Chord "+std::to_wstring(catChord)+L" / Drum "+std::to_wstring(catDrum)+L"）；仅 ACCEPTED_EXACT。下拉显示 中文名 + BPM + 拍号；curve476/短测参数只作参考。";
        DevCtl(hwnd,L"STATIC",catStatus.c_str(),SS_LEFT|SS_NOPREFIX,0,405,531,545,22);

        static const wchar_t* slotLabels[4]={L"A拨片和弦",L"B拨片和弦",L"A鼓",L"B鼓"};
        const int slotComboIds[4]={IDC_DEV_SLOT_A_CHORD,IDC_DEV_SLOT_B_CHORD,IDC_DEV_SLOT_A_DRUM,IDC_DEV_SLOT_B_DRUM};
        const int slotSetIds[4]={IDC_DEV_SLOT_A_CHORD_SET,IDC_DEV_SLOT_B_CHORD_SET,IDC_DEV_SLOT_A_DRUM_SET,IDC_DEV_SLOT_B_DRUM_SET};
        for (int i=0;i<4;++i) {
            const int yy=558+i*31;
            DevCtl(hwnd,L"STATIC",slotLabels[i],SS_LEFT,0,22,yy+4,82,22);
            ns->styleSlotCombo[i]=DevCtl(hwnd,L"COMBOBOX",L"",CBS_DROPDOWN|WS_VSCROLL|CBS_AUTOHSCROLL,slotComboIds[i],106,yy,225,260,WS_EX_CLIENTEDGE);
            SendMessageW(ns->styleSlotCombo[i],CB_SETDROPPEDWIDTH,650,0);
            FillStyleResourceCombo(ns->styleSlotCombo[i],i>=2);
            ns->styleSlotInfo[i]=DevCtl(hwnd,L"STATIC",L"-- 未读回 --",SS_LEFT|SS_NOPREFIX,0,340,yy+3,510,24);
            DevCtl(hwnd,L"BUTTON",L"写入",BS_PUSHBUTTON,slotSetIds[i],865,yy-1,78,27);
        }

        DevCtl(hwnd,L"BUTTON",L"自动演奏 / Auto Play（GET 0x0F / SET 0x10；2026-09-04 真机差分映射）",BS_GROUPBOX,0,10,700,960,105);
        struct AutoUiRow { int slot; int wireType; int x; int y; int offId; int onId; const wchar_t* name; };
        const AutoUiRow ar[6]={
            {1,1,22,720,IDC_DEV_AUTO_T1_OFF,IDC_DEV_AUTO_T1_ON,L"主自动播放/演奏"},
            {2,2,338,720,IDC_DEV_AUTO_T2_OFF,IDC_DEV_AUTO_T2_ON,L"鼓机自动挂挡许可"},
            {3,3,654,720,IDC_DEV_AUTO_T3_OFF,IDC_DEV_AUTO_T3_ON,L"自动转调"},
            {4,5,22,760,IDC_DEV_AUTO_T4_OFF,IDC_DEV_AUTO_T4_ON,L"Solo/演奏模式"},
            {5,6,338,760,IDC_DEV_AUTO_T5_OFF,IDC_DEV_AUTO_T5_ON,L"聪明模式"},
            {6,4,654,760,IDC_DEV_AUTO_T6_OFF,IDC_DEV_AUTO_T6_ON,L"type04 未标定"}
        };
        for (const auto& a:ar) {
            ns->autoInfo[a.slot]=DevCtl(hwnd,L"STATIC",a.name,SS_LEFT|SS_NOPREFIX,0,a.x,a.y+4,136,22);
            wchar_t offText[32]{},onText[32]{};
            wsprintfW(offText,L"关 %02X 00",a.wireType); wsprintfW(onText,L"开 %02X 01",a.wireType);
            DevCtl(hwnd,L"BUTTON",offText,BS_PUSHBUTTON,a.offId,a.x+138,a.y,78,28);
            DevCtl(hwnd,L"BUTTON",onText,BS_PUSHBUTTON,a.onId,a.x+220,a.y,78,28);
        }
        DevCtl(hwnd,L"STATIC",L"实机优先：01=主自动播放；02=鼓机自动挂挡许可；03=自动转调；05=Solo；06=聪明模式。C2 多档换挡在本次抓包中由 set_pre_level 执行，未确认独立 SET_AUTO_PLAY type。",SS_LEFT|SS_NOPREFIX,0,22,792,925,18);

        DevCtl(hwnd,L"STATIC",L"设备/协议信息（原始回包）",SS_LEFT,0,12,814,220,22);
        ns->infoEdit=DevCtl(hwnd,L"EDIT",L"",ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL|ES_AUTOHSCROLL|WS_VSCROLL|WS_HSCROLL,
            IDC_DEV_INFO_EDIT,12,836,958,84,WS_EX_CLIENTEDGE);
        SendMessageW(ns->infoEdit,EM_SETLIMITTEXT,1024*1024,0);
        SetWindowTextW(ns->infoEdit,L"设备中心已创建。正在准备设备状态快照...\r\n");
        // Do not copy/format the full C2 state from inside WM_CREATE. VS2019 Debug
        // can re-enter allocation-heavy CRT code while CreateWindowEx is still in
        // the user callback. Defer it until the window has returned from WM_CREATE.
        PostMessageW(hwnd,WM_DEVICECENTER_INIT,0,0);
        return 0;
    }
    case WM_DEVICECENTER_INIT:
        if (st) RefreshDeviceCenterControls(st);
        return 0;
    case WM_DEVICECENTER_REALTIME:
        return 0;
    case WM_DEVICECENTER_STATUS: {
        std::unique_ptr<std::wstring> text(reinterpret_cast<std::wstring*>(lp));
        if (st && text && st->status) SetWindowTextW(st->status,text->c_str());
        return 0;
    }
    case WM_DEVICECENTER_DONE: {
        std::unique_ptr<DeviceCenterDone> done(reinterpret_cast<DeviceCenterDone*>(lp));
        g_c2Busy.store(false);
        if (st) {
            SetDeviceCenterTaskUi(hwnd,st,false);
            RefreshDeviceCenterControls(st);
            if (done) {
                if (done->ok) {
                    SetDeviceCenterStatus(st,done->message.empty()?L"C2 设备中心操作完成":done->message);
                    if ((done->task==DeviceCenterTask::TrackCurrent || done->task==DeviceCenterTask::TrackAll) && g_loaded) {
                        PopulateTracksForSegment(g_currentSegment);
                        UpdateDetails();
                    }
                } else {
                    const std::wstring e=done->error.empty()?L"C2 设备中心操作失败":done->error;
                    SetDeviceCenterStatus(st,e);
                    MessageBoxW(hwnd,e.c_str(),L"C2 设备中心",MB_ICONERROR);
                }
            }
        }
        UpdateC2Buttons();
        return 0;
    }
    case WM_COMMAND: {
        if (!st) return 0;
        const int id=LOWORD(wp);
        const int notifyCode=HIWORD(wp);
        if (id==IDC_DEV_TRACK_COMBO && notifyCode==CBN_SELCHANGE && !st->refreshing && !st->taskRunning) { RefreshDeviceCenterControls(st); return 0; }
        if (!st->refreshing && !st->taskRunning &&
            (id==IDC_DEV_SLOT_A_CHORD || id==IDC_DEV_SLOT_B_CHORD || id==IDC_DEV_SLOT_A_DRUM || id==IDC_DEV_SLOT_B_DRUM) &&
            (notifyCode==CBN_SELCHANGE || notifyCode==CBN_EDITCHANGE)) {
            int idx=0;
            if (id==IDC_DEV_SLOT_B_CHORD) idx=1; else if (id==IDC_DEV_SLOT_A_DRUM) idx=2; else if (id==IDC_DEV_SLOT_B_DRUM) idx=3;
            UpdateStyleSlotInfo(st,idx);
            return 0;
        }

        // SetWindowTextW() / BM_SETCHECK can synchronously send WM_COMMAND.
        // Ignore those notifications and accept only actual button clicks.
        if (st->refreshing || st->taskRunning) return 0;
        const bool isActionButton =
            id==IDC_DEV_REFRESH || id==IDC_DEV_APPLY_MIXER ||
            id==IDC_DEV_KEY_SET || id==IDC_DEV_BPM_SET ||
            id==IDC_DEV_TONE_SET || id==IDC_DEV_LEAD_CURRENT || id==IDC_DEV_LEAD_ALL || id==IDC_DEV_STYLE_APPLY ||
            id==IDC_DEV_JSON_PACK || id==IDC_DEV_PACK_REFRESH ||
            id==IDC_DEV_AUTO_T1_OFF || id==IDC_DEV_AUTO_T1_ON || id==IDC_DEV_AUTO_T2_OFF || id==IDC_DEV_AUTO_T2_ON ||
            id==IDC_DEV_AUTO_T3_OFF || id==IDC_DEV_AUTO_T3_ON || id==IDC_DEV_AUTO_T4_OFF || id==IDC_DEV_AUTO_T4_ON ||
            id==IDC_DEV_AUTO_T5_OFF || id==IDC_DEV_AUTO_T5_ON || id==IDC_DEV_AUTO_T6_OFF || id==IDC_DEV_AUTO_T6_ON ||
            id==IDC_DEV_SLOT_A_CHORD_SET || id==IDC_DEV_SLOT_B_CHORD_SET || id==IDC_DEV_SLOT_A_DRUM_SET || id==IDC_DEV_SLOT_B_DRUM_SET;
        if (!isActionButton || notifyCode!=BN_CLICKED) return 0;

        if (id==IDC_DEV_SLOT_A_CHORD_SET || id==IDC_DEV_SLOT_B_CHORD_SET ||
            id==IDC_DEV_SLOT_A_DRUM_SET || id==IDC_DEV_SLOT_B_DRUM_SET) {
            int slotIndex=0;
            if (id==IDC_DEV_SLOT_B_CHORD_SET) slotIndex=1;
            else if (id==IDC_DEV_SLOT_A_DRUM_SET) slotIndex=2;
            else if (id==IDC_DEV_SLOT_B_DRUM_SET) slotIndex=3;
            const bool drum=slotIndex>=2;
            const int ab=slotIndex&1;
            const std::string code=StyleResourceFromCombo(st->styleSlotCombo[slotIndex]);
            if (code.empty()) { MessageBoxW(hwnd,L"请输入资源代码，例如 GS_1 或 POP_ChapMen_1。",L"A/B资源",MB_ICONERROR); return 0; }
            // Resource catalogue BPM/meter are AUDITION/REFERENCE metadata only.
            // They must never replace the score master tempo.  Official Red Sun upload
            // writes the score BPM=120 into the live config pack for every A/B pick/drum
            // entry, regardless of each resource's catalogue audition BPM.
            int referenceBpm=-1, referenceMeter=-1;
            if (const auto* cat=FindCatalogStyleMeta(code); cat && cat->trustedWriteParams) {
                referenceBpm=cat->bpm;
                referenceMeter=cat->meterEnum;
            } else if (const auto* meta=FindMeasuredStyleMeta(code)) {
                referenceBpm=meta->bpm;
                referenceMeter=StyleMeterEnumFromText(meta->meter);
            }
            const C2DeviceState timingState=g_c2.DeviceState();
            int writeBpm=(g_loaded && g_bpm>=40 && g_bpm<=240) ? g_bpm : timingState.bpm;
            int writeMeter=-1;
            if (g_loaded) {
                const std::wstring meterW=Utf8ToWide(!g_song.content.beat.empty()?g_song.content.beat:g_song.content.baseConfig.beat);
                writeMeter=StyleMeterEnumFromText(meterW.c_str());
            }
            if (!(writeMeter==0 || writeMeter==1 || writeMeter==3))
                writeMeter=timingState.basicStyleMeter[static_cast<std::size_t>(slotIndex)];
            if (writeBpm<40 || writeBpm>240)
                writeBpm=timingState.basicStyleBpm[static_cast<std::size_t>(slotIndex)];
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::BasicStyleSlot,
                [drum,ab,code,referenceBpm,referenceMeter,writeBpm,writeMeter](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.SetBasicStyleSlot(drum,ab,code,err,status,writeBpm,writeMeter)) return false;
                    msg=std::wstring(ab?L"B":L"A")+(drum?L"鼓":L"拨片和弦")+L"已写入并 get_config_v2basic 回读: "+
                        StyleResourceInfoText(code,drum);
                    msg+=L"；运行拍速保持主谱 BPM="+std::to_wstring(writeBpm);
                    if (referenceBpm>0) {
                        msg+=L"（资源试听/参考 BPM="+std::to_wstring(referenceBpm);
                        if (referenceMeter>=0) msg+=L"，参考拍号="+StyleMeterName(referenceMeter);
                        msg+=L"；仅展示，不改主 BPM）";
                    }
                    return true;
                }, L"正在写入 A/B 风格资源（保持主谱 BPM，不采用资源试听 BPM）...");
            return 0;
        }

        if (id==IDC_DEV_AUTO_T1_OFF || id==IDC_DEV_AUTO_T1_ON ||
            id==IDC_DEV_AUTO_T2_OFF || id==IDC_DEV_AUTO_T2_ON || id==IDC_DEV_AUTO_T3_OFF || id==IDC_DEV_AUTO_T3_ON ||
            id==IDC_DEV_AUTO_T4_OFF || id==IDC_DEV_AUTO_T4_ON || id==IDC_DEV_AUTO_T5_OFF || id==IDC_DEV_AUTO_T5_ON ||
            id==IDC_DEV_AUTO_T6_OFF || id==IDC_DEV_AUTO_T6_ON) {
            // 2026-09-04 real-device mapping.  UI slots are function-oriented:
            // 01 main, 02 drum auto-shift permission, 03 auto-key, 05 solo,
            // 06 smart; 04 is kept as an explicit experimental/unmarked slot.
            int type=1,state=0;
            if (id==IDC_DEV_AUTO_T1_OFF || id==IDC_DEV_AUTO_T1_ON) type=1;
            else if (id==IDC_DEV_AUTO_T2_OFF || id==IDC_DEV_AUTO_T2_ON) type=2;
            else if (id==IDC_DEV_AUTO_T3_OFF || id==IDC_DEV_AUTO_T3_ON) type=3;
            else if (id==IDC_DEV_AUTO_T4_OFF || id==IDC_DEV_AUTO_T4_ON) type=5;
            else if (id==IDC_DEV_AUTO_T5_OFF || id==IDC_DEV_AUTO_T5_ON) type=6;
            else type=4;
            state=(id==IDC_DEV_AUTO_T1_ON || id==IDC_DEV_AUTO_T2_ON || id==IDC_DEV_AUTO_T3_ON ||
                id==IDC_DEV_AUTO_T4_ON || id==IDC_DEV_AUTO_T5_ON || id==IDC_DEV_AUTO_T6_ON)?1:0;
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::AutoPlay,
                [type,state](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.SetAutoPlayState(type,state,err,status)) return false;
                    wchar_t hexbuf[32]{}; wsprintfW(hexbuf,L"%02X %02X",type,state);
                    msg=L"SET_AUTO_PLAY 已发送: "+std::wstring(hexbuf);
                    return true;
                }, L"正在发送 SET_AUTO_PLAY...");
            return 0;
        }

        if (id==IDC_DEV_PACK_REFRESH) {
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::BasicStyleSlot,
                [](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.RefreshBasicStyleSlots(err,status)) return false;
                    const C2DeviceState ds=g_c2.DeviceState();
                    msg=L"A/B四槽已由 get_config_v2basic → A102 读回：AChord="+Utf8ToWide(StripStyleResourcePrefix(ds.chordStyleA))+
                        L"  BChord="+Utf8ToWide(StripStyleResourcePrefix(ds.chordStyleB))+
                        L"  ADrum="+Utf8ToWide(StripStyleResourcePrefix(ds.drumStyleA))+
                        L"  BDrum="+Utf8ToWide(StripStyleResourcePrefix(ds.drumStyleB));
                    return true;
                }, L"正在按 C2SingleResourceAuditioner 流程读取 get_config_v2basic...");
            return 0;
        }

        if (id==IDC_DEV_REFRESH) {
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::RefreshInfo,
                [](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    const bool ok=g_c2.RefreshDeviceInfo(err,status);
                    msg=L"C2 设备信息已刷新";
                    return ok;
                }, L"正在后台读取设备信息...");
            return 0;
        }

        if (id==IDC_DEV_APPLY_MIXER) {
            const C2DeviceState before=g_c2.DeviceState();
            std::vector<std::pair<int,int>> changes;
            for (int ch=1;ch<=13;++ch) {
                int v=0; if (!ReadIntEdit(st->mixer[ch],v)) continue;
                v=std::max<int>(0,std::min<int>(100,v));
                if (before.mixer[static_cast<std::size_t>(ch)]!=v) changes.push_back({ch,v});
            }
            if (changes.empty()) { SetDeviceCenterStatus(st,L"Mixer 没有变化项。 "); return 0; }
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::ApplyMixer,
                [changes=std::move(changes)](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    int changed=0;
                    for (const auto& cv:changes) {
                        if (!g_c2.SetMixerVolume(cv.first,cv.second,err,status)) return false;
                        ++changed;
                    }
                    msg=L"Mixer 应用完成，变化通道="+std::to_wstring(changed);
                    return true;
                }, L"正在后台应用 Mixer...");
            return 0;
        }

        if (id==IDC_DEV_KEY_SET) {
            int v=0;
            if (!ReadIntEdit(st->keyEdit,v)) { MessageBoxW(hwnd,L"Key 输入无效",L"设置 Key",MB_ICONERROR); return 0; }
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::SetKey,
                [v](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.SetDeviceKey(v,err,status)) return false;
                    msg=L"C2 Key 已设置为 "+std::to_wstring(v);
                    return true;
                }, L"正在后台设置 Key...");
            return 0;
        }

        if (id==IDC_DEV_BPM_SET) {
            int v=0;
            if (!ReadIntEdit(st->bpmEdit,v)) { MessageBoxW(hwnd,L"BPM 输入无效",L"设置 BPM",MB_ICONERROR); return 0; }
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::SetBpm,
                [v](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.SetDeviceBpm(v,err,status)) return false;
                    msg=L"C2 BPM 已设置为 "+std::to_wstring(v);
                    return true;
                }, L"正在后台设置 BPM...");
            return 0;
        }

        if (id==IDC_DEV_TONE_SET) {
            std::string card,tone; std::wstring label;
            if (!SelectedTone(st->toneCombo,card,tone,label)) { MessageBoxW(hwnd,L"请选择设备全局旋律音色",L"设置音色",MB_ICONERROR); return 0; }
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::SetDeviceTone,
                [card,tone,label](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.SetDeviceMelodyTone(card,tone,err,status)) return false;
                    msg=L"设备全局旋律音色已设置: "+label;
                    return true;
                }, L"正在按原厂序列设置设备全局旋律音色...");
            return 0;
        }

        if (id==IDC_DEV_LEAD_CURRENT || id==IDC_DEV_LEAD_ALL) {
            const int sel=static_cast<int>(SendMessageW(st->trackCombo,CB_GETCURSEL,0,0));
            if (sel==CB_ERR) { MessageBoxW(hwnd,L"请选择曲谱轨道",L"INT26",MB_ICONERROR); return 0; }
            const int trackId=static_cast<int>(SendMessageW(st->trackCombo,CB_GETITEMDATA,sel,0));
            std::string card,tone; std::wstring label;
            if (!SelectedTone(st->leadToneCombo,card,tone,label)) { MessageBoxW(hwnd,L"请选择轨道音色",L"INT26",MB_ICONERROR); return 0; }
            int vol=80;
            if (!ReadIntEdit(st->leadVolumeEdit,vol)) { MessageBoxW(hwnd,L"轨道音量输入无效",L"INT26",MB_ICONERROR); return 0; }
            vol=std::max<int>(0,std::min<int>(100,vol));
            const bool all=(id==IDC_DEV_LEAD_ALL);
            StartDeviceCenterTask(hwnd,st,all?DeviceCenterTask::TrackAll:DeviceCenterTask::TrackCurrent,
                [trackId,card,tone,vol,all,label](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (trackId==kLeadViolinVirtualTrack || trackId==kLeadPianoVirtualTrack) {
                        std::string matchCard,matchTone; LeadVirtualInfo(trackId,matchCard,matchTone);
                        if (!g_c2.ApplyTrackToneVolumeForTone(0,matchCard,matchTone,card,tone,vol,err,status)) return false;
                        msg=(trackId==kLeadViolinVirtualTrack?L"主旋律01":L"主旋律02")+
                            std::wstring(L" tk0音色组已修改: ")+label+L"  volume="+std::to_wstring(vol);
                        return true;
                    }
                    if (!g_c2.ApplyTrackToneVolume(static_cast<std::uint8_t>(trackId),card,tone,vol,all,err,status)) return false;
                    msg=std::wstring(all?L"全部段":L"当前段")+L" tk"+std::to_wstring(trackId)+L" 已修改: "+label+L"  volume="+std::to_wstring(vol);
                    return true;
                }, (trackId==kLeadViolinVirtualTrack || trackId==kLeadPianoVirtualTrack)?L"正在发送 tk0 主旋律音色组 INT26...":(all?L"正在发送所选轨全部段 INT26...":L"正在读取当前 beat 并发送所选轨当前段 INT26..."));
            return 0;
        }

        if (id==IDC_DEV_STYLE_APPLY) {
            const C2DeviceState before=g_c2.DeviceState();
            std::vector<std::pair<int,int>> changes;
            for (int type=1;type<=7;++type) {
                int v=0;
                if (!ReadIntEdit(st->style[type],v)) continue; // blank = leave untouched
                v=std::max<int>(0,std::min<int>(255,v));
                if (before.styleSettings[static_cast<std::size_t>(type)]!=v) changes.push_back({type,v});
            }
            if (changes.empty()) { SetDeviceCenterStatus(st,L"演奏偏好 / Style Settings 没有变化项。 "); return 0; }
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::ApplyStyle,
                [changes=std::move(changes)](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    int changed=0;
                    for (const auto& tv:changes) {
                        if (!g_c2.SetStyleSetting(tv.first,tv.second,err,status)) return false;
                        ++changed;
                    }
                    msg=L"演奏偏好 / Style Settings 应用完成，变化项="+std::to_wstring(changed);
                    return true;
                }, L"正在后台应用演奏偏好 / Style Settings...");
            return 0;
        }

        if (id==IDC_DEV_JSON_PACK) {
            if (!g_loaded) { MessageBoxW(hwnd,L"请先在主窗口打开 JSON。",L"应用 configV2Pack",MB_ICONINFORMATION); return 0; }
            const MDSSong songCopy=g_song;
            const int bpmCopy=g_bpm;
            StartDeviceCenterTask(hwnd,st,DeviceCenterTask::ApplyJsonPack,
                [songCopy,bpmCopy](std::wstring& err,std::wstring& msg,C2Controller::StatusFn status)->bool {
                    if (!g_c2.ApplyJsonConfigPack(songCopy,bpmCopy,err,status)) return false;
                    msg=L"当前 JSON configV2Pack 已下发；可继续实机试听。";
                    return true;
                }, L"正在后台下发当前 JSON configV2Pack...");
            return 0;
        }
        return 0;
    }
    case WM_SIZE: {
        if (st && st->infoEdit) {
            RECT rc{}; GetClientRect(hwnd,&rc);
            MoveWindow(st->infoEdit,12,836,std::max<int>(300,rc.right-24),std::max<int>(70,rc.bottom-848),TRUE);
        }
        return 0;
    }
    case WM_CLOSE:
        if (st && st->taskRunning) {
            MessageBoxW(hwnd,L"C2 设备操作正在后台执行，请完成后再关闭窗口。",L"C2 设备中心",MB_ICONINFORMATION);
            return 0;
        }
        DestroyWindow(hwnd); return 0;
    case WM_DESTROY:
        if (st) delete st;
        SetWindowLongPtrW(hwnd,GWLP_USERDATA,0);
        g_deviceCenterWnd=nullptr;
        return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}

static void ShowDeviceCenter() {
    if (g_deviceCenterWnd && IsWindow(g_deviceCenterWnd)) {
        ShowWindow(g_deviceCenterWnd,SW_SHOW);
        SetForegroundWindow(g_deviceCenterWnd);
        return;
    }
    WNDCLASSW wc{};
    if (!GetClassInfoW(GetModuleHandleW(nullptr),kDeviceCenterClassName,&wc)) {
        wc.lpfnWndProc=DeviceCenterProc;
        wc.hInstance=GetModuleHandleW(nullptr);
        wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);
        wc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_WINDOW+1);
        wc.lpszClassName=kDeviceCenterClassName;
        RegisterClassW(&wc);
    }
    RECT owner{}; if (g_hwnd) GetWindowRect(g_hwnd,&owner);
    const int ww=1000,hh=990;
    const int x=g_hwnd?owner.left+30:CW_USEDEFAULT;
    const int y=g_hwnd?owner.top+30:CW_USEDEFAULT;
    g_deviceCenterWnd=CreateWindowExW(WS_EX_TOOLWINDOW,kDeviceCenterClassName,L"C2 设备中心 V2.3.20l DrumCue/MasterBPM/PerTrackMIDI / 演奏偏好 StyleSettings + AutoPlay功能映射 / 6/8拍号时值修正 / V2Basic四槽",
        WS_OVERLAPPEDWINDOW|WS_VISIBLE,x,y,ww,hh,g_hwnd,nullptr,GetModuleHandleW(nullptr),nullptr);
}

static void UpdateC2StateLabels() {
    if (!g_c2VolumeStatus || !g_c2BatteryStatus) return;
    if (!g_c2.IsConnected()) {
        SetWindowTextW(g_c2VolumeStatus,L"音量: --");
        SetWindowTextW(g_c2BatteryStatus,L"C2 电量 --");
        return;
    }
    const C2DeviceState st=g_c2.DeviceState();
    auto V=[&](int ch)->std::wstring { const int v=st.mixer[static_cast<std::size_t>(ch)]; return v>=0?std::to_wstring(v):L"--"; };
    const std::wstring vols=L"音量 总"+V(1)+L" A拨"+V(9)+L" B拨"+V(10)+L" A鼓"+V(11)+L" B鼓"+V(12)+L" 琶音"+V(13);
    SetWindowTextW(g_c2VolumeStatus,vols.c_str());
    std::wstring bat=L"C2 电量 "+(st.battery>=0?std::to_wstring(st.battery)+L"%":L"--");
    if (st.charging) bat+=L" [充电]";
    SetWindowTextW(g_c2BatteryStatus,bat.c_str());
}

static std::wstring ToW(double v, int precision = 2) {
    std::wostringstream os;
    os.setf(std::ios::fixed);
    os.precision(precision);
    os << v;
    return os.str();
}

static int EffectiveBpm() { return std::max<int>(20, std::min<int>(300, g_bpm)); }
static double PlaybackScoreBeatsPerSecond() {
    // LiberLive tempo is quarter-note BPM. Timeline score beats follow the JSON
    // denominator: one quarter beat for x/4, one eighth beat for x/8.
    return EffectiveBpm() / 60.0 * (g_loaded ? g_model.ScoreBeatsPerQuarter() : 1.0);
}

static double ClampSongBeat(double beat) {
    if (!g_loaded) return std::max<double>(0.0, beat);
    return std::max<double>(0.0, std::min<double>(g_model.TotalBeats(), beat));
}

static double SnapTimelinePosition(double rawBeat) {
    rawBeat = ClampSongBeat(rawBeat);
    if (!g_loaded) return rawBeat;
    if (g_timelineMode == TimelineInteractionMode::Edit)
        return ClampSongBeat(std::round(rawBeat * 4.0) / 4.0);
    return ClampSongBeat(g_model.SnapToChordSection(rawBeat));
}

static void ResetC2PerformanceFlow(bool keepArmed = false) {
    g_c2FlowRunning = false;
    g_c2FlowStopBeat = g_positionBeat;
    g_c2FlowLastTick = GetTickCount64();
    g_c2HaveAcceptedDeviceBeat = false;
    g_c2AcceptedDeviceBeat = g_positionBeat;
    if (!keepArmed) g_c2PerformanceArmed = false;
}

static int C2ChordRootCode(const std::string& s) {
    if (s=="C" || s=="#B") return 0;
    if (s=="#C" || s=="Db" || s=="bD") return 1;
    if (s=="D") return 2;
    if (s=="#D" || s=="Eb" || s=="bE") return 3;
    if (s=="E" || s=="Fb" || s=="bF") return 4;
    if (s=="F" || s=="#E") return 5;
    if (s=="#F" || s=="Gb" || s=="bG") return 6;
    if (s=="G") return 7;
    if (s=="#G" || s=="Ab" || s=="bA") return 8;
    if (s=="A") return 9;
    if (s=="#A" || s=="Bb" || s=="bB") return 10;
    if (s=="B" || s=="Cb" || s=="bC") return 11;
    return -1;
}

static int C2ExpectedChordType(const std::string& attachKey) {
    // Same mapping currently used by the C2 FILL encoder: major=0, minor=1.
    // Other qualities are kept visible in diagnostics but remain encoded as 0
    // until their binary type values are confirmed by captures.
    return attachKey=="m" ? 1 : 0;
}

static std::wstring C2ChordLabel(const MDSChord& chord) {
    std::wstring label=Utf8ToWide(chord.mainKey);
    if (!chord.attachKey.empty()) label+=Utf8ToWide(chord.attachKey);
    if (!chord.transKey.empty()) label+=L"/"+Utf8ToWide(chord.transKey);
    return label.empty()?L"?":label;
}

static std::wstring C2PlayedChordLabel(const C2PlayEvent& event) {
    static const wchar_t* kNames[12]={L"C",L"C#",L"D",L"D#",L"E",L"F",L"F#",L"G",L"G#",L"A",L"A#",L"B"};
    std::wstring label=(event.level>=0 && event.level<12)?kNames[event.level]:L"?";
    if (event.type==1) label+=L"m";
    else if (event.type>1) label+=L"(type="+std::to_wstring(event.type)+L")";
    return label;
}

// Return the chord the player is asking for at the current stopped gate.  At a
// real chord boundary this is the section starting exactly at the cursor.  If a
// song has a lead-only intro before its first chord, use that first upcoming
// chord as the physical trigger while the UI still starts from beat 0.
static const MDSChordSection* ExpectedC2ChordSection(double gateBeat) {
    const auto& sections=g_model.ChordSections();
    if (sections.empty()) return nullptr;
    gateBeat=ClampSongBeat(gateBeat);
    for (const auto& sec:sections)
        if (std::fabs(sec.startBeat-gateBeat)<=0.20) return &sec;
    if (gateBeat < sections.front().startBeat) return &sections.front();
    for (const auto& sec:sections)
        if (sec.startBeat > gateBeat+0.20) return &sec;
    return &sections.back();
}

static bool ValidateC2ChordTriggerAt(const C2PlayEvent& event,double targetBeat,const MDSChordSection*& expected,std::wstring& reason) {
    expected=ExpectedC2ChordSection(targetBeat);
    if (!expected || !expected->source || !expected->source->hasChord) {
        reason=L"当前位置没有可验证的和弦";
        return false;
    }
    const MDSChord& chord=expected->source->chord;
    const int expectedRoot=C2ChordRootCode(chord.mainKey);
    const int expectedType=C2ExpectedChordType(chord.attachKey);

    // V2.3.20j: A / B / A+B are all valid physical strum events. The score's
    // pickType remains a visual performance cue only and never blocks transport.
    if (event.pickId<0 || event.pickId>2) {
        reason=L"未识别的实体拨片事件";
        return false;
    }
    if (expectedRoot<0 || event.level!=expectedRoot) {
        reason=L"目标="+C2ChordLabel(chord)+L"，实际="+C2PlayedChordLabel(event);
        return false;
    }
    if (event.type>=0 && event.type!=expectedType) {
        reason=L"目标="+C2ChordLabel(chord)+L"，实际="+C2PlayedChordLabel(event);
        return false;
    }
    return true;
}

// V2.3.20j hard performance gate: physical chord/key is authoritative for PC
// transport. The score may request A, B or A+B, but C2 itself accepts a correct
// chord with another pick direction; the PC must follow C2 instead of freezing.
static bool ValidateC2ChordRootGateAt(const C2PlayEvent& event,double targetBeat,const MDSChordSection*& expected,std::wstring& reason) {
    expected=ExpectedC2ChordSection(targetBeat);
    if (!expected || !expected->source || !expected->source->hasChord) {
        reason=L"当前位置没有可验证的和弦";
        return false;
    }
    const MDSChord& chord=expected->source->chord;
    const int expectedRoot=C2ChordRootCode(chord.mainKey);
    // Do not gate transport on pickId. A/B/A+B are equivalent for advancement;
    // chord/key matching below is the hard gate.
    if (expectedRoot<0 || event.level!=expectedRoot) {
        reason=L"目标="+C2ChordLabel(chord)+L"，实际="+C2PlayedChordLabel(event);
        return false;
    }
    // V2.3.20l real-device rule: transport is gated by the physical chord ROOT
    // only. C2 can continue sounding/advancing across F -> Fm even when the same
    // physical F key shape is kept. Therefore major/minor/type/trans are
    // diagnostics only and must never freeze the red cursor.
    return true;
}

static std::wstring SegmentTypeBaseName(int type) {
    switch (type) {
    case 0: return L"前奏";
    case 1: return L"导歌";
    case 2: return L"主歌";
    case 3: return L"副歌";
    case 4: return L"间奏";
    case 6: return L"尾奏";
    default: return L"Type " + std::to_wstring(type);
    }
}

static std::wstring SegmentDisplayName(std::size_t segmentIndex) {
    if (segmentIndex >= g_model.Segments().size()) return L"-";
    const int type = g_model.Segments()[segmentIndex].type;
    std::size_t totalSame = 0, ordinal = 0;
    for (std::size_t i = 0; i < g_model.Segments().size(); ++i) {
        if (g_model.Segments()[i].type == type) {
            ++totalSame;
            if (i <= segmentIndex) ++ordinal;
        }
    }
    std::wstring s = SegmentTypeBaseName(type);
    if (totalSame > 1) s += std::to_wstring(ordinal);
    return s;
}

static const MDSTrackConfig* TrackConfigByIndex(int idx) {
    for (const MDSTrackConfig& tc : g_song.content.trackConfigs)
        if (tc.index == idx) return &tc;
    return nullptr;
}

static bool FindC2Type13Lead(std::string& card,std::string& tone) {
    card.clear(); tone.clear();
    for (const auto& seg:g_song.content.lyrics) for (const auto& bar:seg.bars) for (const auto& beat:bar.beats)
        for (const auto& e:beat.extensions) if (e.type=="13" && !e.cardCode.empty() && !e.code.empty()) {
            const bool c2=e.cardCode.rfind("sound_c2",0)==0 || e.cardCode.rfind("scard_",0)==0;
            if (c2) { card=e.cardCode; tone=e.code; return true; }
        }
    return false;
}

static bool HasDualMainMelody() {
    // Primary evidence: the uploaded INT25 schedule itself.  The official App
    // exposes Moon's tk0 as two logical melody entries because tk0 uses both
    // Violin and PianoStudio in different section ranges.
    if (g_c2.HasUploadedSheet()) {
        bool violin=false,piano=false;
        for (const auto& sec:g_c2.LastPlan().scheduleSections) for (const auto& t:sec.tracks) if (t.trackId==0) {
            if (t.noteCode=="Violin" || t.noteCode=="Viola") violin=true;
            if (t.noteCode=="PianoStudio") piano=true;
        }
        if (violin && piano) return true;
    }
    // Before upload, type14 is the authoritative lead schedule in the JSON model.
    bool violin=false,piano=false;
    for (const auto& seg:g_song.content.lyrics) for (const auto& bar:seg.bars) for (const auto& beat:bar.beats)
        for (const auto& e:beat.extensions) if (e.type=="14")
            for (const auto& a:e.assetNotes) {
                if (a.noteCode=="Violin" || a.noteCode=="Viola") violin=true;
                if (a.noteCode=="PianoStudio") piano=true;
            }
    return violin && piano;
}

static bool LeadVirtualInfo(int virtualTrack,std::string& card,std::string& tone) {
    const bool wantPiano=(virtualTrack==kLeadPianoVirtualTrack);
    if (virtualTrack!=kLeadViolinVirtualTrack && !wantPiano) return false;
    card=wantPiano?"sound_c2":"scard_01";
    tone=wantPiano?"PianoStudio":"Violin";

    if (g_c2.HasUploadedSheet()) {
        for (const auto& sec:g_c2.LastPlan().scheduleSections) for (const auto& t:sec.tracks) if (t.trackId==0) {
            const bool match=wantPiano?(t.noteCode=="PianoStudio"):(t.noteCode=="Violin" || t.noteCode=="Viola");
            if (match) { card=t.cardCode; tone=t.noteCode; return true; }
        }
    }
    for (const auto& seg:g_song.content.lyrics) for (const auto& bar:seg.bars) for (const auto& beat:bar.beats)
        for (const auto& e:beat.extensions) if (e.type=="14")
            for (const auto& a:e.assetNotes) {
                const bool match=wantPiano?(a.noteCode=="PianoStudio"):(a.noteCode=="Violin" || a.noteCode=="Viola");
                if (match) { card=a.timbreCardCode; tone=a.noteCode; return true; }
            }
    return true;
}

static bool SegmentUsesLeadVirtual(std::size_t segmentIndex,int virtualTrack) {
    if (segmentIndex>=g_model.Segments().size()) return false;
    std::string wantCard,wantTone;
    if (!LeadVirtualInfo(virtualTrack,wantCard,wantTone)) return false;

    if (g_c2.HasUploadedSheet()) {
        const auto& plan=g_c2.LastPlan();
        if (segmentIndex<plan.scheduleSections.size()) {
            for (const auto& t:plan.scheduleSections[segmentIndex].tracks) if (t.trackId==0) {
                if (virtualTrack==kLeadPianoVirtualTrack) return t.noteCode=="PianoStudio";
                return t.noteCode=="Violin" || t.noteCode=="Viola";
            }
        }
    }

    // Before upload, use the official JSON extension-type13 markers as a best-effort
    // indication of the alternate violin lead.  Otherwise the section belongs to piano.
    if (segmentIndex<g_song.content.lyrics.size()) {
        bool hasAlt=false;
        for (const auto& bar:g_song.content.lyrics[segmentIndex].bars)
            for (const auto& beat:bar.beats)
                for (const auto& e:beat.extensions)
                    if (e.type=="13" && (e.code=="Violin" || e.code=="Viola")) hasAlt=true;
        return virtualTrack==kLeadViolinVirtualTrack ? hasAlt : !hasAlt;
    }
    return virtualTrack==kLeadPianoVirtualTrack;
}

static int TrackTypeOrdinal(int idx, int type) {
    int ordinal = 0;
    for (const MDSTrackConfig& tc : g_song.content.trackConfigs) {
        if (tc.type == type) ++ordinal;
        if (tc.index == idx) return ordinal;
    }
    return 0;
}

static bool IsPerformanceSlotTrack(int trackIndex) {
    return trackIndex==kStyleAChordVirtualTrack || trackIndex==kStyleBChordVirtualTrack ||
        trackIndex==kStyleADrumVirtualTrack || trackIndex==kStyleBDrumVirtualTrack;
}

static int PerformanceSlotIndex(int trackIndex) {
    if (trackIndex==kStyleAChordVirtualTrack) return 0;
    if (trackIndex==kStyleBChordVirtualTrack) return 1;
    if (trackIndex==kStyleADrumVirtualTrack) return 2;
    if (trackIndex==kStyleBDrumVirtualTrack) return 3;
    return -1;
}

static int PerformanceSlotMixerChannel(int trackIndex) {
    const int slot=PerformanceSlotIndex(trackIndex);
    return slot<0 ? -1 : (0x09+slot); // 09=A拨片, 0A=B拨片, 0B=A鼓, 0C=B鼓
}

static const MDSConfigEntry* PerformanceSlotConfig(int trackIndex) {
    const int slot=PerformanceSlotIndex(trackIndex);
    if (slot<0) return nullptr;
    const bool drum=slot>=2;
    const int pickType=slot&1;
    const auto& v=drum ? g_song.content.baseConfig.configPack.drums : g_song.content.baseConfig.configPack.chords;
    for (const auto& e:v) if (e.pickType==pickType) return &e;
    if (static_cast<std::size_t>(pickType)<v.size()) return &v[static_cast<std::size_t>(pickType)];
    return nullptr;
}

static int PerformanceSlotOriginalVolume(int trackIndex) {
    const auto it=g_trackOriginalVolume.find(trackIndex);
    if (it!=g_trackOriginalVolume.end()) return std::max(0,std::min(100,it->second));
    const MDSConfigEntry* e=PerformanceSlotConfig(trackIndex);
    if (e && e->hasPickVolume) return std::max(0,std::min(100,e->pickVolume));
    return 100;
}

static std::wstring PerformanceSlotResourceName(int trackIndex) {
    const MDSConfigEntry* e=PerformanceSlotConfig(trackIndex);
    if (!e || e->nameCode.empty()) return L"-";
    const bool drum=PerformanceSlotIndex(trackIndex)>=2;
    const std::string code=StripStyleResourcePrefix(e->nameCode);
    const auto* meta=FindCatalogStyleMeta(code);
    std::wstring zh;
    if (meta) zh=!meta->displayZh.empty()?meta->displayZh:(!meta->exactZh.empty()?meta->exactZh:meta->familyZh);
    if (zh.empty()) zh=StyleResourceFamilyZh(code,drum);
    const std::wstring wc=Utf8ToWide(code);
    if (zh.empty() || zh==wc) return wc;
    return zh+L" / "+wc;
}

static std::wstring PerformanceSlotBeatText(int trackIndex) {
    const std::string scoreBeat=!g_song.content.beat.empty()?g_song.content.beat:g_song.content.baseConfig.beat;
    if (!scoreBeat.empty()) return Utf8ToWide(scoreBeat);
    if (g_c2.IsConnected()) {
        const int slot=PerformanceSlotIndex(trackIndex);
        if (slot>=0) {
            const int m=g_c2.DeviceState().basicStyleMeter[static_cast<std::size_t>(slot)];
            if (m==0) return L"3/4"; if (m==1) return L"4/4"; if (m==3) return L"6/8";
        }
    }
    return L"-";
}

static std::wstring PerformanceSlotBpmText(int trackIndex) {
    const int scoreBpm=g_song.content.tempo>0?g_song.content.tempo:g_song.content.baseConfig.bpm;
    if (scoreBpm>0) return std::to_wstring(scoreBpm);
    if (g_c2.IsConnected()) {
        const int slot=PerformanceSlotIndex(trackIndex);
        if (slot>=0) {
            const int b=g_c2.DeviceState().basicStyleBpm[static_cast<std::size_t>(slot)];
            if (b>0) return std::to_wstring(b);
        }
    }
    return L"-";
}

static std::wstring TrackRoleName(int trackIndex) {
    if (trackIndex == kStyleAChordVirtualTrack) return L"A拨片和弦";
    if (trackIndex == kStyleBChordVirtualTrack) return L"B拨片和弦";
    if (trackIndex == kStyleADrumVirtualTrack) return L"A鼓";
    if (trackIndex == kStyleBDrumVirtualTrack) return L"B鼓";
    if (trackIndex == kLeadViolinVirtualTrack) return L"主旋律01";
    if (trackIndex == kLeadPianoVirtualTrack) return L"主旋律02";
    if (trackIndex == 0) return L"主旋律";
    const MDSTrackConfig* tc = TrackConfigByIndex(trackIndex);
    if (!tc) return L"轨道" + std::to_wstring(trackIndex);
    const int ord = std::max<int>(1, TrackTypeOrdinal(trackIndex, tc->type));
    wchar_t num[8]{};
    wsprintfW(num, L"%02d", ord);
    if (tc->type == 1) return std::wstring(L"铺底轨") + num;
    if (tc->type == 2) return std::wstring(L"加花轨") + num;
    return std::wstring(L"轨道") + num;
}

static std::wstring TimbreChineseName(const std::string& code) {
    // Reuse the verified factory C2 tone catalogue so the track list stays
    // consistent with Device Center. Unknown resource codes remain readable.
    for (const auto& choice : kC2ToneChoices) {
        if (code == choice.code) return choice.name;
    }
    return Utf8ToWide(code);
}

static std::wstring TimbreBilingualName(const std::string& code) {
    if (code.empty()) return L"-";
    const std::wstring en = Utf8ToWide(code);
    const std::wstring zh = TimbreChineseName(code);
    if (zh.empty() || zh == en) return en;
    // Chinese first follows the official App naming; the exact resource code
    // is kept after a slash for protocol/debug work.
    return zh + L" / " + en;
}

static bool RuntimeScheduleForModelTrack(int trackIndex,std::string& card,std::string& tone,int& volume) {
    if (trackIndex==kLeadViolinVirtualTrack || trackIndex==kLeadPianoVirtualTrack) {
        LeadVirtualInfo(trackIndex,card,tone);
        volume=(trackIndex==kLeadViolinVirtualTrack)?40:64;
        if (g_c2.HasUploadedSheet()) {
            const auto& plan=g_c2.LastPlan();
            for (const auto& sec:plan.scheduleSections) for (const auto& t:sec.tracks) if (t.trackId==0) {
                const bool match=(trackIndex==kLeadPianoVirtualTrack)?(t.noteCode=="PianoStudio"):(t.noteCode=="Violin"||t.noteCode=="Viola");
                if (match) { card=t.cardCode; tone=t.noteCode; volume=t.volume; return true; }
            }
        }
        return true;
    }
    if (!g_c2.HasUploadedSheet()) return false;
    const int c2TrackId = (trackIndex==0) ? 0 : trackIndex+2;
    std::size_t sections=0;
    return FirstTrackScheduleState(static_cast<std::uint8_t>(c2TrackId),card,tone,volume,sections);
}

static std::wstring TrackTimbreName(int trackIndex) {
    if (trackIndex==kLeadViolinVirtualTrack || trackIndex==kLeadPianoVirtualTrack) {
        std::string c,t; LeadVirtualInfo(trackIndex,c,t); return TimbreBilingualName(t);
    }
    // Once a sheet has been uploaded, the C2 schedule is the authoritative
    // runtime source. This keeps the main-window "全部轨道" list synchronized
    // with Device Center INT26 edits instead of continuing to show stale JSON.
    std::string runtimeCard,runtimeTone; int runtimeVol=80;
    if (RuntimeScheduleForModelTrack(trackIndex,runtimeCard,runtimeTone,runtimeVol) && !runtimeTone.empty())
        return TimbreBilingualName(runtimeTone);

    // tk0 is the scheduled lead layer.  In dual-main-melody scores, preserve
    // extension type13 (e.g. Violin) as 主旋律02 instead of collapsing it into
    // the base PianoStudio lead layer shown above as 主旋律01.
    if (trackIndex == 0) {
        std::string card,tone;
        if (FindC2Type13Lead(card,tone)) return TimbreBilingualName(tone);
        const std::size_t sep=g_song.content.melodicNote.find(':');
        if (sep!=std::string::npos) tone=g_song.content.melodicNote.substr(sep+1);
        else tone=g_song.content.melodicNote;
        return tone.empty()?TimbreBilingualName("PianoStudio"):TimbreBilingualName(tone);
    }
    const MDSTrackConfig* tc = TrackConfigByIndex(trackIndex);
    if (!tc) return L"-";
    if (!tc->assetNotes.empty() && !tc->assetNotes.front().noteCode.empty()) {
        std::wstring zh = TimbreBilingualName(tc->assetNotes.front().noteCode);
        if (!zh.empty()) return zh;
    }
    if (!tc->noteCode.empty()) return TimbreBilingualName(tc->noteCode);
    return Utf8ToWide(tc->name);
}

static bool IsTrackEnabled(int trackIndex) {
    const auto it = g_trackEnabled.find(trackIndex);
    return it == g_trackEnabled.end() ? true : it->second;
}

static bool IsTrackActiveForSegment(int trackIndex, std::size_t segmentIndex) {
    if (trackIndex==kLeadViolinVirtualTrack || trackIndex==kLeadPianoVirtualTrack)
        return g_model.SegmentTrackNoteCount(segmentIndex,0)>0 && SegmentUsesLeadVirtual(segmentIndex,trackIndex);
    if (segmentIndex >= g_model.Segments().size()) return false;
    if (g_model.SegmentTrackNoteCount(segmentIndex, trackIndex) == 0) return false;
    if (trackIndex == 0 && !g_model.SegmentUsesMainMelodyAt(segmentIndex)) return false;
    return true;
}

static bool IsScheduledNotePlayable(const MDSScheduledNote& n) {
    if (n.trackIndex==0 && HasDualMainMelody()) {
        const int logical=SegmentUsesLeadVirtual(n.segmentIndex,kLeadViolinVirtualTrack)?kLeadViolinVirtualTrack:kLeadPianoVirtualTrack;
        return IsTrackEnabled(logical) && IsTrackActiveForSegment(logical,n.segmentIndex);
    }
    return IsTrackEnabled(n.trackIndex) && IsTrackActiveForSegment(n.trackIndex, n.segmentIndex);
}

// ---- Local PC MIDI timbre mapping -------------------------------------------------
// C2/SCARD tone codes are proprietary. Windows MIDI Mapper is General MIDI, so local
// playback uses the closest GM program while preserving each JSON track's own timbre
// identity. This is intentionally a PC-preview mapping only; no C2 JSON/timbre data is
// rewritten.
static std::string LowerAscii(std::string v) {
    for (char& c:v) c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return v;
}

static int GmProgramForTone(const std::string& toneCode) {
    const std::string s=LowerAscii(toneCode);
    if (s.empty()) return 0;
    if (s.find("pianorhodes")!=std::string::npos || s.find("rhodes")!=std::string::npos ||
        s.find("mks20")!=std::string::npos || s=="ep2" || s.find("electricpiano")!=std::string::npos) return 4;
    if (s.find("piano")!=std::string::npos) return 0;
    if (s.find("organ")!=std::string::npos) return 16;
    if (s.find("accordion")!=std::string::npos) return 21;
    if (s.find("guitarn")!=std::string::npos || s.find("nylon")!=std::string::npos) return 24;
    if (s.find("guitars")!=std::string::npos || s.find("steel")!=std::string::npos) return 25;
    if (s.find("egsolo")!=std::string::npos || s.find("lgsolo")!=std::string::npos ||
        s.find("guitar")!=std::string::npos || s.find("gec")!=std::string::npos || s.find("ged")!=std::string::npos) return 29;
    if (s.find("bass")!=std::string::npos) return 33;
    if (s.find("violin")!=std::string::npos || s.find("fiddle")!=std::string::npos) return 40;
    if (s.find("viola")!=std::string::npos) return 41;
    if (s.find("cello")!=std::string::npos) return 42;
    if (s.find("string")!=std::string::npos) return 48;
    if (s.find("trumpet")!=std::string::npos) return 56;
    if (s.find("trombone")!=std::string::npos) return 57;
    if (s.find("sax")!=std::string::npos) return 65;
    if (s.find("recorder")!=std::string::npos) return 74;
    if (s.find("flute")!=std::string::npos) return 73;
    if (s.find("harp")!=std::string::npos) return 46;
    if (s.find("guzheng")!=std::string::npos || s.find("koto")!=std::string::npos) return 107;
    if (s.find("summerbell")!=std::string::npos || s.find("bell")!=std::string::npos) return 14;
    if (s.find("marimba")!=std::string::npos) return 12;
    if (s.find("toy")!=std::string::npos || s.find("musicbox")!=std::string::npos) return 10;
    if (s.find("pad")!=std::string::npos) return 89;
    if (s.find("pluck")!=std::string::npos) return 45;
    if (s.find("key")!=std::string::npos || s.find("mk80")!=std::string::npos) return 4;
    return 0;
}

static void SplitTimbreCode(const std::string& full,std::string& card,std::string& tone) {
    card.clear(); tone=full;
    const std::size_t sep=full.find(':');
    if (sep!=std::string::npos) { card=full.substr(0,sep); tone=full.substr(sep+1); }
}

static void JsonLeadVoiceAtBeat(double scoreBeat,std::string& tone,int& volume) {
    std::string card;
    SplitTimbreCode(g_song.content.melodicNote,card,tone);
    if (tone.empty()) tone="PianoStudio";
    volume=100;
    // type13/type14 can override the lead sound for a bounded region. Choose the
    // latest active marker at this note position, matching the JSON rather than a
    // single global Piano program.
    double best=-1.0;
    for (const MDSFlatBeat& fb:g_model.Beats()) {
        if (!fb.source || fb.absoluteBeat>scoreBeat+0.001) break;
        for (const MDSExtension& e:fb.source->extensions) {
            const double start=fb.absoluteBeat+g_model.RawUnitsToScoreBeats(e.start);
            if (start>scoreBeat+0.001) continue;
            const double end=(e.length>0.0)?start+g_model.RawUnitsToScoreBeats(e.length):1.0e30;
            if (scoreBeat>=end-0.001) continue;
            std::string candidate;
            int candidateVol=volume;
            if (e.type=="13" && !e.code.empty()) candidate=e.code;
            if (e.type=="14" && !e.assetNotes.empty() && !e.assetNotes.front().noteCode.empty()) {
                candidate=e.assetNotes.front().noteCode;
                if (e.volume>0) candidateVol=e.volume;
            }
            if (!candidate.empty() && start>=best) { best=start; tone=candidate; volume=candidateVol; }
        }
    }
}

static void JsonTrackVoiceForNote(const MDSScheduledNote& n,std::string& tone,int& volume) {
    tone.clear(); volume=100;
    if (n.trackIndex==0) {
        JsonLeadVoiceAtBeat(n.startBeat,tone,volume);
        return;
    }
    const MDSTrackConfig* tc=TrackConfigByIndex(n.trackIndex);
    if (!tc) { tone="PianoStudio"; return; }
    volume=tc->volume;
    if (!tc->assetNotes.empty() && !tc->assetNotes.front().noteCode.empty()) tone=tc->assetNotes.front().noteCode;
    else if (!tc->noteCode.empty()) tone=tc->noteCode;
    else tone=tc->name;
}

static void ApplyMidiVoiceForNote(const MDSScheduledNote& n) {
    if (!g_midi || n.midiChannel<0 || n.midiChannel>=16 || n.midiChannel==9) return;
    std::string tone; int volume=100;
    JsonTrackVoiceForNote(n,tone,volume);
    const int program=std::max<int>(0,std::min<int>(127,GmProgramForTone(tone)));
    const int cc7=std::max<int>(0,std::min<int>(127,volume));
    const std::size_t ch=static_cast<std::size_t>(n.midiChannel);
    if (g_midiPrograms[ch]!=program) {
        midiOutShortMsg(g_midi,static_cast<DWORD>(0xC0 | n.midiChannel | (program<<8)));
        g_midiPrograms[ch]=program;
    }
    if (g_midiVolumes[ch]!=cc7) {
        midiOutShortMsg(g_midi,static_cast<DWORD>(0xB0 | n.midiChannel | (7<<8) | (cc7<<16)));
        g_midiVolumes[ch]=cc7;
    }
}

static void MidiAllOff() {
    if (!g_midi) { g_activeMidi.clear(); return; }
    for (int ch = 0; ch < 16; ++ch)
        midiOutShortMsg(g_midi, static_cast<DWORD>(0xB0 | ch | (123 << 8)));
    for (const ActiveMidi& a : g_activeMidi)
        midiOutShortMsg(g_midi, static_cast<DWORD>(0x80 | a.channel | (a.note << 8)));
    g_activeMidi.clear();
}

static void EnsureMidi() {
    if (g_midi || !g_midiCheck || SendMessageW(g_midiCheck, BM_GETCHECK, 0, 0) != BST_CHECKED) return;
    if (midiOutOpen(&g_midi, MIDI_MAPPER, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) { g_midi = nullptr; return; }
    g_midiPrograms.fill(-1);
    g_midiVolumes.fill(-1);
    // Do NOT initialize every channel to Piano. ApplyMidiVoiceForNote() assigns
    // the closest GM voice from melodicNote / trackConfigs / active type13/14.
}

static void StartMidiNote(const MDSScheduledNote& n) {
    if (!g_midi) return;
    ApplyMidiVoiceForNote(n);

    // Every JSON note onset must be audible, including repeated/tied-looking notes
    // on consecutive beats. If the same MIDI note is still active on this channel,
    // explicitly end the old voice before retriggering it. Otherwise the old NoteOff
    // can later cut off the newly-triggered voice on many Windows MIDI synths.
    for (auto it = g_activeMidi.begin(); it != g_activeMidi.end();) {
        if (it->channel == n.midiChannel && it->note == n.midiNote) {
            midiOutShortMsg(g_midi, static_cast<DWORD>(0x80 | it->channel | (it->note << 8)));
            it = g_activeMidi.erase(it);
        } else {
            ++it;
        }
    }
    midiOutShortMsg(g_midi, static_cast<DWORD>(0x90 | n.midiChannel | (n.midiNote << 8) | (n.velocity << 16)));
    g_activeMidi.push_back({n.midiNote, n.midiChannel, n.trackIndex, n.endBeat});
}

static void CloseMidi() {
    MidiAllOff();
    if (g_midi) { midiOutReset(g_midi); midiOutClose(g_midi); g_midi = nullptr; }
    g_midiPrograms.fill(-1);
    g_midiVolumes.fill(-1);
}

static std::wstring ChordText(const MDSBeat& b) {
    if (!b.hasChord) return L"-";
    std::wstring s = Utf8ToWide(b.chord.mainKey);
    if (!b.chord.attachKey.empty()) s += Utf8ToWide(b.chord.attachKey);
    return s.empty() ? L"-" : s;
}

static void AppendNoteLine(std::wostringstream& os, const MDSNote& n) {
    os << L"    n=" << n.note << L" oct=" << n.upOctave
       << L" start=" << n.start << L" len=" << n.length << L" vel=" << n.velocity
       << L" stretch=" << (n.stretch ? 1 : 0) << L"\r\n";
}

static std::wstring PickTypeName(int pickType) {
    switch (pickType) {
    case 0: return L"A拨片";
    case 1: return L"B拨片";
    case 2: return L"A+B拨片";
    default: return L"未知拨片(" + std::to_wstring(pickType) + L")";
    }
}

static std::wstring DrumSwitchName(int switchType) {
    if (switchType==1) return L"启动鼓";
    if (switchType==0) return L"关闭鼓";
    return L"鼓切换("+std::to_wstring(switchType)+L")";
}

// V2.3.20l: official 《红日（进阶版）》 APK timeline + matching JSON/BLE capture
// closed the previously ambiguous type=3 cue semantics for the main-screen cue lane:
//   type3 switchType=1 pick=0 -> 进A鼓
//   type3 switchType=1 pick=1 -> 进B鼓
//   type3 switchType=0        -> 关鼓机
// This is deliberately separate from SET_AUTO_PLAY type=3.  03 00/03 01 controls
// whether the drum machine may auto-shift; it is NOT the per-beat A/B drum cue.
static std::wstring PickCueName(int pickType) {
    switch (pickType) {
    case 0: return L"用A拨片";
    case 1: return L"用B拨片";
    case 2: return L"用A+B拨片";
    default: return L"用未知拨片("+std::to_wstring(pickType)+L")";
    }
}

static std::wstring Type3DrumCueName(const MDSExtension& e) {
    if (e.switchType==0) return L"关鼓机";
    if (e.switchType==1) {
        if (e.pick==0) return L"进A鼓";
        if (e.pick==1) return L"进B鼓";
        if (e.pick==2) return L"进A+B鼓";
        return L"进鼓("+std::to_wstring(e.pick)+L")";
    }
    return L"鼓切换("+std::to_wstring(e.switchType)+L")";
}

static std::vector<int> AllTrackIndexes() {
    std::vector<int> out;
    if (HasDualMainMelody()) {
        out.push_back(kLeadViolinVirtualTrack);
        out.push_back(kLeadPianoVirtualTrack);
    }
    for (const MDSPlaybackTrack& t : g_model.Tracks()) {
        if (HasDualMainMelody() && t.index==0) continue; // tk0 is represented by two logical main-melody rows.
        out.push_back(t.index);
    }
    auto category = [&](int idx) {
        if (idx == kLeadViolinVirtualTrack) return -2;
        if (idx == kLeadPianoVirtualTrack) return -1;
        if (idx == 0) return 0;
        const MDSPlaybackTrack* t = g_model.FindTrack(idx);
        if (!t) return 3;
        if (t->type == 1) return 1;
        if (t->type == 2) return 2;
        return 3;
    };
    std::sort(out.begin(), out.end(), [&](int a, int b) {
        const int ca = category(a), cb = category(b);
        if (ca != cb) return ca < cb;
        return a < b;
    });
    return out;
}

static void InitTrackListColumns() {
    ListView_SetExtendedListViewStyle(g_tracks,
        LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_CHECKBOXES | LVS_EX_DOUBLEBUFFER);
    struct Col { const wchar_t* text; int width; } cols[] = {
        {L"轨道角色", 92}, {L"资源 / 音色", 176}, {L"Vol", 42}, {L"节拍", 48}, {L"BPM", 44}, {L"总Notes", 58}, {L"本段Notes", 64}
    };
    for (int i = 0; i < 7; ++i) {
        LVCOLUMNW c{};
        c.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM;
        c.pszText = const_cast<LPWSTR>(cols[i].text);
        c.cx = cols[i].width;
        c.iSubItem = i;
        ListView_InsertColumn(g_tracks, i, &c);
    }
}

static void InsertPerformanceSlotRow(int& row,int trackIndex) {
    const int channel=PerformanceSlotMixerChannel(trackIndex);
    int vol=PerformanceSlotOriginalVolume(trackIndex);
    if (g_c2.IsConnected() && channel>=1) {
        const int got=g_c2.DeviceState().mixer[static_cast<std::size_t>(channel)];
        if (got>=0) vol=got;
    }
    LVITEMW item{};
    item.mask=LVIF_TEXT|LVIF_PARAM;
    item.iItem=row; item.iSubItem=0;
    const std::wstring role=TrackRoleName(trackIndex);
    item.pszText=const_cast<LPWSTR>(role.c_str()); item.lParam=trackIndex;
    const int inserted=ListView_InsertItem(g_tracks,&item);
    if (inserted>=0) {
        const std::wstring resource=PerformanceSlotResourceName(trackIndex);
        const std::wstring wvol=std::to_wstring(vol);
        const std::wstring meter=PerformanceSlotBeatText(trackIndex);
        const std::wstring bpm=PerformanceSlotBpmText(trackIndex);
        ListView_SetItemText(g_tracks,inserted,1,const_cast<LPWSTR>(resource.c_str()));
        ListView_SetItemText(g_tracks,inserted,2,const_cast<LPWSTR>(wvol.c_str()));
        ListView_SetItemText(g_tracks,inserted,3,const_cast<LPWSTR>(meter.c_str()));
        ListView_SetItemText(g_tracks,inserted,4,const_cast<LPWSTR>(bpm.c_str()));
        ListView_SetItemText(g_tracks,inserted,5,const_cast<LPWSTR>(L"-"));
        ListView_SetItemText(g_tracks,inserted,6,const_cast<LPWSTR>(L"-"));
        ListView_SetCheckState(g_tracks,inserted,IsTrackEnabled(trackIndex)?TRUE:FALSE);
    }
    ++row;
}

static void PopulateTracksForSegment(std::size_t segmentIndex) {
    if (!g_tracks) return;
    g_populatingTracks = true;
    SendMessageW(g_tracks, WM_SETREDRAW, FALSE, 0);
    ListView_DeleteAllItems(g_tracks);

    const bool validSegment = segmentIndex < g_model.Segments().size();
    const std::vector<int> all = AllTrackIndexes();
    std::size_t activeCount = 0;
    int row = 0;

    // V2.3.20m: performance mixer slots always occupy the first four rows.
    // They control C2 mixer 09/0A/0B/0C and are intentionally not note tracks.
    InsertPerformanceSlotRow(row,kStyleAChordVirtualTrack);
    InsertPerformanceSlotRow(row,kStyleBChordVirtualTrack);
    InsertPerformanceSlotRow(row,kStyleADrumVirtualTrack);
    InsertPerformanceSlotRow(row,kStyleBDrumVirtualTrack);

    for (int idx : all) {
        const int modelIdx=(idx==kLeadViolinVirtualTrack || idx==kLeadPianoVirtualTrack)?0:idx;
        const MDSPlaybackTrack* t = g_model.FindTrack(modelIdx);
        const bool active = validSegment && IsTrackActiveForSegment(idx, segmentIndex);
        if (active) ++activeCount;

        std::wstring role = TrackRoleName(idx);
        if (!active && validSegment) role += L"  ·";
        const std::wstring timbre = TrackTimbreName(idx);
        std::string rtCard,rtTone; int rtVol=80;
        const bool haveRuntime=RuntimeScheduleForModelTrack(idx,rtCard,rtTone,rtVol);
        const std::wstring vol = haveRuntime ? std::to_wstring(rtVol) : ((idx == 0 || !t) ? L"-" : std::to_wstring(t->volume));
        std::size_t logicalTotal=0;
        if (idx==kLeadViolinVirtualTrack || idx==kLeadPianoVirtualTrack) {
            for (std::size_t si=0;si<g_model.Segments().size();++si)
                if (SegmentUsesLeadVirtual(si,idx)) logicalTotal+=g_model.SegmentTrackNoteCount(si,0);
        }
        const std::wstring totalNotes = (idx==kLeadViolinVirtualTrack || idx==kLeadPianoVirtualTrack)
            ? std::to_wstring(logicalTotal) : (t ? std::to_wstring(t->noteCount) : L"0");
        const std::wstring segNotes = validSegment
            ? std::to_wstring((idx==kLeadViolinVirtualTrack || idx==kLeadPianoVirtualTrack) && !SegmentUsesLeadVirtual(segmentIndex,idx)
                ? 0 : g_model.SegmentTrackNoteCount(segmentIndex, modelIdx))
            : L"-";
        if (g_trackOriginalVolume.find(idx)==g_trackOriginalVolume.end()) {
            int baseVol=80;
            if (haveRuntime) baseVol=rtVol;
            else if (idx==kLeadViolinVirtualTrack) baseVol=40;
            else if (idx==kLeadPianoVirtualTrack) baseVol=64;
            else if (idx!=0 && t) baseVol=t->volume;
            g_trackOriginalVolume[idx]=std::max(0,std::min(100,baseVol));
        }

        LVITEMW item{};
        item.mask = LVIF_TEXT | LVIF_PARAM;
        item.iItem = row;
        item.iSubItem = 0;
        item.pszText = const_cast<LPWSTR>(role.c_str());
        item.lParam = idx;
        const int inserted = ListView_InsertItem(g_tracks, &item);
        if (inserted >= 0) {
            ListView_SetItemText(g_tracks, inserted, 1, const_cast<LPWSTR>(timbre.c_str()));
            ListView_SetItemText(g_tracks, inserted, 2, const_cast<LPWSTR>(vol.c_str()));
            ListView_SetItemText(g_tracks, inserted, 3, const_cast<LPWSTR>(L"-"));
            ListView_SetItemText(g_tracks, inserted, 4, const_cast<LPWSTR>(L"-"));
            ListView_SetItemText(g_tracks, inserted, 5, const_cast<LPWSTR>(totalNotes.c_str()));
            ListView_SetItemText(g_tracks, inserted, 6, const_cast<LPWSTR>(segNotes.c_str()));
            ListView_SetCheckState(g_tracks, inserted, IsTrackEnabled(idx) ? TRUE : FALSE);
        }
        ++row;
    }

    if (validSegment) {
        const std::wstring label = L"全部轨道（前4行=A/B拨片和弦/A/B鼓；" + SegmentDisplayName(segmentIndex) + L" 使用 " +
            std::to_wstring(activeCount) + L" / " + std::to_wstring(all.size()) + L" 音符轨；取消勾选=音量0，勾选=恢复原音量）";
        SetWindowTextW(g_trackLabel, label.c_str());
    } else {
        SetWindowTextW(g_trackLabel, L"全部轨道（前4行为演奏槽；取消勾选=音量0；重新勾选=恢复原音量）");
    }

    SendMessageW(g_tracks, WM_SETREDRAW, TRUE, 0);
    RedrawWindow(g_tracks, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ALLCHILDREN);
    g_populatingTracks = false;
}

static void PopulateSegmentList() {
    SendMessageW(g_segments, WM_SETREDRAW, FALSE, 0);
    SendMessageW(g_segments, LB_RESETCONTENT, 0, 0);
    for (const MDSSegmentSpan& s : g_model.Segments()) {
        const std::vector<int> active = g_model.ActiveTrackIndexes(s.segmentIndex);
        std::wostringstream os;
        os << SegmentDisplayName(s.segmentIndex) << L"   type=" << s.type << L"   " << s.bars << L" bars   "
           << Utf8ToWide(g_model.MeterText()) << L"   " << active.size() << L"轨   拍 "
           << ToW(s.startBeat, 0) << L"-" << ToW(s.endBeat, 0);
        const std::wstring line = os.str();
        SendMessageW(g_segments, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(line.c_str()));
    }
    SendMessageW(g_segments, WM_SETREDRAW, TRUE, 0);
    RedrawWindow(g_segments, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
}

static bool SyncCurrentSegment(bool force = false) {
    if (!g_loaded) return false;
    const MDSSegmentSpan* s = g_model.FindSegment(g_positionBeat);
    if (!s) return false;
    if (force || g_currentSegment != s->segmentIndex) {
        g_currentSegment = s->segmentIndex;
        SendMessageW(g_segments, LB_SETCURSEL, static_cast<WPARAM>(g_currentSegment), 0);
        PopulateTracksForSegment(g_currentSegment);
        return true;
    }
    return false;
}

static void UpdateDetails() {
    if (!g_loaded) {
        SetWindowTextW(g_details, L"尚未加载多维谱。\r\n点击“打开 JSON”选择曲谱。");
        return;
    }
    const MDSFlatBeat* fb = g_model.FindBeat(g_positionBeat);
    if (!fb || !fb->source) return;
    const MDSBeat& b = *fb->source;
    const std::size_t si = fb->segmentIndex;
    const std::vector<int> active = g_model.ActiveTrackIndexes(si);

    std::wostringstream os;
    os << L"当前位置\r\n";
    os << L"谱段: " << SegmentDisplayName(si) << L"   type=" << fb->segmentType << L"   有效轨=" << active.size() << L"\r\n";
    os << L"拍号: " << Utf8ToWide(g_model.MeterText()) << L"   Bar: " << fb->bar << L"   Beat: " << fb->beat
       << L" / " << g_model.BeatsPerBar() << L"\r\n";
    os << L"绝对拍: " << ToW(g_positionBeat) << L" / " << ToW(g_model.TotalBeats()) << L"\r\n";
    if (g_hasC2Beat) {
        os << L"C2 A101: rawBeat=" << ToW(g_lastC2RawBeat, 4)
           << L" row=" << g_lastC2Row << L" col=" << g_lastC2Col
           << L" level=" << g_lastC2Level << L" type=" << g_lastC2ChordType
           << L" trans12=" << g_lastC2Trans12 << L" pickId=" << g_lastC2PickId << L"\r\n";
    }
    os << L"\r\nChord: " << ChordText(b) << L"\r\n";
    if (b.hasChord) os << L"Chord length: " << b.chord.length << L" (= "
        << ToW(g_model.RawUnitsToScoreBeats(b.chord.length)) << L" 拍)\r\n";

    if (g_model.SegmentUsesMainMelodyAt(si)) {
        if (HasDualMainMelody()) os << L"\r\n[主旋律01/Violin] " << (IsTrackEnabled(kLeadViolinVirtualTrack)?L"ON":L"OFF")
            << L"   [主旋律02/PianoStudio] " << (IsTrackEnabled(kLeadPianoVirtualTrack)?L"ON":L"OFF") << L"   tk0 notes=" << b.notes.size();
        else os << L"\r\n[主旋律01] " << (IsTrackEnabled(0) ? L"ON" : L"OFF") << L"   notes=" << b.notes.size();
        if (g_model.HasOnlyMainMelodyTrack() && (fb->segmentType == 0 || fb->segmentType == 4))
            os << L"   （单主旋律谱：前奏/间奏从 beat.notes 正常播放）";
        os << L"\r\n";
    } else {
        os << L"\r\n[beat.notes] " << b.notes.size() << L" 个（多轨谱沿用原前奏/间奏显示规则）\r\n";
    }
    for (std::size_t i = 0; i < b.notes.size() && i < 20; ++i) AppendNoteLine(os, b.notes[i]);

    os << L"\r\n[本 Beat 其它轨]\r\n";
    if (b.extraTracks.empty()) os << L"  (无)\r\n";
    for (const MDSExtraTrack& et : b.extraTracks) {
        os << L"  #" << et.index << L" " << TrackRoleName(et.index) << L" / " << TrackTimbreName(et.index)
           << L"   " << (IsTrackEnabled(et.index) ? L"ON" : L"OFF") << L"   notes=" << et.notes.size() << L"\r\n";
        for (std::size_t i = 0; i < et.notes.size() && i < 16; ++i) AppendNoteLine(os, et.notes[i]);
    }

    os << L"\r\nWords: " << b.words.size() << L"（按 start/length 单字对齐时间轴）\r\n";
    for (std::size_t i = 0; i < b.words.size() && i < 12; ++i) {
        const MDSWord& w = b.words[i];
        os << L"  '" << Utf8ToWide(w.word) << L"' start=" << w.start << L" len=" << w.length
           << L" newLine=" << (w.newLine ? 1 : 0) << L" stretch=" << (w.stretch ? 1 : 0) << L"\r\n";
    }

    os << L"\r\nExtensions: " << b.extensions.size() << L"\r\n";
    for (std::size_t i = 0; i < b.extensions.size() && i < 12; ++i) {
        const MDSExtension& e = b.extensions[i];
        os << L"  type=" << Utf8ToWide(e.type) << L" start=" << e.start;
        if (e.type == "7" || e.pickAction != 0) {
            os << L" pickAction=" << e.pickAction << L" pickType=" << e.pickType << L" (" << PickTypeName(e.pickType) << L")";
        }
        if (e.type == "3") {
            os << L" drumCue=" << Type3DrumCueName(e) << L" switchType=" << e.switchType
               << L" position=" << e.position << L" pick=" << e.pick;
        }
        if (e.type == "12") {
            os << L" drumSection=" << DrumSwitchName(e.switchType) << L" switchType=" << e.switchType
               << L" position=" << e.position << L" pick=" << e.pick;
            if (!e.drumCodes.empty()) os << L" drumCode=" << Utf8ToWide(e.drumCodes.front());
        }
        if (e.level) os << L" level=" << e.level;
        if (!e.group.empty()) os << L" group=" << Utf8ToWide(e.group);
        if (e.volume) os << L" volume=" << e.volume;
        if (e.mute) os << L" mute=" << e.mute;
        if (!e.assetNotes.empty()) {
            const auto& an = e.assetNotes.front();
            os << L" timbre=" << Utf8ToWide(an.timbreCardCode + ":" + an.noteCode);
        }
        os << L"\r\n";
    }

    os << L"\r\n========== JSON 原文对照 ==========\r\n";
    if (!g_loadedFilePath.empty()) os << L"文件: " << g_loadedFilePath.wstring() << L"\r\n";
    const std::wstring jsonBase = g_song.sourceContentPath.empty() ? L"$" : Utf8ToWide(g_song.sourceContentPath);
    os << L"JSON path: " << jsonBase << L".lyrics[" << b.jsonSegmentIndex << L"].bars[" << b.jsonBarArrayIndex
       << L"].beats[" << b.jsonBeatArrayIndex << L"]\r\n";
    os << L"字段值: bar=" << fb->bar << L"   beat=" << b.beat << L"\r\n";
    if (b.jsonSourceExact) {
        os << L"文件字节偏移(0-based): " << b.jsonByteStart << L" .. " << b.jsonByteEnd;
        if (b.jsonByteEnd >= b.jsonByteStart) os << L"   length=" << (b.jsonByteEnd - b.jsonByteStart);
        os << L"\r\n";
        os << L"十六进制偏移: 0x" << std::hex << b.jsonByteStart << L" .. 0x" << b.jsonByteEnd << std::dec << L"\r\n";
        os << L"文件行号(1-based): " << b.jsonLineStart << L" .. " << b.jsonLineEnd << L"\r\n";
    } else {
        os << L"来源: 内嵌/加密/字符串 JSON 已解包；下列原文来自解包后的 JSON，偏移不对应外层文件。\r\n";
        os << L"解包后行号(1-based): " << b.jsonLineStart << L" .. " << b.jsonLineEnd << L"\r\n";
    }
    os << L"主旋律调度: 每个 beat.notes[] 的每个 note 都独立触发；stretch 不用于跳过 Note-On。\r\n";
    os << L"\r\n--- 当前 beat JSON 原文 ---\r\n";
    os << Utf8ToWide(b.jsonRaw) << L"\r\n";

    SetWindowTextW(g_details, os.str().c_str());
}

static double MaxTimelineSpan();
static void ClampTimelineViewStart();

static void UpdateProgress() {
    // V2.3.19: the bottom trackbar is a VIEWPORT scrollbar, not a playhead seek
    // control.  The red line is moved only by clicking/dragging the score or by
    // selecting a section.  Therefore playback must not drag this thumb along
    // with g_positionBeat.
    if (!g_loaded || g_model.TotalBeats() <= 0.0) {
        if (g_lastProgressPos != 0) {
            SendMessageW(g_progress, TBM_SETPOS, TRUE, 0);
            g_lastProgressPos = 0;
        }
        return;
    }
    ClampTimelineViewStart();
    const double span = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), g_timelineSpan));
    const double maxStart = std::max<double>(0.0, g_model.TotalBeats() - span);
    const int pos = maxStart > 1e-9
        ? static_cast<int>(std::round(g_timelineViewStart / maxStart * 10000.0))
        : 0;
    const int clamped = std::max<int>(0, std::min<int>(10000, pos));
    if (clamped != g_lastProgressPos) {
        SendMessageW(g_progress, TBM_SETPOS, TRUE, clamped);
        g_lastProgressPos = clamped;
    }
}

static void UpdateInfo() {
    if (!g_loaded) { SetWindowTextW(g_info, L"未加载曲谱"); return; }
    const MDSStats st = CMDSParser::CalculateStats(g_song);
    std::wostringstream os;
    os << Utf8ToWide(g_song.title);
    if (!g_song.content.originalTone.empty()) os << L"   | 原调 " << Utf8ToWide(g_song.content.originalTone);
    os << L"   | BPM " << g_bpm;
    os << L"   | 拍号 " << Utf8ToWide(g_model.MeterText());
    if (!g_song.content.originalSinger.empty()) os << L"   | 歌手 " << Utf8ToWide(g_song.content.originalSinger);
    if (g_currentSegment < g_model.Segments().size())
        os << L"   | 当前 " << SegmentDisplayName(g_currentSegment) << L" / " << g_model.ActiveTrackIndexes(g_currentSegment).size() << L"轨";
    os << L"   | 全轨 " << g_model.Tracks().size() << L"   | Beats " << st.beats << L"   | Notes " << (st.notes + st.extraTrackNotes);
    if (!g_song.sourceFormat.empty()) os << L"   | JSON " << Utf8ToWide(g_song.sourceFormat);
    SetWindowTextW(g_info, os.str().c_str());
}

static fs::path C2LogDirectory() {
    std::error_code ec;
    fs::path dir=ExecutableDirectory()/L"logs";
    fs::create_directories(dir,ec);
    if (ec) {
        ec.clear();
        dir=fs::current_path()/L"logs";
        fs::create_directories(dir,ec);
    }
    return dir;
}

static void AppendUtf8LogLine(const fs::path& path,const std::string& prefix,const std::wstring& text) {
    if (path.empty()) return;
    std::ofstream f(path,std::ios::binary|std::ios::app);
    if (f) f << prefix << WideToUtf8(text) << "\r\n";
}

static void AppendC2Log(const std::wstring& text) {
    SYSTEMTIME st{}; GetLocalTime(&st);
    char prefix[64]{};
    sprintf_s(prefix,"%04u-%02u-%02u %02u:%02u:%02u.%03u ",
        st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
    std::lock_guard<std::mutex> lock(g_c2LogMutex);
    const fs::path dir=C2LogDirectory();
    AppendUtf8LogLine(dir/L"c2_ble.log",prefix,text); // rolling log across runs
    if (!g_c2UploadSessionLogPath.empty())
        AppendUtf8LogLine(g_c2UploadSessionLogPath,prefix,text);
}

static fs::path StartC2UploadSessionLog() {
    SYSTEMTIME st{}; GetLocalTime(&st);
    wchar_t name[96]{};
    swprintf_s(name,L"c2_upload_%04u%02u%02u_%02u%02u%02u_%03u.log",
        st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
    const fs::path path=C2LogDirectory()/name;
    {
        std::lock_guard<std::mutex> lock(g_c2LogMutex);
        g_c2UploadSessionLogPath=path;
        g_c2UiProgressBucket.store(-1);
        std::ofstream f(path,std::ios::binary|std::ios::trunc);
        if (f) {
            const unsigned char bom[3]={0xEF,0xBB,0xBF};
            f.write(reinterpret_cast<const char*>(bom),3);
            f << "LiberLive MDS Player V2.3.20l - DrumCue/MasterBPM/PerTrackMIDI / 460B WR-Pack + UIProgress50\r\n";
            f << "Per-upload log: status + progress + pipeline diagnostics\r\n";
        }
    }
    return path;
}

static void EndC2UploadSessionLog() {
    std::lock_guard<std::mutex> lock(g_c2LogMutex);
    g_c2UploadSessionLogPath.clear();
}

static void PostC2Status(const std::wstring& text) {
    // Log on the producer thread before posting to the UI. This preserves the
    // diagnostic line even when the one-line status control overwrites it fast.
    AppendC2Log(text);
    HWND h=g_hwnd;
    if (!h || !IsWindow(h)) return;
    auto* copy=new std::wstring(text);
    if (!PostMessageW(h,WM_APP_C2_STATUS,0,reinterpret_cast<LPARAM>(copy))) delete copy;
}

static void PostC2Progress(int done,int total) {
    // Keep every controller-reported progress point in the log file for diagnosis.
    AppendC2Log(L"C2 上传进度 "+std::to_wstring(done)+L" / "+std::to_wstring(total));

    // Screen/UI: first update, then only when crossing another 50-FILL bucket,
    // plus the final value.  Packed uploads can jump over an exact multiple of
    // 50, so compare buckets instead of testing done % 50 == 0.
    const int bucket=(done>0)?((done-1)/50):0;
    const int previous=g_c2UiProgressBucket.load();
    const bool show=(done<=1) || (done>=total) || (bucket!=previous);
    if (!show) return;
    g_c2UiProgressBucket.store(bucket);

    HWND h=g_hwnd;
    if (h && IsWindow(h))
        PostMessageW(h,WM_APP_C2_PROGRESS,static_cast<WPARAM>(done),static_cast<LPARAM>(total));
}

static void PostC2Event(const C2PlayEvent& event) {
    HWND h = g_hwnd;
    if (!h || !IsWindow(h)) return;
    auto* copy = new C2PlayEvent(event);
    if (!PostMessageW(h, WM_APP_C2_EVENT, 0, reinterpret_cast<LPARAM>(copy))) delete copy;
}

static void UpdateC2Buttons() {
    const bool busy = g_c2Busy.load();
    const bool connected = g_c2.IsConnected();
    if (g_c2Connect) EnableWindow(g_c2Connect, (!busy && !connected) ? TRUE : FALSE);
    if (g_c2Disconnect) EnableWindow(g_c2Disconnect, (!busy && connected) ? TRUE : FALSE);
    if (g_c2Upload) EnableWindow(g_c2Upload, (!busy && connected && g_loaded) ? TRUE : FALSE);
    if (g_c2UploadPlay) EnableWindow(g_c2UploadPlay, (!busy && connected && g_loaded) ? TRUE : FALSE);
    if (g_c2Play) EnableWindow(g_c2Play, (!busy && connected && g_c2.HasUploadedSheet()) ? TRUE : FALSE);
    if (g_c2Stop) EnableWindow(g_c2Stop, (!busy && connected) ? TRUE : FALSE);
    const BOOL mixerEnable=(!busy && connected) ? TRUE : FALSE;
    if (g_c2LeadOn) EnableWindow(g_c2LeadOn,mixerEnable);
    if (g_c2LeadAuto) EnableWindow(g_c2LeadAuto,mixerEnable);
    if (g_c2LeadOff) EnableWindow(g_c2LeadOff,mixerEnable);
    if (g_deviceInfo) EnableWindow(g_deviceInfo,mixerEnable);
    if (g_timbreConfig) EnableWindow(g_timbreConfig,(!busy && g_loaded)?TRUE:FALSE);
    if (g_styleConfig) EnableWindow(g_styleConfig,(!busy && g_loaded)?TRUE:FALSE);
}

static void StartC2Action(C2Action action) {
    if (g_c2Busy.exchange(true)) return;
    if (action==C2Action::UploadArm || action==C2Action::ArmFromCursor) {
        // C2 becomes the performance source.  The PC timer remains installed,
        // but it is used only for the trigger-gated visual flow.
        g_playing=false;
        ResetC2PerformanceFlow(false);
        g_hasC2Beat=false;
        g_lastC2RawBeat=0.0;
        KillTimer(g_hwnd,TIMER_PREVIEW_OFF);
        MidiAllOff();
    } else if (action==C2Action::Upload || action==C2Action::CloseSheet || action==C2Action::Disconnect) {
        ResetC2PerformanceFlow(false);
    }
    g_c2.SetEventCallback([](const C2PlayEvent& event) { PostC2Event(event); });
    if ((action == C2Action::Upload || action == C2Action::UploadArm) && !g_loaded) {
        g_c2Busy.store(false);
        MessageBoxW(g_hwnd, L"请先打开一个 LiberLive JSON。", L"C2", MB_ICONINFORMATION);
        UpdateC2Buttons();
        return;
    }
    MDSSong songCopy;
    int bpmCopy = g_bpm;
    const double cursorBeat = g_positionBeat;
    const bool cursorWasExplicitlySelected = g_cursorUserSelected;
    if (action == C2Action::Upload || action == C2Action::UploadArm) songCopy = g_song;
    UpdateC2Buttons();
    if (action==C2Action::Upload || action==C2Action::UploadArm) {
        const fs::path logPath=StartC2UploadSessionLog();
        PostC2Status(L"V2.3.20l 本次上传日志："+logPath.wstring());
    }
    PostC2Status(action==C2Action::Disconnect ? L"正在断开 C2 蓝牙..." : L"C2 操作开始...");
    std::thread([action, songCopy = std::move(songCopy), bpmCopy, cursorBeat, cursorWasExplicitlySelected]() mutable {
        winrt::init_apartment(winrt::apartment_type::multi_threaded);
        std::wstring error;
        const auto status = [](const std::wstring& m) { PostC2Status(m); };
        const auto progress = [](int d, int t) { PostC2Progress(d, t); };
        bool ok = false;
        double completionBeat=-1.0;
        switch (action) {
        case C2Action::Connect:
            ok = g_c2.Connect(error, status);
            break;
        case C2Action::Disconnect:
            g_c2.Disconnect();
            ok = true;
            break;
        case C2Action::Upload:
            ok = g_c2.Upload(songCopy, bpmCopy, false, error, status, progress);
            if (ok) completionBeat=cursorWasExplicitlySelected ? cursorBeat : static_cast<double>(g_c2.LastPlan().initialBeat);
            break;
        case C2Action::UploadArm:
            ok = g_c2.Upload(songCopy, bpmCopy, true, error, status, progress);
            if (ok) {
                completionBeat=static_cast<double>(g_c2.LastPlan().initialBeat);
                // Preserve the proven official upload handshake when the user has
                // not touched the red cursor. Once the user explicitly moves it,
                // finish the upload by seeking C2 to that cursor position.
                if (cursorWasExplicitlySelected) {
                    ok=g_c2.ArmKeyPlayFromBeat(static_cast<float>(cursorBeat),error,status);
                    if (ok) completionBeat=cursorBeat;
                }
            }
            break;
        case C2Action::ArmFromCursor:
            ok = g_c2.ArmKeyPlayFromBeat(static_cast<float>(cursorBeat), error, status);
            if (ok) completionBeat=cursorBeat;
            break;
        case C2Action::CloseSheet:
            ok = g_c2.CloseSheet(error, status);
            break;
        case C2Action::Melody100:
            ok = g_c2.SetMixerVolume(0x05,100,error,status);
            break;
        case C2Action::Melody50:
            ok = g_c2.SetMixerVolume(0x05,50,error,status);
            break;
        case C2Action::Melody0:
            ok = g_c2.SetMixerVolume(0x05,0,error,status);
            break;
        case C2Action::DeviceInfo:
            ok = g_c2.RefreshDeviceInfo(error,status);
            break;
        }
        auto* done = new C2DoneMessage{ok, error, action, completionBeat};
        HWND h = g_hwnd;
        if (!h || !IsWindow(h) || !PostMessageW(h, WM_APP_C2_DONE, 0, reinterpret_cast<LPARAM>(done))) delete done;
        winrt::uninit_apartment();
    }).detach();
}


static void AutoWriteC2PlaybackPositionFromCursor() {
    // Local browsing remains available without C2.  Once the current sheet is
    // resident on a connected C2, every explicit cursor/section selection
    // immediately performs the same proven seek+arm transaction that the old
    // “从红线待按键” button invoked.
    if (!g_loaded || !g_c2.IsConnected() || !g_c2.HasUploadedSheet()) return;
    if (g_c2Busy.load()) {
        AppendC2Log(L"自动写入播放位置：C2 正忙，本次定位仅更新 PC 红线。");
        return;
    }
    StartC2Action(C2Action::ArmFromCursor);
}

static void InvalidateTimeline();

static void ClampPaneWidths(HWND hwnd) {
    RECT rc{}; GetClientRect(hwnd, &rc);
    const int w = rc.right;
    g_leftPaneW = std::max<int>(kMinPaneW, std::min<int>(kMaxPaneW, g_leftPaneW));
    g_rightPaneW = std::max<int>(kMinPaneW, std::min<int>(kMaxPaneW, g_rightPaneW));
    const int available = std::max<int>(2 * kMinPaneW, w - 20 - 2 * kSplitterW - kMinTimelineW);
    if (g_leftPaneW + g_rightPaneW > available) {
        int overflow = g_leftPaneW + g_rightPaneW - available;
        const int cutRight = std::min<int>(overflow, std::max<int>(0, g_rightPaneW - kMinPaneW));
        g_rightPaneW -= cutRight; overflow -= cutRight;
        if (overflow > 0) g_leftPaneW = std::max<int>(kMinPaneW, g_leftPaneW - overflow);
    }
}

static RECT LeftSplitterRect(HWND hwnd) {
    ClampPaneWidths(hwnd);
    RECT rc{}; GetClientRect(hwnd, &rc);
    RECT r{10 + g_leftPaneW, kBodyTop, 10 + g_leftPaneW + kSplitterW, std::max<int>(kBodyTop + 180, rc.bottom - 54)};
    return r;
}

static RECT RightSplitterRect(HWND hwnd) {
    ClampPaneWidths(hwnd);
    RECT rc{}; GetClientRect(hwnd, &rc);
    const int rightPaneX = rc.right - 10 - g_rightPaneW;
    RECT r{rightPaneX - kSplitterW, kBodyTop, rightPaneX, std::max<int>(kBodyTop + 180, rc.bottom - 54)};
    return r;
}

static RECT TimelineRect(HWND hwnd) {
    ClampPaneWidths(hwnd);
    RECT rc{}; GetClientRect(hwnd, &rc);
    const RECT ls = LeftSplitterRect(hwnd);
    const RECT rs = RightSplitterRect(hwnd);
    rc.left = ls.right;
    rc.top = kBodyTop;
    rc.right = std::max<int>(rc.left + 180, rs.left);
    rc.bottom = std::max<int>(rc.top + 180, rc.bottom - 58);
    return rc;
}

static void UpdateZoomLabel() {
    if (!g_zoomLabel) return;
    std::wostringstream os;
    os.setf(std::ios::fixed);
    os.precision(g_timelineSpan < 10.0 ? 1 : 0);
    os << L"视野 " << g_timelineSpan << L"拍";
    if (g_loaded) os << L" " << Utf8ToWide(g_model.MeterText());
    SetWindowTextW(g_zoomLabel, os.str().c_str());
}

static double MaxTimelineSpan() {
    if (g_loaded && g_model.TotalBeats() > 0.0) return std::max<double>(4.0, g_model.TotalBeats());
    return 96.0;
}

static void ClampTimelineViewStart() {
    if (!g_loaded || g_model.TotalBeats() <= 0.0) {
        g_timelineViewStart = 0.0;
        g_timelineViewInitialized = true;
        return;
    }
    const double span = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), g_timelineSpan));
    const double maxStart = std::max<double>(0.0, g_model.TotalBeats() - span);
    g_timelineViewStart = std::max<double>(0.0, std::min<double>(maxStart, g_timelineViewStart));
    g_timelineViewInitialized = true;
}

// Manual cursor movement does not recenter the page.  If a non-timeline control
// jumps outside the visible window, reveal it near an edge. During playback we
// pan only after the playhead approaches the right edge, then place the red line
// at about 1/3 of the visible window. This intentionally exposes more upcoming
// score than V2.3.18e, which could leave too little look-ahead after a page pan.
static void EnsureTimelineBeatVisible(double beat, bool playbackFollow) {
    if (!g_loaded || g_model.TotalBeats() <= 0.0) return;
    ClampTimelineViewStart();
    const double span = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), g_timelineSpan));
    const double maxStart = std::max<double>(0.0, g_model.TotalBeats() - span);
    const double left = g_timelineViewStart;
    const double right = left + span;

    if (playbackFollow) {
        const double followRight = left + span * 0.82;
        const double followLeft = left + span * 0.08;
        if (beat > followRight)
            g_timelineViewStart = std::min<double>(maxStart, std::max<double>(0.0, beat - span / 3.0));
        else if (beat < followLeft)
            g_timelineViewStart = std::min<double>(maxStart, std::max<double>(0.0, beat - span * 0.08));
    } else {
        if (beat < left)
            g_timelineViewStart = std::min<double>(maxStart, std::max<double>(0.0, beat - span * 0.08));
        else if (beat > right)
            g_timelineViewStart = std::min<double>(maxStart, std::max<double>(0.0, beat - span * 0.92));
    }
    ClampTimelineViewStart();
}

static void SetTimelineSpan(double span) {
    g_timelineSpan = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), span));
    EnsureTimelineBeatVisible(g_positionBeat, false);
    UpdateZoomLabel();
    UpdateProgress();
    InvalidateTimeline();
}

static void InvalidateTimeline() {
    if (!g_hwnd) return;
    RECT r = TimelineRect(g_hwnd);
    InvalidateRect(g_hwnd, &r, FALSE);
}

static void RefreshPositionUI(bool forceSegment = false, bool forceDetails = true) {
    const bool segmentChanged = SyncCurrentSegment(forceSegment);
    if (segmentChanged || forceSegment) UpdateInfo();
    UpdateProgress();
    if (forceDetails) UpdateDetails();
    InvalidateTimeline();
}

static void StopPlayback(bool rewind) {
    g_playing = false;
    ResetC2PerformanceFlow(false);
    KillTimer(g_hwnd, TIMER_PREVIEW_OFF);
    MidiAllOff();
    if (rewind) g_positionBeat = 0.0;
    g_nextMidi = g_model.FindScheduledNoteIndex(g_positionBeat);
    g_lastTick = GetTickCount64();
    g_lastTimelinePaintTick = 0;
    g_lastDetailsTick = 0;
    RefreshPositionUI(true, true);
}

static bool LoadSong(const fs::path& file) {
    CMDSParser parser;
    MDSSong song;
    std::string error;
    if (!parser.LoadFile(file, song, error)) {
        const std::wstring msg = L"JSON 解析失败:\r\n" + Utf8ToWide(error);
        MessageBoxW(g_hwnd, msg.c_str(), L"LiberLive MDS Player", MB_ICONERROR);
        return false;
    }
    g_playing = false;
    MidiAllOff();
    g_song = std::move(song);
    g_loadedFilePath = file;
    ResetC2PerformanceFlow(false);
    g_hasC2Beat = false;
    g_lastC2RawBeat = 0.0;
    g_lastC2Row = g_lastC2Col = g_lastC2Level = -1;
    g_lastC2ChordType = g_lastC2Trans12 = g_lastC2PickId = -1;
    g_c2.InvalidateUploadedSheet();
    g_model.Build(g_song);
    g_loaded = true;
    g_timelineSpan = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), g_timelineSpan));
    UpdateZoomLabel();
    // Master tempo is score-owned.  Resource catalogue BPMs are audition/reference
    // metadata only and never feed g_bpm.  This matches the Red Sun official upload:
    // JSON tempo/baseConfig BPM=120 is the live score BPM while A/B resource choices
    // carry their own catalogue audition BPM only in the resource browser.
    g_bpm = g_song.content.tempo > 0 ? g_song.content.tempo : (g_song.content.baseConfig.bpm > 0 ? g_song.content.baseConfig.bpm : 80);
    wchar_t bpm[16]{}; wsprintfW(bpm, L"%d", g_bpm); SetWindowTextW(g_bpmEdit, bpm);
    g_positionBeat = 0.0;
    g_cursorUserSelected = false;
    g_timelineViewStart = 0.0;
    g_timelineViewInitialized = true;
    g_nextMidi = 0;
    g_currentSegment = INVALID_SEGMENT;
    g_lastProgressPos = -1;
    g_lastTimelinePaintTick = 0;
    g_lastDetailsTick = 0;
    g_trackEnabled.clear();
    g_trackOriginalVolume.clear();
    for (int idx : {kStyleAChordVirtualTrack,kStyleBChordVirtualTrack,kStyleADrumVirtualTrack,kStyleBDrumVirtualTrack}) {
        g_trackEnabled[idx]=true;
        const MDSConfigEntry* e=PerformanceSlotConfig(idx);
        g_trackOriginalVolume[idx]=(e && e->hasPickVolume)?std::max(0,std::min(100,e->pickVolume)):100;
    }
    g_trackEnabled[0] = true;
    if (HasDualMainMelody()) {
        g_trackEnabled[kLeadViolinVirtualTrack]=true;
        g_trackEnabled[kLeadPianoVirtualTrack]=true;
    }
    for (const MDSTrackConfig& tc : g_song.content.trackConfigs) g_trackEnabled[tc.index] = true; // V2.3.18b: UI defaults all checked
    PopulateSegmentList();
    RefreshPositionUI(true, true);
    const std::wstring title = L"LiberLive MDS Player V2.3.20m PerformanceSlots/LeadIntro/AutoMap / 460B WR-Pack + UIProgress50 / 6/8 MeterTimingFix / C2 - " + Utf8ToWide(g_song.title);
    SetWindowTextW(g_hwnd, title.c_str());
    if (g_c2Status) SetWindowTextW(g_c2Status, g_c2.IsConnected() ? L"C2 已连接；当前 JSON 尚未上传" : L"C2 未连接");
    UpdateC2Buttons();
    InvalidateTimeline();
    return true;
}

static void OpenDialog() {
    wchar_t file[MAX_PATH] = L"";
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn); ofn.hwndOwner = g_hwnd; ofn.lpstrFile = file; ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"LiberLive JSON (*.json)\0*.json\0All files (*.*)\0*.*\0";
    ofn.nFilterIndex = 1; ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileNameW(&ofn)) LoadSong(fs::path(file));
}

static void ResizeTrackListColumns() {
    if (!g_tracks) return;
    const int fixed = 92 + 42 + 48 + 44 + 58 + 64 + 24;
    const int resource = std::max<int>(130, g_leftPaneW - fixed);
    ListView_SetColumnWidth(g_tracks, 0, 92);
    ListView_SetColumnWidth(g_tracks, 1, resource);
    ListView_SetColumnWidth(g_tracks, 2, 42);
    ListView_SetColumnWidth(g_tracks, 3, 48);
    ListView_SetColumnWidth(g_tracks, 4, 44);
    ListView_SetColumnWidth(g_tracks, 5, 58);
    ListView_SetColumnWidth(g_tracks, 6, 64);
}

static void Layout(HWND hwnd) {
    ClampPaneWidths(hwnd);
    RECT rc{}; GetClientRect(hwnd, &rc);
    const int w = rc.right, h = rc.bottom, top = 10, bh = 30;
    MoveWindow(g_open, 10, top, 100, bh, TRUE);
    MoveWindow(g_play, 120, top, 70, bh, TRUE);
    MoveWindow(g_pause, 198, top, 70, bh, TRUE);
    MoveWindow(g_stop, 276, top, 70, bh, TRUE);
    MoveWindow(g_bpmEdit, 405, top, 55, bh, TRUE);
    MoveWindow(g_bpmApply, 466, top, 62, bh, TRUE);
    MoveWindow(g_midiCheck, 540, top, 138, bh, TRUE);
    MoveWindow(g_zoomOut, 690, top, 42, bh, TRUE);
    MoveWindow(g_zoomIn, 736, top, 42, bh, TRUE);
    MoveWindow(g_zoomReset, 782, top, 54, bh, TRUE);
    MoveWindow(g_zoomLabel, 842, top + 4, 108, 22, TRUE);
    const int batteryW=150;
    const int volumeX=954;
    MoveWindow(g_c2VolumeStatus, volumeX, top + 4, std::max<int>(140,w-volumeX-batteryW-20), 22, TRUE);
    MoveWindow(g_c2BatteryStatus, std::max<int>(volumeX+140,w-batteryW-10), top + 4, batteryW, 22, TRUE);

    const int c2y = 46;
    MoveWindow(g_c2Connect, 10, c2y, 86, 28, TRUE);
    MoveWindow(g_c2Disconnect, 102, c2y, 86, 28, TRUE);
    MoveWindow(g_c2Upload, 194, c2y, 96, 28, TRUE);
    MoveWindow(g_c2Play, 296, c2y, 110, 28, TRUE);
    MoveWindow(g_c2Stop, 412, c2y, 96, 28, TRUE);
    MoveWindow(g_c2UploadPlay, 514, c2y, 124, 28, TRUE);
    MoveWindow(g_timbreConfig, 858, c2y, 78, 28, TRUE);
    MoveWindow(g_styleConfig, 940, c2y, 72, 28, TRUE);
    MoveWindow(g_deviceInfo, 1016, c2y, 62, 28, TRUE);
    MoveWindow(g_c2Status, 1086, c2y + 4, std::max<int>(120, w - 1096), 22, TRUE);
    MoveWindow(g_info, 10, 82, std::max<int>(100, w - 20), 24, TRUE);

    const int bodyTop = kBodyTop, bottom = 54;
    const int bodyH = std::max<int>(180, h - bodyTop - bottom);
    const int segH = std::max<int>(135, bodyH * 31 / 100);
    const int leftX = 10;
    const int rightX = w - 10 - g_rightPaneW;
    MoveWindow(g_segLabel, leftX, bodyTop, g_leftPaneW, 20, TRUE);
    MoveWindow(g_segments, leftX, bodyTop + 22, g_leftPaneW, std::max<int>(80, segH - 22), TRUE);
    MoveWindow(g_trackLabel, leftX, bodyTop + segH, g_leftPaneW, 20, TRUE);
    MoveWindow(g_tracks, leftX, bodyTop + segH + 22, g_leftPaneW, std::max<int>(100, bodyH - segH - 22), TRUE);
    MoveWindow(g_details, rightX, bodyTop, g_rightPaneW, bodyH, TRUE);
    const RECT tr = TimelineRect(hwnd);
    MoveWindow(g_progress, tr.left, h - 44, std::max<int>(100, tr.right - tr.left), 32, TRUE);
    ResizeTrackListColumns();
}

struct TimelineView {
    RECT r{};
    int labelW = 116;
    int plotLeft = 0;
    int plotWidth = 1;
    double span = 24.0;
    double start = 0.0;
    double end = 0.0;
};

static TimelineView GetTimelineView(HWND hwnd) {
    TimelineView v;
    v.r = TimelineRect(hwnd);
    v.plotLeft = v.r.left + v.labelW;
    v.plotWidth = std::max<int>(40, v.r.right - v.plotLeft);
    v.span = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), g_timelineSpan));
    if (g_loaded && g_model.TotalBeats() > 0.0) {
        // While dragging the cursor, freeze the same window for stable x->beat
        // mapping. Outside dragging the window has its own persistent start and
        // is deliberately NOT derived from g_positionBeat.
        if (g_dragTimelineCursor && g_dragTimelinePlotWidth > 0) {
            v.start = g_dragTimelineViewStart;
            v.span = g_dragTimelineViewSpan;
        } else {
            ClampTimelineViewStart();
            v.start = g_timelineViewStart;
        }
        if (v.start + v.span > g_model.TotalBeats())
            v.start = std::max<double>(0.0, g_model.TotalBeats() - v.span);
        v.end = std::min<double>(g_model.TotalBeats(), v.start + v.span);
    }
    return v;
}


static void PreviewAtPosition(double pos);

static bool SetTimelineCursorFromX(HWND hwnd,int x,bool preview) {
    if (!g_loaded) return false;
    const TimelineView v=GetTimelineView(hwnd);
    if (x<v.plotLeft || x>v.r.right) return false;
    g_playing=false;
    KillTimer(hwnd,TIMER_PREVIEW_OFF);
    MidiAllOff();
    double raw=v.start+(x-v.plotLeft)*v.span/static_cast<double>(v.plotWidth);
    raw=std::max<double>(0.0,std::min<double>(g_model.TotalBeats(),raw));
    // Performance mode = chord-section granularity.  The future editor keeps
    // the 1/4-beat branch in SnapTimelinePosition().
    g_positionBeat=SnapTimelinePosition(raw);
    ResetC2PerformanceFlow(false);
    g_cursorUserSelected=true;
    g_nextMidi=g_model.FindScheduledNoteIndex(g_positionBeat);
    RefreshPositionUI(false,true);
    if (preview) {
        PreviewAtPosition(g_positionBeat);
        AutoWriteC2PlaybackPositionFromCursor();
    }
    return true;
}

static HBRUSH TrackBrush(const MDSPlaybackTrack* track, bool enabled, bool active,
                         HBRUSH mainBrush, HBRUSH type1Brush, HBRUSH type2Brush,
                         HBRUSH otherBrush, HBRUSH disabledBrush, HBRUSH inactiveBrush) {
    if (!enabled) return disabledBrush;
    if (!active) return inactiveBrush;
    if (!track || track->index == 0) return mainBrush;
    if (track->type == 1) return type1Brush;
    if (track->type == 2) return type2Brush;
    return otherBrush;
}

static COLORREF ChordColor(const std::string& key) {
    const char root = key.empty() ? 'C' : static_cast<char>(std::toupper(static_cast<unsigned char>(key[0])));
    switch (root) {
    case 'C': return RGB(226, 83, 102);
    case 'D': return RGB(225, 139, 69);
    case 'E': return RGB(207, 172, 64);
    case 'F': return RGB(75, 207, 102);
    case 'G': return RGB(72, 165, 216);
    case 'A': return RGB(86, 92, 218);
    case 'B': return RGB(151, 91, 196);
    default: return RGB(100, 130, 180);
    }
}

static void DrawTimeline(HDC hdc, HWND hwnd) {
    TimelineView v = GetTimelineView(hwnd);
    RECT r = v.r;
    FillRect(hdc, &r, reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1));
    FrameRect(hdc, &r, reinterpret_cast<HBRUSH>(GetStockObject(GRAY_BRUSH)));
    SetBkMode(hdc, TRANSPARENT);
    if (!g_loaded || g_model.TotalBeats() <= 0.0) {
        DrawTextW(hdc, L"打开 LiberLive 多维谱 JSON 后，这里显示谱段、和弦、拨片/鼓提示、逐字歌词和全部音轨。", -1, &r,
                  DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        return;
    }

    const int headerH = 25, chordH = 45, cueH = 46, lyricH = 40;
    const int plotLeft = v.plotLeft, plotWidth = v.plotWidth;
    const int chordTop = r.top + headerH;
    const int cueTop = chordTop + chordH;
    const int lyricTop = cueTop + cueH;
    const int noteTop = lyricTop + lyricH;
    const int noteBottom = r.bottom;
    const int noteAreaH = std::max<int>(40, noteBottom - noteTop);
    const std::size_t si = g_currentSegment < g_model.Segments().size() ? g_currentSegment : 0;
    const std::vector<int> laneTracks = AllTrackIndexes();
    const int laneCount = std::max<int>(1, static_cast<int>(laneTracks.size()));
    const double laneH = static_cast<double>(noteAreaH) / laneCount;

    auto X = [&](double b) { return plotLeft + static_cast<int>((b - v.start) / v.span * plotWidth); };

    RECT hdrLabel{r.left + 4, r.top + 3, plotLeft - 2, r.top + headerH};
    const std::wstring timelineHeader = L"时间 / 谱段  " + Utf8ToWide(g_model.MeterText());
    DrawTextW(hdc, timelineHeader.c_str(), -1, &hdrLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT chLabel{r.left + 4, chordTop, plotLeft - 2, cueTop};
    DrawTextW(hdc, L"Chord / 和弦", -1, &chLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT cueLabel{r.left + 4, cueTop, plotLeft - 2, lyricTop};
    DrawTextW(hdc, L"拨片 / A鼓 / B鼓 / 关鼓机", -1, &cueLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT lyricLabel{r.left + 4, lyricTop, plotLeft - 2, noteTop};
    DrawTextW(hdc, L"Words / 逐字歌词", -1, &lyricLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    HPEN beatGrid = CreatePen(PS_SOLID, 1, RGB(232, 232, 232));
    HPEN barGrid = CreatePen(PS_SOLID, 1, RGB(185, 185, 195));
    HPEN oldPen = reinterpret_cast<HPEN>(SelectObject(hdc, beatGrid));
    const int beatsPerBar = std::max<int>(1, g_model.BeatsPerBar());
    for (int bi = static_cast<int>(std::floor(v.start)); bi <= static_cast<int>(std::ceil(v.end)); ++bi) {
        const bool barLine = (bi % beatsPerBar) == 0;
        SelectObject(hdc, barLine ? barGrid : beatGrid);
        const int x = X(static_cast<double>(bi));
        MoveToEx(hdc, x, r.top, nullptr); LineTo(hdc, x, r.bottom);
    }
    SelectObject(hdc, oldPen); DeleteObject(beatGrid); DeleteObject(barGrid);

    HPEN segPen = CreatePen(PS_DOT, 1, RGB(120, 120, 180));
    oldPen = reinterpret_cast<HPEN>(SelectObject(hdc, segPen));
    for (const MDSSegmentSpan& s : g_model.Segments()) {
        if (s.endBeat < v.start || s.startBeat > v.end) continue;
        const int x = X(s.startBeat);
        MoveToEx(hdc, x, r.top, nullptr); LineTo(hdc, x, r.bottom);
        RECT tr{x + 3, r.top + 2, std::min<int>(x + 96, r.right), r.top + headerH};
        const std::wstring nm = SegmentDisplayName(s.segmentIndex);
        DrawTextW(hdc, nm.c_str(), -1, &tr, DT_LEFT | DT_TOP | DT_SINGLELINE | DT_END_ELLIPSIS);
    }
    SelectObject(hdc, oldPen); DeleteObject(segPen);

    MoveToEx(hdc, r.left, chordTop, nullptr); LineTo(hdc, r.right, chordTop);
    MoveToEx(hdc, r.left, cueTop, nullptr); LineTo(hdc, r.right, cueTop);
    MoveToEx(hdc, r.left, lyricTop, nullptr); LineTo(hdc, r.right, lyricTop);
    MoveToEx(hdc, r.left, noteTop, nullptr); LineTo(hdc, r.right, noteTop);
    MoveToEx(hdc, r.left, noteBottom, nullptr); LineTo(hdc, r.right, noteBottom);
    MoveToEx(hdc, plotLeft, r.top, nullptr); LineTo(hdc, plotLeft, r.bottom);

    // Draw chord blocks with the meter-dependent LiberLive raw timing unit.
    // x/4 uses unit=4; 6/8 uses unit=2, so length=6 spans beats 0..3 without
    // the false blank gap seen in V2.3.20c.
    for (const MDSFlatBeat& fb : g_model.Beats()) {
        if (!fb.source || !fb.source->hasChord) continue;
        const double cStart = fb.absoluteBeat;
        const double cEnd = cStart + std::max<double>(0.25, g_model.RawUnitsToScoreBeats(fb.source->chord.length));
        if (cEnd < v.start || cStart > v.end) continue;
        const int x1 = std::max<int>(plotLeft, X(cStart));
        const int x2 = std::min<int>(r.right, std::max<int>(x1 + 8, X(cEnd)));
        RECT cr{x1 + 1, chordTop + 3, x2 - 1, cueTop - 3};
        HBRUSH cb = CreateSolidBrush(ChordColor(fb.source->chord.mainKey));
        FillRect(hdc, &cr, cb);
        DeleteObject(cb);
        const COLORREF old = SetTextColor(hdc, RGB(255, 255, 255));
        RECT tx{cr.left + 6, cr.top, cr.right - 4, cr.bottom};
        const std::wstring c = ChordText(*fb.source);
        DrawTextW(hdc, c.c_str(), -1, &tx, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        SetTextColor(hdc, old);
    }

    // Dedicated cue lane between chord and lyrics.  V2.3.20l follows the official
    // APK wording.  In the verified Red Sun opening, the same JSON beats map exactly:
    // type7 pickType0 -> “用A拨片”; type3 [switch=1,pick=1] -> “进B鼓”;
    // type3 [switch=0] -> “关鼓机”.  type12 remains an older/explicit drum-section cue.
    struct TimelineCue { double beat=0.0; std::wstring text; };
    std::vector<TimelineCue> cues;
    auto appendCue=[&](double beat,const std::wstring& text) {
        for (auto& c:cues) if (std::fabs(c.beat-beat)<0.001) {
            if (!c.text.empty()) c.text+=L" | ";
            c.text+=text; return;
        }
        cues.push_back({beat,text});
    };
    for (const MDSFlatBeat& fb : g_model.Beats()) {
        if (!fb.source || fb.absoluteBeat > v.end || fb.absoluteBeat + 2.0 < v.start) continue;
        for (const MDSExtension& e : fb.source->extensions) {
            const bool pickCue=(e.type=="7" || e.pickAction!=0);
            const bool abDrumCue=(e.type=="3");
            const bool legacyDrumCue=(e.type=="12");
            if (!pickCue && !abDrumCue && !legacyDrumCue) continue;
            const double eventBeat=fb.absoluteBeat+g_model.RawUnitsToScoreBeats(e.start);
            if (eventBeat < v.start || eventBeat > v.end) continue;
            if (pickCue) appendCue(eventBeat,PickCueName(e.pickType));
            if (abDrumCue) appendCue(eventBeat,Type3DrumCueName(e));
            if (legacyDrumCue) appendCue(eventBeat,DrumSwitchName(e.switchType));
        }
    }
    // APK uses stacked cue badges when two drum operations are close inside the
    // same chord block (e.g. Red Sun C: “进B鼓” + “关鼓机”).  Use two compact rows
    // so nearby events do not overwrite each other on the PC timeline.
    std::sort(cues.begin(),cues.end(),[](const TimelineCue& a,const TimelineCue& b){ return a.beat<b.beat; });
    int cueRight[2]={plotLeft-8,plotLeft-8};
    for (const auto& cue:cues) {
        const int x=X(cue.beat);
        SIZE sz{};
        GetTextExtentPoint32W(hdc,cue.text.c_str(),static_cast<int>(cue.text.size()),&sz);
        const int w=std::max<int>(52,std::min<int>(132,sz.cx+12));
        int row=0;
        if (x<=cueRight[0]+4) row=1;
        if (x<=cueRight[row]+4 && x>cueRight[1-row]+4) row=1-row;
        RECT er{x+2,cueTop+1+row*21,std::min<int>(x+2+w,r.right),cueTop+21+row*21};
        DrawTextW(hdc,cue.text.c_str(),-1,&er,DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
        cueRight[row]=er.right;
    }

    // Draw each word at its own absolute start position. Font is intentionally
    // smaller than V1.8; the current word only changes to red (no underline).
    HFONT oldFont = g_timelineLyricFont ? reinterpret_cast<HFONT>(SelectObject(hdc, g_timelineLyricFont)) : nullptr;
    for (const MDSLyricWordEvent& word : g_model.LyricWords()) {
        if (word.text.empty()) continue;
        if (word.endBeat < v.start || word.startBeat > v.end) continue;
        const int x1 = std::max<int>(plotLeft, X(word.startBeat));
        const std::wstring text = Utf8ToWide(word.text);
        SIZE textSize{};
        GetTextExtentPoint32W(hdc, text.c_str(), static_cast<int>(text.size()), &textSize);
        const int timedX2 = X(word.endBeat);
        const int wanted = std::max<int>(textSize.cx + 3, std::max<int>(14, timedX2 - x1));
        const int x2 = std::min<int>(r.right, x1 + wanted);
        RECT wr{x1, lyricTop + 2, x2, noteTop - 2};
        const bool current = g_positionBeat >= word.startBeat && g_positionBeat < word.endBeat;
        const COLORREF oldColor = SetTextColor(hdc, current ? RGB(210, 30, 30) : RGB(35, 35, 35));
        DrawTextW(hdc, text.c_str(), -1, &wr, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
        SetTextColor(hdc, oldColor);
    }
    if (oldFont) SelectObject(hdc, oldFont);

    HBRUSH mainBrush = CreateSolidBrush(RGB(55, 55, 55));
    HBRUSH type1Brush = CreateSolidBrush(RGB(55, 105, 175));
    HBRUSH type2Brush = CreateSolidBrush(RGB(65, 145, 90));
    HBRUSH otherBrush = CreateSolidBrush(RGB(145, 95, 165));
    HBRUSH disabledBrush = CreateSolidBrush(RGB(195, 195, 195));
    HBRUSH inactiveBrush = CreateSolidBrush(RGB(225, 225, 225));

    for (int li = 0; li < laneCount; ++li) {
        const int y0 = noteTop + static_cast<int>(li * laneH);
        const int y1 = noteTop + static_cast<int>((li + 1) * laneH);
        if (li > 0) {
            HPEN lanePen = CreatePen(PS_SOLID, 1, RGB(238, 238, 238));
            HPEN old = reinterpret_cast<HPEN>(SelectObject(hdc, lanePen));
            MoveToEx(hdc, r.left, y0, nullptr); LineTo(hdc, r.right, y0);
            SelectObject(hdc, old); DeleteObject(lanePen);
        }
        if (li < static_cast<int>(laneTracks.size())) {
            const int idx = laneTracks[static_cast<std::size_t>(li)];
            const bool enabled = IsTrackEnabled(idx);
            const bool active = IsTrackActiveForSegment(idx, si);
            std::wstring label = TrackRoleName(idx) + L" " + TrackTimbreName(idx);
            if (!active) label += L"  [本段未用]";
            RECT lr{r.left + 3, y0 + 1, plotLeft - 3, y1 - 1};
            const COLORREF old = SetTextColor(hdc, !enabled ? RGB(160, 160, 160) : (active ? RGB(20, 20, 20) : RGB(130, 130, 130)));
            DrawTextW(hdc, label.c_str(), -1, &lr, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
            SetTextColor(hdc, old);
        }
    }

    std::size_t ni = g_model.FindScheduledNoteIndex(std::max<double>(0.0, v.start - 32.0));
    const std::vector<MDSScheduledNote>& notes = g_model.Notes();
    for (; ni < notes.size(); ++ni) {
        const MDSScheduledNote& n = notes[ni];
        if (n.startBeat > v.end) break;
        if (n.endBeat < v.start) continue;
        // V2.3.18d: tk0 is one physical LEAD track in CREATE/FILL, but the
        // official App exposes its Violin and PianoStudio schedule ranges as two
        // logical main-melody rows.  The lane list therefore contains virtual
        // IDs (-1001/-1002), not physical tk0.  Map every scheduled tk0 note to
        // the logical row selected by that note's segment before drawing.
        int drawTrackIndex = n.trackIndex;
        if (n.trackIndex == 0 && HasDualMainMelody()) {
            drawTrackIndex = SegmentUsesLeadVirtual(n.segmentIndex, kLeadViolinVirtualTrack)
                ? kLeadViolinVirtualTrack : kLeadPianoVirtualTrack;
        }
        if (!IsTrackActiveForSegment(drawTrackIndex, n.segmentIndex)) continue;
        const auto it = std::find(laneTracks.begin(), laneTracks.end(), drawTrackIndex);
        if (it == laneTracks.end()) continue;
        const int lane = static_cast<int>(it - laneTracks.begin());
        const MDSPlaybackTrack* track = g_model.FindTrack(n.trackIndex);
        const bool enabled = IsTrackEnabled(drawTrackIndex);
        const bool activeForNote = IsTrackActiveForSegment(drawTrackIndex, n.segmentIndex);
        const int y0 = noteTop + static_cast<int>(lane * laneH);
        const int y1 = noteTop + static_cast<int>((lane + 1) * laneH);
        const int usableH = std::max<int>(5, y1 - y0 - 5);
        const int pitchClass = ((n.midiNote % 12) + 12) % 12;
        const int y = y0 + 2 + (11 - pitchClass) * usableH / 12;
        const int x1 = std::max<int>(plotLeft, X(n.startBeat));
        const int x2 = std::min<int>(r.right, std::max<int>(x1 + 3, X(n.endBeat)));
        RECT nr{x1, y, x2, std::min<int>(y + 4, y1 - 1)};
        FillRect(hdc, &nr, TrackBrush(track, enabled, activeForNote, mainBrush, type1Brush, type2Brush, otherBrush, disabledBrush, inactiveBrush));
    }

    DeleteObject(mainBrush); DeleteObject(type1Brush); DeleteObject(type2Brush);
    DeleteObject(otherBrush); DeleteObject(disabledBrush); DeleteObject(inactiveBrush);

    const int cx = X(g_positionBeat);
    HPEN cursor = CreatePen(PS_SOLID, 2, RGB(210, 30, 30));
    oldPen = reinterpret_cast<HPEN>(SelectObject(hdc, cursor));
    MoveToEx(hdc, cx, r.top, nullptr); LineTo(hdc, cx, r.bottom);
    SelectObject(hdc, oldPen); DeleteObject(cursor);
    HBRUSH red = CreateSolidBrush(RGB(210, 30, 30));
    RECT dot{cx - 4, r.top + 1, cx + 5, r.top + 10}; FillRect(hdc, &dot, red); DeleteObject(red);
}

static void DrawSplitters(HDC hdc, HWND hwnd) {
    const RECT ls = LeftSplitterRect(hwnd);
    const RECT rs = RightSplitterRect(hwnd);
    HBRUSH face = CreateSolidBrush(RGB(205, 205, 205));
    FillRect(hdc, &ls, face);
    FillRect(hdc, &rs, face);
    DeleteObject(face);
    HPEN pen = CreatePen(PS_SOLID, 1, RGB(150, 150, 150));
    HPEN old = reinterpret_cast<HPEN>(SelectObject(hdc, pen));
    const int lx = (ls.left + ls.right) / 2;
    const int rx = (rs.left + rs.right) / 2;
    MoveToEx(hdc, lx, ls.top + 8, nullptr); LineTo(hdc, lx, ls.bottom - 8);
    MoveToEx(hdc, rx, rs.top + 8, nullptr); LineTo(hdc, rx, rs.bottom - 8);
    SelectObject(hdc, old);
    DeleteObject(pen);
}

static void DrawTimelineBuffered(HDC hdc, HWND hwnd) {
    const RECT r = TimelineRect(hwnd);
    const int w = std::max<int>(1, r.right - r.left);
    const int h = std::max<int>(1, r.bottom - r.top);
    HDC mem = CreateCompatibleDC(hdc);
    if (!mem) { DrawTimeline(hdc, hwnd); return; }
    HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
    if (!bmp) { DeleteDC(mem); DrawTimeline(hdc, hwnd); return; }
    HGDIOBJ oldBmp = SelectObject(mem, bmp);
    const int saved = SaveDC(mem);
    SetViewportOrgEx(mem, -r.left, -r.top, nullptr);
    DrawTimeline(mem, hwnd);
    RestoreDC(mem, saved);
    BitBlt(hdc, r.left, r.top, w, h, mem, 0, 0, SRCCOPY);
    SelectObject(mem, oldBmp);
    DeleteObject(bmp);
    DeleteDC(mem);
}

static void PreviewAtPosition(double pos) {
    KillTimer(g_hwnd, TIMER_PREVIEW_OFF);
    MidiAllOff();
    EnsureMidi();
    if (!g_midi) return;
    const std::vector<MDSScheduledNote>& notes = g_model.Notes();
    bool any = false;
    std::size_t begin = g_model.FindScheduledNoteIndex(std::max<double>(0.0, pos - 16.0));
    for (std::size_t i = begin; i < notes.size(); ++i) {
        const MDSScheduledNote& n = notes[i];
        if (n.startBeat > pos + 0.04) break;
        if (n.startBeat <= pos + 0.04 && n.endBeat > pos - 0.01 && IsScheduledNotePlayable(n)) {
            StartMidiNote(n);
            any = true;
        }
    }
    if (!any) {
        std::size_t i = g_model.FindScheduledNoteIndex(pos);
        double onset = -1.0;
        for (; i < notes.size(); ++i) {
            const MDSScheduledNote& n = notes[i];
            if (n.startBeat > pos + 0.25) break;
            if (!IsScheduledNotePlayable(n)) continue;
            if (onset < 0.0) onset = n.startBeat;
            if (std::fabs(n.startBeat - onset) > 0.01) break;
            StartMidiNote(n);
            any = true;
        }
    }
    if (any) SetTimer(g_hwnd, TIMER_PREVIEW_OFF, 650, nullptr);
}

static void PrimeMidiAtPosition(double pos) {
    EnsureMidi();
    if (!g_midi) return;
    const std::vector<MDSScheduledNote>& notes = g_model.Notes();
    const std::size_t begin = g_model.FindScheduledNoteIndex(std::max<double>(0.0, pos - 16.0));
    for (std::size_t i = begin; i < notes.size(); ++i) {
        const MDSScheduledNote& n = notes[i];
        if (n.startBeat >= pos - 0.0001) break; // exact/current onsets are handled by TickPlayback
        if (n.endBeat > pos + 0.0001 && IsScheduledNotePlayable(n)) StartMidiNote(n);
    }
}

static void ArmC2PerformanceUI(double startBeat) {
    if (!g_loaded) return;
    g_c2PerformanceArmed = true;
    g_c2FlowRunning = false;
    g_c2FlowStopBeat = ClampSongBeat(startBeat);
    g_c2FlowLastTick = GetTickCount64();

    // Every new arm is a new trigger session. Do not compare its first beat with
    // a stale beat from a prior take/song.
    g_hasC2Beat = false;
    g_lastC2RawBeat = 0.0;
    g_c2HaveAcceptedDeviceBeat = false;
    g_c2AcceptedDeviceBeat = ClampSongBeat(startBeat);
    g_c2LastAcceptedTriggerTick = 0;
}

static void StartC2ChordFlow(double deviceBeat) {
    if (!g_loaded) return;
    const double chordStart = ClampSongBeat(g_model.SnapToChordSection(deviceBeat));
    const double chordEnd = ClampSongBeat(g_model.ChordSectionEnd(chordStart));

    g_playing = false; // C2 owns performance audio/clock; PC only animates UI.
    KillTimer(g_hwnd, TIMER_PREVIEW_OFF);
    MidiAllOff();

    // C2 replies can arrive slightly late/out of order relative to the smooth
    // local red-line animation.  A newly accepted device beat may therefore map
    // to a chordStart just behind the already-rendered cursor. Never rewind the
    // visual playhead during an armed performance; keep the farther-ahead UI
    // position while still accepting the device beat as synchronization state.
    const double visualStart = std::max<double>(g_positionBeat, chordStart);
    g_positionBeat = visualStart;
    g_nextMidi = g_model.FindScheduledNoteIndex(g_positionBeat);
    g_c2FlowStopBeat = std::max<double>(visualStart, chordEnd);
    g_c2FlowRunning = g_c2FlowStopBeat > visualStart + 1e-6;
    g_c2FlowLastTick = GetTickCount64();
    EnsureTimelineBeatVisible(g_positionBeat, true);

    // V2.3.15: paint the authoritative C2 cursor before rebuilding the verbose
    // detail panel. This prevents a large JSON/detail refresh from making the
    // red line look one or more physical triggers behind the C2 LEDs.
    const bool segmentChanged=SyncCurrentSegment(false);
    if (segmentChanged) UpdateInfo();
    UpdateProgress();
    InvalidateTimeline();
    if (g_hwnd) UpdateWindow(g_hwnd);
    g_lastTimelinePaintTick=GetTickCount64();
    UpdateDetails();
    g_lastDetailsTick=GetTickCount64();
}

static bool AcceptC2PhysicalTrigger(const C2PlayEvent& event,std::wstring& note) {
    if (!g_loaded || !g_c2PerformanceArmed || event.kind!=C2PlayEvent::Kind::Chord) return false;

    const ULONGLONG now=event.receivedTickMs?event.receivedTickMs:GetTickCount64();
    if (g_c2LastAcceptedTriggerTick && now>=g_c2LastAcceptedTriggerTick &&
        now-g_c2LastAcceptedTriggerTick<80) {
        note=L"[DEBOUNCE: 80ms 内重复物理事件，忽略]";
        return false;
    }

    // While the previous chord/note is still sounding, the next physical pick is
    // already allowed to target the NEXT score trigger. This is essential for
    // repeated chords such as F F D D: the second F pick interrupts the first
    // visual duration and jumps immediately to the second F start.
    const double gateBeat=g_c2FlowRunning ? g_c2FlowStopBeat : g_positionBeat;
    const MDSChordSection* expected=nullptr;
    std::wstring reason;
    if (!ValidateC2ChordRootGateAt(event,gateBeat,expected,reason)) {
        note=L"[REJECT INPUT: 和弦/按键与当前待演奏项不匹配，禁止推进] "+reason+
            L"；gate="+ToW(gateBeat,2);
        return false;
    }
    if (!expected) {
        note=L"[REJECT INPUT: 无法确定下一待演奏项]";
        return false;
    }

    // Type/trans mapping is still incomplete, so keep it diagnostic rather than
    // making advanced chord qualities impossible to play.
    std::wstring typeDiag;
    const MDSChordSection* fullExpected=nullptr;
    std::wstring fullReason;
    if (!ValidateC2ChordTriggerAt(event,expected->startBeat,fullExpected,fullReason))
        typeDiag=L"；type/trans诊断="+fullReason;

    const double triggerBeat=ClampSongBeat(expected->startBeat);
    g_c2LastAcceptedTriggerTick=now;
    g_c2HaveAcceptedDeviceBeat=true;
    if (event.hasBeat && std::isfinite(event.beat))
        g_c2AcceptedDeviceBeat=ClampSongBeat(event.beat);
    else
        g_c2AcceptedDeviceBeat=triggerBeat;

    // Use the SCORE trigger boundary, not the returned beat, to start the flow.
    // This makes an early second pick on repeated F/F retrigger the second F even
    // when C2's returned beat still reflects the first note's sounding duration.
    StartC2ChordFlow(triggerBeat);
    note=L"[MATCHED PHYSICAL TRIGGER ACCEPT] 目标="+C2ChordLabel(expected->source->chord)+
        L" @"+ToW(triggerBeat,2)+L" pick="+PickTypeName(event.pickId)+L"（拨片方向不参与推进判断）";
    if (event.hasBeat) note+=L"；C2返回beat="+ToW(event.beat,4);
    note+=L"；立即推进到下一触发边界="+ToW(g_c2FlowStopBeat,2)+typeDiag;
    return true;
}

static void ObserveC2DeviceBeatOnly(double rawBeat,std::wstring& note) {
    if (!std::isfinite(rawBeat)) return;
    const double beat=ClampSongBeat(rawBeat);
    if (!g_c2HaveAcceptedDeviceBeat || beat>g_c2AcceptedDeviceBeat)
        g_c2AcceptedDeviceBeat=beat;
    // Deliberately do NOT move g_positionBeat here. From V2.3.20a onward, a
    // position reply without the matching physical chord event is sync-only.
    note=L"[C2 BEAT SYNC ONLY: 不作为推进许可] beat="+ToW(beat,4);
}

static void RefreshPlaybackUIThrottled(ULONGLONG now) {
    if (now - g_lastTimelinePaintTick >= 33) {
        const bool segmentChanged = SyncCurrentSegment(false);
        if (segmentChanged) UpdateInfo();
        UpdateProgress();
        InvalidateTimeline();
        g_lastTimelinePaintTick = now;
    }
    if (now - g_lastDetailsTick >= 120) {
        UpdateDetails();
        g_lastDetailsTick = now;
    }
}

static void TickPlayback() {
    if (!g_loaded) return;
    const ULONGLONG now = GetTickCount64();

    // C2 key-trigger performance: after the physical trigger, animate at BPM
    // speed only until the next chord-section gate.  If no new trigger arrives,
    // the playhead remains parked at that boundary.
    if (g_c2PerformanceArmed) {
        if (!g_c2FlowLastTick) g_c2FlowLastTick = now;
        if (g_c2FlowRunning) {
            const double dt = (now - g_c2FlowLastTick) / 1000.0;
            g_c2FlowLastTick = now;
            g_positionBeat += dt * PlaybackScoreBeatsPerSecond();
            if (g_positionBeat >= g_c2FlowStopBeat - 1e-6) {
                g_positionBeat = g_c2FlowStopBeat;
                g_c2FlowRunning = false;
                const std::wstring gateText = L"C2 演奏游标到达和弦节 " + ToW(g_positionBeat, 2) +
                    L"；等待下一次实体按键触发";
                if (g_c2Status) SetWindowTextW(g_c2Status, gateText.c_str());
                AppendC2Log(gateText);
            }
            g_positionBeat = ClampSongBeat(g_positionBeat);
            EnsureTimelineBeatVisible(g_positionBeat, true);
            RefreshPlaybackUIThrottled(now);
        } else {
            g_c2FlowLastTick = now; // avoid a large dt when the next trigger arrives
        }
        return;
    }

    if (!g_playing) return;
    if (!g_lastTick) g_lastTick = now;
    const double dt = (now - g_lastTick) / 1000.0;
    g_lastTick = now;
    g_positionBeat += dt * PlaybackScoreBeatsPerSecond();
    if (g_positionBeat >= g_model.TotalBeats()) {
        g_positionBeat = g_model.TotalBeats();
        StopPlayback(false);
        return;
    }

    EnsureMidi();
    if (g_midi) {
        const std::vector<MDSScheduledNote>& notes = g_model.Notes();
        while (g_nextMidi < notes.size() && notes[g_nextMidi].startBeat <= g_positionBeat) {
            const MDSScheduledNote& n = notes[g_nextMidi++];
            if (IsScheduledNotePlayable(n)) {
                StartMidiNote(n);
            }
        }
        for (auto it = g_activeMidi.begin(); it != g_activeMidi.end();) {
            if (it->endBeat <= g_positionBeat || !IsTrackEnabled(it->trackIndex)) {
                midiOutShortMsg(g_midi, static_cast<DWORD>(0x80 | it->channel | (it->note << 8)));
                it = g_activeMidi.erase(it);
            } else {
                ++it;
            }
        }
    }

    EnsureTimelineBeatVisible(g_positionBeat, true);
    RefreshPlaybackUIThrottled(now);
}

static HWND MakeControl(HWND hwnd, LPCWSTR cls, LPCWSTR text, DWORD style, int id, DWORD exStyle = 0) {
    HWND h = CreateWindowExW(exStyle, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 0, 0, hwnd,
                             reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), GetModuleHandleW(nullptr), nullptr);
    if (h) SendMessageW(h, WM_SETFONT, reinterpret_cast<WPARAM>(g_font), TRUE);
    return h;
}

static void CreateControls(HWND hwnd) {
    g_open = MakeControl(hwnd, L"BUTTON", L"打开 JSON", BS_PUSHBUTTON, IDC_OPEN);
    g_play = MakeControl(hwnd, L"BUTTON", L"播放", BS_PUSHBUTTON, IDC_PLAY);
    g_pause = MakeControl(hwnd, L"BUTTON", L"暂停", BS_PUSHBUTTON, IDC_PAUSE);
    g_stop = MakeControl(hwnd, L"BUTTON", L"停止", BS_PUSHBUTTON, IDC_STOP);
    HWND bpmLabel = MakeControl(hwnd, L"STATIC", L"BPM:", SS_LEFT, 0); MoveWindow(bpmLabel, 360, 16, 40, 22, TRUE);
    g_bpmEdit = MakeControl(hwnd, L"EDIT", L"80", WS_BORDER | ES_NUMBER | ES_CENTER, IDC_BPM_EDIT);
    g_bpmApply = MakeControl(hwnd, L"BUTTON", L"应用", BS_PUSHBUTTON, IDC_BPM_APPLY);
    g_midiCheck = MakeControl(hwnd, L"BUTTON", L"PC MIDI 全轨预览", BS_AUTOCHECKBOX, IDC_MIDI);
    SendMessageW(g_midiCheck, BM_SETCHECK, BST_CHECKED, 0);
    g_zoomOut = MakeControl(hwnd, L"BUTTON", L"－", BS_PUSHBUTTON, IDC_ZOOM_OUT);
    g_zoomIn = MakeControl(hwnd, L"BUTTON", L"＋", BS_PUSHBUTTON, IDC_ZOOM_IN);
    g_zoomReset = MakeControl(hwnd, L"BUTTON", L"1:1", BS_PUSHBUTTON, IDC_ZOOM_RESET);
    g_zoomLabel = MakeControl(hwnd, L"STATIC", L"视野 24 beat", SS_LEFT, IDC_ZOOM_LABEL);
    UpdateZoomLabel();
    g_c2Connect = MakeControl(hwnd, L"BUTTON", L"连接 C2", BS_PUSHBUTTON, IDC_C2_CONNECT);
    g_c2Disconnect = MakeControl(hwnd, L"BUTTON", L"断开蓝牙", BS_PUSHBUTTON, IDC_C2_DISCONNECT);
    g_c2Upload = MakeControl(hwnd, L"BUTTON", L"上传到 C2", BS_PUSHBUTTON, IDC_C2_UPLOAD);
    g_c2Play = MakeControl(hwnd, L"BUTTON", L"从红线待按键", BS_PUSHBUTTON, IDC_C2_PLAY);
    g_c2Stop = MakeControl(hwnd, L"BUTTON", L"关闭 C2 曲谱", BS_PUSHBUTTON, IDC_C2_STOP);
    g_c2UploadPlay = MakeControl(hwnd, L"BUTTON", L"上传并待按键", BS_PUSHBUTTON, IDC_C2_UPLOAD_PLAY);
    g_timbreConfig = MakeControl(hwnd, L"BUTTON", L"音色配置", BS_PUSHBUTTON, IDC_TIMBRE_CONFIG);
    g_styleConfig = MakeControl(hwnd, L"BUTTON", L"风格包", BS_PUSHBUTTON, IDC_STYLE_CONFIG);
    g_deviceInfo = MakeControl(hwnd, L"BUTTON", L"设备", BS_PUSHBUTTON, IDC_DEVICE_INFO);
    g_c2VolumeStatus = MakeControl(hwnd, L"STATIC", L"音量: --", SS_LEFT | SS_NOPREFIX, IDC_C2_VOLUME_STATUS);
    g_c2BatteryStatus = MakeControl(hwnd, L"STATIC", L"C2 电量 --", SS_RIGHT | SS_NOPREFIX, IDC_C2_BATTERY_STATUS);
    g_c2Status = MakeControl(hwnd, L"STATIC", L"C2 未连接", SS_LEFT | SS_NOPREFIX, IDC_C2_STATUS);
    g_info = MakeControl(hwnd, L"STATIC", L"未加载曲谱", SS_LEFT, IDC_INFO);
    g_segLabel = MakeControl(hwnd, L"STATIC", L"谱段（type: 0前奏 / 1导歌 / 2主歌 / 3副歌 / 4间奏 / 6尾奏）", SS_LEFT, IDC_SEG_LABEL);
    g_segments = MakeControl(hwnd, L"LISTBOX", L"", WS_BORDER | WS_VSCROLL | LBS_NOTIFY, IDC_SEGMENTS);
    g_trackLabel = MakeControl(hwnd, L"STATIC", L"全部轨道（前4行为演奏槽；取消勾选=音量0；重新勾选=恢复原音量）", SS_LEFT, IDC_TRACK_LABEL);
    g_tracks = MakeControl(hwnd, WC_LISTVIEWW, L"", LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS, IDC_TRACKS, WS_EX_CLIENTEDGE);
    InitTrackListColumns();
    g_details = MakeControl(hwnd, L"EDIT", L"", WS_BORDER | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | ES_AUTOHSCROLL, IDC_DETAILS);
    SendMessageW(g_details, EM_SETLIMITTEXT, 1024 * 1024, 0); // raw JSON beat snippets can be large
    g_progress = MakeControl(hwnd, TRACKBAR_CLASSW, L"", TBS_HORZ | TBS_NOTICKS, IDC_PROGRESS);
    SendMessageW(g_progress, TBM_SETRANGE, TRUE, MAKELONG(0, 10000));
    UpdateC2StateLabels();
    UpdateC2Buttons();
}

static void OnTrackStateChanged(const LPNMLISTVIEW lv) {
    if (!lv || lv->iItem < 0) return;
    LVITEMW item{}; item.mask = LVIF_PARAM; item.iItem = lv->iItem;
    if (!ListView_GetItem(g_tracks, &item)) return;
    const int trackIndex=static_cast<int>(item.lParam);
    const bool enabled=ListView_GetCheckState(g_tracks, lv->iItem) != FALSE;
    g_trackEnabled[trackIndex]=enabled;

    // The first four rows are direct C2 mixer controls, not MIDI/note tracks.
    if (IsPerformanceSlotTrack(trackIndex)) {
        if (!g_c2.IsConnected()) {
            g_trackEnabled[trackIndex]=!enabled;
            PopulateTracksForSegment(g_currentSegment);
            AppendC2Log(L"演奏槽复选框：C2 未连接，未改变设备音量。");
            return;
        }
        const int channel=PerformanceSlotMixerChannel(trackIndex);
        int restore=PerformanceSlotOriginalVolume(trackIndex);
        const int current=g_c2.DeviceState().mixer[static_cast<std::size_t>(channel)];
        if (!enabled && current>0) {
            g_trackOriginalVolume[trackIndex]=current;
            restore=current;
        }
        const int target=enabled?restore:0;
        auto* req=new TrackVolumeDone();
        req->trackIndex=trackIndex; req->requestedEnabled=enabled;
        std::thread([req,channel,target]() {
            std::wstring err;
            req->ok=g_c2.SetMixerVolume(channel,target,err,{});
            req->error=err;
            PostMessageW(g_hwnd,WM_TRACK_VOLUME_DONE,0,reinterpret_cast<LPARAM>(req));
        }).detach();
        return;
    }

    // PC MIDI preview follows the checkbox immediately.
    MidiAllOff();
    g_nextMidi = g_model.FindScheduledNoteIndex(g_positionBeat);
    UpdateDetails();
    InvalidateTimeline();

    // When a sheet is resident on C2, the same checkbox becomes a real device
    // mute/restore control.  Uncheck -> volume 0 on all sections.  Re-check ->
    // restore the volume captured before the first mute.
    if (!g_c2.IsConnected() || !g_c2.HasUploadedSheet()) return;

    int restore=80;
    const auto itOrig=g_trackOriginalVolume.find(trackIndex);
    if (itOrig!=g_trackOriginalVolume.end()) restore=itOrig->second;
    const int target=enabled?restore:0;

    std::string card,tone; int currentVol=restore; std::size_t secCount=0;
    int c2TrackId=-1;
    const bool logicalLead=(trackIndex==kLeadViolinVirtualTrack || trackIndex==kLeadPianoVirtualTrack);
    if (logicalLead) {
        c2TrackId=0;
        RuntimeScheduleForModelTrack(trackIndex,card,tone,currentVol);
        if (!enabled && currentVol>0) g_trackOriginalVolume[trackIndex]=currentVol;
    } else {
        c2TrackId=(trackIndex==0)?0:trackIndex+2;
        if (!FirstTrackScheduleState(static_cast<std::uint8_t>(c2TrackId),card,tone,currentVol,secCount)) {
            g_trackEnabled[trackIndex]=!enabled;
            PopulateTracksForSegment(g_currentSegment);
            AppendC2Log(L"轨道复选框：未找到该轨 C2 schedule，已恢复勾选状态。");
            return;
        }
        if (!enabled && currentVol>0) g_trackOriginalVolume[trackIndex]=currentVol;
    }

    auto* req=new TrackVolumeDone();
    req->trackIndex=trackIndex; req->requestedEnabled=enabled;
    std::thread([req,trackIndex,c2TrackId,card,tone,target,logicalLead]() {
        std::wstring err;
        if (logicalLead) {
            req->ok=g_c2.ApplyTrackVolumeForTone(0,card,tone,target,err,{});
        } else {
            req->ok=g_c2.ApplyTrackToneVolume(static_cast<std::uint8_t>(c2TrackId),card,tone,target,true,err,{});
        }
        req->error=err;
        PostMessageW(g_hwnd,WM_TRACK_VOLUME_DONE,0,reinterpret_cast<LPARAM>(req));
    }).detach();
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        g_font = reinterpret_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
        g_timelineLyricFont = CreateFontW(-16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
            DEFAULT_PITCH, L"Microsoft YaHei UI");
        CreateControls(hwnd);
        DragAcceptFiles(hwnd, TRUE);
        SetTimer(hwnd, TIMER_PLAY, 15, nullptr);
        Layout(hwnd);
        return 0;
    case WM_SIZE:
        Layout(hwnd);
        InvalidateRect(hwnd, nullptr, TRUE);
        return 0;
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case IDC_OPEN: OpenDialog(); break;
        case IDC_PLAY:
            if (g_loaded) {
                // Local PC preview and C2 trigger-gated performance are mutually
                // exclusive UI clocks.
                ResetC2PerformanceFlow(false);
                KillTimer(hwnd, TIMER_PREVIEW_OFF);
                MidiAllOff();
                g_playing = true;
                g_lastTick = GetTickCount64();
                g_nextMidi = g_model.FindScheduledNoteIndex(g_positionBeat);
                // If playback resumes in the middle of a sustained note, restore the
                // note(s) that should already be sounding at this position.
                PrimeMidiAtPosition(g_positionBeat);
            }
            break;
        case IDC_PAUSE:
            g_playing = false;
            if (g_c2PerformanceArmed) ResetC2PerformanceFlow(true);
            MidiAllOff();
            break;
        case IDC_STOP:
            // Stop means stop sounding/advancing, NOT rewind. Keep the red cursor
            // and progress at the exact current position for analysis/comparison.
            StopPlayback(false);
            break;
        case IDC_BPM_APPLY: {
            wchar_t b[16]{};
            GetWindowTextW(g_bpmEdit, b, 16);
            g_bpm = std::max<int>(20, std::min<int>(300, _wtoi(b)));
            wsprintfW(b, L"%d", g_bpm);
            SetWindowTextW(g_bpmEdit, b);
            UpdateInfo();
            break;
        }
        case IDC_ZOOM_IN:
            SetTimelineSpan(g_timelineSpan / 1.5);
            break;
        case IDC_ZOOM_OUT:
            SetTimelineSpan(g_timelineSpan * 1.5);
            break;
        case IDC_ZOOM_RESET:
            SetTimelineSpan(24.0);
            break;
        case IDC_MIDI:
            if (SendMessageW(g_midiCheck, BM_GETCHECK, 0, 0) != BST_CHECKED) CloseMidi();
            break;
        case IDC_C2_CONNECT: StartC2Action(C2Action::Connect); break;
        case IDC_C2_DISCONNECT: StartC2Action(C2Action::Disconnect); break;
        case IDC_C2_UPLOAD: StartC2Action(C2Action::Upload); break;
        case IDC_C2_UPLOAD_PLAY: StartC2Action(C2Action::UploadArm); break;
        case IDC_C2_PLAY: StartC2Action(C2Action::ArmFromCursor); break;
        case IDC_C2_STOP: StartC2Action(C2Action::CloseSheet); break;
        case IDC_C2_LEAD_ON: StartC2Action(C2Action::Melody100); break;
        case IDC_C2_LEAD_AUTO: StartC2Action(C2Action::Melody50); break;
        case IDC_C2_LEAD_OFF: StartC2Action(C2Action::Melody0); break;
        case IDC_TIMBRE_CONFIG: ShowTextViewer(L"音色配置",BuildTimbreConfigText()); break;
        case IDC_STYLE_CONFIG: ShowTextViewer(L"风格包配置",BuildStyleConfigText()); break;
        case IDC_DEVICE_INFO: ShowDeviceCenter(); break;
        case IDC_SEGMENTS:
            if (HIWORD(wp) == LBN_SELCHANGE && g_loaded) {
                const int s = static_cast<int>(SendMessageW(g_segments, LB_GETCURSEL, 0, 0));
                if (s >= 0 && s < static_cast<int>(g_model.Segments().size())) {
                    g_playing = false;
                    ResetC2PerformanceFlow(false);
                    MidiAllOff();
                    g_positionBeat = SnapTimelinePosition(g_model.Segments()[static_cast<std::size_t>(s)].startBeat);
                    g_cursorUserSelected = true;
                    g_nextMidi = g_model.FindScheduledNoteIndex(g_positionBeat);
                    EnsureTimelineBeatVisible(g_positionBeat, false);
                    RefreshPositionUI(true, true);
                    AutoWriteC2PlaybackPositionFromCursor();
                }
            }
            break;
        }
        return 0;
    case WM_APP_C2_STATUS: {
        std::unique_ptr<std::wstring> text(reinterpret_cast<std::wstring*>(lp));
        if (text) {
            if (g_c2Status) SetWindowTextW(g_c2Status,text->c_str());
        }
        return 0;
    }
    case WM_APP_C2_PROGRESS: {
        const int done = static_cast<int>(wp);
        const int total = static_cast<int>(lp);
        std::wstring text = L"C2 上传进度 " + std::to_wstring(done) + L" / " + std::to_wstring(total);
        if (g_c2Status) SetWindowTextW(g_c2Status, text.c_str());
        return 0;
    }
    case WM_APP_C2_DONE: {
        std::unique_ptr<C2DoneMessage> done(reinterpret_cast<C2DoneMessage*>(lp));
        g_c2Busy.store(false);
        if (done) {
            std::wstring text;
            if (done->ok) {
                switch (done->action) {
                case C2Action::Connect: text = L"C2 连接成功"; break;
                case C2Action::Disconnect: text = L"C2 蓝牙已断开"; g_hasC2Beat=false; break;
                case C2Action::Upload: text = L"C2 曲谱上传成功；点击谱面或段落即可自动定位并待按键"; break;
                case C2Action::UploadArm: text = L"C2 曲谱上传成功；已进入目标位置实体按键模式"; break;
                case C2Action::ArmFromCursor: text = L"C2 已定位红线并待按键"; break;
                case C2Action::CloseSheet: text = L"C2 当前曲谱已关闭"; break;
                case C2Action::Melody100: text = L"C2 ch05=100（回读寄存器；非sheet tk0实时增益）"; break;
                case C2Action::Melody50: text = L"C2 ch05=50（回读寄存器；非sheet tk0实时增益）"; break;
                case C2Action::Melody0: text = L"C2 ch05=0（回读寄存器；非sheet tk0实时增益）"; break;
                case C2Action::DeviceInfo: text = L"C2 设备信息已刷新"; break;
                }
            } else text = L"C2 失败: " + done->error;
            if (g_c2Status) SetWindowTextW(g_c2Status,text.c_str());
            AppendC2Log(text);
            const bool wasUploadAction=(done->action==C2Action::Upload || done->action==C2Action::UploadArm);
            if (wasUploadAction) EndC2UploadSessionLog();
            if (done->ok && g_loaded && (done->action==C2Action::Upload ||
                done->action==C2Action::UploadArm || done->action==C2Action::ArmFromCursor)) {
                const double startBeat=done->completionBeat>=0.0 ? done->completionBeat : static_cast<double>(g_c2.LastPlan().initialBeat);
                g_playing=false;
                MidiAllOff();
                g_positionBeat=ClampSongBeat(startBeat);
                g_nextMidi=g_model.FindScheduledNoteIndex(g_positionBeat);
                EnsureTimelineBeatVisible(g_positionBeat, false);
                if (done->action==C2Action::UploadArm || done->action==C2Action::ArmFromCursor)
                    ArmC2PerformanceUI(g_positionBeat);
                else
                    ResetC2PerformanceFlow(false);
                RefreshPositionUI(false,true);
            }
            if (done->ok && (done->action==C2Action::Disconnect || done->action==C2Action::CloseSheet)) {
                ResetC2PerformanceFlow(false);
                g_hasC2Beat=false;
            }
            if (done->ok && done->action==C2Action::DeviceInfo)
                ShowTextViewer(L"C2 设备信息",BuildDeviceInfoText());
            if (!done->ok) MessageBoxW(hwnd, text.c_str(), L"C2 BLE", MB_ICONERROR);
        }
        UpdateC2StateLabels();
        UpdateC2Buttons();
        return 0;
    }
    case WM_APP_C2_EVENT: {
        std::unique_ptr<C2PlayEvent> event(reinterpret_cast<C2PlayEvent*>(lp));
        if (!event) return 0;

        if (event->kind==C2PlayEvent::Kind::Basic) {
            UpdateC2StateLabels();
            std::wostringstream basic;
            basic << L"RX noti_basic key=" << event->basicKey << L" bpm=" << event->basicBpm
                  << L" sysVol=" << event->basicVolume << L" battery=" << event->battery
                  << L" mode=" << event->guitarMode << L" chargeState=" << event->chargeState;
            AppendC2Log(basic.str());
            if (g_deviceCenterWnd && IsWindow(g_deviceCenterWnd)) PostMessageW(g_deviceCenterWnd,WM_DEVICECENTER_REALTIME,0,0);
            return 0;
        }

        std::wostringstream os;
        os << L"RX " << Utf8ToWide(event->command) << L" len=" << event->data.size();
        if (event->receivedTickMs) {
            const ULONGLONG uiNow=GetTickCount64();
            const ULONGLONG latency=uiNow>=event->receivedTickMs ? uiNow-event->receivedTickMs : 0;
            os << L" BLE->UI=" << latency << L"ms";
        }
        if (event->kind==C2PlayEvent::Kind::Frets) {
            os << L" key=" << event->fretKey << L" BPMtouch=" << event->bpmTouch << L" Pads=[";
            for (int i=0;i<6;++i) {
                if (i) os << L",";
                os << (event->arpeggioPressed[static_cast<std::size_t>(i)]?L"DOWN":L"up")
                   << L"/" << event->arpeggioRaw[static_cast<std::size_t>(i)];
            }
            os << L"]";
        } else if (event->kind==C2PlayEvent::Kind::Picks) {
            os << L" state=" << event->pickState;
            if (event->hasPickAngles) os << L" angleA=" << ToW(event->pickAngleA,2) << L" angleB=" << ToW(event->pickAngleB,2);
        } else if (event->kind==C2PlayEvent::Kind::Event) {
            os << L" type=" << event->eventType << L" value=" << event->eventValue;
            if (event->eventType==1) os << L" [MAIN_TRACK_AUTO=" << (event->eventValue?L"ON":L"OFF") << L"]";
            else if (event->eventType==2) os << L" [MIC_VOL]";
            else if (event->eventType==3) os << L" [DOUBLE_PICK]";
            else if (event->eventType==4) os << L" [BATTERY_SHOW]";
        }
        if (event->kind == C2PlayEvent::Kind::Chord) {
            os << L" row=" << event->row << L" col=" << event->col
               << L" level=" << event->level << L" type=" << event->type
               << L" trans12=" << event->trans12 << L" pickId=" << event->pickId;
            g_lastC2Row = event->row;
            g_lastC2Col = event->col;
            g_lastC2Level = event->level;
            g_lastC2ChordType = event->type;
            g_lastC2Trans12 = event->trans12;
            g_lastC2PickId = event->pickId;
            const C2DeviceState ds=g_c2.DeviceState();
            bool anyPad=false;
            for (int i=0;i<6;++i) if (ds.arpeggioPressed[static_cast<std::size_t>(i)]>0) anyPad=true;
            if (anyPad) {
                os << L" [ARPEGGIO_HELD:";
                for (int i=0;i<6;++i) if (ds.arpeggioPressed[static_cast<std::size_t>(i)]>0) os << L" P" << (i+1);
                os << L"]";
            }
        }

        // V2.3.20a: device beat is synchronization evidence, not transport
        // permission. Only a chord/key+pick event matching the CURRENT waiting
        // score trigger may move the red line.
        if (event->hasBeat) {
            g_hasC2Beat = true;
            g_lastC2RawBeat = static_cast<double>(event->beat);
        }

        if (!g_loaded || !g_c2PerformanceArmed) {
            if (event->hasBeat) os << L"  C2 beat=" << ToW(event->beat,4);
            os << L"  [MONITOR: 当前未进入C2待按键演奏态]";
        } else if (event->kind==C2PlayEvent::Kind::Chord) {
            std::wstring flowNote;
            AcceptC2PhysicalTrigger(*event,flowNote);
            os << L"  " << flowNote;
            if (!event->hasBeat)
                os << L" [legacy 6B: 后续A102仅作同步，不会再次推进]";
        } else if (event->hasBeat) {
            std::wstring syncNote;
            ObserveC2DeviceBeatOnly(event->beat,syncNote);
            os << L"  " << syncNote;
        }

        const std::wstring text = os.str();
        if (g_c2Status) SetWindowTextW(g_c2Status, text.c_str());
        AppendC2Log(text);
        if (g_deviceCenterWnd && IsWindow(g_deviceCenterWnd) &&
            (event->kind==C2PlayEvent::Kind::Frets || event->kind==C2PlayEvent::Kind::Picks ||
             event->kind==C2PlayEvent::Kind::Event || event->kind==C2PlayEvent::Kind::Chord))
            PostMessageW(g_deviceCenterWnd,WM_DEVICECENTER_REALTIME,0,0);
        return 0;
    }
    case WM_TRACK_VOLUME_DONE: {
        std::unique_ptr<TrackVolumeDone> done(reinterpret_cast<TrackVolumeDone*>(lp));
        if (!done) return 0;
        if (!done->ok) {
            g_trackEnabled[done->trackIndex]=!done->requestedEnabled;
            PopulateTracksForSegment(g_currentSegment);
            const std::wstring msg=L"轨道音量切换失败："+done->error;
            AppendC2Log(msg);
            MessageBoxW(hwnd,msg.c_str(),L"C2 轨道静音",MB_ICONERROR);
        } else {
            PopulateTracksForSegment(g_currentSegment);
            AppendC2Log(L"全部轨道复选框："+TrackRoleName(done->trackIndex)+
                (done->requestedEnabled?L" 恢复原始音量":L" 音量=0（静音）"));
        }
        return 0;
    }
    case WM_NOTIFY: {
        const LPNMHDR hdr = reinterpret_cast<LPNMHDR>(lp);
        if (hdr && hdr->idFrom == IDC_TRACKS && hdr->code == LVN_ITEMCHANGED && !g_populatingTracks) {
            const LPNMLISTVIEW lv = reinterpret_cast<LPNMLISTVIEW>(lp);
            if ((lv->uChanged & LVIF_STATE) != 0) {
                const UINT oldImg = lv->uOldState & LVIS_STATEIMAGEMASK;
                const UINT newImg = lv->uNewState & LVIS_STATEIMAGEMASK;
                if (oldImg != newImg) OnTrackStateChanged(lv);
            }
        }
        return 0;
    }
    case WM_HSCROLL:
        if (reinterpret_cast<HWND>(lp) == g_progress && g_loaded) {
            const int code = LOWORD(wp);
            if (code == TB_THUMBTRACK || code == TB_THUMBPOSITION || code == SB_LINELEFT || code == SB_LINERIGHT ||
                code == SB_PAGELEFT || code == SB_PAGERIGHT || code == SB_ENDSCROLL) {
                const int p = static_cast<int>(SendMessageW(g_progress, TBM_GETPOS, 0, 0));
                const double span = std::max<double>(4.0, std::min<double>(MaxTimelineSpan(), g_timelineSpan));
                const double maxStart = std::max<double>(0.0, g_model.TotalBeats() - span);
                g_timelineViewStart = maxStart * std::max<int>(0,std::min<int>(10000,p)) / 10000.0;
                ClampTimelineViewStart();
                g_lastProgressPos = p;
                InvalidateTimeline();
            }
        }
        return 0;
    case WM_LBUTTONDOWN: {
        POINT pt{GET_X_LPARAM(lp), GET_Y_LPARAM(lp)};
        const RECT ls = LeftSplitterRect(hwnd);
        const RECT rs = RightSplitterRect(hwnd);
        if (PtInRect(&ls, pt)) {
            g_dragLeftSplitter = true; g_dragRightSplitter = false;
            SetCapture(hwnd);
            SetCursor(LoadCursorW(nullptr, IDC_SIZEWE));
            return 0;
        }
        if (PtInRect(&rs, pt)) {
            g_dragRightSplitter = true; g_dragLeftSplitter = false;
            SetCapture(hwnd);
            SetCursor(LoadCursorW(nullptr, IDC_SIZEWE));
            return 0;
        }
        if (g_loaded) {
            const TimelineView v = GetTimelineView(hwnd);
            if (PtInRect(&v.r, pt) && pt.x >= v.plotLeft && pt.x <= v.r.right) {
                // Capture the visible beat window before changing g_positionBeat.
                // GetTimelineView() will keep this window frozen until mouse-up.
                g_dragTimelineViewStart = v.start;
                g_dragTimelineViewSpan = v.span;
                g_dragTimelinePlotWidth = v.plotWidth;
                g_dragTimelineCursor = true;
                SetCapture(hwnd);
                SetTimelineCursorFromX(hwnd,pt.x,false);
                SetFocus(hwnd);
                return 0;
            }
        }
        break;
    }
    case WM_MOUSEMOVE:
        if (g_dragLeftSplitter || g_dragRightSplitter) {
            RECT rc{}; GetClientRect(hwnd, &rc);
            const int x = GET_X_LPARAM(lp);
            if (g_dragLeftSplitter) {
                const int maxLeft = std::max<int>(kMinPaneW, rc.right - 20 - 2 * kSplitterW - kMinTimelineW - g_rightPaneW);
                g_leftPaneW = std::max<int>(kMinPaneW, std::min<int>(std::min<int>(kMaxPaneW, maxLeft), x - 10));
            } else {
                const int requested = rc.right - 10 - x;
                const int maxRight = std::max<int>(kMinPaneW, rc.right - 20 - 2 * kSplitterW - kMinTimelineW - g_leftPaneW);
                g_rightPaneW = std::max<int>(kMinPaneW, std::min<int>(std::min<int>(kMaxPaneW, maxRight), requested));
            }
            Layout(hwnd);
            InvalidateRect(hwnd, nullptr, FALSE);
            SetCursor(LoadCursorW(nullptr, IDC_SIZEWE));
            return 0;
        }
        if (g_dragTimelineCursor) {
            SetTimelineCursorFromX(hwnd,GET_X_LPARAM(lp),false);
            return 0;
        }
        break;
    case WM_LBUTTONUP:
        if (g_dragLeftSplitter || g_dragRightSplitter) {
            g_dragLeftSplitter = false; g_dragRightSplitter = false;
            ReleaseCapture();
            return 0;
        }
        if (g_dragTimelineCursor) {
            // Apply the final x coordinate while the frozen drag window is still
            // active. Releasing the mouse keeps the same viewport; manual cursor
            // movement must not recenter the score.
            SetTimelineCursorFromX(hwnd,GET_X_LPARAM(lp),true);
            g_dragTimelineCursor=false;
            g_dragTimelinePlotWidth=0;
            ReleaseCapture();
            InvalidateTimeline();
            return 0;
        }
        break;
    case WM_CAPTURECHANGED:
        g_dragLeftSplitter = false; g_dragRightSplitter = false; g_dragTimelineCursor=false;
        g_dragTimelinePlotWidth=0;
        break;
    case WM_MOUSEWHEEL:
        if (g_loaded) {
            POINT pt{GET_X_LPARAM(lp), GET_Y_LPARAM(lp)};
            ScreenToClient(hwnd, &pt);
            const TimelineView v = GetTimelineView(hwnd);
            if (PtInRect(&v.r, pt)) {
                const short delta = GET_WHEEL_DELTA_WPARAM(wp);
                if (delta > 0) SetTimelineSpan(g_timelineSpan / 1.25);
                else if (delta < 0) SetTimelineSpan(g_timelineSpan * 1.25);
                return 0;
            }
        }
        break;
    case WM_SETCURSOR: {
        POINT pt{}; GetCursorPos(&pt); ScreenToClient(hwnd, &pt);
        const RECT ls = LeftSplitterRect(hwnd);
        const RECT rs = RightSplitterRect(hwnd);
        if (PtInRect(&ls, pt) || PtInRect(&rs, pt)) {
            SetCursor(LoadCursorW(nullptr, IDC_SIZEWE));
            return TRUE;
        }
        break;
    }
    case WM_TIMER:
        if (wp == TIMER_PLAY) TickPlayback();
        else if (wp == TIMER_PREVIEW_OFF) {
            KillTimer(hwnd, TIMER_PREVIEW_OFF);
            MidiAllOff();
        }
        return 0;
    case WM_DROPFILES: {
        wchar_t path[MAX_PATH]{};
        const HDROP h = reinterpret_cast<HDROP>(wp);
        if (DragQueryFileW(h, 0, path, MAX_PATH)) LoadSong(fs::path(path));
        DragFinish(h);
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps{};
        HDC hdc = BeginPaint(hwnd, &ps);
        DrawTimelineBuffered(hdc, hwnd);
        DrawSplitters(hdc, hwnd);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_CLOSE:
        if (g_c2Busy.load()) {
            MessageBoxW(hwnd, L"C2 正在上传/发送命令，请等待当前操作完成后再关闭。", L"C2 BLE", MB_ICONINFORMATION);
            return 0;
        }
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        if (!g_c2Busy.load()) g_c2.Disconnect();
        CloseMidi();
        KillTimer(hwnd, TIMER_PLAY);
        KillTimer(hwnd, TIMER_PREVIEW_OFF);
        if (g_timelineLyricFont) { DeleteObject(g_timelineLyricFont); g_timelineLyricFont = nullptr; }
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int show) {
    winrt::init_apartment(winrt::apartment_type::single_threaded);
    INITCOMMONCONTROLSEX ic{sizeof(ic), ICC_BAR_CLASSES | ICC_LISTVIEW_CLASSES};
    InitCommonControlsEx(&ic);

    WNDCLASSEXW wc{sizeof(wc)};
    wc.style = 0; // Do not force whole-window redraw on every horizontal/vertical size change.
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_BTNFACE + 1);
    wc.lpszClassName = kClassName;
    wc.hIconSm = wc.hIcon;
    if (!RegisterClassExW(&wc)) return 1;

    HWND hwnd = CreateWindowExW(0, kClassName,
        L"LiberLive MDS Player V2.3.20l - DrumCue/MasterBPM/PerTrackMIDI / 460B WR-Pack + UIProgress50 / 6/8 MeterTimingFix / C2",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT, CW_USEDEFAULT, 1540, 920,
        nullptr, nullptr, hInst, nullptr);
    if (!hwnd) return 2;

    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);
    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    const int result = static_cast<int>(msg.wParam);
    winrt::uninit_apartment();
    return result;
}
