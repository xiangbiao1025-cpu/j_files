#include "JsonLite.h"
#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <sstream>

namespace jsonlite {

const Value* Value::Find(const std::string& key) const {
    if (!IsObject()) return nullptr;
    auto it = objectValue.find(key);
    return it == objectValue.end() ? nullptr : &it->second;
}

const char* TypeName(Type type) {
    switch (type) {
    case Type::Null: return "null";
    case Type::Bool: return "bool";
    case Type::Number: return "number";
    case Type::String: return "string";
    case Type::Array: return "array";
    case Type::Object: return "object";
    }
    return "unknown";
}

class Parser {
public:
    Parser(const std::string& text) : text_(text), begin_(text_.c_str()), p_(begin_), end_(begin_ + text_.size()) {}

    bool Run(Value& out, std::string& error) {
        SkipWs();
        if (!ParseValue(out)) { error = ErrorText(); return false; }
        SkipWs();
        if (p_ != end_) { SetError("unexpected trailing characters"); error = ErrorText(); return false; }
        return true;
    }

private:
    const std::string& text_;
    const char* begin_;
    const char* p_;
    const char* end_;
    std::string error_;

    void SkipWs() {
        while (p_ < end_ && (*p_ == ' ' || *p_ == '\t' || *p_ == '\r' || *p_ == '\n')) ++p_;
    }

    void SetError(const std::string& msg) {
        if (error_.empty()) error_ = msg;
    }

    std::string ErrorText() const {
        size_t offset = static_cast<size_t>(p_ - begin_);
        size_t line = 1, col = 1;
        for (size_t i = 0; i < offset && i < text_.size(); ++i) {
            if (text_[i] == '\n') { ++line; col = 1; }
            else ++col;
        }
        std::ostringstream oss;
        oss << error_ << " at line " << line << ", column " << col << " (offset " << offset << ")";
        return oss.str();
    }

    bool Match(const char* s) {
        const char* q = p_;
        while (*s) {
            if (q >= end_ || *q != *s) return false;
            ++q; ++s;
        }
        p_ = q;
        return true;
    }

    static bool IsHex(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }

    static unsigned HexValue(char c) {
        if (c >= '0' && c <= '9') return static_cast<unsigned>(c - '0');
        if (c >= 'a' && c <= 'f') return static_cast<unsigned>(10 + c - 'a');
        return static_cast<unsigned>(10 + c - 'A');
    }

    bool ReadHex4(unsigned& cp) {
        if (end_ - p_ < 4) { SetError("incomplete unicode escape"); return false; }
        cp = 0;
        for (int i = 0; i < 4; ++i) {
            if (!IsHex(p_[i])) { SetError("invalid unicode escape"); return false; }
            cp = (cp << 4) | HexValue(p_[i]);
        }
        p_ += 4;
        return true;
    }

    static void AppendUtf8(std::string& out, unsigned cp) {
        if (cp <= 0x7F) out.push_back(static_cast<char>(cp));
        else if (cp <= 0x7FF) {
            out.push_back(static_cast<char>(0xC0 | ((cp >> 6) & 0x1F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp <= 0xFFFF) {
            out.push_back(static_cast<char>(0xE0 | ((cp >> 12) & 0x0F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | ((cp >> 18) & 0x07)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }

    bool ParseString(std::string& out) {
        if (p_ >= end_ || *p_ != '"') { SetError("expected string"); return false; }
        ++p_;
        out.clear();
        while (p_ < end_) {
            unsigned char c = static_cast<unsigned char>(*p_++);
            if (c == '"') return true;
            if (c < 0x20) { SetError("control character in string"); return false; }
            if (c != '\\') { out.push_back(static_cast<char>(c)); continue; }
            if (p_ >= end_) { SetError("incomplete string escape"); return false; }
            char e = *p_++;
            switch (e) {
            case '"': out.push_back('"'); break;
            case '\\': out.push_back('\\'); break;
            case '/': out.push_back('/'); break;
            case 'b': out.push_back('\b'); break;
            case 'f': out.push_back('\f'); break;
            case 'n': out.push_back('\n'); break;
            case 'r': out.push_back('\r'); break;
            case 't': out.push_back('\t'); break;
            case 'u': {
                unsigned cp = 0;
                if (!ReadHex4(cp)) return false;
                if (cp >= 0xD800 && cp <= 0xDBFF) {
                    if (end_ - p_ < 6 || p_[0] != '\\' || p_[1] != 'u') { SetError("missing low surrogate"); return false; }
                    p_ += 2;
                    unsigned low = 0;
                    if (!ReadHex4(low)) return false;
                    if (low < 0xDC00 || low > 0xDFFF) { SetError("invalid low surrogate"); return false; }
                    cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00);
                } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
                    SetError("unexpected low surrogate"); return false;
                }
                AppendUtf8(out, cp);
                break;
            }
            default: SetError("invalid string escape"); return false;
            }
        }
        SetError("unterminated string");
        return false;
    }

    bool ParseNumber(Value& out) {
        const char* start = p_;
        if (p_ < end_ && *p_ == '-') ++p_;
        if (p_ >= end_) { SetError("invalid number"); return false; }
        if (*p_ == '0') ++p_;
        else {
            if (!std::isdigit(static_cast<unsigned char>(*p_))) { SetError("invalid number"); return false; }
            while (p_ < end_ && std::isdigit(static_cast<unsigned char>(*p_))) ++p_;
        }
        if (p_ < end_ && *p_ == '.') {
            ++p_;
            if (p_ >= end_ || !std::isdigit(static_cast<unsigned char>(*p_))) { SetError("invalid fraction"); return false; }
            while (p_ < end_ && std::isdigit(static_cast<unsigned char>(*p_))) ++p_;
        }
        if (p_ < end_ && (*p_ == 'e' || *p_ == 'E')) {
            ++p_;
            if (p_ < end_ && (*p_ == '+' || *p_ == '-')) ++p_;
            if (p_ >= end_ || !std::isdigit(static_cast<unsigned char>(*p_))) { SetError("invalid exponent"); return false; }
            while (p_ < end_ && std::isdigit(static_cast<unsigned char>(*p_))) ++p_;
        }
        std::string token(start, p_);
        errno = 0;
        char* endptr = nullptr;
        double v = std::strtod(token.c_str(), &endptr);
        if (errno == ERANGE || !endptr || *endptr != '\0') { SetError("number conversion failed"); return false; }
        out.type = Type::Number;
        out.numberValue = v;
        out.numberToken = token;
        return true;
    }

    bool ParseArray(Value& out) {
        ++p_; // [
        out.type = Type::Array;
        out.arrayValue.clear();
        SkipWs();
        if (p_ < end_ && *p_ == ']') { ++p_; return true; }
        while (p_ < end_) {
            Value v;
            if (!ParseValue(v)) return false;
            out.arrayValue.push_back(std::move(v));
            SkipWs();
            if (p_ < end_ && *p_ == ',') { ++p_; SkipWs(); continue; }
            if (p_ < end_ && *p_ == ']') { ++p_; return true; }
            SetError("expected ',' or ']' in array");
            return false;
        }
        SetError("unterminated array");
        return false;
    }

    bool ParseObject(Value& out) {
        ++p_; // {
        out.type = Type::Object;
        out.objectValue.clear();
        SkipWs();
        if (p_ < end_ && *p_ == '}') { ++p_; return true; }
        while (p_ < end_) {
            std::string key;
            if (!ParseString(key)) return false;
            SkipWs();
            if (p_ >= end_ || *p_ != ':') { SetError("expected ':' after object key"); return false; }
            ++p_;
            SkipWs();
            Value v;
            if (!ParseValue(v)) return false;
            out.objectValue[key] = std::move(v);
            SkipWs();
            if (p_ < end_ && *p_ == ',') { ++p_; SkipWs(); continue; }
            if (p_ < end_ && *p_ == '}') { ++p_; return true; }
            SetError("expected ',' or '}' in object");
            return false;
        }
        SetError("unterminated object");
        return false;
    }

    bool ParseValue(Value& out) {
        SkipWs();
        if (p_ >= end_) { SetError("unexpected end of input"); return false; }
        const char* valueStart = p_;
        bool ok = false;
        const char c = *p_;
        if (c == '{') ok = ParseObject(out);
        else if (c == '[') ok = ParseArray(out);
        else if (c == '"') { out.type = Type::String; ok = ParseString(out.stringValue); }
        else if (c == '-' || std::isdigit(static_cast<unsigned char>(c))) ok = ParseNumber(out);
        else if (Match("true")) { out.type = Type::Bool; out.boolValue = true; ok = true; }
        else if (Match("false")) { out.type = Type::Bool; out.boolValue = false; ok = true; }
        else if (Match("null")) { out.type = Type::Null; ok = true; }
        else { SetError("unexpected token"); return false; }

        if (ok) {
            out.sourceStart = static_cast<std::size_t>(valueStart - begin_);
            out.sourceEnd = static_cast<std::size_t>(p_ - begin_);
        }
        return ok;
    }
};

bool Parse(const std::string& text, Value& out, std::string& error) {
    error.clear();
    Parser p(text);
    return p.Run(out, error);
}

} // namespace jsonlite
