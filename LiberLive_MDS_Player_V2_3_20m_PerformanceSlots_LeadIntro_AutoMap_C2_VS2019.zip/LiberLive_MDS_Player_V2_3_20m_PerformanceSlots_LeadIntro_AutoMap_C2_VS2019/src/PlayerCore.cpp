﻿#include "PlayerCore.h"
#include <algorithm>
#include <cmath>

int CMDSPlayerModel::ParseBeatsPerBar(const std::string& beatText) {
    const std::size_t slash = beatText.find('/');
    if (slash == std::string::npos) return 4;
    try {
        const int n = std::stoi(beatText.substr(0, slash));
        return n > 0 && n <= 16 ? n : 4;
    } catch (...) {
        return 4;
    }
}


int CMDSPlayerModel::ParseBeatDenominator(const std::string& beatText) {
    const std::size_t slash = beatText.find('/');
    if (slash == std::string::npos) return 4;
    try {
        const int d = std::stoi(beatText.substr(slash + 1));
        return d > 0 && d <= 32 ? d : 4;
    } catch (...) {
        return 4;
    }
}

int CMDSPlayerModel::ToMidiNote(const MDSNote& note) {
    int pitchClass = std::max<int>(1, std::min<int>(12, note.note));
    const int midi = 60 + (pitchClass - 1) + note.upOctave * 12;
    return std::max<int>(0, std::min<int>(127, midi));
}

int CMDSPlayerModel::MidiChannelForTrack(int trackIndex) {
    if (trackIndex <= 0) return 0;
    int ch = trackIndex;
    if (ch >= 9) ++ch; // skip GM percussion channel 10 (zero-based 9)
    if (ch > 15) ch = 1 + ((ch - 1) % 15);
    if (ch == 9) ch = 10;
    return std::max<int>(0, std::min<int>(15, ch));
}

bool CMDSPlayerModel::SegmentUsesMainMelody(int segmentType) {
    // Legacy presentation helper kept for compatibility.  V2.3.20m no longer
    // uses segment type to decide whether real tk0/beat.notes exist.
    return segmentType != 0 && segmentType != 4;
}

void CMDSPlayerModel::EnsureTrack(int trackIndex, const std::string& name, int type, int volume, int mute, std::size_t segmentCount) {
    for (MDSPlaybackTrack& t : m_tracks) {
        if (t.index == trackIndex) {
            if (!name.empty()) t.name = name;
            if (type >= 0) t.type = type;
            t.volume = volume;
            t.mute = mute;
            if (t.segmentNoteCounts.size() < segmentCount) t.segmentNoteCounts.resize(segmentCount, 0);
            return;
        }
    }
    MDSPlaybackTrack t;
    t.index = trackIndex;
    t.name = name.empty() ? (trackIndex == 0 ? "Main / Lead" : "Track " + std::to_string(trackIndex)) : name;
    t.type = type;
    t.volume = volume;
    t.mute = mute;
    t.segmentNoteCounts.resize(segmentCount, 0);
    m_tracks.push_back(std::move(t));
}

void CMDSPlayerModel::IncrementTrackNoteCount(int trackIndex, std::size_t segmentIndex, std::size_t segmentCount) {
    for (MDSPlaybackTrack& t : m_tracks) {
        if (t.index == trackIndex) {
            ++t.noteCount;
            if (t.segmentNoteCounts.size() < segmentCount) t.segmentNoteCounts.resize(segmentCount, 0);
            if (segmentIndex < t.segmentNoteCounts.size()) ++t.segmentNoteCounts[segmentIndex];
            return;
        }
    }
    EnsureTrack(trackIndex, "Track " + std::to_string(trackIndex), -1, 100, 0, segmentCount);
    m_tracks.back().noteCount = 1;
    if (segmentIndex < m_tracks.back().segmentNoteCounts.size()) m_tracks.back().segmentNoteCounts[segmentIndex] = 1;
}

void CMDSPlayerModel::Clear() {
    m_beatsPerBar = 4;
    m_beatDenominator = 4;
    m_meterText = "4/4";
    m_rawUnitsPerScoreBeat = 4.0;
    m_scoreBeatsPerQuarter = 1.0;
    m_totalBeats = 0.0;
    m_beats.clear();
    m_notes.clear();
    m_segments.clear();
    m_tracks.clear();
    m_lyricWords.clear();
    m_lyricLines.clear();
    m_chordSections.clear();
    m_hasExtraTrackNotes = false;
}

void CMDSPlayerModel::Build(const MDSSong& song) {
    Clear();
    const std::size_t segmentCount = song.content.lyrics.size();
    m_meterText = !song.content.beat.empty() ? song.content.beat : song.content.baseConfig.beat;
    if (m_meterText.empty()) m_meterText = "4/4";
    m_beatsPerBar = ParseBeatsPerBar(m_meterText);
    m_beatDenominator = ParseBeatDenominator(m_meterText);
    // LiberLive JSON raw timing unit is 1/16 note: unit = 16 / denominator.
    // Therefore 4/4 => 4 raw units per score beat; 6/8 => 2.
    m_rawUnitsPerScoreBeat = 16.0 / static_cast<double>(m_beatDenominator);
    if (!(m_rawUnitsPerScoreBeat > 0.0)) m_rawUnitsPerScoreBeat = 4.0;
    // JSON beat cells are denominator-note units. BPM remains quarter-note BPM,
    // so x/8 advances two score beats per quarter note.
    m_scoreBeatsPerQuarter = static_cast<double>(m_beatDenominator) / 4.0;
    if (!(m_scoreBeatsPerQuarter > 0.0)) m_scoreBeatsPerQuarter = 1.0;

    EnsureTrack(0, "Main / Lead", -1, 100, 0, segmentCount);
    for (const MDSTrackConfig& tc : song.content.trackConfigs)
        EnsureTrack(tc.index, tc.name, tc.type, tc.volume, tc.mute, segmentCount);

    double segmentBase = 0.0;
    for (std::size_t si = 0; si < song.content.lyrics.size(); ++si) {
        const MDSLyricTrack& seg = song.content.lyrics[si];
        int maxBar = -1;
        for (const MDSBar& bar : seg.bars) maxBar = std::max<int>(maxBar, bar.bar);
        const double segmentLength = (maxBar >= 0 ? (maxBar + 1) : static_cast<int>(seg.bars.size())) * m_beatsPerBar;

        MDSSegmentSpan span;
        span.segmentIndex = si;
        span.type = seg.type;
        span.startBeat = segmentBase;
        span.endBeat = segmentBase + segmentLength;
        span.bars = seg.bars.size();
        m_segments.push_back(span);

        struct WordEvent {
            double startBeat = 0.0;
            double endBeat = 0.0;
            bool newLine = false;
            std::string text;
        };
        std::vector<WordEvent> wordEvents;

        for (const MDSBar& bar : seg.bars) {
            for (const MDSBeat& beat : bar.beats) {
                const double absBeat = segmentBase + bar.bar * m_beatsPerBar + beat.beat;
                MDSFlatBeat fb;
                fb.segmentIndex = si;
                fb.segmentType = seg.type;
                fb.bar = bar.bar;
                fb.beat = beat.beat;
                fb.absoluteBeat = absBeat;
                fb.source = &beat;
                m_beats.push_back(fb);

                if (beat.hasChord) {
                    MDSChordSection cs;
                    cs.startBeat = absBeat;
                    cs.endBeat = absBeat + std::max<double>(0.25, RawUnitsToScoreBeats(beat.chord.length));
                    cs.segmentIndex = si;
                    cs.source = &beat;
                    m_chordSections.push_back(cs);
                }

                auto addNote = [&](const MDSNote& n, int trackIndex) {
                    MDSScheduledNote sn;
                    sn.startBeat = absBeat + RawUnitsToScoreBeats(n.start);
                    sn.endBeat = sn.startBeat + std::max<double>(0.05, RawUnitsToScoreBeats(n.length));
                    sn.midiNote = ToMidiNote(n);
                    sn.velocity = n.velocity > 0 ? std::max<int>(1, std::min<int>(127, n.velocity)) : 80;
                    sn.trackIndex = trackIndex;
                    sn.midiChannel = MidiChannelForTrack(trackIndex);
                    sn.segmentIndex = si;
                    sn.sourceBeat = absBeat;
                    sn.stretch = n.stretch;
                    m_notes.push_back(sn);
                    IncrementTrackNoteCount(trackIndex, si, segmentCount);
                };

                for (const MDSNote& n : beat.notes) addNote(n, 0);
                for (const MDSExtraTrack& et : beat.extraTracks) {
                    if (!FindTrack(et.index))
                        EnsureTrack(et.index, "Track " + std::to_string(et.index), -1, 100, 0, segmentCount);
                    if (!et.notes.empty()) m_hasExtraTrackNotes = true;
                    for (const MDSNote& n : et.notes) addNote(n, et.index);
                }

                for (const MDSWord& w : beat.words) {
                    MDSLyricWordEvent word;
                    word.segmentIndex = si;
                    word.startBeat = absBeat + RawUnitsToScoreBeats(w.start);
                    word.endBeat = word.startBeat + std::max<double>(0.05, RawUnitsToScoreBeats(w.length));
                    word.text = w.word;
                    word.newLine = w.newLine;
                    word.stretch = w.stretch;
                    m_lyricWords.push_back(word);

                    WordEvent ev;
                    ev.startBeat = word.startBeat;
                    ev.endBeat = word.endBeat;
                    ev.newLine = word.newLine;
                    ev.text = word.text;
                    wordEvents.push_back(std::move(ev));
                }
            }
        }

        std::sort(wordEvents.begin(), wordEvents.end(), [](const WordEvent& a, const WordEvent& b) {
            if (a.startBeat != b.startBeat) return a.startBeat < b.startBeat;
            return a.endBeat < b.endBeat;
        });
        MDSLyricLine line;
        bool haveLine = false;
        for (const WordEvent& ev : wordEvents) {
            if (!haveLine && !ev.text.empty()) {
                line = MDSLyricLine{};
                line.segmentIndex = si;
                line.startBeat = ev.startBeat;
                line.endBeat = ev.endBeat;
                haveLine = true;
            }
            if (haveLine) {
                line.endBeat = std::max<double>(line.endBeat, ev.endBeat);
                if (!ev.text.empty()) line.text += ev.text;
                if (ev.newLine) {
                    if (!line.text.empty()) m_lyricLines.push_back(line);
                    haveLine = false;
                }
            }
        }
        if (haveLine && !line.text.empty()) m_lyricLines.push_back(line);

        segmentBase += segmentLength;
    }

    m_totalBeats = segmentBase;
    std::sort(m_beats.begin(), m_beats.end(), [](const MDSFlatBeat& a, const MDSFlatBeat& b) {
        if (a.absoluteBeat != b.absoluteBeat) return a.absoluteBeat < b.absoluteBeat;
        return a.segmentIndex < b.segmentIndex;
    });
    std::sort(m_chordSections.begin(), m_chordSections.end(), [](const MDSChordSection& a, const MDSChordSection& b) {
        if (a.startBeat != b.startBeat) return a.startBeat < b.startBeat;
        return a.endBeat < b.endBeat;
    });
    // A malformed/legacy file can occasionally declare a chord length that
    // crosses the following chord start. Never let one perform-mode gate
    // overrun the next chord section.
    for (std::size_t i = 0; i + 1 < m_chordSections.size(); ++i) {
        if (m_chordSections[i].endBeat > m_chordSections[i + 1].startBeat)
            m_chordSections[i].endBeat = m_chordSections[i + 1].startBeat;
        if (m_chordSections[i].endBeat <= m_chordSections[i].startBeat)
            m_chordSections[i].endBeat = m_chordSections[i + 1].startBeat;
    }
    if (!m_chordSections.empty())
        m_chordSections.back().endBeat = std::min<double>(m_totalBeats, std::max<double>(
            m_chordSections.back().endBeat, m_chordSections.back().startBeat + 0.25));
    std::sort(m_notes.begin(), m_notes.end(), [](const MDSScheduledNote& a, const MDSScheduledNote& b) {
        if (a.startBeat != b.startBeat) return a.startBeat < b.startBeat;
        if (a.trackIndex != b.trackIndex) return a.trackIndex < b.trackIndex;
        return a.midiNote < b.midiNote;
    });
    std::sort(m_tracks.begin(), m_tracks.end(), [](const MDSPlaybackTrack& a, const MDSPlaybackTrack& b) {
        return a.index < b.index;
    });
    std::sort(m_lyricWords.begin(), m_lyricWords.end(), [](const MDSLyricWordEvent& a, const MDSLyricWordEvent& b) {
        if (a.startBeat != b.startBeat) return a.startBeat < b.startBeat;
        return a.endBeat < b.endBeat;
    });
    std::sort(m_lyricLines.begin(), m_lyricLines.end(), [](const MDSLyricLine& a, const MDSLyricLine& b) {
        return a.startBeat < b.startBeat;
    });

    // Keep a lyric line visible until the next line starts. The last line of each
    // segment remains visible to the segment boundary.
    for (std::size_t i = 0; i < m_lyricLines.size(); ++i) {
        double holdUntil = m_totalBeats;
        const std::size_t si = m_lyricLines[i].segmentIndex;
        if (si < m_segments.size()) holdUntil = m_segments[si].endBeat;
        if (i + 1 < m_lyricLines.size() && m_lyricLines[i + 1].startBeat > m_lyricLines[i].startBeat)
            holdUntil = std::min<double>(holdUntil, m_lyricLines[i + 1].startBeat);
        m_lyricLines[i].endBeat = std::max<double>(m_lyricLines[i].endBeat, holdUntil);
    }
}

const MDSPlaybackTrack* CMDSPlayerModel::FindTrack(int trackIndex) const {
    for (const MDSPlaybackTrack& t : m_tracks)
        if (t.index == trackIndex) return &t;
    return nullptr;
}

const MDSFlatBeat* CMDSPlayerModel::FindBeat(double absoluteBeat) const {
    if (m_beats.empty()) return nullptr;
    auto it = std::upper_bound(m_beats.begin(), m_beats.end(), absoluteBeat,
        [](double v, const MDSFlatBeat& b) { return v < b.absoluteBeat; });
    if (it == m_beats.begin()) return &m_beats.front();
    --it;
    return &*it;
}

const MDSSegmentSpan* CMDSPlayerModel::FindSegment(double absoluteBeat) const {
    if (m_segments.empty()) return nullptr;
    for (const MDSSegmentSpan& s : m_segments) {
        if (absoluteBeat >= s.startBeat && absoluteBeat < s.endBeat) return &s;
    }
    if (absoluteBeat >= m_segments.back().endBeat) return &m_segments.back();
    return &m_segments.front();
}

const MDSLyricLine* CMDSPlayerModel::FindLyricLine(double absoluteBeat) const {
    const MDSLyricLine* best = nullptr;
    for (const MDSLyricLine& l : m_lyricLines) {
        if (l.startBeat > absoluteBeat) break;
        if (absoluteBeat >= l.startBeat && absoluteBeat < l.endBeat) best = &l;
    }
    return best;
}

const MDSLyricLine* CMDSPlayerModel::FindNextLyricLine(double absoluteBeat) const {
    for (const MDSLyricLine& l : m_lyricLines)
        if (l.startBeat > absoluteBeat + 1e-9) return &l;
    return nullptr;
}

std::size_t CMDSPlayerModel::FindScheduledNoteIndex(double absoluteBeat) const {
    auto it = std::lower_bound(m_notes.begin(), m_notes.end(), absoluteBeat,
        [](const MDSScheduledNote& n, double v) { return n.startBeat < v; });
    return static_cast<std::size_t>(it - m_notes.begin());
}

std::size_t CMDSPlayerModel::SegmentTrackNoteCount(std::size_t segmentIndex, int trackIndex) const {
    const MDSPlaybackTrack* t = FindTrack(trackIndex);
    if (!t || segmentIndex >= t->segmentNoteCounts.size()) return 0;
    return t->segmentNoteCounts[segmentIndex];
}

std::vector<int> CMDSPlayerModel::ActiveTrackIndexes(std::size_t segmentIndex) const {
    std::vector<int> out;
    if (segmentIndex >= m_segments.size()) return out;
    for (const MDSPlaybackTrack& t : m_tracks) {
        if (SegmentTrackNoteCount(segmentIndex, t.index) == 0) continue;
        if (t.index == 0 && !SegmentUsesMainMelodyAt(segmentIndex)) continue;
        out.push_back(t.index);
    }
    auto category = [&](int idx) {
        if (idx == 0) return 0;
        const MDSPlaybackTrack* t = FindTrack(idx);
        if (!t) return 3;
        if (t->type == 1) return 1; // 铺底轨
        if (t->type == 2) return 2; // 加花轨
        return 3;
    };
    std::sort(out.begin(), out.end(), [&](int a, int b) {
        const int ca = category(a), cb = category(b);
        if (ca != cb) return ca < cb;
        return a < b;
    });
    return out;
}

bool CMDSPlayerModel::SegmentUsesMainMelodyAt(std::size_t segmentIndex) const {
    if (segmentIndex >= m_segments.size()) return false;
    // V2.3.20m: actual tk0/beat.notes are authoritative for every score class.
    // A multi-track song may contain real lead notes in type0 intro/type4
    // interlude (Red Sun intro has 29 notes and the C2 really performs them).
    // Do not hide those notes merely because the section type is intro/interlude.
    return SegmentTrackNoteCount(segmentIndex, 0) > 0;
}

double CMDSPlayerModel::SnapToChordSection(double absoluteBeat) const {
    if (m_totalBeats <= 0.0) return 0.0;
    absoluteBeat = std::max<double>(0.0, std::min<double>(m_totalBeats, absoluteBeat));
    if (m_chordSections.empty()) {
        // Performance fallback for unusual chord-less scores: whole beat.
        return std::max<double>(0.0, std::min<double>(m_totalBeats, std::floor(absoluteBeat + 1e-9)));
    }

    // Preserve a real intro before the first chord. Some base/multilevel JSONs
    // have lead notes from beat 0 while the first chord trigger is at beat 4.
    // Treat 0..firstChord as a virtual intro performance section so selecting
    // the prelude never jumps the cursor forward to the first chord.
    if (absoluteBeat < m_chordSections.front().startBeat - 1e-9) return 0.0;

    auto it = std::upper_bound(m_chordSections.begin(), m_chordSections.end(), absoluteBeat + 1e-9,
        [](double v, const MDSChordSection& s) { return v < s.startBeat; });
    if (it == m_chordSections.begin()) return 0.0;
    --it;
    return it->startBeat;
}

double CMDSPlayerModel::ChordSectionEnd(double absoluteBeat) const {
    if (m_totalBeats <= 0.0) return 0.0;
    absoluteBeat = std::max<double>(0.0, std::min<double>(m_totalBeats, absoluteBeat));
    if (m_chordSections.empty())
        return std::min<double>(m_totalBeats, std::floor(absoluteBeat + 1e-9) + 1.0);

    if (absoluteBeat < m_chordSections.front().startBeat - 1e-9)
        return m_chordSections.front().startBeat;

    auto it = std::upper_bound(m_chordSections.begin(), m_chordSections.end(), absoluteBeat + 1e-9,
        [](double v, const MDSChordSection& s) { return v < s.startBeat; });
    if (it == m_chordSections.begin()) return m_chordSections.front().startBeat;
    --it;

    double endBeat = it->endBeat;
    const auto next = it + 1;
    if (next != m_chordSections.end()) {
        // The physical next trigger is tied to the next chord section.  If a
        // legacy chord.length leaves a gap, let the visual playhead travel to
        // that next trigger boundary instead of freezing early in empty space.
        if (endBeat < next->startBeat) endBeat = next->startBeat;
        if (endBeat > next->startBeat) endBeat = next->startBeat;
    }
    return std::max<double>(it->startBeat, std::min<double>(m_totalBeats, endBeat));
}

