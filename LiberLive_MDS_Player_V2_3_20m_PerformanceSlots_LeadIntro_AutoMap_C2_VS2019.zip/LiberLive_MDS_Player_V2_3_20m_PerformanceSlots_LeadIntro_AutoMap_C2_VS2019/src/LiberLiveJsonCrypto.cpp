#include "LiberLiveJsonCrypto.h"
#include <array>
#include <cctype>
#include <cstdint>
#include <vector>

namespace {

int B64Value(unsigned char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

bool Base64Decode(const std::string& text, std::vector<std::uint8_t>& out) {
    out.clear();
    int val = 0;
    int bits = -8;
    for (unsigned char c : text) {
        if (std::isspace(c)) continue;
        if (c == '=') break;
        const int d = B64Value(c);
        if (d < 0) return false;
        val = (val << 6) | d;
        bits += 6;
        if (bits >= 0) {
            out.push_back(static_cast<std::uint8_t>((val >> bits) & 0xFF));
            bits -= 8;
        }
    }
    return !out.empty();
}

std::uint8_t GfMul(std::uint8_t a, std::uint8_t b) {
    std::uint8_t p = 0;
    for (int i = 0; i < 8; ++i) {
        if (b & 1) p ^= a;
        const bool high = (a & 0x80) != 0;
        a = static_cast<std::uint8_t>(a << 1);
        if (high) a ^= 0x1B;
        b = static_cast<std::uint8_t>(b >> 1);
    }
    return p;
}

std::uint8_t GfPow(std::uint8_t a, unsigned power) {
    std::uint8_t result = 1;
    while (power) {
        if (power & 1U) result = GfMul(result, a);
        a = GfMul(a, a);
        power >>= 1U;
    }
    return result;
}

std::uint8_t RotL8(std::uint8_t x, unsigned n) {
    return static_cast<std::uint8_t>((static_cast<unsigned>(x) << n) |
                                     (static_cast<unsigned>(x) >> (8U - n)));
}

struct AesTables {
    std::array<std::uint8_t, 256> sbox{};
    std::array<std::uint8_t, 256> invSbox{};

    AesTables() {
        for (unsigned i = 0; i < 256; ++i) {
            const std::uint8_t x = static_cast<std::uint8_t>(i);
            const std::uint8_t inv = x == 0 ? 0 : GfPow(x, 254);
            const std::uint8_t s = static_cast<std::uint8_t>(
                inv ^ RotL8(inv, 1) ^ RotL8(inv, 2) ^ RotL8(inv, 3) ^ RotL8(inv, 4) ^ 0x63);
            sbox[i] = s;
            invSbox[s] = x;
        }
    }
};

const AesTables& Tables() {
    static const AesTables t;
    return t;
}

void ExpandKey128(const std::uint8_t key[16], std::array<std::uint8_t, 176>& roundKey) {
    const auto& sbox = Tables().sbox;
    for (int i = 0; i < 16; ++i) roundKey[static_cast<std::size_t>(i)] = key[i];

    int generated = 16;
    std::uint8_t rcon = 1;
    std::uint8_t temp[4]{};
    while (generated < 176) {
        for (int i = 0; i < 4; ++i) temp[i] = roundKey[static_cast<std::size_t>(generated - 4 + i)];
        if ((generated % 16) == 0) {
            const std::uint8_t first = temp[0];
            temp[0] = temp[1];
            temp[1] = temp[2];
            temp[2] = temp[3];
            temp[3] = first;
            for (auto& b : temp) b = sbox[b];
            temp[0] ^= rcon;
            rcon = GfMul(rcon, 2);
        }
        for (int i = 0; i < 4; ++i) {
            roundKey[static_cast<std::size_t>(generated)] =
                static_cast<std::uint8_t>(roundKey[static_cast<std::size_t>(generated - 16)] ^ temp[i]);
            ++generated;
        }
    }
}

void AddRoundKey(std::uint8_t state[16], const std::array<std::uint8_t, 176>& roundKey, int round) {
    const std::size_t base = static_cast<std::size_t>(round) * 16U;
    for (int i = 0; i < 16; ++i) state[i] ^= roundKey[base + static_cast<std::size_t>(i)];
}

void InvShiftRows(std::uint8_t s[16]) {
    // row 1: right by 1
    std::uint8_t t = s[13];
    s[13] = s[9];
    s[9] = s[5];
    s[5] = s[1];
    s[1] = t;

    // row 2: right by 2
    t = s[2]; s[2] = s[10]; s[10] = t;
    t = s[6]; s[6] = s[14]; s[14] = t;

    // row 3: right by 3 (left by 1)
    t = s[3];
    s[3] = s[7];
    s[7] = s[11];
    s[11] = s[15];
    s[15] = t;
}

void InvSubBytes(std::uint8_t s[16]) {
    const auto& inv = Tables().invSbox;
    for (int i = 0; i < 16; ++i) s[i] = inv[s[i]];
}

void InvMixColumns(std::uint8_t s[16]) {
    for (int c = 0; c < 4; ++c) {
        const int i = c * 4;
        const std::uint8_t a0 = s[i + 0];
        const std::uint8_t a1 = s[i + 1];
        const std::uint8_t a2 = s[i + 2];
        const std::uint8_t a3 = s[i + 3];
        s[i + 0] = static_cast<std::uint8_t>(GfMul(a0,14) ^ GfMul(a1,11) ^ GfMul(a2,13) ^ GfMul(a3, 9));
        s[i + 1] = static_cast<std::uint8_t>(GfMul(a0, 9) ^ GfMul(a1,14) ^ GfMul(a2,11) ^ GfMul(a3,13));
        s[i + 2] = static_cast<std::uint8_t>(GfMul(a0,13) ^ GfMul(a1, 9) ^ GfMul(a2,14) ^ GfMul(a3,11));
        s[i + 3] = static_cast<std::uint8_t>(GfMul(a0,11) ^ GfMul(a1,13) ^ GfMul(a2, 9) ^ GfMul(a3,14));
    }
}

void Aes128DecryptBlock(const std::uint8_t in[16], std::uint8_t out[16],
                        const std::array<std::uint8_t, 176>& roundKey) {
    std::uint8_t state[16];
    for (int i = 0; i < 16; ++i) state[i] = in[i];

    AddRoundKey(state, roundKey, 10);
    for (int round = 9; round >= 1; --round) {
        InvShiftRows(state);
        InvSubBytes(state);
        AddRoundKey(state, roundKey, round);
        InvMixColumns(state);
    }
    InvShiftRows(state);
    InvSubBytes(state);
    AddRoundKey(state, roundKey, 0);

    for (int i = 0; i < 16; ++i) out[i] = state[i];
}

bool Aes128CbcDecryptPkcs7(const std::vector<std::uint8_t>& cipher,
                           const std::uint8_t key[16], const std::uint8_t iv[16],
                           std::string& plain, std::string& error) {
    plain.clear();
    if (cipher.empty() || (cipher.size() % 16U) != 0U) {
        error = "ciphertext length is not a non-zero multiple of AES block size";
        return false;
    }

    std::array<std::uint8_t, 176> roundKey{};
    ExpandKey128(key, roundKey);
    std::vector<std::uint8_t> out(cipher.size());
    std::uint8_t prev[16];
    for (int i = 0; i < 16; ++i) prev[i] = iv[i];

    for (std::size_t off = 0; off < cipher.size(); off += 16) {
        std::uint8_t block[16];
        Aes128DecryptBlock(cipher.data() + off, block, roundKey);
        for (int i = 0; i < 16; ++i) out[off + static_cast<std::size_t>(i)] = static_cast<std::uint8_t>(block[i] ^ prev[i]);
        for (int i = 0; i < 16; ++i) prev[i] = cipher[off + static_cast<std::size_t>(i)];
    }

    const std::uint8_t pad = out.back();
    if (pad == 0 || pad > 16 || static_cast<std::size_t>(pad) > out.size()) {
        error = "invalid PKCS7 padding";
        return false;
    }
    for (std::size_t i = out.size() - pad; i < out.size(); ++i) {
        if (out[i] != pad) {
            error = "invalid PKCS7 padding bytes";
            return false;
        }
    }
    out.resize(out.size() - pad);
    plain.assign(reinterpret_cast<const char*>(out.data()), out.size());
    return true;
}

} // namespace

bool DecryptLiberLiveApiData(const std::string& encoded, std::string& plainUtf8, std::string& error) {
    plainUtf8.clear();
    error.clear();
    if (encoded.size() < 4 || encoded.compare(0, 3, "@_@") != 0) {
        error = "data does not use the @_@ encrypted envelope";
        return false;
    }

    std::vector<std::uint8_t> cipher;
    if (!Base64Decode(encoded.substr(3), cipher)) {
        error = "invalid encrypted data base64";
        return false;
    }

    static const std::uint8_t kKey[16] = {
        'A','A','A','A','A','0','A','2','2','9','4','D','B','6','0','5'
    };
    static const std::uint8_t kIv[16] = {
        'A','A','A','A','A','A','E','9','7','B','C','9','3','6','2','9'
    };
    return Aes128CbcDecryptPkcs7(cipher, kKey, kIv, plainUtf8, error);
}
