﻿#include "MDSParser.h"
#include "JsonLite.h"
#include "LiberLiveJsonCrypto.h"
#include <algorithm>
#include <cmath>
#include <cctype>
#include <deque>
#include <fstream>
#include <iomanip>
#include <sstream>

using jsonlite::Value;

namespace {

const Value* Find(const Value& o, const char* key) {
    return o.IsObject() ? o.Find(key) : nullptr;
}

std::string GetString(const Value& o, const char* key, const std::string& def = {}) {
    const Value* v = Find(o, key);
    if (!v || v->IsNull()) return def;
    if (v->IsString()) return v->stringValue;
    if (v->IsNumber()) {
        if (!v->numberToken.empty()) return v->numberToken;
        std::ostringstream oss;
        const double n = v->numberValue;
        if (std::floor(n) == n) oss << std::fixed << std::setprecision(0) << n;
        else oss << std::setprecision(15) << n;
        return oss.str();
    }
    if (v->IsBool()) return v->boolValue ? "true" : "false";
    return def;
}

int GetInt(const Value& o, const char* key, int def = 0) {
    const Value* v = Find(o, key);
    if (!v || v->IsNull()) return def;
    if (v->IsNumber()) {
        if (!v->numberToken.empty()) { try { return std::stoi(v->numberToken); } catch (...) {} }
        return static_cast<int>(v->numberValue);
    }
    if (v->IsString()) {
        try { return std::stoi(v->stringValue); } catch (...) { return def; }
    }
    if (v->IsBool()) return v->boolValue ? 1 : 0;
    return def;
}

std::int64_t GetInt64(const Value& o, const char* key, std::int64_t def = 0) {
    const Value* v = Find(o, key);
    if (!v || v->IsNull()) return def;
    if (v->IsNumber()) {
        if (!v->numberToken.empty()) { try { return std::stoll(v->numberToken); } catch (...) {} }
        return static_cast<std::int64_t>(v->numberValue);
    }
    if (v->IsString()) {
        try { return std::stoll(v->stringValue); } catch (...) { return def; }
    }
    return def;
}

double GetDouble(const Value& o, const char* key, double def = 0.0) {
    const Value* v = Find(o, key);
    if (!v || v->IsNull()) return def;
    if (v->IsNumber()) return v->numberValue;
    if (v->IsString()) {
        try { return std::stod(v->stringValue); } catch (...) { return def; }
    }
    if (v->IsBool()) return v->boolValue ? 1.0 : 0.0;
    return def;
}

bool GetBool(const Value& o, const char* key, bool def = false) {
    const Value* v = Find(o, key);
    if (!v || v->IsNull()) return def;
    if (v->IsBool()) return v->boolValue;
    if (v->IsNumber()) return v->numberValue != 0.0;
    if (v->IsString()) {
        std::string s = v->stringValue;
        std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return s == "true" || s == "1" || s == "yes";
    }
    return def;
}

std::string EscapeJsonString(const std::string& s) {
    std::ostringstream os;
    os << '"';
    for (unsigned char c : s) {
        switch (c) {
        case '"': os << "\\\""; break;
        case '\\': os << "\\\\"; break;
        case '\b': os << "\\b"; break;
        case '\f': os << "\\f"; break;
        case '\n': os << "\\n"; break;
        case '\r': os << "\\r"; break;
        case '\t': os << "\\t"; break;
        default:
            if (c < 0x20) {
                os << "\\u" << std::hex << std::uppercase << std::setw(4) << std::setfill('0') << static_cast<int>(c)
                   << std::dec << std::nouppercase << std::setfill(' ');
            } else os << static_cast<char>(c);
            break;
        }
    }
    os << '"';
    return os.str();
}

std::string CompactJson(const Value& v) {
    switch (v.type) {
    case jsonlite::Type::Null: return "null";
    case jsonlite::Type::Bool: return v.boolValue ? "true" : "false";
    case jsonlite::Type::Number: {
        std::ostringstream os;
        if (std::floor(v.numberValue) == v.numberValue)
            os << std::fixed << std::setprecision(0) << v.numberValue;
        else os << std::setprecision(15) << v.numberValue;
        return os.str();
    }
    case jsonlite::Type::String: return EscapeJsonString(v.stringValue);
    case jsonlite::Type::Array: {
        std::string out = "[";
        for (std::size_t i = 0; i < v.arrayValue.size(); ++i) {
            if (i) out += ',';
            out += CompactJson(v.arrayValue[i]);
        }
        out += ']';
        return out;
    }
    case jsonlite::Type::Object: {
        std::string out = "{";
        bool first = true;
        for (const auto& kv : v.objectValue) {
            if (!first) out += ',';
            first = false;
            out += EscapeJsonString(kv.first);
            out += ':';
            out += CompactJson(kv.second);
        }
        out += '}';
        return out;
    }
    }
    return "null";
}

bool LooksLikeJsonText(const std::string& raw) {
    const auto p = raw.find_first_not_of(" \t\r\n");
    return p != std::string::npos && (raw[p] == '{' || raw[p] == '[');
}

bool LooksLikeContentObject(const Value& v) {
    if (!v.IsObject()) return false;
    const Value* lyrics = Find(v, "lyrics");
    if (lyrics && (lyrics->IsArray() || (lyrics->IsString() && LooksLikeJsonText(lyrics->stringValue)))) return true;
    // Some partially exported rows may have no lyrics but still carry unmistakable sheet fields.
    return Find(v, "trackConfigs") && (Find(v, "beat") || Find(v, "tempo") || Find(v, "baseConfig"));
}

struct ResolvedJson {
    const Value* songObject = nullptr;
    const Value* content = nullptr;
    const std::string* sourceText = nullptr;
    std::string contentPath;
    std::string format;
    bool sourceOffsetsExact = true;
};

bool ResolveNode(const Value& node,
                 const Value* envelope,
                 const std::string& path,
                 const std::string* sourceText,
                 bool sourceExact,
                 int depth,
                 std::deque<Value>& parsedPool,
                 ResolvedJson& out);

bool ResolveContentValue(const Value& value,
                         const Value& envelope,
                         const std::string& path,
                         const std::string* sourceText,
                         bool sourceExact,
                         int depth,
                         std::deque<Value>& parsedPool,
                         ResolvedJson& out) {
    if (depth > 8) return false;
    if (value.IsObject()) {
        if (LooksLikeContentObject(value)) {
            out.songObject = &envelope;
            out.content = &value;
            out.sourceText = sourceText;
            out.contentPath = path;
            out.format = path == "$.content" ? "root.content" : "wrapped content object";
            out.sourceOffsetsExact = sourceExact;
            return true;
        }
        return ResolveNode(value, &envelope, path, sourceText, sourceExact, depth + 1, parsedPool, out);
    }
    if (value.IsString() && LooksLikeJsonText(value.stringValue)) {
        parsedPool.emplace_back();
        std::string parseError;
        if (!jsonlite::Parse(value.stringValue, parsedPool.back(), parseError)) {
            parsedPool.pop_back();
            return false;
        }
        const Value& decoded = parsedPool.back();
        if (decoded.IsObject() && LooksLikeContentObject(decoded)) {
            out.songObject = &envelope;
            out.content = &decoded;
            out.sourceText = &value.stringValue;
            out.contentPath = path + " (JSON string)";
            out.format = "stringified content";
            out.sourceOffsetsExact = false;
            return true;
        }
        return ResolveNode(decoded, &envelope, path + " (JSON string)", &value.stringValue, false, depth + 1, parsedPool, out);
    }
    return false;
}

bool ResolveNode(const Value& node,
                 const Value* envelope,
                 const std::string& path,
                 const std::string* sourceText,
                 bool sourceExact,
                 int depth,
                 std::deque<Value>& parsedPool,
                 ResolvedJson& out) {
    if (depth > 8) return false;

    if (node.IsString()) {
        if (!LooksLikeJsonText(node.stringValue)) return false;
        parsedPool.emplace_back();
        std::string parseError;
        if (!jsonlite::Parse(node.stringValue, parsedPool.back(), parseError)) {
            parsedPool.pop_back();
            return false;
        }
        return ResolveNode(parsedPool.back(), envelope, path + " (JSON string)", &node.stringValue, false, depth + 1, parsedPool, out);
    }

    if (node.IsArray()) {
        for (std::size_t i = 0; i < node.arrayValue.size(); ++i) {
            if (ResolveNode(node.arrayValue[i], nullptr, path + "[" + std::to_string(i) + "]", sourceText,
                            sourceExact, depth + 1, parsedPool, out)) {
                if (out.format.empty()) out.format = "array wrapper";
                return true;
            }
        }
        return false;
    }

    if (!node.IsObject()) return false;

    if (LooksLikeContentObject(node)) {
        out.songObject = envelope ? envelope : &node;
        out.content = &node;
        out.sourceText = sourceText;
        out.contentPath = path;
        out.format = (path == "$" ? "direct song/content object" : "wrapped direct song/content object");
        out.sourceOffsetsExact = sourceExact;
        return true;
    }

    if (const Value* content = Find(node, "content")) {
        if (ResolveContentValue(*content, node, path + ".content", sourceText, sourceExact, depth + 1, parsedPool, out))
            return true;
    }

    // Common API/database/export wrapper names. We deliberately do not recursively scan every
    // arbitrary object key because a beat/chord child could otherwise be mistaken for a song.
    static const char* kWrappers[] = {
        "data", "result", "body", "payload", "response", "detail", "song", "music",
        "item", "record", "records", "rows", "list", "items"
    };
    for (const char* key : kWrappers) {
        if (const Value* child = Find(node, key)) {
            if (ResolveNode(*child, nullptr, path + "." + key, sourceText, sourceExact, depth + 1, parsedPool, out)) {
                if (out.format == "direct song/content object") out.format = "wrapped direct song/content object";
                return true;
            }
        }
    }
    return false;
}

const Value* DecodeArrayIfNeeded(const Value* v, std::deque<Value>& parsedPool) {
    if (!v) return nullptr;
    if (v->IsArray()) return v;
    if (v->IsString() && LooksLikeJsonText(v->stringValue)) {
        parsedPool.emplace_back();
        std::string error;
        if (jsonlite::Parse(v->stringValue, parsedPool.back(), error) && parsedPool.back().IsArray()) return &parsedPool.back();
        parsedPool.pop_back();
    }
    return nullptr;
}

void ParseAssetNotes(const Value& parent, std::vector<MDSAssetNote>& dst) {
    const Value* ans = Find(parent, "assetNotes");
    if (!ans) return;
    auto parseOne = [&](const Value& an) {
        if (!an.IsObject()) return;
        MDSAssetNote a;
        a.noteCode = GetString(an, "noteCode");
        a.timbreCardCode = GetString(an, "timbreCardCode");
        dst.push_back(std::move(a));
    };
    if (ans->IsArray()) for (const Value& an : ans->arrayValue) parseOne(an);
    else if (ans->IsObject()) parseOne(*ans);
}

void ParseNote(const Value& n, MDSNote& out) {
    out.length = GetDouble(n, "length");
    out.note = GetInt(n, "note");
    out.start = GetDouble(n, "start");
    out.stretch = GetBool(n, "stretch");
    out.upOctave = GetInt(n, "upOctave");
    out.velocity = GetInt(n, "velocity");
}

void ParseExtension(const Value& e, MDSExtension& out) {
    out.type = GetString(e, "type");
    out.start = GetDouble(e, "start");
    out.direction = GetInt(e, "direction");
    out.pick = GetInt(e, "pick");
    out.position = GetInt(e, "position");
    out.switchType = GetInt(e, "switchType");
    out.originKey = GetInt(e, "originKey");
    out.toneType = GetInt(e, "toneType");
    out.pickAction = GetInt(e, "pickAction");
    out.pickType = GetInt(e, "pickType");
    out.level = GetInt(e, "level");
    out.model = GetString(e, "model");
    out.cardCode = GetString(e, "cardCode");
    out.code = GetString(e, "code");
    out.length = GetDouble(e, "length");
    out.group = GetString(e, "group");
    out.volume = GetInt(e, "volume");
    out.mute = GetInt(e, "mute");
    ParseAssetNotes(e, out.assetNotes);
    if (const Value* a = Find(e, "drumCodes"); a && a->IsArray()) {
        for (const Value& x : a->arrayValue) if (x.IsString()) out.drumCodes.push_back(x.stringValue);
    }
}

void ParseConfigEntry(const Value& e, MDSConfigEntry& out) {
    out.bpmRate = GetDouble(e, "bpmRate");
    out.cardCode = GetString(e, "cardCode");
    out.cardName = GetString(e, "cardName");
    out.dataType = GetString(e, "dataType");
    out.nameCode = GetString(e, "nameCode");
    out.version = GetString(e, "version");
    out.pickAction = GetInt(e, "pickAction");
    out.pickType = GetInt(e, "pickType");
    if (const Value* pv = Find(e, "pickVolume"); pv && !pv->IsNull()) {
        out.pickVolume = GetInt(e, "pickVolume");
        out.hasPickVolume = true;
    }
    out.star = GetInt(e, "star");
    out.bassVolume = GetInt(e, "bassVolume");
}

void ParseConfigPackValue(const Value& root, MDSConfigPack& out) {
    out = MDSConfigPack{};
    if (!root.IsObject()) return;
    auto parseList = [&](const char* key, std::vector<MDSConfigEntry>& dst) {
        const Value* a = Find(root, key);
        if (!a || !a->IsArray()) return;
        for (const Value& x : a->arrayValue) {
            if (!x.IsObject()) continue;
            MDSConfigEntry e;
            ParseConfigEntry(x, e);
            dst.push_back(std::move(e));
        }
    };
    parseList("chords", out.chords);
    parseList("drums", out.drums);
    parseList("instrument", out.instrument);
    out.parsed = true;
}

void ParseConfigPack(const Value* cp, MDSBaseConfig& base) {
    base.configPack = MDSConfigPack{};
    if (!cp || cp->IsNull()) return;
    if (cp->IsString()) {
        base.configPackRaw = cp->stringValue;
        if (cp->stringValue.empty()) return;
        Value root;
        std::string error;
        if (!jsonlite::Parse(cp->stringValue, root, error) || !root.IsObject()) return;
        ParseConfigPackValue(root, base.configPack);
        return;
    }
    if (cp->IsObject()) {
        // Some export tools materialize the nested configPack string as an object.
        // Re-serialize compactly so the existing C2 encoder can still use it.
        base.configPackRaw = CompactJson(*cp);
        ParseConfigPackValue(*cp, base.configPack);
    }
}

void ParseTrackConfig(const Value& tc, MDSTrackConfig& out) {
    out.index = GetInt(tc, "index");
    out.mute = GetInt(tc, "mute");
    out.name = GetString(tc, "name");
    out.noteCode = GetString(tc, "noteCode");
    out.type = GetInt(tc, "type");
    out.volume = GetInt(tc, "volume", 100);
    ParseAssetNotes(tc, out.assetNotes);
}

} // namespace

bool CMDSParser::LoadFile(const std::filesystem::path& fileName, MDSSong& song, std::string& error) const {
    song = MDSSong{};
    error.clear();

    std::ifstream in(fileName, std::ios::binary);
    if (!in) { error = "cannot open input file"; return false; }
    std::string text((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    std::size_t bomBytes = 0;
    if (text.size() >= 3 && static_cast<unsigned char>(text[0]) == 0xEF && static_cast<unsigned char>(text[1]) == 0xBB && static_cast<unsigned char>(text[2]) == 0xBF) {
        text.erase(0, 3);
        bomBytes = 3;
    }

    Value root;
    if (!jsonlite::Parse(text, root, error)) return false;

    std::deque<Value> parsedPool;
    ResolvedJson resolved;

    // song/detail raw HTTP responses can be an encrypted outer object:
    // {success, code, encrypt:1, data:"@_@..."}.  Decrypt it in the Windows
    // build so the player can open either the raw response or the already
    // extracted detail JSON directly.
    std::string decryptedText;
    Value decryptedRoot;
    bool usedEncryptedEnvelope = false;
    std::string decryptError;
    if (root.IsObject() && GetBool(root, "encrypt")) {
        const Value* data = Find(root, "data");
        if (data && data->IsString() && data->stringValue.rfind("@_@", 0) == 0) {
            if (DecryptLiberLiveApiData(data->stringValue, decryptedText, decryptError)) {
                std::string innerError;
                if (!jsonlite::Parse(decryptedText, decryptedRoot, innerError)) {
                    error = "decrypted API data is not valid JSON: " + innerError;
                    return false;
                }
                usedEncryptedEnvelope = true;
            }
        }
    }

    const Value& resolveRoot = usedEncryptedEnvelope ? decryptedRoot : root;
    const std::string* resolveText = usedEncryptedEnvelope ? &decryptedText : &text;
    const bool resolveOffsetsExact = !usedEncryptedEnvelope;
    const std::string resolvePath = usedEncryptedEnvelope ? "$.data (AES decrypted)" : "$";

    if (!ResolveNode(resolveRoot, nullptr, resolvePath, resolveText, resolveOffsetsExact, 0, parsedPool, resolved) || !resolved.content || !resolved.songObject) {
        if (root.IsObject() && GetBool(root, "encrypt") && Find(root, "data") && Find(root, "data")->IsString()) {
            error = decryptError.empty()
                ? "encrypted API response could not be resolved after decryption"
                : "encrypted API response: " + decryptError;
        } else {
            error = "unsupported LiberLive JSON layout: cannot locate a song object containing lyrics (supported: root.content, direct song JSON, common data/result/body wrappers, JSON-string content)";
        }
        return false;
    }
    if (usedEncryptedEnvelope) resolved.format = "encrypted API response -> " + resolved.format;

    const Value& meta = *resolved.songObject;
    const Value& content = *resolved.content;

    song.sourceFormat = resolved.format;
    song.sourceContentPath = resolved.contentPath;
    song.sourceOffsetsExact = resolved.sourceOffsetsExact;

    song.id = GetInt64(meta, "id", GetInt64(content, "id"));
    song.songId = GetString(meta, "songId", GetString(content, "songId"));
    if (song.songId.empty()) song.songId = GetString(meta, "id", GetString(content, "id"));
    song.songType = GetInt(meta, "songType", GetInt(content, "songType"));
    song.title = GetString(meta, "title", GetString(content, "title"));
    song.author = GetString(meta, "author", GetString(content, "author"));
    song.createAuthor = GetString(meta, "createAuthor", GetString(content, "createAuthor"));
    song.avatar = GetString(meta, "avatar", GetString(content, "avatar"));
    song.cover = GetString(meta, "cover", GetString(content, "cover"));
    song.createTime = GetInt64(meta, "createTime", GetInt64(content, "createTime"));
    song.updateTime = GetString(meta, "updateTime", GetString(content, "updateTime"));

    song.content.beat = GetString(content, "beat");
    song.content.tempo = GetInt(content, "tempo", GetInt(content, "bpm"));
    song.content.originalTone = GetString(content, "originalTone", GetString(content, "tone"));
    song.content.originalSinger = GetString(content, "originalSinger", song.author);
    song.content.composer = GetString(content, "composer");
    song.content.lyricist = GetString(content, "lyricist");
    song.content.productModel = GetString(content, "productModel", GetString(meta, "productModel"));
    song.content.musicalInstrumentId = GetInt(content, "musicalInstrumentId");
    song.content.isMultiTrack = GetBool(content, "isMultiTrack");
    song.content.isVideo = GetBool(content, "isVideo");
    song.content.leadNote = GetInt(content, "leadNote");
    song.content.singleVoice = GetString(content, "singleVoice");
    song.content.melodicNote = GetString(content, "melodicNote");

    if (const Value* bc = Find(content, "baseConfig"); bc && bc->IsObject()) {
        song.content.baseConfig.beat = GetString(*bc, "beat");
        song.content.baseConfig.bpm = GetInt(*bc, "bpm", GetInt(*bc, "tempo"));
        song.content.baseConfig.configType = GetString(*bc, "configType");
        song.content.baseConfig.defaultLevel = GetInt(*bc, "defaultLevel");
        song.content.baseConfig.model = GetString(*bc, "model");
        song.content.baseConfig.tone = GetString(*bc, "tone");
        ParseConfigPack(Find(*bc, "configPack"), song.content.baseConfig);
    }
    if (song.content.beat.empty()) song.content.beat = song.content.baseConfig.beat;
    if (song.content.tempo <= 0) song.content.tempo = song.content.baseConfig.bpm;
    if (song.content.productModel.empty()) song.content.productModel = song.content.baseConfig.model;
    if (song.content.originalTone.empty()) song.content.originalTone = song.content.baseConfig.tone;

    if (const Value* tcs = DecodeArrayIfNeeded(Find(content, "trackConfigs"), parsedPool)) {
        for (const Value& tc : tcs->arrayValue) {
            if (!tc.IsObject()) continue;
            MDSTrackConfig outTc;
            ParseTrackConfig(tc, outTc);
            song.content.trackConfigs.push_back(std::move(outTc));
        }
    } else if (const Value* tcsObj = Find(content, "trackConfigs"); tcsObj && tcsObj->IsObject()) {
        // Tolerate export tools that converted an indexed array into an object/map.
        for (const auto& kv : tcsObj->objectValue) {
            if (!kv.second.IsObject()) continue;
            MDSTrackConfig outTc;
            ParseTrackConfig(kv.second, outTc);
            if (!Find(kv.second, "index")) {
                try { outTc.index = std::stoi(kv.first); } catch (...) {}
            }
            song.content.trackConfigs.push_back(std::move(outTc));
        }
    }

    const Value* lyrics = DecodeArrayIfNeeded(Find(content, "lyrics"), parsedPool);
    if (!lyrics) { error = "missing array: " + resolved.contentPath + ".lyrics"; return false; }

    const std::string* activeSourceText = resolved.sourceText ? resolved.sourceText : &text;
    std::vector<std::size_t> lineStarts;
    lineStarts.push_back(0);
    for (std::size_t i = 0; i < activeSourceText->size(); ++i)
        if ((*activeSourceText)[i] == '\n') lineStarts.push_back(i + 1);
    auto lineOfOffset = [&](std::size_t offset) -> std::size_t {
        const auto it = std::upper_bound(lineStarts.begin(), lineStarts.end(), offset);
        return static_cast<std::size_t>(it - lineStarts.begin());
    };
    const std::size_t sourceOffsetBase = resolved.sourceOffsetsExact ? bomBytes : 0;

    for (std::size_t lyricIndex = 0; lyricIndex < lyrics->arrayValue.size(); ++lyricIndex) {
        const Value& lt = lyrics->arrayValue[lyricIndex];
        if (!lt.IsObject()) continue;
        MDSLyricTrack track;
        track.type = GetInt(lt, "type");
        const Value* bars = Find(lt, "bars");
        if (bars && bars->IsArray()) {
            for (std::size_t barArrayIndex = 0; barArrayIndex < bars->arrayValue.size(); ++barArrayIndex) {
                const Value& bj = bars->arrayValue[barArrayIndex];
                if (!bj.IsObject()) continue;
                MDSBar bar;
                bar.bar = GetInt(bj, "bar", static_cast<int>(barArrayIndex));
                const Value* beats = Find(bj, "beats");
                if (beats && beats->IsArray()) {
                    for (std::size_t beatArrayIndex = 0; beatArrayIndex < beats->arrayValue.size(); ++beatArrayIndex) {
                        const Value& bt = beats->arrayValue[beatArrayIndex];
                        if (!bt.IsObject()) continue;
                        MDSBeat beat;
                        beat.beat = GetDouble(bt, "beat", static_cast<double>(beatArrayIndex));
                        beat.jsonSegmentIndex = lyricIndex;
                        beat.jsonBarArrayIndex = barArrayIndex;
                        beat.jsonBeatArrayIndex = beatArrayIndex;
                        beat.jsonSourceExact = resolved.sourceOffsetsExact;
                        beat.jsonByteStart = bt.sourceStart + sourceOffsetBase;
                        beat.jsonByteEnd = bt.sourceEnd + sourceOffsetBase;
                        beat.jsonLineStart = lineOfOffset(bt.sourceStart);
                        beat.jsonLineEnd = lineOfOffset(bt.sourceEnd > bt.sourceStart ? bt.sourceEnd - 1 : bt.sourceStart);
                        if (bt.sourceEnd > bt.sourceStart && bt.sourceEnd <= activeSourceText->size())
                            beat.jsonRaw = activeSourceText->substr(bt.sourceStart, bt.sourceEnd - bt.sourceStart);

                        if (const Value* ch = Find(bt, "chord"); ch && ch->IsObject()) {
                            beat.hasChord = true;
                            beat.chord.attachKey = GetString(*ch, "attachKey");
                            beat.chord.length = GetDouble(*ch, "length");
                            beat.chord.mainKey = GetString(*ch, "mainKey");
                            beat.chord.transKey = GetString(*ch, "transKey");
                        }
                        if (const Value* ns = Find(bt, "notes"); ns && ns->IsArray()) {
                            for (const Value& n : ns->arrayValue)
                                if (n.IsObject()) { MDSNote x; ParseNote(n, x); beat.notes.push_back(std::move(x)); }
                        }
                        if (const Value* es = Find(bt, "extensions"); es && es->IsArray()) {
                            for (const Value& e : es->arrayValue)
                                if (e.IsObject()) { MDSExtension x; ParseExtension(e, x); beat.extensions.push_back(std::move(x)); }
                        }
                        if (const Value* ets = Find(bt, "extraTracks"); ets && ets->IsArray()) {
                            for (const Value& e : ets->arrayValue) {
                                if (!e.IsObject()) continue;
                                MDSExtraTrack x;
                                x.index = GetInt(e, "index");
                                if (const Value* ens = Find(e, "notes"); ens && ens->IsArray())
                                    for (const Value& n : ens->arrayValue)
                                        if (n.IsObject()) { MDSNote nn; ParseNote(n, nn); x.notes.push_back(std::move(nn)); }
                                beat.extraTracks.push_back(std::move(x));
                            }
                        }
                        if (const Value* ws = Find(bt, "words"); ws && ws->IsArray()) {
                            for (const Value& w : ws->arrayValue) {
                                if (!w.IsObject()) continue;
                                MDSWord x;
                                x.length = GetDouble(w, "length");
                                x.newLine = GetBool(w, "newLine");
                                x.start = GetDouble(w, "start");
                                x.stretch = GetBool(w, "stretch");
                                x.word = GetString(w, "word");
                                beat.words.push_back(std::move(x));
                            }
                        }
                        bar.beats.push_back(std::move(beat));
                    }
                }
                track.bars.push_back(std::move(bar));
            }
        }
        song.content.lyrics.push_back(std::move(track));
    }

    if (song.title.empty()) song.title = "Untitled LiberLive JSON";
    return true;
}

MDSStats CMDSParser::CalculateStats(const MDSSong& song) {
    MDSStats s;
    s.songs = 1;
    s.trackConfigs = song.content.trackConfigs.size();
    s.tracks = song.content.lyrics.size();
    for (const auto& t : song.content.lyrics) {
        s.bars += t.bars.size();
        for (const auto& b : t.bars) {
            s.beats += b.beats.size();
            for (const auto& bt : b.beats) {
                if (bt.hasChord) ++s.chords;
                s.notes += bt.notes.size();
                s.extensions += bt.extensions.size();
                s.extraTracks += bt.extraTracks.size();
                for (const auto& et : bt.extraTracks) s.extraTrackNotes += et.notes.size();
                s.words += bt.words.size();
            }
        }
    }
    return s;
}
