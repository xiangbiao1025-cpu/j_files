#include "C2Protocol.h"
#include <chrono>
#include <iomanip>
#include <random>
#include <sstream>

namespace {
constexpr std::uint8_t kKey[12] = {0xB6,0x1E,0x2A,0xB7,0x69,0x0D,0xEA,0x06,0x7E,0x6D,0xEA,0xCC};
}

std::uint8_t C2Protocol::Crc8(const std::uint8_t* data, std::size_t len) {
    std::uint8_t crc = 0;
    for (std::size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (int bit = 0; bit < 8; ++bit)
            crc = (crc & 0x80) ? static_cast<std::uint8_t>((crc << 1) ^ 0x31) : static_cast<std::uint8_t>(crc << 1);
    }
    return crc;
}

std::uint16_t C2Protocol::Crc16(const std::uint8_t* data, std::size_t len) {
    std::uint16_t crc = 0;
    for (std::size_t i = 0; i < len; ++i) {
        crc ^= static_cast<std::uint16_t>(data[i]) << 8;
        for (int bit = 0; bit < 8; ++bit)
            crc = (crc & 0x8000) ? static_cast<std::uint16_t>((crc << 1) ^ 0x1021) : static_cast<std::uint16_t>(crc << 1);
    }
    return crc;
}

std::array<std::uint8_t, 12> C2Protocol::MakeIv() {
    std::array<std::uint8_t, 12> iv{};
    std::random_device rd;
    for (int i = 0; i < 8; ++i) iv[static_cast<std::size_t>(i)] = static_cast<std::uint8_t>(rd());
    const auto ms = static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
    const std::uint32_t low = static_cast<std::uint32_t>(ms & 0xFFFFFFFFu);
    iv[8] = static_cast<std::uint8_t>((low >> 24) & 0xFF);
    iv[9] = static_cast<std::uint8_t>((low >> 16) & 0xFF);
    iv[10] = static_cast<std::uint8_t>((low >> 8) & 0xFF);
    iv[11] = static_cast<std::uint8_t>(low & 0xFF);
    return iv;
}

std::vector<std::uint8_t> C2Protocol::EncodeIntCommand(std::uint8_t cmd,
    const std::vector<std::uint8_t>& data) {
    return EncodeIntCommandWithIv(cmd, data, MakeIv());
}

std::vector<std::uint8_t> C2Protocol::EncodeIntCommandWithIv(std::uint8_t cmd,
    const std::vector<std::uint8_t>& data,
    const std::array<std::uint8_t, 12>& iv) {
    const std::size_t cmdLen = 1;
    const std::size_t bodyLen = 1 + cmdLen + data.size();
    const std::uint16_t lengthField = static_cast<std::uint16_t>(
        ((cmdLen + 18 + data.size() + 2) & 0x0FFFu) | (12u << 12));

    std::vector<std::uint8_t> out(17 + bodyLen + 2, 0);
    out[0] = 0x24;
    out[1] = 0x4D;
    out[2] = static_cast<std::uint8_t>(lengthField & 0xFF);
    out[3] = static_cast<std::uint8_t>((lengthField >> 8) & 0xFF);
    for (std::size_t i = 0; i < iv.size(); ++i) out[4 + i] = iv[i];
    out[16] = Crc8(out.data(), 16);

    out[17] = 1;
    out[18] = cmd;
    for (std::size_t i = 0; i < data.size(); ++i) out[19 + i] = data[i];

    for (std::size_t i = 0; i < bodyLen; ++i) {
        const std::size_t pos = 17 + i;
        out[pos] ^= kKey[i % 12];
        out[pos] ^= iv[i % 12];
    }
    const std::uint16_t crc = Crc16(out.data() + 17, bodyLen);
    out[17 + bodyLen] = static_cast<std::uint8_t>(crc & 0xFF);
    out[18 + bodyLen] = static_cast<std::uint8_t>((crc >> 8) & 0xFF);
    return out;
}

std::vector<std::uint8_t> C2Protocol::EncodeStringCommand(const std::string& cmd,
    const std::vector<std::uint8_t>& data) {
    return EncodeStringCommandWithIv(cmd,data,MakeIv());
}

std::vector<std::uint8_t> C2Protocol::EncodeStringCommandWithIv(const std::string& cmd,
    const std::vector<std::uint8_t>& data,
    const std::array<std::uint8_t, 12>& iv) {
    if (cmd.empty() || cmd.size()>255) return {};
    const std::size_t cmdLen=cmd.size();
    const std::size_t bodyLen=1+cmdLen+data.size();
    const std::size_t packetLen=17+bodyLen+2;
    if (packetLen>0x0FFFu) return {};
    const std::uint16_t lengthField=static_cast<std::uint16_t>((packetLen & 0x0FFFu) | (12u<<12));

    std::vector<std::uint8_t> out(packetLen,0);
    out[0]=0x24; out[1]=0x4D;
    out[2]=static_cast<std::uint8_t>(lengthField & 0xFF);
    out[3]=static_cast<std::uint8_t>((lengthField>>8)&0xFF);
    for (std::size_t i=0;i<iv.size();++i) out[4+i]=iv[i];
    out[16]=Crc8(out.data(),16);

    out[17]=static_cast<std::uint8_t>(cmdLen);
    for (std::size_t i=0;i<cmdLen;++i) out[18+i]=static_cast<std::uint8_t>(cmd[i]);
    for (std::size_t i=0;i<data.size();++i) out[18+cmdLen+i]=data[i];
    for (std::size_t i=0;i<bodyLen;++i) {
        const std::size_t pos=17+i;
        out[pos]^=kKey[i%12];
        out[pos]^=iv[i%12];
    }
    const std::uint16_t crc=Crc16(out.data()+17,bodyLen);
    out[17+bodyLen]=static_cast<std::uint8_t>(crc&0xFF);
    out[18+bodyLen]=static_cast<std::uint8_t>((crc>>8)&0xFF);
    return out;
}

bool C2Protocol::DecodePacket(const std::vector<std::uint8_t>& packet,
    C2DecodedPacket& decoded, std::string& error) {
    decoded = C2DecodedPacket{};
    error.clear();
    if (packet.size() < 20 || packet[0] != 0x24 || (packet[1] != 0x4D && packet[1] != 0x41)) {
        error = "bad TLVC header/length";
        return false;
    }
    if (Crc8(packet.data(), 16) != packet[16]) {
        error = "CRC8 mismatch";
        return false;
    }

    const std::size_t bodyLen = packet.size() - 19;
    if (bodyLen < 2) {
        error = "TLVC body too short";
        return false;
    }
    const std::uint16_t got = static_cast<std::uint16_t>(packet[packet.size()-2]) |
        (static_cast<std::uint16_t>(packet[packet.size()-1]) << 8);
    if (Crc16(packet.data()+17, bodyLen) != got) {
        error = "CRC16 mismatch";
        return false;
    }

    std::array<std::uint8_t,12> iv{};
    for (std::size_t i=0;i<12;++i) iv[i]=packet[4+i];
    std::vector<std::uint8_t> plain(bodyLen);
    for (std::size_t i=0;i<bodyLen;++i)
        plain[i] = packet[17+i] ^ kKey[i%12] ^ iv[i%12];

    const std::size_t cmdLen = plain[0];
    if (cmdLen == 0 || plain.size() < 1 + cmdLen) {
        error = "invalid command length";
        return false;
    }

    decoded.fromDevice = (packet[1] == 0x41);
    if (cmdLen == 1) {
        decoded.intCommand = true;
        decoded.intCmd = plain[1];
    } else {
        decoded.intCommand = false;
        decoded.stringCmd.assign(reinterpret_cast<const char*>(plain.data()+1), cmdLen);
    }
    decoded.data.assign(plain.begin()+static_cast<std::ptrdiff_t>(1+cmdLen), plain.end());
    return true;
}

bool C2Protocol::DecodeIntCommand(const std::vector<std::uint8_t>& packet,
    std::uint8_t& cmd, std::vector<std::uint8_t>& data, std::string& error) {
    C2DecodedPacket d;
    if (!DecodePacket(packet,d,error)) { cmd=0; data.clear(); return false; }
    if (!d.intCommand) { error="not int command"; cmd=0; data.clear(); return false; }
    cmd=d.intCmd;
    data=d.data;
    return true;
}

std::string C2Protocol::Hex(const std::vector<std::uint8_t>& bytes) {
    std::ostringstream os;
    os << std::hex << std::setfill('0');
    for (std::size_t i=0;i<bytes.size();++i) {
        if (i) os << ' ';
        os << std::setw(2) << static_cast<unsigned>(bytes[i]);
    }
    return os.str();
}

bool C2Protocol::SelfTest(std::string& report) {
    const std::array<std::uint8_t,12> iv = {0xDC,0xF7,0xA2,0x26,0x60,0xA0,0x41,0x53,0x33,0xD9,0x63,0x62};
    const std::vector<std::uint8_t> expected = {
        0x24,0x4D,0x17,0xC0,0xDC,0xF7,0xA2,0x26,0x60,0xA0,0x41,0x53,0x33,0xD9,0x63,0x62,0xF5,0x6B,0xF9,0x89,0x90,0xB7,0x18};
    const auto packet = EncodeIntCommandWithIv(C2CmdId::SET_AUTO_PLAY, {0x01,0x01}, iv);
    if (packet != expected) {
        report = "TLVC fixed-vector mismatch\nactual=" + Hex(packet) + "\nexpected=" + Hex(expected);
        return false;
    }
    std::uint8_t cmd=0; std::vector<std::uint8_t> data; std::string err;
    if (!DecodeIntCommand(packet,cmd,data,err) || cmd!=C2CmdId::SET_AUTO_PLAY || data!=std::vector<std::uint8_t>({1,1})) {
        report="TLVC int round-trip failed: "+err;
        return false;
    }

    // Real captured App->C2 set_remind_chord packet, payload 00 00 00.
    // This independently validates UTF-8/string command packing.
    const std::array<std::uint8_t,12> remindIv={0xE7,0x5A,0x32,0xA2,0x5C,0x2E,0xE6,0xBA,0x26,0x08,0x3A,0x2D};
    const std::vector<std::uint8_t> remindExpected={
        0x24,0x4D,0x27,0xC0,0xE7,0x5A,0x32,0xA2,0x5C,0x2E,0xE6,0xBA,0x26,0x08,0x3A,0x2D,
        0x7B,0x41,0x37,0x7D,0x61,0x6A,0x51,0x69,0xD1,0x31,0x0B,0xB4,0xBE,0x32,0x2C,0x77,
        0x67,0x51,0x23,0x0C,0xBC,0x4B,0xD5};
    const auto remindPacket=EncodeStringCommandWithIv("set_remind_chord",{0,0,0},remindIv);
    if (remindPacket!=remindExpected) {
        report="TLVC string fixed-vector mismatch\nactual="+Hex(remindPacket)+"\nexpected="+Hex(remindExpected);
        return false;
    }
    C2DecodedPacket remindDecoded;
    if (!DecodePacket(remindPacket,remindDecoded,err) || remindDecoded.fromDevice || remindDecoded.intCommand ||
        remindDecoded.stringCmd!="set_remind_chord" || remindDecoded.data!=std::vector<std::uint8_t>({0,0,0})) {
        report="TLVC string round-trip failed: "+err;
        return false;
    }

    // Real A101 noti_chord capture:
    // cmd="noti_chord", payload=05 01 05 00 00 00 62 13 00 40
    // last 4 bytes are float32 LE ~= 2.0012 beat.
    const std::vector<std::uint8_t> capturedA101 = {
        0x24,0x41,0x28,0xC0,0x07,0x9A,0xD3,0x4C,0x77,0x6D,0x88,0x8C,0x97,0xDF,0x0D,0x00,
        0x18,0xBB,0xEA,0x96,0x8F,0x77,0x3F,0x01,0xE2,0x86,0xC0,0x83,0xC9,0xB0,0x81,0xF9,
        0xFB,0x1E,0x02,0x71,0x8A,0xA9,0x54,0x5F
    };
    C2DecodedPacket rx;
    if (!DecodePacket(capturedA101,rx,err) || !rx.fromDevice || rx.intCommand ||
        rx.stringCmd!="noti_chord" ||
        rx.data!=std::vector<std::uint8_t>({0x05,0x01,0x05,0x00,0x00,0x00,0x62,0x13,0x00,0x40})) {
        report="A101 noti_chord capture decode failed: "+err;
        return false;
    }

    report="TLVC int/string fixed vectors + real A101 noti_chord capture PASS";
    return true;
}
