﻿#include "C2Controller.h"
#include "C2Protocol.h"
#include <windows.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <deque>
#include <iomanip>
#include <sstream>
#include <thread>
#include <utility>

std::wstring C2Controller::Widen(const std::string& s) {
    if (s.empty()) return {};
    const int n=MultiByteToWideChar(CP_UTF8,0,s.data(),static_cast<int>(s.size()),nullptr,0);
    if (n<=0) return {};
    std::wstring w(static_cast<std::size_t>(n),L'\0');
    MultiByteToWideChar(CP_UTF8,0,s.data(),static_cast<int>(s.size()),w.data(),n);
    return w;
}

namespace {
bool BuildTonePayload(const std::string& card,const std::string& tone,std::vector<std::uint8_t>& payload,std::wstring& error) {
    payload.clear(); error.clear();
    if (card.empty() || tone.empty()) { error=L"音色 card/tone 不能为空"; return false; }
    if (card.size()>255 || tone.size()>255) { error=L"音色 code 过长"; return false; }
    payload.reserve(2+card.size()+tone.size()+32);
    payload.push_back(static_cast<std::uint8_t>(card.size()));
    payload.insert(payload.end(),card.begin(),card.end());
    payload.push_back(static_cast<std::uint8_t>(tone.size()));
    payload.insert(payload.end(),tone.begin(),tone.end());
    auto putF32=[&](float f) {
        std::uint32_t u=0; std::memcpy(&u,&f,sizeof(u));
        payload.push_back(static_cast<std::uint8_t>(u&0xff));
        payload.push_back(static_cast<std::uint8_t>((u>>8)&0xff));
        payload.push_back(static_cast<std::uint8_t>((u>>16)&0xff));
        payload.push_back(static_cast<std::uint8_t>((u>>24)&0xff));
    };
    // Factory capture: identical 8-float tail for sound_c2 and scard_01 tones.
    const float tail[8]={0.0f,1.0f,0.0f,1.0f,4.0f,1.0f,0.05f,0.0f};
    for (float f:tail) putF32(f);
    return true;
}

// V2.3.20i TEST: FILL_SHEET is a list of typed items. The generated item
// bodies already carry absolute beat/duration values, so packet boundaries are
// a transport batching boundary. For the *generic bulk tail only* we can merge
// multiple adjacent generated FILL payloads without changing any item bytes.
//
// MTU500 test rule: target at most 460 bytes of FILL data. Integer TLVC adds
// exactly 21 bytes, so a 460-byte FILL becomes a 481-byte A103 value and still
// leaves 16 bytes below the ATT value limit of 497 when MaxPduSize=500.
// INT25 remains untouched at its proven 469-byte data/page geometry.
struct GeneratedFillItem {
    std::uint8_t type=0;
    std::vector<std::uint8_t> raw;
};

static bool DecodeGeneratedFill(const std::vector<std::uint8_t>& payload,
    std::vector<GeneratedFillItem>& items) {
    items.clear();
    if (payload.empty()) return false;
    const std::size_t count=payload[0];
    if (count==0 || payload.size()<1+count) return false;
    std::size_t off=1+count;
    items.reserve(count);
    for (std::size_t i=0;i<count;++i) {
        const std::uint8_t type=payload[1+i];
        std::size_t len=0;
        // Generated Note item: tkid|index|pitch|velocity|beat|duration = 13B.
        if (type==1 || type==3 || type==4 || type==6) len=13;
        // Generated Chord item = 15B.
        else if (type==2) len=15;
        else if (type==5) {
            // Generated Event common prefix is 7B; byte7 selects the two
            // currently encoded variants: type3 => 12B, type7 => 10B.
            if (off+8>payload.size()) return false;
            const std::uint8_t variant=payload[off+7];
            if (variant==1) len=12;
            else if (variant==2) len=10;
            else return false;
        } else return false;
        if (off+len>payload.size()) return false;
        GeneratedFillItem item; item.type=type;
        item.raw.assign(payload.begin()+static_cast<std::ptrdiff_t>(off),
            payload.begin()+static_cast<std::ptrdiff_t>(off+len));
        items.push_back(std::move(item));
        off+=len;
    }
    return off==payload.size();
}

static bool BuildGreedyMergedFill(const std::vector<std::vector<std::uint8_t>>& payloads,
    std::size_t start,std::size_t maxDataBytes,std::size_t& consumed,
    std::vector<std::uint8_t>& merged) {
    consumed=0; merged.clear();
    if (start>=payloads.size() || maxDataBytes<2) return false;

    std::vector<GeneratedFillItem> all;
    std::size_t rawBytes=0;
    for (std::size_t pos=start;pos<payloads.size();++pos) {
        std::vector<GeneratedFillItem> part;
        if (!DecodeGeneratedFill(payloads[pos],part)) break;
        std::size_t addRaw=0;
        for (const auto& x:part) addRaw+=x.raw.size();
        const std::size_t newCount=all.size()+part.size();
        if (newCount==0 || newCount>255) break;
        const std::size_t newDataBytes=1+newCount+rawBytes+addRaw;
        if (newDataBytes>maxDataBytes) break;
        for (auto& x:part) all.push_back(std::move(x));
        rawBytes+=addRaw;
        ++consumed;
        if (newDataBytes==maxDataBytes) break;
    }
    if (consumed==0 || all.empty()) return false;
    const std::size_t dataBytes=1+all.size()+rawBytes;
    merged.reserve(dataBytes);
    merged.push_back(static_cast<std::uint8_t>(all.size()));
    for (const auto& x:all) merged.push_back(x.type);
    for (const auto& x:all) merged.insert(merged.end(),x.raw.begin(),x.raw.end());
    return merged.size()==dataBytes && merged.size()<=maxDataBytes;
}

// Split one generated FILL at item boundaries while preserving every item byte
// and original order. This is used only when a single original FILL itself
// exceeds the negotiated ATT-value budget.
static bool SplitGeneratedFill(const std::vector<std::uint8_t>& payload,
    std::size_t maxDataBytes,std::vector<std::vector<std::uint8_t>>& chunks) {
    chunks.clear();
    std::vector<GeneratedFillItem> items;
    if (!DecodeGeneratedFill(payload,items) || items.empty() || maxDataBytes<3) return false;

    std::size_t pos=0;
    while (pos<items.size()) {
        std::size_t end=pos;
        std::size_t rawBytes=0;
        while (end<items.size()) {
            const std::size_t newCount=end-pos+1;
            const std::size_t newRaw=rawBytes+items[end].raw.size();
            const std::size_t bytes=1+newCount+newRaw;
            if (bytes>maxDataBytes) break;
            rawBytes=newRaw;
            ++end;
        }
        if (end==pos) return false; // one item can never fit; malformed/unexpected
        std::vector<std::uint8_t> out;
        out.reserve(1+(end-pos)+rawBytes);
        out.push_back(static_cast<std::uint8_t>(end-pos));
        for (std::size_t i=pos;i<end;++i) out.push_back(items[i].type);
        for (std::size_t i=pos;i<end;++i)
            out.insert(out.end(),items[i].raw.begin(),items[i].raw.end());
        if (out.size()>maxDataBytes) return false;
        chunks.push_back(std::move(out));
        pos=end;
    }
    return !chunks.empty();
}
}

void C2Controller::SetEventCallback(EventFn fn) {
    std::lock_guard<std::mutex> lock(eventMutex_);
    eventFn_=std::move(fn);
}

void C2Controller::DispatchEvent(const C2PlayEvent& event) {
    EventFn fn;
    {
        std::lock_guard<std::mutex> lock(eventMutex_);
        fn=eventFn_;
    }
    if (fn) fn(event);
}

std::wstring C2Controller::PayloadSummary(const std::vector<std::uint8_t>& data) {
    std::wostringstream os;
    os << L"len=" << data.size() << L"  hex=";
    const std::size_t maxHex=std::min<std::size_t>(data.size(),160);
    os << std::hex << std::setfill(L'0');
    for (std::size_t i=0;i<maxHex;++i) {
        if (i) os << L' ';
        os << std::setw(2) << static_cast<unsigned>(data[i]);
    }
    if (data.size()>maxHex) os << L" ...";
    os << std::dec << L"\r\nprintable: ";
    std::wstring run;
    for (std::uint8_t b:data) {
        if (b>=32 && b<127) run.push_back(static_cast<wchar_t>(b));
        else {
            if (run.size()>=3) os << L"[" << run << L"] ";
            run.clear();
        }
    }
    if (run.size()>=3) os << L"[" << run << L"]";
    return os.str();
}


static bool IsPrintableResourceString(const std::string& v) {
    if (v.empty()) return false;
    for (unsigned char c : v) if (c < 32 || c >= 127) return false;
    return true;
}

static bool LooksLikeStyleResource(const std::string& v) {
    if (v.rfind("C1:",0)==0) return true;
    const std::size_t colon=v.find(':');
    if (colon==std::string::npos || colon+1>=v.size()) return false;
    const std::string tail=v.substr(colon+1);
    // get_config_basic also contains a bank/family pair such as
    // sound_c2:PianoStudio. A four-slot resource has either a numeric suffix
    // (GS_1/PianoStudio_76/...) or is an explicit legacy C1 code.
    const std::size_t us=tail.find_last_of('_');
    if (us==std::string::npos || us+1>=tail.size()) return false;
    for (std::size_t i=us+1;i<tail.size();++i)
        if (tail[i]<'0' || tail[i]>'9') return false;
    return true;
}

static std::vector<std::string> ExtractBasicStyleResources(const std::vector<std::uint8_t>& data) {
    std::vector<std::string> tokens;
    // The factory reply is a compact length-prefixed structure. Scan every byte
    // for a plausible [len][ASCII] field instead of assuming firmware-specific
    // padding around the four slots. This also keeps older/newer firmware safe.
    for (std::size_t i=0;i<data.size();++i) {
        const std::size_t n=data[i];
        if (n<3 || n>96 || i+1+n>data.size()) continue;
        std::string v(reinterpret_cast<const char*>(data.data()+i+1),n);
        if (!IsPrintableResourceString(v)) continue;
        tokens.push_back(v);
    }
    std::vector<std::string> resources;
    for (std::size_t i=0;i<tokens.size();++i) {
        std::string v=tokens[i];
        if (v=="sound_c2" && i+1<tokens.size() && tokens[i+1].find(':')==std::string::npos) {
            const std::string combined=v+":"+tokens[i+1];
            if (LooksLikeStyleResource(combined)) resources.push_back(combined);
        }
        if (LooksLikeStyleResource(v)) resources.push_back(v);
    }
    // Preserve order while removing scanner duplicates/overlaps.
    std::vector<std::string> unique;
    for (const auto& v:resources)
        if (std::find(unique.begin(),unique.end(),v)==unique.end()) unique.push_back(v);
    return unique;
}

static std::string NormalizeBasicStyleResource(std::string resource) {
    while (!resource.empty() && (resource.front()==' ' || resource.front()=='\t')) resource.erase(resource.begin());
    while (!resource.empty() && (resource.back()==' ' || resource.back()=='\t')) resource.pop_back();
    if (resource.empty()) return resource;
    if (resource.find(':')==std::string::npos) resource="sound_c2:"+resource;
    return resource;
}

void C2Controller::CacheStringReply(const C2DecodedPacket& decoded) {
    if (decoded.intCommand) return;
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (decoded.stringCmd=="get_volume") {
        if (!decoded.data.empty()) {
            const std::size_t count=decoded.data[0];
            for (std::size_t i=0;i<count && 2+2*i<decoded.data.size();++i) {
                const int ch=decoded.data[1+2*i];
                const int value=decoded.data[2+2*i];
                if (ch>=1 && ch<=13) deviceState_.mixer[static_cast<std::size_t>(ch)]=value;
            }
        }
    } else if (decoded.stringCmd=="get_vers_all") {
        deviceState_.versions=PayloadSummary(decoded.data);
    } else if (decoded.stringCmd=="get_midi_info") {
        deviceState_.midiInfo=PayloadSummary(decoded.data);
    } else if (decoded.stringCmd=="get_config_basic") {
        const auto resources=ExtractBasicStyleResources(decoded.data);
        // Captures and DEX agree on the factory order: A chord, B chord, A drum, B drum.
        // Only publish a parsed state when all four are visible; otherwise retain the
        // previous known state and keep the raw reply for protocol diagnosis.
        if (resources.size()>=4) {
            const std::size_t base=resources.size()-4;
            deviceState_.chordStyleA=resources[base+0];
            deviceState_.chordStyleB=resources[base+1];
            deviceState_.drumStyleA=resources[base+2];
            deviceState_.drumStyleB=resources[base+3];
            deviceState_.hasBasicStyleSlots=true;
        }
    } else if (decoded.stringCmd=="get_config_v2basic") {
        deviceState_.configBasic=PayloadSummary(decoded.data);
        deviceState_.hasBasicStyleSlots=false;
        // V2.3.20b: exact C2SingleResourceAuditioner parser:
        // [LP cardCode][LP cardName][count] then count *
        // [slot][kind][flag][LP fullResource][bpm][meter].
        // This ONE reply carries both the device/global tone and the four A/B
        // chord/drum slots.
        std::size_t off=0;
        auto readLP=[&](std::string& out)->bool {
            if (off>=decoded.data.size()) return false;
            const std::size_t n=decoded.data[off++];
            if (off+n>decoded.data.size()) return false;
            out.assign(reinterpret_cast<const char*>(decoded.data.data()+off),n);
            off+=n;
            return true;
        };
        std::string cardCode,cardName;
        bool parsed=readLP(cardCode) && readLP(cardName) && off<decoded.data.size();
        if (parsed) {
            deviceState_.currentToneCard=cardCode;
            deviceState_.currentTone=cardName;
            const std::size_t count=decoded.data[off++];
            bool seen[4]={false,false,false,false};
            for (std::size_t i=0;i<count;++i) {
                if (off+4>decoded.data.size()) { parsed=false; break; }
                const int slot=decoded.data[off++];
                const int kind=decoded.data[off++];
                (void)decoded.data[off++]; // flag/enable
                const std::size_t n=decoded.data[off++];
                if (off+n+2>decoded.data.size()) { parsed=false; break; }
                std::string full(reinterpret_cast<const char*>(decoded.data.data()+off),n);
                off+=n;
                const int bpm=decoded.data[off++];
                const int meter=decoded.data[off++];
                int idx=-1;
                if (slot==0 && kind==1) idx=0;
                else if (slot==1 && kind==1) idx=1;
                else if (slot==0 && kind==2) idx=2;
                else if (slot==1 && kind==2) idx=3;
                if (idx>=0) {
                    if (idx==0) deviceState_.chordStyleA=full;
                    else if (idx==1) deviceState_.chordStyleB=full;
                    else if (idx==2) deviceState_.drumStyleA=full;
                    else deviceState_.drumStyleB=full;
                    deviceState_.basicStyleBpm[static_cast<std::size_t>(idx)]=bpm;
                    deviceState_.basicStyleMeter[static_cast<std::size_t>(idx)]=meter;
                    seen[idx]=true;
                }
            }
            if (parsed) deviceState_.hasBasicStyleSlots=seen[0]&&seen[1]&&seen[2]&&seen[3];
        }
    } else if (decoded.stringCmd=="get_sys_onoff") {
        deviceState_.sysOnOff=PayloadSummary(decoded.data);
    } else if (decoded.stringCmd=="get_style_settings") {
        if (!decoded.data.empty()) {
            const std::size_t count=decoded.data[0];
            for (std::size_t i=0;i<count && 2+2*i<decoded.data.size();++i) {
                const int type=decoded.data[1+2*i];
                const int value=decoded.data[2+2*i];
                if (type>=0 && type<static_cast<int>(deviceState_.styleSettings.size()))
                    deviceState_.styleSettings[static_cast<std::size_t>(type)]=value;
            }
        }
    }
    if (!decoded.stringCmd.empty()) {
        const std::wstring item=L"["+Widen(decoded.stringCmd)+L"]\r\n"+PayloadSummary(decoded.data)+L"\r\n";
        // Keep a bounded diagnostic transcript. The device-center UI only needs
        // the latest refresh cycle, so do not retain an ever-growing STL tree.
        if (deviceState_.rawRepliesText.size()+item.size()>65536)
            deviceState_.rawRepliesText.clear();
        deviceState_.rawRepliesText+=item;
    }
}

C2DeviceState C2Controller::DeviceState() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return deviceState_;
}

void C2Controller::HandleNotify(const std::vector<std::uint8_t>& raw) {
    C2DecodedPacket d;
    std::string err;
    if (!C2Protocol::DecodePacket(raw,d,err) || !d.fromDevice)
        return;

    // 2026-08-20 btsnoop: after the first four FILL packets and SET_BEAT=0,
    // C2 emits integer notify 29 / data=01 before the official app proceeds
    // with the three get_config_v2basic read-backs. Treat it as a stage-ready
    // signal; old DEX snapshots do not contain its symbolic name.
    if (d.intCommand) {
        if (d.intCmd==C2CmdId::STAGE_READY_NOTIFY && !d.data.empty() && d.data[0]==0x01) stageReady29_.store(true);
        return;
    }

    // noti_basic is periodic. Parse the DEX-confirmed fields, cache them, and
    // dispatch only when a visible device-state value changed. This provides the
    // battery/BPM/system-volume UI without flooding the Windows message queue.
    if (d.stringCmd=="noti_basic") {
        if (d.data.size()<5) return;
        C2PlayEvent e;
        e.kind=C2PlayEvent::Kind::Basic;
        e.receivedTickMs=static_cast<std::uint64_t>(GetTickCount64());
        e.command=d.stringCmd;
        e.data=d.data;
        e.basicKey=d.data[0];
        e.basicBpm=d.data[1];
        e.basicVolume=d.data[2];
        e.battery=d.data[3];
        e.guitarMode=d.data[4]&0x0F;
        if (d.data.size()>=13) {
            e.chargeState=(d.data[12]>>4)&0x0F;
            e.charging=(e.chargeState>=2 && e.chargeState<=4);
        }
        bool changed=false;
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            changed = deviceState_.key!=e.basicKey || deviceState_.bpm!=e.basicBpm ||
                deviceState_.systemVolume!=e.basicVolume || deviceState_.battery!=e.battery ||
                deviceState_.mode!=e.guitarMode || deviceState_.chargeState!=e.chargeState ||
                deviceState_.charging!=e.charging;
            deviceState_.key=e.basicKey;
            deviceState_.bpm=e.basicBpm;
            deviceState_.systemVolume=e.basicVolume;
            deviceState_.battery=e.battery;
            deviceState_.mode=e.guitarMode;
            deviceState_.chargeState=e.chargeState;
            deviceState_.charging=e.charging;
        }
        if (changed) DispatchEvent(e);
        return;
    }

    C2PlayEvent e;
    e.receivedTickMs=static_cast<std::uint64_t>(GetTickCount64());
    e.command=d.stringCmd;
    e.data=d.data;
    if (d.stringCmd=="noti_chord") e.kind=C2PlayEvent::Kind::Chord;
    else if (d.stringCmd=="noti_note") e.kind=C2PlayEvent::Kind::Note;
    else if (d.stringCmd=="noti_drum") e.kind=C2PlayEvent::Kind::Drum;
    else if (d.stringCmd=="noti_event") e.kind=C2PlayEvent::Kind::Event;
    else if (d.stringCmd=="noti_sheet") e.kind=C2PlayEvent::Kind::Sheet;
    else if (d.stringCmd=="noti_frets") e.kind=C2PlayEvent::Kind::Frets;
    else if (d.stringCmd=="noti_picks") e.kind=C2PlayEvent::Kind::Picks;
    else e.kind=C2PlayEvent::Kind::Other;

    // The first 6 bytes are the already known chord/key fields.
    if (e.kind==C2PlayEvent::Kind::Chord && d.data.size()>=6) {
        e.row=d.data[0];
        e.col=d.data[1];
        e.level=d.data[2];
        e.type=d.data[3];
        e.trans12=d.data[4];
        e.pickId=d.data[5];
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            deviceState_.lastPickId=e.pickId;
            ++deviceState_.shortcutEventCounter;
        }
    }

    // V2.3.17 retains the shortcut monitor: decode the device-side result of physical
    // combinations. Keep the raw payload in C2PlayEvent as well so unknown
    // firmware event types remain visible in the PC log.
    if (e.kind==C2PlayEvent::Kind::Event && d.data.size()>=2) {
        e.eventType=d.data[0];
        e.eventValue=d.data[1];
        std::lock_guard<std::mutex> lock(stateMutex_);
        deviceState_.lastSystemEventType=e.eventType;
        deviceState_.lastSystemEventValue=e.eventValue;
        if (e.eventType==1) deviceState_.mainTrackAuto=e.eventValue;
        else if (e.eventType==2) deviceState_.micVolumeEvent=e.eventValue;
        else if (e.eventType==3) deviceState_.doublePickEvent=e.eventValue;
        else if (e.eventType==4) deviceState_.batteryShowEvent=e.eventValue;
        ++deviceState_.shortcutEventCounter;
    }

    // DEX layout: key + keyboard[36] + bpm touch + arpeggio[6].  The historical
    // note called this 45B, but the indexed fields through [43] require only
    // 44 bytes. Accept >=44 so both observed variants are handled.
    if (e.kind==C2PlayEvent::Kind::Frets && d.data.size()>=44) {
        e.fretKey=d.data[0];
        e.bpmTouch=(d.data[37]<=240)?1:0;
        bool changed=false;
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            changed=deviceState_.fretKey!=e.fretKey || deviceState_.bpmTouch!=e.bpmTouch;
            deviceState_.fretKey=e.fretKey;
            deviceState_.bpmTouch=e.bpmTouch;
            for (std::size_t i=0;i<6;++i) {
                e.arpeggioRaw[i]=d.data[38+i];
                e.arpeggioPressed[i]=(d.data[38+i]<=240)?1:0;
                // Raw capacitance bytes naturally wobble while a finger is held.
                // Log only threshold-state transitions so the 100 ms stream does
                // not flood the GUI; still cache the latest raw value for display.
                if (deviceState_.arpeggioPressed[i]!=e.arpeggioPressed[i]) changed=true;
                deviceState_.arpeggioRaw[i]=e.arpeggioRaw[i];
                deviceState_.arpeggioPressed[i]=e.arpeggioPressed[i];
            }
            if (changed) ++deviceState_.shortcutEventCounter;
        }
        // noti_frets can arrive at ~100 ms. Only forward actual state changes.
        if (!changed) return;
    }

    if (e.kind==C2PlayEvent::Kind::Picks && d.data.size()>=9) {
        e.pickState=d.data[0];
        std::uint32_t ua=static_cast<std::uint32_t>(d.data[1]) |
            (static_cast<std::uint32_t>(d.data[2])<<8) |
            (static_cast<std::uint32_t>(d.data[3])<<16) |
            (static_cast<std::uint32_t>(d.data[4])<<24);
        std::uint32_t ub=static_cast<std::uint32_t>(d.data[5]) |
            (static_cast<std::uint32_t>(d.data[6])<<8) |
            (static_cast<std::uint32_t>(d.data[7])<<16) |
            (static_cast<std::uint32_t>(d.data[8])<<24);
        std::memcpy(&e.pickAngleA,&ua,sizeof(e.pickAngleA));
        std::memcpy(&e.pickAngleB,&ub,sizeof(e.pickAngleB));
        e.hasPickAngles=std::isfinite(e.pickAngleA) && std::isfinite(e.pickAngleB);
        bool changed=false;
        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            changed=deviceState_.pickState!=e.pickState || !deviceState_.hasPickAngles ||
                (e.hasPickAngles && (std::fabs(deviceState_.pickAngleA-e.pickAngleA)>0.5f ||
                                     std::fabs(deviceState_.pickAngleB-e.pickAngleB)>0.5f));
            deviceState_.pickState=e.pickState;
            if (e.hasPickAngles) {
                deviceState_.hasPickAngles=true;
                deviceState_.pickAngleA=e.pickAngleA;
                deviceState_.pickAngleB=e.pickAngleB;
            }
            if (changed) ++deviceState_.shortcutEventCounter;
        }
        if (!changed) return;
    }

    // The official sheet-play capture proves noti_chord grows to 10 bytes:
    // [row][col][level][type][trans12][pickId][beat float32 LE]
    if (e.kind==C2PlayEvent::Kind::Chord && d.data.size()>=10) {
        const std::uint32_t u=
            static_cast<std::uint32_t>(d.data[6]) |
            (static_cast<std::uint32_t>(d.data[7])<<8) |
            (static_cast<std::uint32_t>(d.data[8])<<16) |
            (static_cast<std::uint32_t>(d.data[9])<<24);
        float beat=0.0f;
        std::memcpy(&beat,&u,sizeof(beat));
        if (std::isfinite(beat) && beat>=0.0f && beat<100000.0f) {
            e.hasBeat=true;
            e.beat=beat;
        }
    }
    if (e.hasBeat && uploaded_.load() && armed_.load()) {
        const int cue=CueLevelForBeat(e.beat);
        if (cue>=0 && cue!=appliedPreLevel_.load()) QueueCueLevel(cue);
    }
    DispatchEvent(e);

    // Compatibility fallback: some C2 states/firmwares emit the legacy 6-byte
    // noti_chord even while a sheet is resident. Never guess +2 beats from a
    // physical key event (wrong keys must not advance). Instead ask the device
    // for its authoritative sheet position using integer 0x09 / A102.
    if (e.kind==C2PlayEvent::Kind::Chord && !e.hasBeat &&
        d.data.size()>=6 && uploaded_.load() && armed_.load()) {
        QueuePositionQuery();
    }
}

bool C2Controller::Connect(std::wstring& error,StatusFn status) {
    if (status) status(L"正在连接 C2（C2SingleResourceAuditioner 扫描/连接模式：主动扫描 + Service FF/A101/A102/A103 判定）...");
    const bool ok=ble_.Connect(error,status,[this](const std::vector<std::uint8_t>& raw) {
        HandleNotify(raw);
    });
    if (ok) {
        if (status) status(L"C2 已连接：Service FF / Notify A101 / Read A102 / Write A103");
        // Enable the normal noti_basic stream used by the official app. The GUI
        // de-duplicates unchanged packets, so 01 0A does not flood the UI.
        std::wstring ignored;
        if (!SendString("set_notify_param",{0x01,0x0A},ignored,{},12) && status)
            status(L"提示：set_notify_param 01 0A 未确认，电量仍会使用设备主动上报");
        C2DecodedPacket vol;
        ignored.clear();
        if (SendString("get_volume",{},ignored,{},10) && ReadExpectedString("get_volume",vol,ignored,{},6)) {
            if (status) status(L"C2 Mixer 已读取：主旋律 ch05="+
                std::to_wstring(DeviceState().mixer[5]));
        }
    }
    return ok;
}

void C2Controller::Disconnect() {
    ble_.Disconnect();
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        deviceState_.shortcutMonitorEnabled=false;
    }
    uploaded_.store(false);
    armed_.store(false);
    appliedPreLevel_.store(-1);
    pendingPreLevel_.store(-1);
    positionQueryRunning_.store(false);
    positionQueryPending_.store(false);
    stageReady29_.store(false);
    // A BLE disconnect only releases the Windows GATT connection. It does not
    // prove that C2 discarded the resident sheet/scheduler. Preserve this bit so
    // a later reconnect + Upload() performs the proven CrossSongReset first.
}

bool C2Controller::IsConnected() const { return ble_.IsConnected(); }

bool C2Controller::Send(std::uint8_t cmd,const std::vector<std::uint8_t>& data,
    std::wstring& error,StatusFn status,int sleepMs) {
    const auto packet=C2Protocol::EncodeIntCommand(cmd,data);
    if (!ble_.WritePacket(packet,error)) return false;
    if (status) status(L"TX cmd=" + std::to_wstring(static_cast<unsigned>(cmd)) +
        L" data=" + std::to_wstring(data.size()) + L"B packet=" +
        std::to_wstring(packet.size()) + L"B");
    if (sleepMs>0) std::this_thread::sleep_for(std::chrono::milliseconds(sleepMs));
    return true;
}

bool C2Controller::SendString(const std::string& cmd,const std::vector<std::uint8_t>& data,
    std::wstring& error,StatusFn status,int sleepMs) {
    const auto packet=C2Protocol::EncodeStringCommand(cmd,data);
    if (packet.empty()) { error=L"无效 C2 字符串命令"; return false; }
    if (!ble_.WritePacket(packet,error)) return false;
    if (status) status(L"TX "+Widen(cmd)+L" data="+std::to_wstring(data.size())+L"B packet="+
        std::to_wstring(packet.size())+L"B");
    if (sleepMs>0) std::this_thread::sleep_for(std::chrono::milliseconds(sleepMs));
    return true;
}


bool C2Controller::ReadExpectedInt(std::uint8_t expectedCmd,C2DecodedPacket& decoded,
    std::wstring& error,StatusFn status,int attempts) {
    for (int i=0;i<std::max<int>(1,attempts);++i) {
        std::vector<std::uint8_t> raw;
        if (!ble_.ReadPacket(raw,error)) {
            if (i+1<attempts) { std::this_thread::sleep_for(std::chrono::milliseconds(12)); continue; }
            return false;
        }
        std::string de;
        C2DecodedPacket d;
        if (C2Protocol::DecodePacket(raw,d,de) && d.fromDevice && d.intCommand && d.intCmd==expectedCmd) {
            decoded=std::move(d);
            if (status) status(L"RX A102 int cmd="+std::to_wstring(static_cast<unsigned>(expectedCmd))+
                L" data="+std::to_wstring(decoded.data.size())+L"B");
            return true;
        }
        if (i+1<attempts) std::this_thread::sleep_for(std::chrono::milliseconds(12));
    }
    error=L"A102 回包不是期望的整数命令 "+std::to_wstring(static_cast<unsigned>(expectedCmd));
    return false;
}

bool C2Controller::ReadExpectedString(const std::string& expectedCmd,C2DecodedPacket& decoded,
    std::wstring& error,StatusFn status,int attempts) {
    std::wstring lastSeen;
    for (int i=0;i<std::max<int>(1,attempts);++i) {
        std::vector<std::uint8_t> raw;
        if (!ble_.ReadPacket(raw,error)) {
            if (i+1<attempts) { std::this_thread::sleep_for(std::chrono::milliseconds(20)); continue; }
            return false;
        }
        std::string de;
        C2DecodedPacket d;
        if (C2Protocol::DecodePacket(raw,d,de) && d.fromDevice && !d.intCommand) {
            lastSeen=Widen(d.stringCmd);
            if (d.stringCmd==expectedCmd) {
                decoded=std::move(d);
                CacheStringReply(decoded);
                if (status) status(L"RX A102 "+Widen(expectedCmd)+L" data="+
                    std::to_wstring(decoded.data.size())+L"B");
                return true;
            }

            // Legacy V2.3.20a get_config_basic compatibility branch only.
            // V2.3.20b four-slot UI does NOT use this path: the validated
            // C2SingleResourceAuditioner route is get_config_v2basic -> A102
            // with an exact command match and ConfigV2Basic parser.
            if (expectedCmd=="get_config_basic") {
                const auto resources=ExtractBasicStyleResources(d.data);
                if (resources.size()>=4) {
                    decoded=std::move(d);
                    {
                        std::lock_guard<std::mutex> lock(stateMutex_);
                        const std::size_t base=resources.size()-4;
                        deviceState_.chordStyleA=resources[base+0];
                        deviceState_.chordStyleB=resources[base+1];
                        deviceState_.drumStyleA=resources[base+2];
                        deviceState_.drumStyleB=resources[base+3];
                        deviceState_.hasBasicStyleSlots=true;
                    }
                    if (status) status(L"RX A102 四槽结构回读（cmd="+lastSeen+L"） data="+
                        std::to_wstring(decoded.data.size())+L"B");
                    return true;
                }
            }
        } else if (!de.empty()) {
            lastSeen=Widen(de);
        }
        if (i+1<attempts) std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    error=L"A102 未等到 "+Widen(expectedCmd);
    if (!lastSeen.empty()) error+=L"；最后看到="+lastSeen;
    return false;
}

bool C2Controller::QuerySheetBeat(float& beat,std::wstring& error,StatusFn status) {
    C2DecodedPacket d;
    if (!Send(C2CmdId::GET_SHEET_BEAT,{},error,{},12)) return false;
    if (!ReadExpectedInt(C2CmdId::GET_SHEET_BEAT,d,error,status,5)) return false;
    if (d.data.size()<4) { error=L"GET_SHETT_BEAT 回包不足4字节"; return false; }
    const std::uint32_t u=static_cast<std::uint32_t>(d.data[0]) |
        (static_cast<std::uint32_t>(d.data[1])<<8) |
        (static_cast<std::uint32_t>(d.data[2])<<16) |
        (static_cast<std::uint32_t>(d.data[3])<<24);
    std::memcpy(&beat,&u,sizeof(beat));
    if (!std::isfinite(beat) || beat<0.0f || beat>=100000.0f) {
        error=L"GET_SHETT_BEAT 返回非法 float"; return false;
    }
    if (status) status(L"C2 实机位置确认：beat="+std::to_wstring(beat));
    return true;
}

bool C2Controller::VerifySheetBeat(float targetBeat,std::wstring& error,StatusFn status) {
    float got=0.0f;
    if (QuerySheetBeat(got,error,status) && std::fabs(got-targetBeat)<=0.20f) return true;

    // One recovery pass based on the two successful btsnoop variants: command 28
    // is always present around the final SET_BEAT. If the first SET_BEAT was sent
    // before C2 finished the staged upload, re-issue 28 -> SET_BEAT after all FILLs.
    if (status) status(L"C2 当前 beat 未到目标，执行抓包兼容恢复：cmd28 -> SET_BEAT -> GET_BEAT");
    error.clear();
    if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,{},18)) return false;
    if (!Send(C2CmdId::SET_SHEET_BEAT,C2MusicEncoder::BuildPositionPayloadForPlan(targetBeat,plan_),error,{},35)) return false;
    if (!QuerySheetBeat(got,error,status)) return false;
    if (std::fabs(got-targetBeat)>0.20f) {
        error=L"C2 未接受目标 beat：目标="+std::to_wstring(targetBeat)+L"，设备="+std::to_wstring(got);
        return false;
    }
    return true;
}

bool C2Controller::SendRemindChord(std::wstring& error,StatusFn status) {
    if (plan_.firstChordLevel<0) return true;
    const std::vector<std::uint8_t> remind={
        static_cast<std::uint8_t>(plan_.firstChordLevel),
        static_cast<std::uint8_t>(std::max<int>(0,plan_.firstChordType)),
        static_cast<std::uint8_t>(plan_.firstChordTrans12)};
    return SendString("set_remind_chord",remind,error,status,12);
}

bool C2Controller::SendPreLevel(int level,std::wstring& error,StatusFn status) {
    if (level<0) return true;
    const std::vector<std::uint8_t> d={static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,level))),0x01};
    if (!SendString("set_pre_level",d,error,status,12)) return false;
    appliedPreLevel_.store(level);
    return true;
}


bool C2Controller::SendMainMelodyMode(int mode,float beat,std::wstring& error,StatusFn status) {
    mode=std::max<int>(0,std::min<int>(2,mode));
    if (!std::isfinite(beat) || beat<0.0f) beat=0.0f;
    if (mode==0) beat=0.0f;

    std::vector<std::uint8_t> d;
    const std::string tone=(plan_.leadTone.empty()?std::string("PianoStudio"):plan_.leadTone);
    d.reserve(6+tone.size());
    d.push_back(static_cast<std::uint8_t>(mode));
    std::uint32_t u=0;
    std::memcpy(&u,&beat,sizeof(beat));
    d.push_back(static_cast<std::uint8_t>(u & 0xff));
    d.push_back(static_cast<std::uint8_t>((u >> 8) & 0xff));
    d.push_back(static_cast<std::uint8_t>((u >> 16) & 0xff));
    d.push_back(static_cast<std::uint8_t>((u >> 24) & 0xff));
    if (mode==0) {
        d.push_back(0x00);
    } else {
        if (tone.size()>255) { error=L"主旋律音色代码过长"; return false; }
        d.push_back(static_cast<std::uint8_t>(tone.size()));
        d.insert(d.end(),tone.begin(),tone.end());
    }
    if (status) {
        const wchar_t* name=(mode==0?L"关":(mode==1?L"开":L"Auto"));
        status(std::wstring(L"C2 主旋律运行态：set_pre_lead=")+name+
            L" preBeat="+std::to_wstring(beat)+
            (mode==0?L"":(L" tone="+Widen(tone)+L" card="+Widen(plan_.leadCard))));
    }
    return SendString("set_pre_lead",d,error,status,18);
}

std::vector<std::uint8_t> C2Controller::InitialPosition() const {
    return C2MusicEncoder::BuildPositionPayload(plan_.initialBeat,plan_.descriptors.size());
}

int C2Controller::CueLevelForBeat(float beat) const {
    int level=-1;
    // Official capture prepares the next 2-beat block in advance.
    // Example: device beat 46 -> set_pre_level for the JSON type=10 cue at beat 48.
    const float prepareThrough=beat+2.05f;
    for (const auto& cue:plan_.preLevelCues) {
        if (cue.beat<=prepareThrough) level=cue.level;
        else break;
    }
    return level;
}

void C2Controller::QueueCueLevel(int level) {
    if (level<0 || level==appliedPreLevel_.load()) return;
    pendingPreLevel_.store(level);
    bool expected=false;
    if (!cueWorkerRunning_.compare_exchange_strong(expected,true)) return;
    std::thread([this]() { CueWorker(); }).detach();
}

void C2Controller::CueWorker() {
    try { winrt::init_apartment(winrt::apartment_type::multi_threaded); } catch (...) {}
    for (;;) {
        const int level=pendingPreLevel_.exchange(-1);
        if (level<0) break;
        if (level==appliedPreLevel_.load() || !uploaded_.load() || !armed_.load()) continue;
        std::lock_guard<std::mutex> lock(opMutex_);
        if (!ble_.IsConnected() || !uploaded_.load() || !armed_.load()) continue;
        std::wstring ignored;
        SendPreLevel(level,ignored,{});
    }
    cueWorkerRunning_.store(false);
    // Close the race where a notification arrives between exchange(-1)
    // and cueWorkerRunning_=false.
    if (pendingPreLevel_.load()>=0) QueueCueLevel(pendingPreLevel_.load());
    try { winrt::uninit_apartment(); } catch (...) {}
}

void C2Controller::QueuePositionQuery() {
    // Coalesce legacy 6-byte noti_chord bursts instead of dropping every trigger
    // that arrives while an A102 GET_SHEET_BEAT is in flight. The worker always
    // performs one more read when a trigger arrived during the previous query.
    positionQueryPending_.store(true);
    bool expected=false;
    if (!positionQueryRunning_.compare_exchange_strong(expected,true)) return;
    std::thread([this]() { PositionQueryWorker(); }).detach();
}

void C2Controller::PositionQueryWorker() {
    try { winrt::init_apartment(winrt::apartment_type::multi_threaded); } catch (...) {}
    for (;;) {
        positionQueryPending_.store(false);
        C2PlayEvent event;
        bool haveBeat=false;
        {
            std::lock_guard<std::mutex> lock(opMutex_);
            if (ble_.IsConnected() && uploaded_.load() && armed_.load()) {
                std::wstring ignored;
                // DEX getRemindNotesV2(): GET_SHETT_BEAT (0x09), then A102 payload
                // begins with float32 little-endian beat.
                if (Send(C2CmdId::GET_SHEET_BEAT,{},ignored,{},18)) {
                    std::vector<std::uint8_t> raw;
                    if (ble_.ReadPacket(raw,ignored)) {
                        C2DecodedPacket d;
                        std::string decodeError;
                        if (C2Protocol::DecodePacket(raw,d,decodeError) && d.fromDevice &&
                            d.intCommand && d.intCmd==C2CmdId::GET_SHEET_BEAT && d.data.size()>=4) {
                            const std::uint32_t u=static_cast<std::uint32_t>(d.data[0]) |
                                (static_cast<std::uint32_t>(d.data[1])<<8) |
                                (static_cast<std::uint32_t>(d.data[2])<<16) |
                                (static_cast<std::uint32_t>(d.data[3])<<24);
                            float beat=0.0f;
                            std::memcpy(&beat,&u,sizeof(beat));
                            if (std::isfinite(beat) && beat>=0.0f && beat<100000.0f) {
                                event.kind=C2PlayEvent::Kind::Other;
                                event.command="get_sheet_beat(A102 fallback)";
                                event.data=d.data;
                                event.hasBeat=true;
                                event.beat=beat;
                                event.receivedTickMs=static_cast<std::uint64_t>(GetTickCount64());
                                haveBeat=true;
                            }
                        }
                    }
                }
            }
        }
        if (haveBeat) {
            const int cue=CueLevelForBeat(event.beat);
            if (cue>=0 && cue!=appliedPreLevel_.load()) QueueCueLevel(cue);
            DispatchEvent(event);
        }
        if (!positionQueryPending_.load()) break;
    }
    positionQueryRunning_.store(false);
    // Close the race where a 6-byte trigger lands just after the last pending
    // check but just before running=false becomes visible.
    if (positionQueryPending_.load()) QueuePositionQuery();
    try { winrt::uninit_apartment(); } catch (...) {}
}

void C2Controller::ResetCrossSongState(bool replacingResidentSheet,StatusFn status) {
    // V2.3.8a: a plain CLOSE_SHEET was sufficient for the first upload but did
    // not reliably clear the C2 track scheduler/AUTO state before the second song.
    // This exactly matches the historical V2.3.4 cross-song symptom: physical
    // noti_chord continues arriving while the authoritative sheet beat is held.
    //
    // Keep the first-upload behavior conservative: always issue CLOSE_SHEET as
    // before. Only when this process knows C2 already holds a resident sheet do
    // the stronger reset: disable the track scheduler and drive AUTO type2 to a
    // neutral 0 baseline before closing. The new song later sets type2 to its
    // deterministic target (extra-track=1, base/3-track=0).
    std::wstring e;
    if (replacingResidentSheet) {
        if (status) status(L"CrossSongReset：检测到 C2 仍驻留上一首曲谱；先退出旧轨道演奏态");
        if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x00},e,{},22)) {
            if (status) status(L"CrossSongReset 警告：SET_TRACK_ENABLE=0 写入失败："+e);
            e.clear();
        } else if (status) {
            status(L"CrossSongReset：SET_TRACK_ENABLE=0");
        }
        if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,0x00},e,{},22)) {
            if (status) status(L"CrossSongReset 警告：SET_AUTO type2=0 写入失败："+e);
            e.clear();
        } else if (status) {
            status(L"CrossSongReset：SET_AUTO_PLAY type2=0 baseline");
        }
    }

    if (!Send(C2CmdId::CLOSE_SHEET,{},e,{},replacingResidentSheet?70:25)) {
        if (status) status(L"CrossSongReset 提示：CLOSE_SHEET 未确认写入，继续按原有非致命策略上传："+e);
    } else if (status && replacingResidentSheet) {
        status(L"CrossSongReset：CLOSE_SHEET 完成，等待 C2 清理旧 transport");
    }
    deviceSheetResident_.store(false);
    stageReady29_.store(false);
    appliedPreLevel_.store(-1);
    pendingPreLevel_.store(-1);
    positionQueryRunning_.store(false);
    positionQueryPending_.store(false);
}

bool C2Controller::EnableKeyTriggerEngine(std::wstring& error,StatusFn status) {
    // Re-arm path for an already uploaded sheet. The upload path below follows
    // the complete 2026-08-20 staged btsnoop sequence; this helper mirrors only
    // the state-changing tail needed after a restart.
    C2DecodedPacket autoReply;
    if (!Send(C2CmdId::GET_AUTO_PLAY,{},error,{},12)) return false;
    if (!ReadExpectedInt(C2CmdId::GET_AUTO_PLAY,autoReply,error,status,5)) return false;
    int autoType2=-1;
    if (!autoReply.data.empty()) {
        const std::size_t n=autoReply.data[0];
        for (std::size_t i=0;i<n && 2+2*i<autoReply.data.size();++i)
            if (autoReply.data[1+2*i]==2) autoType2=autoReply.data[2+2*i];
    }
    const int targetType2=plan_.trackSetup.empty()?0:1;
    if (status) status(L"重新进入实体演奏：GET_AUTO type2="+std::to_wstring(autoType2)+
        L"，本曲目标="+std::to_wstring(targetType2));
    if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,static_cast<std::uint8_t>(targetType2)},error,status,18)) return false;
    if (!SendRemindChord(error,status)) return false;
    if (!SendString("set_guitar_mode",{0x02},error,status,15)) return false;
    const int initialCue=CueLevelForBeat(plan_.initialBeat-2.0f);
    if (initialCue>=0 && !SendPreLevel(initialCue,error,status)) return false;
    if (!Send(C2CmdId::SET_AUTO_PLAY,{0x01,0x01},error,status,15)) return false;
    if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,status,15)) return false;
    armed_.store(true);
    return true;
}

bool C2Controller::Upload(const MDSSong& song,int bpm,bool armKeyPlayAfterUpload,
    std::wstring& error,StatusFn status,ProgressFn progress) {
    std::lock_guard<std::mutex> lock(opMutex_);
    const bool replacingResidentSheet=deviceSheetResident_.load();
    error.clear(); uploaded_.store(false); armed_.store(false);
    appliedPreLevel_.store(-1); pendingPreLevel_.store(-1); positionQueryRunning_.store(false); positionQueryPending_.store(false); stageReady29_.store(false);
    stageReady29_.store(false);
    if (!ble_.IsConnected() && !Connect(error,status)) return false;

    std::string encErr;
    if (!C2MusicEncoder::Build(song,bpm,plan_,encErr)) {
        error=Widen(encErr);
        return false;
    }
    if (status) {
        status(L"C2 V2.3.18 MultiTrack / INT26："+std::to_wstring(plan_.descriptors.size())+L" tracks, "+
            std::to_wstring(plan_.fillPayloads.size())+L" fill packets, startBeat="+
            std::to_wstring(plan_.initialBeat)+L", BPM="+std::to_wstring(plan_.encodedBpm));
        for (const auto& w:plan_.warnings) status(L"警告："+Widen(w));
    }

    // V2.3.20i 460B WR-Pack + OversizeSplit TEST. Preserve every 6/8 MeterTimingFix / song-flow
    // decision above and below this block. FILL_SHEET / INT25 use conservative
    // WriteWithoutResponse pacing. Generic FILLs after the proven first-stage
    // control interleave may greedily merge adjacent generated FILLs up to a
    // 460-byte data target (481-byte TLVC/A103 value) when MTU500 is available.
    // CREATE/GET/Verify/Notify29 and all control commands keep their existing waits.
    using BulkClock=std::chrono::steady_clock;
    const auto uploadStart=BulkClock::now();
    BulkClock::time_point lastBulkStart{};
    int bulkCadenceMs=ble_.SupportsWriteWithoutResponse()?15:25; // stability first
    std::uint64_t bulkWrites=0,bulkBytes=0,bulkRetries=0,bulkFallbacks=0;
    std::uint64_t fillPackedWrites=0,fillPackedOriginals=0,fillPackCandidates=0;
    std::uint64_t fillSplitOriginals=0,fillSplitWrites=0;
    std::size_t fillPackedMaxData=0,fillPackedMaxOriginals=0;
    long long bulkWriteMs=0,bulkPaceMs=0;
    // V2.3.20i diagnostics for the depth-2 WriteWithoutResponse window.
    std::uint64_t pipeSubmitted=0,pipeCompleted=0,pipeBeginFailures=0,pipeFinishFailures=0,pipeFallbacks=0;
    std::size_t pipePeakInFlight=0;
    long long pipeBeginCallMs=0,pipeWaitCallMs=0,pipeLatencyMs=0,pipeMaxWaitMs=0;

    if (status) {
        std::size_t totalItems=0,multiItemPackets=0,maxItems=0,maxFillData=0;
        for (const auto& f:plan_.fillPayloads) {
            if (!f.empty()) {
                const std::size_t n=f[0];
                totalItems+=n;
                if (n>1) ++multiItemPackets;
                maxItems=std::max(maxItems,n);
            }
            maxFillData=std::max(maxFillData,f.size());
        }
        status(L"V2.3.20j PlaybackUI（传输沿用20i）：460B动态合包不依赖WNR；Windows仅WriteWithResponse也启用MTU合包；单个超大FILL按item边界拆分；Pipeline2仍仅WNR可用；不改6/8时序");
        status(L"A103 WNR="+std::wstring(ble_.SupportsWriteWithoutResponse()?L"YES":L"NO")+
            L"，MaxPduSize="+std::to_wstring(ble_.MaxPduSize())+
            L"，ATT value上限="+std::to_wstring(ble_.MaxGattWriteValueBytes())+L"B");
        status(L"原始FILL：packets="+std::to_wstring(plan_.fillPayloads.size())+
            L"，totalItems="+std::to_wstring(totalItems)+L"，multiItemPackets="+
            std::to_wstring(multiItemPackets)+L"，maxItemCount="+std::to_wstring(maxItems)+
            L"，maxData="+std::to_wstring(maxFillData)+L"B");
    }

    auto paceBulk=[&]() {
        const auto now=BulkClock::now();
        if (lastBulkStart.time_since_epoch().count()!=0) {
            const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(now-lastBulkStart).count();
            if (elapsed<bulkCadenceMs) {
                const auto wait=bulkCadenceMs-elapsed;
                std::this_thread::sleep_for(std::chrono::milliseconds(wait));
                bulkPaceMs+=wait;
            }
        }
        lastBulkStart=BulkClock::now();
    };
    auto sendBulk=[&](std::uint8_t cmd,const std::vector<std::uint8_t>& data)->bool {
        const auto packet=C2Protocol::EncodeIntCommand(cmd,data);
        if (packet.empty()) { error=L"460B WR-Pack TEST: TLVC编码失败"; return false; }
        const auto maxValue=ble_.MaxGattWriteValueBytes();
        // Only enforce a negotiated value above the legacy 23-byte placeholder.
        // If Windows still reports 23/unknown here, let WriteValueAsync decide;
        // this avoids rejecting a connection whose MTU update is merely late.
        if (ble_.MaxPduSize()>23 && maxValue>0 && packet.size()>maxValue) {
            error=L"460B WR-Pack TEST: packet="+std::to_wstring(packet.size())+L"B > ATT value上限="+
                std::to_wstring(maxValue)+L"B；当前版本不改INT25分页/不跨beat重组，以保证基线时序";
            return false;
        }
        for (int attempt=0;attempt<3;++attempt) {
            paceBulk();
            const auto t0=lastBulkStart;
            std::wstring writeErr;
            const bool ok=ble_.WritePacket(packet,writeErr); // already selects WNR when A103 supports it
            const auto t1=BulkClock::now();
            bulkWriteMs+=std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count();
            if (ok) { ++bulkWrites; bulkBytes+=data.size(); return true; }
            ++bulkRetries;
            if (attempt==2) { error=writeErr; return false; }
            const int old=bulkCadenceMs;
            bulkCadenceMs=(bulkCadenceMs<18)?18:25;
            ++bulkFallbacks;
            if (status) status(L"460B WR-Pack TEST串行写失败，退速重试："+std::to_wstring(old)+L" -> "+
                std::to_wstring(bulkCadenceMs)+L"ms；"+writeErr);
            std::this_thread::sleep_for(std::chrono::milliseconds(bulkCadenceMs));
            lastBulkStart={};
        }
        return false;
    };
    auto reportBulk=[&](const wchar_t* profile) {
        if (!status) return;
        const auto totalMs=std::chrono::duration_cast<std::chrono::milliseconds>(BulkClock::now()-uploadStart).count();
        status(std::wstring(L"V2.3.20j PlaybackUI/20i-WRPack统计[")+profile+L"]：total="+std::to_wstring(totalMs)+
            L"ms，bulkWrites="+std::to_wstring(bulkWrites)+L"，bulkPayload="+std::to_wstring(bulkBytes)+
            L"B，串行Write等待累计="+std::to_wstring(bulkWriteMs)+L"ms，串行节拍等待="+std::to_wstring(bulkPaceMs)+
            L"ms，retry="+std::to_wstring(bulkRetries)+L"，fallback="+std::to_wstring(bulkFallbacks)+
            L"，packedWrites="+std::to_wstring(fillPackedWrites)+L"，packedOriginals="+std::to_wstring(fillPackedOriginals)+
            L"，maxPackedOriginals="+std::to_wstring(fillPackedMaxOriginals)+L"，maxPackedData="+std::to_wstring(fillPackedMaxData)+
            L"B，packCandidates="+std::to_wstring(fillPackCandidates)+L"，splitOriginals="+std::to_wstring(fillSplitOriginals)+
            L"，splitWrites="+std::to_wstring(fillSplitWrites)+L"，pipeSubmitted="+std::to_wstring(pipeSubmitted)+
            L"，pipeCompleted="+std::to_wstring(pipeCompleted)+L"，pipePeak="+std::to_wstring(pipePeakInFlight)+
            L"，pipeBeginCall="+std::to_wstring(pipeBeginCallMs)+L"ms，pipeWaitCall="+std::to_wstring(pipeWaitCallMs)+
            L"ms，pipeLatencySum="+std::to_wstring(pipeLatencyMs)+L"ms，pipeMaxWait="+std::to_wstring(pipeMaxWaitMs)+
            L"ms，pipeBeginFail="+std::to_wstring(pipeBeginFailures)+L"，pipeFinishFail="+std::to_wstring(pipeFinishFailures)+
            L"，pipeFallback="+std::to_wstring(pipeFallbacks)+L"，finalCadence="+std::to_wstring(bulkCadenceMs)+
            L"ms，MaxPdu="+std::to_wstring(ble_.MaxPduSize()));
    };

    // V2.3.8a: preserve a device-side residency bit across GUI song changes.
    // The second upload gets a stronger scheduler/AUTO reset; the first upload
    // keeps the historical non-fatal CLOSE behavior.
    ResetCrossSongState(replacingResidentSheet,status);

    // V2.3.15: do NOT force set_volume ch05 during upload. Real-device tests
    // proved ch05 reads/writes/persists but does not control the active MDS tk0
    // lead. Keep sheet lead loudness/tone exclusively in INT25/INT26 scheduling.
    // Known successful send-order profiles. In V2.3.8a they preserve timing/order only;
    // INT25 itself is generated from the current JSON before entering these branches.
    const bool exactUlaan=(plan_.officialFlowProfile==C2OfficialFlowProfile::UlaanAdvanced20260821);
    const bool exactOurTime=(plan_.officialFlowProfile==C2OfficialFlowProfile::OurTimeAdvanced20260821);
    const bool exactOurTimeNormal=(plan_.officialFlowProfile==C2OfficialFlowProfile::OurTimeNormal202607Capture);
    if (exactUlaan || exactOurTime || exactOurTimeNormal) {
        auto queryStringData=[&](const std::string& cmd,const std::vector<std::uint8_t>& q,int delay=10)->bool {
            C2DecodedPacket reply;
            if (!SendString(cmd,q,error,{},delay)) return false;
            return ReadExpectedString(cmd,reply,error,status,6);
        };
        // V2.3.15: ch05 is retained as a device mixer register for diagnostics only.
        // Real-device testing proved set_volume 05 00/32/64 reads back correctly but
        // does NOT mute/scale the currently running sheet tk0 lead. Do not force it
        // during upload; sheet lead volume/tone belongs to INT25/INT26 scheduling.
        auto ensureLeadVolume100=[&]()->bool {
            C2DecodedPacket reply;
            if (!SendString("get_volume",{},error,{},10)) return false;
            if (!ReadExpectedString("get_volume",reply,error,status,6)) return false;
            int master=-1, ch05=-1, arp=-1;
            if (!reply.data.empty()) {
                const std::size_t count=reply.data[0];
                for (std::size_t i=0;i<count && 2+2*i<reply.data.size();++i) {
                    const int ch=reply.data[1+2*i];
                    const int value=reply.data[2+2*i];
                    if (ch==0x01) master=value;
                    else if (ch==0x05) ch05=value;
                    else if (ch==0x0D) arp=value;
                }
            }
            if (status) status(L"C2 Mixer诊断：ch01="+std::to_wstring(master)+
                L"，ch05="+std::to_wstring(ch05)+L"（非sheet主旋律实时音量），ch0D="+std::to_wstring(arp));
            return true;
        };
        auto sendCreate=[&]()->bool {
            if (!Send(C2CmdId::CREATE_SHEET,plan_.createPayload,error,status,35)) return false;
            C2DecodedPacket reply;
            if (!ReadExpectedInt(C2CmdId::CREATE_SHEET,reply,error,status,6)) return false;
            if (reply.data.empty() || reply.data[0]!=0x01) { error=L"C2 CREATE 未返回成功(01)"; return false; }
            deviceSheetResident_.store(true);
            return true;
        };
        const int total=static_cast<int>(plan_.fillPayloads.size());
        int nextFill=0;
        auto sendFill=[&](int /*legacyDelay*/=12)->bool {
            if (nextFill>=total) return true;
            if (!sendBulk(C2CmdId::FILL_SHEET,plan_.fillPayloads[static_cast<std::size_t>(nextFill)])) return false;
            ++nextFill;
            if (progress && (nextFill<=12 || nextFill%8==0 || nextFill==total)) progress(nextFill,total);
            return true;
        };
        auto sendInt25=[&](std::size_t page)->bool {
            if (page>=plan_.int25Payloads.size()) { error=L"INT25 页索引越界"; return false; }
            if (status) status(L"TX generated INT25 page "+std::to_wstring(page)+L"/"+
                std::to_wstring(plan_.int25Payloads.size()-1)+L" data="+
                std::to_wstring(plan_.int25Payloads[page].size())+L"B");
            return sendBulk(C2CmdId::SET_TRACK_CREATE,plan_.int25Payloads[page]);
        };
        auto sendTrackInstrument=[&](const C2TrackSetup& t)->bool {
            if (t.instrument.empty() || t.instrument.size()>255) return t.instrument.empty();
            std::vector<std::uint8_t> d{t.tkid,static_cast<std::uint8_t>(t.instrument.size())};
            d.insert(d.end(),t.instrument.begin(),t.instrument.end());
            return Send(C2CmdId::SET_TRACK_INSTRUMENT,d,error,status,12);
        };
        auto sendTrackVolume=[&](std::uint8_t tk,int vol)->bool {
            return Send(C2CmdId::SET_TRACK_VOLUME,{tk,static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(127,vol)))},error,status,12);
        };
        auto readAutoAndNormalizeType2=[&](int expectedType2)->bool {
            C2DecodedPacket autoReply;
            if (!Send(C2CmdId::GET_AUTO_PLAY,{},error,{},12)) return false;
            if (!ReadExpectedInt(C2CmdId::GET_AUTO_PLAY,autoReply,error,status,6)) return false;
            int type2=-1;
            if (!autoReply.data.empty()) {
                const std::size_t n=autoReply.data[0];
                for (std::size_t i=0;i<n && 2+2*i<autoReply.data.size();++i)
                    if (autoReply.data[1+2*i]==2) type2=autoReply.data[2+2*i];
            }
            if (status) status(L"GET_AUTO type2="+std::to_wstring(type2)+L"；本曲抓包目标="+std::to_wstring(expectedType2));
            if (type2>=0 && type2!=expectedType2) {
                if (status) status(L"切换歌曲状态：SET_AUTO_PLAY type2 -> "+std::to_wstring(expectedType2));
                if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,static_cast<std::uint8_t>(expectedType2)},error,status,18)) return false;
            }
            return true;
        };

        if (exactUlaan) {
            // Exact order reconstructed from btsnoop_hci乌兰巴托的夜_进阶版_.log,
            // successful session beginning at relative 8301.446692 s.
            if (status) status(L"V2.3.13《乌兰巴托的夜》已验证时序 + 当前 JSON 动态 CREATE/FILL/INT25");
            if (!sendCreate()) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!SendRemindChord(error,status)) return false;                         // 05 00 00
            if (!queryStringData("get_midi_info",{})) return false;
            if (!Send(C2CmdId::SET_SECTION_RANGE,plan_.sectionRangePayload,error,status,12)) return false;
            if (!queryStringData("get_sys_onoff",{0x06})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!SendString("set_config_v2pack",plan_.configV2PackPayload,error,status,12)) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!ensureLeadVolume100()) return false;

            // Captured base channels are all 0x5A (90) in this session.
            if (!SendString("set_volume",{0x09,0x5A},error,{},12)) return false;
            if (!queryStringData("get_volume",{})) return false;
            if (!queryStringData("get_volume",{})) return false;
            if (!SendString("set_volume",{0x0A,0x5A},error,{},12)) return false;
            if (!sendInt25(0)) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!SendString("set_volume",{0x0B,0x5A},error,{},12)) return false;
            if (!sendInt25(1)) return false;
            if (!queryStringData("get_sys_onoff",{0x06})) return false;
            if (!SendString("set_volume",{0x0C,0x5A},error,{},12)) return false;
            if (!sendInt25(2)) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!sendInt25(3)) return false;
            if (!readAutoAndNormalizeType2(1)) return false;                         // official response type2=1
            if (!sendInt25(4)) return false;
            if (!SendPreLevel(3,error,status)) return false;
            if (!SendString("set_guitar_mode",{0x02},error,status,12)) return false;
            if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,status,12)) return false;
            if (!sendInt25(5)) return false;
            if (!Send(C2CmdId::SET_AUTO_PLAY,{0x01,0x01},error,status,12)) return false;
            if (!sendInt25(6) || !sendInt25(7)) return false;

            // Exact per-track setup. tk10 is generated by the official app and
            // is absent from the raw JSON trackConfigs; omitting it is the main
            // reason V2.3.4 could never reproduce the multi-track sound.
            if (!sendTrackVolume(3,72) || !sendTrackVolume(4,64)) return false;
            for (int tk=10;tk>=4;--tk) {
                auto it=std::find_if(plan_.trackSetup.begin(),plan_.trackSetup.end(),[&](const C2TrackSetup& t){return t.tkid==tk;});
                if (it==plan_.trackSetup.end() || !sendTrackInstrument(*it)) return false;
            }
            if (!sendFill()) return false;                                           // FILL #0
            {
                auto it=std::find_if(plan_.trackSetup.begin(),plan_.trackSetup.end(),[](const C2TrackSetup& t){return t.tkid==3;});
                if (it==plan_.trackSetup.end() || !sendTrackInstrument(*it)) return false;
            }
            if (!sendTrackVolume(10,50)) return false;
            const auto pos=C2MusicEncoder::BuildPositionPayload(0.0f,11);
            stageReady29_.store(false);
            if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
            if (!sendFill()) return false;                                           // FILL #1
            for (int waited=0;waited<160 && !stageReady29_.load();waited+=10)
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if (status) status(stageReady29_.load()?L"RX Notify29=01：Ulaan 第一阶段就绪":L"提示：Ulaan 未捕获 Notify29=01，继续按官方顺序");
            if (!sendTrackVolume(9,43) || !sendTrackVolume(8,36)) return false;
            if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
            if (!sendFill()) return false;                                           // FILL #2
            if (!sendTrackVolume(7,58) || !sendTrackVolume(6,15)) return false;
            if (!sendFill()) return false;                                           // FILL #3
            if (!sendTrackVolume(5,25)) return false;
            while (nextFill<total) if (!sendFill()) return false;

            if (armKeyPlayAfterUpload) {
                if (!VerifySheetBeat(0.0f,error,status)) return false;
                uploaded_.store(true); armed_.store(true);
                if (status) status(L"《乌兰巴托的夜》C2 官方11轨数据已全部下发；等待实体按键。主旋律/铺底/加花均由 C2 自身调度。");
            } else {
                uploaded_.store(true); armed_.store(false);
            }
            reportBulk(L"UlaanExact");
            return true;
        }

        if (exactOurTimeNormal) {
            // Exact successful normal 《我们的时光》 sequence from the earlier official capture.
            // Most importantly, force type2 back to 0 BEFORE CREATE so a previous Ulaan
            // multi-track session cannot leak its type2=1 state into this 3-track song.
            if (status) status(L"V2.3.13《我们的时光》普通版：动态 INT25 + 已验证时序，先清除上一首多轨 type2 状态");
            if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,0x00},error,status,18)) return false;
            if (!SendRemindChord(error,status)) return false;
            if (!sendCreate()) return false;
            if (!Send(C2CmdId::SET_SECTION_RANGE,plan_.sectionRangePayload,error,status,12)) return false;
            if (!queryStringData("get_midi_info",{})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!SendString("set_config_v2pack",plan_.configV2PackPayload,error,status,12)) return false;
            if (!ensureLeadVolume100()) return false;
            if (!SendString("set_volume",{0x09,0x64},error,{},12)) return false;
            if (!sendInt25(0)) return false;
            if (!SendString("set_volume",{0x0A,0x64},error,{},12)) return false;
            if (!sendFill()) return false;                                                // #0
            if (!SendString("set_volume",{0x0B,0x64},error,{},12)) return false;
            if (!sendFill()) return false;                                                // #1
            const auto pos=C2MusicEncoder::BuildPositionPayload(0.0f,3);
            if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
            if (!SendString("set_volume",{0x0C,0x64},error,{},12)) return false;
            stageReady29_.store(false);
            if (!sendFill()) return false;                                                // #2
            for (int waited=0;waited<160 && !stageReady29_.load();waited+=10)
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!queryStringData("get_config_v2basic",{})) return false;
            if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
            if (!readAutoAndNormalizeType2(0)) return false;
            if (!SendRemindChord(error,status)) return false;
            if (!sendFill()) return false;                                                // #3
            if (!SendString("set_guitar_mode",{0x02},error,status,12)) return false;
            const int cue=CueLevelForBeat(-2.0f);
            if (cue>=0 && !SendPreLevel(cue,error,status)) return false;
            if (!sendFill()) return false;                                                // #4
            if (!Send(C2CmdId::SET_AUTO_PLAY,{0x01,0x01},error,status,12)) return false;
            if (!sendFill()) return false;                                                // #5
            if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
            for (int i=0;i<5 && nextFill<total;++i) if (!sendFill()) return false;        // #6..#10
            if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,status,12)) return false;
            while (nextFill<total) if (!sendFill()) return false;
            if (armKeyPlayAfterUpload) {
                if (!VerifySheetBeat(0.0f,error,status)) return false;
                uploaded_.store(true); armed_.store(true);
                if (status) status(L"《我们的时光》普通版已恢复官方 type2=0 / beat0；等待实体按键，红线应随 noti_chord 前进。");
            } else { uploaded_.store(true); armed_.store(false); }
            reportBulk(L"OurTimeNormalExact");
            return true;
        }

        // Exact successful 《我们的时光（进阶版）》 session from the same new log.
        if (status) status(L"V2.3.13《我们的时光（进阶版）》动态 INT25 + 已验证时序；先把跨歌曲 type2 状态恢复为0");
        if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,0x00},error,status,18)) return false;
        if (!sendCreate()) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!SendRemindChord(error,status)) return false;
        if (!queryStringData("get_midi_info",{})) return false;
        if (!Send(C2CmdId::SET_SECTION_RANGE,plan_.sectionRangePayload,error,status,12)) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!SendString("set_config_v2pack",plan_.configV2PackPayload,error,status,12)) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!ensureLeadVolume100()) return false;
        if (!SendString("set_volume",{0x09,0x64},error,{},12)) return false;
        if (!queryStringData("get_volume",{})) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!SendString("set_volume",{0x0A,0x64},error,{},12)) return false;
        if (!sendInt25(0)) return false;
        if (!queryStringData("get_sys_onoff",{0x06})) return false;
        if (!SendString("set_volume",{0x0B,0x64},error,{},12)) return false;
        if (!sendFill()) return false;                                                // FILL #0
        if (!SendString("set_volume",{0x0C,0x64},error,{},12)) return false;
        stageReady29_.store(false);
        if (!Send(C2CmdId::SET_SHEET_BEAT,C2MusicEncoder::BuildPositionPayload(0.0f,3),error,status,12)) return false;
        if (!sendFill()) return false;                                                // FILL #1
        for (int waited=0;waited<160 && !stageReady29_.load();waited+=10)
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!queryStringData("get_config_v2basic",{})) return false;
        if (!readAutoAndNormalizeType2(0)) return false;                              // official response type2=0
        const auto pos=InitialPosition();                                             // beat4, 3 tracks
        if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
        if (!SendRemindChord(error,status)) return false;
        if (!SendString("set_guitar_mode",{0x02},error,status,12)) return false;
        const int cue=CueLevelForBeat(plan_.initialBeat-2.0f);
        if (cue>=0 && !SendPreLevel(cue,error,status)) return false;
        if (!sendFill()) return false;                                                // #2
        if (!Send(C2CmdId::SET_AUTO_PLAY,{0x01,0x01},error,status,12)) return false;
        if (!sendFill()) return false;                                                // #3
        if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,12)) return false;
        if (!sendFill() || !sendFill() || !sendFill()) return false;                  // #4..#6
        if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,status,12)) return false;
        while (nextFill<total) if (!sendFill()) return false;
        if (armKeyPlayAfterUpload) {
            if (!VerifySheetBeat(plan_.initialBeat,error,status)) return false;
            uploaded_.store(true); armed_.store(true);
            if (status) status(L"《我们的时光（进阶版）》已按新抓包恢复：目标 beat4，等待实体按键；首次正确通知应带 beat≈4。");
        } else {
            uploaded_.store(true); armed_.store(false);
        }
        reportBulk(L"OurTimeAdvancedExact");
        return true;
    }


    // Cross-song CLOSE/reset has already been performed above.

    // Successful official sessions send the first chord reminder immediately
    // before CREATE. Advanced 《我们的时光》 = 09 01 00 (A minor).
    if (armKeyPlayAfterUpload && !SendRemindChord(error,status)) return false;

    // CREATE must be followed by the A102 int-6 acknowledgement. Previous PC
    // revisions wrote CREATE and immediately continued, unlike the app.
    if (!Send(C2CmdId::CREATE_SHEET,plan_.createPayload,error,status,35)) return false;
    C2DecodedPacket createReply;
    if (!ReadExpectedInt(C2CmdId::CREATE_SHEET,createReply,error,status,5)) return false;
    if (createReply.data.empty() || createReply.data[0]!=0x01) {
        error=L"C2 CREATE 未返回成功(01)"; return false;
    }
    deviceSheetResident_.store(true);

    if (!plan_.sectionRangePayload.empty() &&
        !Send(C2CmdId::SET_SECTION_RANGE,plan_.sectionRangePayload,error,status,12)) return false;

    // Exact query/read pairs from the btsnoop setup sequence.
    auto queryString=[&](const std::string& cmd,int writeDelay,C2DecodedPacket* out=nullptr)->bool {
        C2DecodedPacket reply;
        if (!SendString(cmd,{},error,{},writeDelay)) return false;
        if (!ReadExpectedString(cmd,reply,error,status,5)) return false;
        if (out) *out=reply;
        return true;
    };
    if (!queryString("get_midi_info",8)) return false;
    if (!queryString("get_config_v2basic",8)) return false;
    C2DecodedPacket initialVolumeReply;
    if (!queryString("get_volume",8,&initialVolumeReply)) return false;
    {
        int master=-1, lead=-1, arp=-1;
        if (!initialVolumeReply.data.empty()) {
            const std::size_t n=initialVolumeReply.data[0];
            for (std::size_t i=0;i<n && 2+2*i<initialVolumeReply.data.size();++i) {
                const int ch=initialVolumeReply.data[1+2*i];
                const int value=initialVolumeReply.data[2+2*i];
                if (ch==0x01) master=value;
                else if (ch==0x05) lead=value;
                else if (ch==0x0D) arp=value;
            }
        }
        if (status) status(L"C2 Mixer诊断：ch01="+std::to_wstring(master)+
            L"，ch05="+std::to_wstring(lead)+L"（仅设备Mixer寄存器），ch0D="+std::to_wstring(arp)+
            L"；V2.3.15 不自动改写 ch05");
    }

    const bool haveV2Config=!plan_.configV2PackPayload.empty();
    const bool haveExtraTracks=!plan_.trackSetup.empty();
    if (haveV2Config) {
        if (!SendString("set_config_v2pack",plan_.configV2PackPayload,error,status,12)) return false;

        // Read back only for diagnostics. Do not force ch05: real-device tests
        // show it is not the active MDS tk0 gain control.
        C2DecodedPacket postConfigVolume;
        if (!queryString("get_volume",8,&postConfigVolume)) return false;
        int ch05=-1;
        if (!postConfigVolume.data.empty()) {
            const std::size_t n=postConfigVolume.data[0];
            for (std::size_t i=0;i<n && 2+2*i<postConfigVolume.data.size();++i)
                if (postConfigVolume.data[1+2*i]==0x05) ch05=postConfigVolume.data[2+2*i];
        }
        if (status) status(L"configV2Pack 后 ch05="+std::to_wstring(ch05)+
            L"（记录但不作为 sheet tk0 音量）");
    }

    // V2.3.4 audit finding: configV2Pack and per-track configuration are NOT
    // mutually exclusive. In the successful official 10-track btsnoop session
    // both are sent. V2.3.3 incorrectly skipped every SET_TRACK_INS/VOLUME when
    // configPack existed, leaving extra-track notes resident but not configured.
    auto sendTrackInstrument=[&](const C2TrackSetup& t)->bool {
        if (t.instrument.empty()) return true;
        if (t.instrument.size()>255) { error=L"音色字符串过长"; return false; }
        std::vector<std::uint8_t> d{t.tkid,static_cast<std::uint8_t>(t.instrument.size())};
        d.insert(d.end(),t.instrument.begin(),t.instrument.end());
        return Send(C2CmdId::SET_TRACK_INSTRUMENT,d,error,status,12);
    };
    auto sendTrackVolume=[&](const C2TrackSetup& t)->bool {
        return Send(C2CmdId::SET_TRACK_VOLUME,
            {t.tkid,static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(127,t.volume)))},
            error,status,12);
    };

    const int total=static_cast<int>(plan_.fillPayloads.size());
    int nextFill=0;
    auto sendFill=[&](int /*legacyDelayMs*/=12)->bool {
        if (nextFill>=total) return true;
        const auto& src=plan_.fillPayloads[static_cast<std::size_t>(nextFill)];
        const auto maxGatt=ble_.MaxGattWriteValueBytes();
        const std::size_t maxFillData=(maxGatt>21)?std::min<std::size_t>(460,maxGatt-21):0;
        if (maxFillData>=32 && src.size()>maxFillData) {
            std::vector<std::vector<std::uint8_t>> chunks;
            if (!SplitGeneratedFill(src,maxFillData,chunks)) {
                error=L"460B WR-Pack TEST: 单个超大FILL无法按item边界拆分，data="+std::to_wstring(src.size())+L"B";
                return false;
            }
            ++fillSplitOriginals;
            fillSplitWrites+=chunks.size();
            if (status) status(L"超大FILL拆分：logical="+std::to_wstring(nextFill+1)+L"/"+std::to_wstring(total)+
                L"，data="+std::to_wstring(src.size())+L"B -> "+std::to_wstring(chunks.size())+L"包");
            for (const auto& chunk:chunks)
                if (!sendBulk(C2CmdId::FILL_SHEET,chunk)) return false;
        } else {
            if (!sendBulk(C2CmdId::FILL_SHEET,src)) return false;
        }
        ++nextFill;
        if (progress && (nextFill<=12 || nextFill%8==0 || nextFill==total)) progress(nextFill,total);
        return true;
    };

    // Only the final generic FILL tail is eligible for MTU batching. The first
    // 10 FILLs remain byte-for-byte and order-for-order interleaved with the
    // proven volume/SET_BEAT/AUTO/track setup sequence above. This is the slow
    // progress-counter phase visible in the main window.
    auto sendRemainingFillTail=[&]()->bool {
        if (nextFill>=total) return true;
        const auto maxGatt=ble_.MaxGattWriteValueBytes();
        // Keep V2.3.20g's user-verified receiver-capacity result: 460B FILL data
        // -> 481B TLVC/A103 value, fitting inside MTU500's 497B ATT value.
        const std::size_t maxFillData=(maxGatt>21)?std::min<std::size_t>(460,maxGatt-21):0;
        // MTU batching is independent of WriteWithoutResponse. On this user's
        // Windows stack A103 advertises WriteWithResponse only, while MTU500
        // and 469B INT25 pages are already proven. Use 460B FILL batching with
        // WriteWithResponse as well; only the async depth-2 pipeline requires WNR.
        const bool mtuPackEnabled=ble_.MaxPduSize()>=247 && maxFillData>=223;
        bool pipelineEnabled=mtuPackEnabled && ble_.SupportsWriteWithoutResponse();
        constexpr std::size_t kPipelineDepth=2;

        if (status) {
            std::size_t probe=static_cast<std::size_t>(nextFill),estimatedWrites=0;
            std::size_t estimatedPackedWrites=0,estimatedPackedOriginals=0,estimatedMaxGroup=0,estimatedMaxData=0;
            std::size_t estimatedSplitOriginals=0,estimatedSplitWrites=0;
            while (probe<plan_.fillPayloads.size()) {
                const auto& src=plan_.fillPayloads[probe];
                if (mtuPackEnabled && src.size()>maxFillData) {
                    std::vector<std::vector<std::uint8_t>> chunks;
                    if (SplitGeneratedFill(src,maxFillData,chunks)) {
                        ++estimatedSplitOriginals;
                        estimatedSplitWrites+=chunks.size();
                        estimatedWrites+=chunks.size();
                        ++probe;
                        continue;
                    }
                }
                std::size_t consumed=0;
                std::vector<std::uint8_t> mergedProbe;
                if (mtuPackEnabled && BuildGreedyMergedFill(plan_.fillPayloads,probe,maxFillData,consumed,mergedProbe) && consumed>=2) {
                    probe+=consumed;
                    ++estimatedPackedWrites;
                    estimatedPackedOriginals+=consumed;
                    estimatedMaxGroup=std::max(estimatedMaxGroup,consumed);
                    estimatedMaxData=std::max(estimatedMaxData,mergedProbe.size());
                } else {
                    ++probe;
                }
                ++estimatedWrites;
            }
            status(std::wstring(L"FILL尾段：从原始#")+std::to_wstring(nextFill)+L"开始；动态MTU合包="+
                (mtuPackEnabled?L"ON":L"OFF")+L"，Pipeline2="+(pipelineEnabled?L"ON":L"OFF")+
                L"，MaxPdu="+std::to_wstring(ble_.MaxPduSize())+L"，FILL data上限="+
                std::to_wstring(maxFillData)+L"B，TLVC最大约="+std::to_wstring(maxFillData+21)+L"B");
            status(L"FILL尾段预计：原始="+std::to_wstring(total-nextFill)+L"包 -> 物理写约="+
                std::to_wstring(estimatedWrites)+L"次；聚合写="+std::to_wstring(estimatedPackedWrites)+
                L"，聚合原包="+std::to_wstring(estimatedPackedOriginals)+L"，超大原包="+
                std::to_wstring(estimatedSplitOriginals)+L"，拆分写="+std::to_wstring(estimatedSplitWrites)+
                L"，单次最多合="+std::to_wstring(estimatedMaxGroup)+L"包，最大聚合data="+std::to_wstring(estimatedMaxData)+L"B");
            if (pipelineEnabled) status(L"Pipeline2策略：最多2个A103 WriteWithoutResponse异步操作在途；不额外Sleep；若第二个异步提交失败则排空并退回串行18ms。异步完成失败为避免重复/乱序将停止上传。");
        }

        struct PendingFillWrite {
            C2BleClient::AsyncWriteOperation operation{nullptr};
            std::size_t dataBytes=0;
            std::size_t packetBytes=0;
            std::size_t originalCount=0;
            std::size_t packedDataBytes=0;
            bool packed=false;
            bool reportProgress=true;
            int logicalDone=0;
            BulkClock::time_point submittedAt{};
        };
        std::deque<PendingFillWrite> pending;

        auto noteFillSuccess=[&](const PendingFillWrite& p) {
            ++bulkWrites;
            bulkBytes+=p.dataBytes;
            if (p.packed) {
                ++fillPackedWrites;
                fillPackedOriginals+=p.originalCount;
                fillPackedMaxOriginals=std::max(fillPackedMaxOriginals,p.originalCount);
                fillPackedMaxData=std::max(fillPackedMaxData,p.packedDataBytes);
            }
            if (progress && p.reportProgress) progress(p.logicalDone,total);
        };

        auto finishOldest=[&]()->bool {
            if (pending.empty()) return true;
            PendingFillWrite p=std::move(pending.front());
            pending.pop_front();
            const auto wait0=BulkClock::now();
            std::wstring writeErr;
            const bool ok=ble_.FinishWritePacket(p.operation,writeErr);
            const auto wait1=BulkClock::now();
            const long long waitMs=static_cast<long long>(std::chrono::duration_cast<std::chrono::milliseconds>(wait1-wait0).count());
            const long long latencyMs=std::chrono::duration_cast<std::chrono::milliseconds>(wait1-p.submittedAt).count();
            pipeWaitCallMs+=waitMs;
            pipeLatencyMs+=latencyMs;
            pipeMaxWaitMs=std::max(pipeMaxWaitMs,waitMs);
            if (!ok) {
                ++pipeFinishFailures;
                // A WriteWithoutResponse completion failure does not prove whether C2
                // consumed the frame. Retrying could duplicate items, so drain the
                // remaining submitted operation(s) best-effort and abort safely.
                while (!pending.empty()) {
                    auto rest=std::move(pending.front()); pending.pop_front();
                    std::wstring ignored;
                    ble_.FinishWritePacket(rest.operation,ignored);
                }
                error=L"Pipeline2 异步完成失败；为避免重复FILL/乱序不重发当前包："+writeErr;
                return false;
            }
            ++pipeCompleted;
            noteFillSuccess(p);
            if (status && (pipeCompleted<=4 || pipeCompleted%16==0)) {
                status(L"Pipeline2完成：completed="+std::to_wstring(pipeCompleted)+
                    L"，inFlight="+std::to_wstring(pending.size())+L"，本次wait="+
                    std::to_wstring(waitMs)+L"ms，submit->complete="+std::to_wstring(latencyMs)+
                    L"ms，进度="+std::to_wstring(p.logicalDone)+L"/"+std::to_wstring(total));
            }
            return true;
        };

        auto sendCandidate=[&](const std::vector<std::uint8_t>& data,std::size_t originals,bool packed,int logicalDone,bool reportProgress)->bool {
            if (pipelineEnabled) {
                while (pending.size()>=kPipelineDepth) if (!finishOldest()) return false;
                const auto packet=C2Protocol::EncodeIntCommand(C2CmdId::FILL_SHEET,data);
                if (packet.empty()) { error=L"Pipeline2: FILL TLVC编码失败"; return false; }
                const auto maxValue=ble_.MaxGattWriteValueBytes();
                if (ble_.MaxPduSize()>23 && maxValue>0 && packet.size()>maxValue) {
                    error=L"Pipeline2: FILL packet="+std::to_wstring(packet.size())+L"B > ATT value上限="+std::to_wstring(maxValue)+L"B";
                    return false;
                }
                C2BleClient::AsyncWriteOperation op{nullptr};
                std::wstring beginErr;
                const auto b0=BulkClock::now();
                const bool begun=ble_.BeginWritePacket(packet,op,beginErr);
                const auto b1=BulkClock::now();
                pipeBeginCallMs+=std::chrono::duration_cast<std::chrono::milliseconds>(b1-b0).count();
                if (begun) {
                    PendingFillWrite p;
                    p.operation=std::move(op); p.dataBytes=data.size(); p.packetBytes=packet.size();
                    p.originalCount=originals; p.packedDataBytes=data.size(); p.packed=packed;
                    p.reportProgress=reportProgress; p.logicalDone=logicalDone; p.submittedAt=b1;
                    pending.push_back(std::move(p));
                    ++pipeSubmitted;
                    pipePeakInFlight=std::max(pipePeakInFlight,pending.size());
                    if (status && pipeSubmitted<=4) status(L"Pipeline2提交：#"+std::to_wstring(pipeSubmitted)+
                        L" packet="+std::to_wstring(packet.size())+L"B，originalFILL="+
                        std::to_wstring(originals)+L"，inFlight="+std::to_wstring(pending.size()));
                    return true;
                }

                // Begin failure means the current packet was not accepted as an
                // async operation. Existing submitted packets are completed in order,
                // then this and all later FILLs fall back to the proven serial path.
                ++pipeBeginFailures;
                while (!pending.empty()) if (!finishOldest()) return false;
                pipelineEnabled=false;
                ++pipeFallbacks;
                if (bulkCadenceMs<18) bulkCadenceMs=18;
                if (status) status(L"Pipeline2提交失败，安全退回串行18ms；当前包尚未提交，可正常重发。原因："+beginErr);
            }

            if (bulkCadenceMs<18) bulkCadenceMs=18;
            if (!sendBulk(C2CmdId::FILL_SHEET,data)) return false;
            PendingFillWrite done;
            done.dataBytes=data.size(); done.originalCount=originals; done.packedDataBytes=data.size();
            done.packed=packed; done.reportProgress=reportProgress; done.logicalDone=logicalDone;
            // sendBulk already counted bulkWrites/bulkBytes; only account FILL-pack
            // and GUI progress here to avoid double-counting transport statistics.
            if (done.packed) {
                ++fillPackedWrites; fillPackedOriginals+=done.originalCount;
                fillPackedMaxOriginals=std::max(fillPackedMaxOriginals,done.originalCount);
                fillPackedMaxData=std::max(fillPackedMaxData,done.packedDataBytes);
            }
            if (progress && done.reportProgress) progress(done.logicalDone,total);
            return true;
        };

        while (nextFill<total) {
            ++fillPackCandidates;
            const auto& src=plan_.fillPayloads[static_cast<std::size_t>(nextFill)];

            // A few dense beats can produce one original FILL larger than the
            // MTU500 ATT-value budget. Split only that logical FILL at item
            // boundaries, preserving every item and order, then advance the
            // logical progress once all pieces were sent.
            if (mtuPackEnabled && src.size()>maxFillData) {
                std::vector<std::vector<std::uint8_t>> chunks;
                if (!SplitGeneratedFill(src,maxFillData,chunks)) {
                    error=L"460B WR-Pack TEST: 超大FILL拆分失败，logical="+std::to_wstring(nextFill+1)+
                        L"，data="+std::to_wstring(src.size())+L"B";
                    return false;
                }
                ++fillSplitOriginals;
                fillSplitWrites+=chunks.size();
                if (status) status(L"超大FILL拆分：logical="+std::to_wstring(nextFill+1)+L"/"+std::to_wstring(total)+
                    L"，data="+std::to_wstring(src.size())+L"B -> "+std::to_wstring(chunks.size())+L"包");
                for (std::size_t ci=0;ci<chunks.size();++ci) {
                    const bool last=(ci+1==chunks.size());
                    if (!sendCandidate(chunks[ci],1,false,last?nextFill+1:nextFill,last)) return false;
                }
                ++nextFill;
                continue;
            }

            std::size_t consumed=0;
            std::vector<std::uint8_t> merged;
            bool packed=false;
            const std::vector<std::uint8_t>* data=&src;
            if (mtuPackEnabled && BuildGreedyMergedFill(plan_.fillPayloads,static_cast<std::size_t>(nextFill),maxFillData,consumed,merged) && consumed>=2) {
                data=&merged; packed=true;
            } else {
                consumed=1;
            }
            const int logicalDone=nextFill+static_cast<int>(consumed);
            if (!sendCandidate(*data,consumed,packed,logicalDone,true)) return false;
            nextFill=logicalDone;
        }
        while (!pending.empty()) if (!finishOldest()) return false;
        if (status && pipeSubmitted>0) status(L"Pipeline2尾段排空完成：submitted="+std::to_wstring(pipeSubmitted)+
            L"，completed="+std::to_wstring(pipeCompleted)+L"，peakInFlight="+
            std::to_wstring(pipePeakInFlight)+L"，beginCall累计="+std::to_wstring(pipeBeginCallMs)+
            L"ms，waitCall累计="+std::to_wstring(pipeWaitCallMs)+L"ms");
        return true;
    };

    const auto zeroPos=C2MusicEncoder::BuildPositionPayload(0.0f,plan_.descriptors.size());
    const auto initialPos=InitialPosition();
    auto sendGeneratedInt25=[&]()->bool {
        if (plan_.int25Payloads.empty()) return true;
        if (status) status(L"TX 通用 SET_TRACK_CREATE/INT25："+std::to_wstring(plan_.int25SectionCount)+
            L" sections, body="+std::to_wstring(plan_.int25BodyBytes)+L"B, pages="+
            std::to_wstring(plan_.int25Payloads.size()));
        for (std::size_t i=0;i<plan_.int25Payloads.size();++i) {
            if (status) status(L"TX INT25 page "+std::to_wstring(i)+L"/"+
                std::to_wstring(plan_.int25Payloads.size()-1)+L" data="+
                std::to_wstring(plan_.int25Payloads[i].size())+L"B");
            if (!sendBulk(C2CmdId::SET_TRACK_CREATE,plan_.int25Payloads[i])) return false;
        }
        return true;
    };

    if (haveExtraTracks) {
        // Multi-track generic path. INT25 is generated directly from type14 +
        // trackConfigs + extraTracks and no longer depends on songId capture data.
        if (status) status(L"检测到额外轨：V2.3.13 将发送当前 JSON 动态生成的 INT25 轨道区间调度。 ");
        if (haveV2Config && plan_.channelVolumePayloads.size()>=4) {
            for (const auto& v:plan_.channelVolumePayloads)
                if (!SendString("set_volume",v,error,{},12)) return false;
        }
        stageReady29_.store(false);
    } else if (haveV2Config && plan_.channelVolumePayloads.size()>=4) {
        // V2.3.13: generic 3-track order corrected against successful C2 capture.
        // tk0 INT25 must already be resident before the early LEAD FILLs:
        // vol09 -> INT25 -> vol0A/F0 -> vol0B/F1 -> SET_BEAT0 -> vol0C/F2.
        stageReady29_.store(false);
        if (!SendString("set_volume",plan_.channelVolumePayloads[0],error,{},12)) return false;
        if (!sendGeneratedInt25()) return false;
        if (!SendString("set_volume",plan_.channelVolumePayloads[1],error,{},12) || !sendFill()) return false;
        if (!SendString("set_volume",plan_.channelVolumePayloads[2],error,{},12) || !sendFill()) return false;
        if (!Send(C2CmdId::SET_SHEET_BEAT,zeroPos,error,status,12)) return false;
        if (!SendString("set_volume",plan_.channelVolumePayloads[3],error,{},12) || !sendFill()) return false;
    } else {
        for (int i=0;i<std::min<int>(4,total);++i) if (!sendFill()) return false;
        if (!Send(C2CmdId::SET_SHEET_BEAT,zeroPos,error,status,20)) return false;
    }

    if (haveExtraTracks && plan_.int25Payloads.empty()) {
        error=L"多轨 JSON 未能生成 INT25/SET_TRACK_CREATE；为避免静音/错误调度，停止上传";
        return false;
    }
    if (haveExtraTracks || !haveV2Config) {
        if (!sendGeneratedInt25()) return false;
    }

    if (armKeyPlayAfterUpload) {
        // Three GET_CONFIG pairs are observed in the successful song setup.
        if (!queryString("get_config_v2basic",8)) return false;
        for (int waited=0; waited<120 && !stageReady29_.load(); waited+=10)
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        if (status) status(stageReady29_.load() ?
            L"RX Notify29=01：C2 第一阶段曲谱已就绪" :
            L"提示：未见 Notify29=01，继续以 A102 回读结果为准");
        if (!queryString("get_config_v2basic",8)) return false;
        if (!queryString("get_config_v2basic",8)) return false;

        C2DecodedPacket autoReply;
        if (!haveExtraTracks) {
            // 3-track capture positions the sheet before GET_AUTO.
            if (!Send(C2CmdId::SET_SHEET_BEAT,initialPos,error,status,15)) return false;
        }
        if (!Send(C2CmdId::GET_AUTO_PLAY,{},error,{},12)) return false;
        if (!ReadExpectedInt(C2CmdId::GET_AUTO_PLAY,autoReply,error,status,5)) return false;

        int autoType2=-1;
        if (!autoReply.data.empty()) {
            const std::size_t n=autoReply.data[0];
            for (std::size_t i=0;i<n && 2+2*i<autoReply.data.size();++i) {
                const int type=autoReply.data[1+2*i];
                const int state=autoReply.data[2+2*i];
                if (type==2) autoType2=state;
            }
        }

        // V2.3.8a deterministic type2 state. Previous captures proved that
        // leaving type2 from the prior song resident can produce the exact
        // symptom "physical trigger received, C2 sheet beat held". Use 1 for
        // generic songs with actual extra tracks and 0 for the base/3-track path.
        const int targetType2=haveExtraTracks?1:0;
        if (status) status(L"GET_AUTO type2="+std::to_wstring(autoType2)+
            L"；V2.3.13 本曲目标="+std::to_wstring(targetType2)+
            L"（切歌时先归零，再显式设置本曲状态）");
        // Send even if GET_AUTO already reports the target. This makes the new
        // song setup deterministic after CREATE instead of inheriting a latch.
        if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,static_cast<std::uint8_t>(targetType2)},error,status,18)) return false;

        if (haveExtraTracks) {
            // This branch follows the successful official multi-track session;
            // INT25 contents are now produced by the generic JSON Builder.
            const int initialCue=CueLevelForBeat(plan_.initialBeat-2.0f);
            if (initialCue>=0 && !SendPreLevel(initialCue,error,status)) return false;
            if (!SendString("set_guitar_mode",{0x02},error,status,12)) return false;

            // Official order is descending track id (tk9...tk3).
            for (auto it=plan_.trackSetup.rbegin(); it!=plan_.trackSetup.rend(); ++it)
                if (!sendTrackInstrument(*it)) return false;

            if (!Send(C2CmdId::SET_AUTO_PLAY,{0x01,0x01},error,status,12)) return false;
            if (!sendFill()) return false; // official first FILL after instruments
            if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,status,10)) return false;
            if (!Send(C2CmdId::SET_SHEET_BEAT,initialPos,error,status,12)) return false;
            if (!sendFill()) return false;

            // Official capture sends extra-track volumes in descending tkid and
            // interleaves them with the next first-stage FILL packets.
            for (auto it=plan_.trackSetup.rbegin(); it!=plan_.trackSetup.rend(); ++it) {
                if (!sendTrackVolume(*it)) return false;
                if (nextFill<total && nextFill<10) if (!sendFill()) return false;
            }
            if (!Send(C2CmdId::SET_SHEET_BEAT,initialPos,error,status,12)) return false;
            while (nextFill<std::min<int>(10,total)) if (!sendFill()) return false;
        } else {
            // Proven 3-track Our-Time sequence kept unchanged.
            if (!SendRemindChord(error,status)) return false;
            if (!sendFill()) return false; // F5
            if (!SendString("set_guitar_mode",{0x02},error,status,12)) return false;
            const int initialCue=CueLevelForBeat(plan_.initialBeat-2.0f);
            if (initialCue>=0 && !SendPreLevel(initialCue,error,status)) return false;
            if (!sendFill()) return false; // F6
            if (!Send(C2CmdId::SET_AUTO_PLAY,{0x01,0x01},error,status,12)) return false;
            if (!sendFill()) return false; // F7
            if (!Send(C2CmdId::SET_SHEET_BEAT,initialPos,error,status,12)) return false;
            while (nextFill<std::min<int>(10,total)) if (!sendFill()) return false;
            if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x01},error,status,20)) return false;
        }
    }

    if (!sendRemainingFillTail()) return false;

    if (!armKeyPlayAfterUpload) {
        if (!Send(C2CmdId::SET_SHEET_BEAT,initialPos,error,status,25)) return false;
        uploaded_.store(true);
        if (status) status(L"C2 曲谱上传完成；未进入实体按键模式。");
        reportBulk(L"GenericUploadOnly");
        return true;
    }

    // Do not move the GUI merely because the PC *sent* beat=4. Ask C2 itself.
    // In successful official captures the first physical noti_chord after this
    // state returns beat=4.0, not 0.0.
    if (!VerifySheetBeat(plan_.initialBeat,error,status)) return false;
    uploaded_.store(true);
    armed_.store(true);

    // V2.3.13: do NOT auto-send set_pre_lead here. Original successful
    // btsnoop sessions play tk0 via CREATE/FILL + INT25, while set_pre_lead is a
    // separate pre-tone/smart-melody path. It remains available only via the
    // three manual protocol-test buttons.

    if (status) {
        if (haveExtraTracks)
            status(L"C2 多轨上传/位置已就绪；已发送通用 INT25 + extra-track INS/VOLUME，等待实体按键。");
        else
            status(L"C2 已确认处于首个可演奏 beat；等待实体按键。正确首键应回传设备 beat。 ");
    }
    reportBulk(haveExtraTracks?L"GenericMultiTrack":L"GenericBase");
    return true;
}

bool C2Controller::ArmKeyPlayFromBeginning(std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (!uploaded_.load()) { error=L"尚未向 C2 上传当前 JSON 曲谱"; return false; }

    if (!armed_.load()) {
        if (!EnableKeyTriggerEngine(error,status)) return false;
    }

    const auto pos=InitialPosition();
    if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,35)) return false;
    const int initialCue=CueLevelForBeat(plan_.initialBeat-2.0f);
    if (initialCue>=0 && !SendPreLevel(initialCue,error,status)) return false;
    if (!VerifySheetBeat(plan_.initialBeat,error,status)) return false;
    if (status) status(L"C2 已由 A102 确认回到首个可演奏 beat；不自动修改 set_pre_lead；等待实体按键/拨片。\n");
    return true;
}

bool C2Controller::ArmKeyPlayFromBeat(float beat,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (!uploaded_.load()) { error=L"尚未向 C2 上传当前 JSON 曲谱"; return false; }

    if (!armed_.load()) {
        if (!EnableKeyTriggerEngine(error,status)) return false;
    }

    float target=beat;
    if (!std::isfinite(target)) target=plan_.initialBeat;
    target=std::max<float>(0.0f,std::min<float>(plan_.totalBeats,target));
    // GUI cursor is score-beat based (JSON denominator beat: quarter for x/4,
    // eighth for x/8). Preserve that exact position in the C2 float while the
    // encoder supplies the per-track noteid table required by
    // C2MusicCmdDataTransformer.findPosition().
    target=std::round(target*4.0f)/4.0f;
    const auto pos=C2MusicEncoder::BuildPositionPayloadForPlan(target,plan_);
    if (status) status(L"从红线定位 C2：beat="+std::to_wstring(target)+
        L"，trackCount="+std::to_wstring(plan_.descriptors.size())+L"（使用每轨 noteIndex）");
    if (!Send(C2CmdId::SET_SHEET_BEAT,pos,error,status,35)) return false;
    const int cue=CueLevelForBeat(target-2.0f);
    if (cue>=0 && !SendPreLevel(cue,error,status)) return false;
    if (!VerifySheetBeat(target,error,status)) return false;
    if (status) status(L"C2 已定位到红线 beat="+std::to_wstring(target)+L"；不自动修改 set_pre_lead；下一次实体触发从这里继续。\n");
    return true;
}

bool C2Controller::RefreshMixerVolumes(std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    C2DecodedPacket reply;
    if (!SendString("get_volume",{},error,{},10)) return false;
    if (!ReadExpectedString("get_volume",reply,error,status,8)) return false;
    return true;
}


bool C2Controller::RefreshBasicStyleSlots(std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    C2DecodedPacket reply;
    // Exact timing/path from C2SingleResourceAuditioner: TX, allow A102 to
    // update, then one uncached A102 read.  ReadExpectedString retains a few
    // retries for Windows scheduling jitter.
    if (!SendString("get_config_v2basic",{},error,status,130)) return false;
    if (!ReadExpectedString("get_config_v2basic",reply,error,status,5)) return false;
    const C2DeviceState ds=DeviceState();
    if (!ds.hasBasicStyleSlots) {
        error=L"get_config_v2basic 已回包，但未解析出完整 AChord/BChord/ADrum/BDrum 四槽";
        return false;
    }
    if (status) status(L"RX get_config_v2basic: AChord="+Widen(ds.chordStyleA)+
        L" BChord="+Widen(ds.chordStyleB)+L" ADrum="+Widen(ds.drumStyleA)+L" BDrum="+Widen(ds.drumStyleB));
    return true;
}

bool C2Controller::SetBasicStyleSlot(bool drum,int slotAB,const std::string& resourceCode,
    std::wstring& error,StatusFn status,int bpm,int meterEnum) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (slotAB<0 || slotAB>1) { error=L"A/B 槽必须为 0(A) 或 1(B)"; return false; }
    const std::string resource=NormalizeBasicStyleResource(resourceCode);
    if (resource.empty() || resource.size()>96) { error=L"资源代码为空或过长"; return false; }

    // set_*_v2basic carries a BPM/meter byte pair with the selected slot, but that
    // pair is runtime timing for the slot, NOT authority for the song master tempo.
    // The caller therefore passes the current score/device BPM. Catalogue resource
    // BPM is audition/reference metadata only. If timing is unavailable, retain the
    // currently read slot values rather than borrowing a catalogue audition BPM.
    const int idx=(drum?2:0)+slotAB;
    const C2DeviceState before=DeviceState();
    if (bpm<30 || bpm>240) {
        const int old=before.basicStyleBpm[static_cast<std::size_t>(idx)];
        if (old>=30 && old<=240) bpm=old;
        else {
            error=L"当前主谱/设备 BPM 未知，而且 C2 槽 BPM 尚未读回；请先加载曲谱或点击“读取/回读四槽”";
            return false;
        }
    }
    if (!(meterEnum==0 || meterEnum==1 || meterEnum==3)) {
        const int old=before.basicStyleMeter[static_cast<std::size_t>(idx)];
        if (old==0 || old==1 || old==3) meterEnum=old;
        else {
            error=L"当前主谱拍号未知，而且 C2 槽拍号尚未读回；请先加载曲谱或点击“读取/回读四槽”";
            return false;
        }
    }

    std::vector<std::uint8_t> payload;
    payload.reserve(6+resource.size());
    payload.push_back(static_cast<std::uint8_t>(slotAB));
    payload.push_back(static_cast<std::uint8_t>(drum?2:1));
    payload.push_back(0x01);
    payload.push_back(static_cast<std::uint8_t>(resource.size()));
    payload.insert(payload.end(),resource.begin(),resource.end());
    payload.push_back(static_cast<std::uint8_t>(bpm));
    payload.push_back(static_cast<std::uint8_t>(meterEnum));
    const std::string cmd=drum?"set_drums_v2basic":"set_chord_v2basic";
    if (status) status(std::wstring(L"写入")+(slotAB?L"B":L"A")+(drum?L"鼓":L"和弦/拨片")+
        L"资源: "+Widen(resource)+L"  BPM="+std::to_wstring(bpm)+L" meter="+std::to_wstring(meterEnum));
    if (!SendString(cmd,payload,error,status,100)) return false;

    C2DecodedPacket reply;
    if (!SendString("get_config_v2basic",{},error,{},130)) return false;
    if (!ReadExpectedString("get_config_v2basic",reply,error,status,5)) return false;
    const C2DeviceState after=DeviceState();
    const std::string got=drum ? (slotAB?after.drumStyleB:after.drumStyleA)
                               : (slotAB?after.chordStyleB:after.chordStyleA);
    if (got.empty()) {
        error=L"get_config_v2basic 回读为空，未确认写入";
        return false;
    }
    if (got!=resource) {
        error=L"get_config_v2basic 回读不一致：目标="+Widen(resource)+L"，设备="+Widen(got);
        return false;
    }
    if (status) status(L"写入确认："+Widen(got)+L"（get_config_v2basic）");
    return true;
}

bool C2Controller::SetShortcutMonitor(bool open,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }

    // These selector/value pairs come from real-device experiments, not guesses:
    //   02 0A -> periodic noti_frets; 02 00 -> stop
    //   03 01 -> noti_picks;        03 00 -> stop
    const std::uint8_t fretsRate=open?0x0A:0x00;
    const std::uint8_t picksRate=open?0x01:0x00;
    if (!SendString("set_notify_param",{0x02,fretsRate},error,status,14)) return false;
    if (!SendString("set_notify_param",{0x03,picksRate},error,status,14)) return false;
    {
        std::lock_guard<std::mutex> stateLock(stateMutex_);
        deviceState_.shortcutMonitorEnabled=open;
        if (open) {
            // Keep the previous MAIN_TRACK_AUTO value for comparison, but reset
            // transient touch/pick values so the first new notify is obvious.
            deviceState_.fretKey=-1;
            deviceState_.bpmTouch=-1;
            deviceState_.arpeggioRaw.fill(-1);
            deviceState_.arpeggioPressed.fill(-1);
            deviceState_.pickState=-1;
            deviceState_.hasPickAngles=false;
            deviceState_.lastPickId=-1;
        }
    }
    if (status) status(open ?
        L"快捷键监视已开启：noti_frets(02 0A) + noti_picks(03 01)，请测试‘按住琶音垫 + 拨片’" :
        L"快捷键监视已停止：noti_frets/noti_picks notify 已关闭");
    return true;
}

bool C2Controller::SetMixerVolume(int channel,int value,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (channel<1 || channel>13) { error=L"C2 volume channel 必须为 1..13"; return false; }
    value=std::max<int>(0,std::min<int>(100,value));
    if (!SendString("set_volume",{static_cast<std::uint8_t>(channel),static_cast<std::uint8_t>(value)},error,status,14)) return false;
    C2DecodedPacket reply;
    if (!SendString("get_volume",{},error,{},10)) return false;
    if (!ReadExpectedString("get_volume",reply,error,status,8)) return false;
    const C2DeviceState state=DeviceState();
    const int got=state.mixer[static_cast<std::size_t>(channel)];
    if (status) status(L"C2 Mixer ch"+std::to_wstring(channel)+L"="+std::to_wstring(got));
    if (got>=0 && got!=value) {
        error=L"C2 volume 回读不一致：目标="+std::to_wstring(value)+L"，设备="+std::to_wstring(got);
        return false;
    }
    return true;
}

bool C2Controller::RefreshDeviceInfo(std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    {
        std::lock_guard<std::mutex> stateLock(stateMutex_);
        deviceState_.rawRepliesText.clear();
    }
    auto query=[&](const std::string& cmd,const std::vector<std::uint8_t>& payload)->bool {
        std::wstring e;
        C2DecodedPacket reply;
        const int settleMs=(cmd=="get_config_v2basic") ? 130 : (cmd=="get_midi_info" ? 250 : 30);
        const int tries=5;
        if (!SendString(cmd,payload,e,{},settleMs) || !ReadExpectedString(cmd,reply,e,status,tries)) {
            if (status) status(L"设备中心："+Widen(cmd)+L" 读取失败/固件不支持："+e);
            return false;
        }
        return true;
    };
    // Best effort: one unsupported query must not make the device center fail.
    query("get_volume",{});
    query("get_vers_all",{});
    query("get_func_support",{});
    query("get_func_v2_support",{});
    query("get_config_v2basic",{}); // four slots + device tone, SingleResourceAuditioner-proven
    query("get_midi_info",{});
    query("get_style_settings",{});
    // Integer GET_AUTO_PLAY (0x0F) has the same [count][type][state] structure
    // observed in official captures. Keep all raw type1..6 states visible.
    {
        C2DecodedPacket reply;
        std::wstring e;
        if (Send(C2CmdId::GET_AUTO_PLAY,{},e,{},12) && ReadExpectedInt(C2CmdId::GET_AUTO_PLAY,reply,e,status,5)) {
            std::lock_guard<std::mutex> stateLock(stateMutex_);
            if (!reply.data.empty()) {
                const std::size_t count=reply.data[0];
                for (std::size_t i=0;i<count && 2+2*i<reply.data.size();++i) {
                    const int type=reply.data[1+2*i], value=reply.data[2+2*i];
                    if (type>=0 && type<static_cast<int>(deviceState_.autoPlay.size()))
                        deviceState_.autoPlay[static_cast<std::size_t>(type)]=value;
                }
            }
            deviceState_.rawRepliesText+=L"[GET_AUTO_PLAY 0x0F]\r\n"+PayloadSummary(reply.data)+L"\r\n";
        } else if (status) status(L"设备中心：GET_AUTO_PLAY 读取失败/固件不支持："+e);
    }
    query("get_light_cfg",{});
    query("get_humanize",{});
    query("get_sys_onoff",{0x06});
    // 3.7.6 DEX-confirmed StylePack queries. Payload semantics are firmware-side;
    // unsupported firmware is allowed to ignore them.
    query("get_style_pack_mode",{});
    query("get_style_pack_seq",{});
    query("get_style_pack0",{});
    if (status) status(L"C2 设备中心信息已刷新（未知/不支持项保留原始回包）");
    return true;
}

bool C2Controller::SetDeviceKey(int key,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (key<0 || key>11) { error=L"Key 必须为 0..11 (C..B)"; return false; }
    if (!SendString("set_key",{static_cast<std::uint8_t>(key)},error,status,16)) return false;
    if (status) status(L"C2 Key 已设置为 "+std::to_wstring(key));
    return true;
}

bool C2Controller::SetDeviceBpm(int bpm,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (bpm<40 || bpm>240) { error=L"BPM 必须为 40..240"; return false; }
    if (!SendString("set_bpm",{static_cast<std::uint8_t>(bpm)},error,status,16)) return false;
    if (status) status(L"C2 BPM 已设置为 "+std::to_wstring(bpm));
    return true;
}

bool C2Controller::SetFretInstrument(const std::string& tone,std::wstring& error,StatusFn status) {
    return SetFretInstrument("sound_c2",tone,error,status);
}

bool C2Controller::SetFretInstrument(const std::string& cardCode,const std::string& tone,
    std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    std::vector<std::uint8_t> payload;
    if (!BuildTonePayload(cardCode,tone,payload,error)) return false;
    if (!SendString("set_fret_instru",payload,error,status,16)) return false;
    if (status) status(L"C2 指板/演奏音色: "+Widen(cardCode)+L":"+Widen(tone));
    return true;
}

bool C2Controller::SetDeviceMelodyTone(const std::string& cardCode,const std::string& tone,
    std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    std::vector<std::uint8_t> payload;
    if (!BuildTonePayload(cardCode,tone,payload,error)) return false;
    // Exact factory device-page sequence observed 2026-08-28.
    if (!SendString("set_fret_instru",payload,error,status,12)) return false;
    if (!SendString("set_lead_preview",payload,error,status,12)) return false;
    C2DecodedPacket reply;
    std::wstring qerr;
    if (SendString("get_config_v2basic",{},qerr,{},8) && ReadExpectedString("get_config_v2basic",reply,qerr,status,5)) {
        const C2DeviceState ds=DeviceState();
        if (status) status(L"设备页音色回读: "+Widen(ds.currentToneCard)+L":"+Widen(ds.currentTone));
    } else if (status) {
        status(L"设备页音色已写入；get_config_v2basic 回读未确认: "+qerr);
    }
    return true;
}

bool C2Controller::ApplyTrackToneVolume(std::uint8_t trackId,const std::string& cardCode,const std::string& tone,int volume,
    bool allSections,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (!uploaded_.load()) { error=L"尚未向 C2 上传当前 JSON；INT26 只能修改已驻留的 sheet"; return false; }
    volume=std::max<int>(0,std::min<int>(100,volume));

    float beat=plan_.initialBeat;
    std::wstring qerr;
    if (!allSections && !QuerySheetBeat(beat,qerr,{})) {
        if (status) status(L"GET_SHEET_BEAT 未确认，当前段 INT26 使用 initialBeat="+std::to_wstring(beat)+L"；"+qerr);
    }

    std::vector<std::vector<std::uint8_t>> pages;
    std::vector<std::size_t> sectionIndexes;
    std::string encErr;
    if (!C2MusicEncoder::BuildTrackAmendPayloads(plan_,trackId,beat,allSections,cardCode,tone,volume,pages,sectionIndexes,encErr)) {
        error=Widen(encErr); return false;
    }

    // Factory capture is exact here: tone change -> set_lead_preview + INT26;
    // pure volume change -> INT26 only. Detect the selected section(s) before
    // mutating plan_ so the PC reproduces that behavior.
    bool toneChanged=false;
    for (std::size_t si:sectionIndexes) if (si<plan_.scheduleSections.size()) {
        for (const auto& t:plan_.scheduleSections[si].tracks) if (t.trackId==trackId) {
            if (t.cardCode!=cardCode || t.noteCode!=tone) toneChanged=true;
        }
    }
    if (toneChanged && trackId==0) {
        std::vector<std::uint8_t> preview;
        if (!BuildTonePayload(cardCode,tone,preview,error)) return false;
        if (!SendString("set_lead_preview",preview,error,status,12)) return false;
    } else if (!toneChanged && status) {
        status(L"目标轨音色未变化：仅发送 INT26 音量/section patch");
    }

    if (status) status(std::wstring(L"TX INT26 tk")+std::to_wstring(trackId)+L" "+(allSections?L"全部段":L"当前段")+
        L" sections="+std::to_wstring(sectionIndexes.size())+L" pages="+std::to_wstring(pages.size())+
        L" tone="+Widen(cardCode)+L":"+Widen(tone)+L" volume="+std::to_wstring(volume));
    for (std::size_t i=0;i<pages.size();++i) {
        if (status) status(L"TX SET_AMEND_TRACK/INT26 page "+std::to_wstring(i)+L"/"+
            std::to_wstring(pages.size()-1)+L" data="+std::to_wstring(pages[i].size())+L"B");
        if (!Send(C2CmdId::SET_AMEND_TRACK,pages[i],error,{},14)) return false;
    }

    // Keep the PC-side schedule in sync so consecutive current/all edits do not
    // fall back to stale tk0 tone/volume metadata.
    for (std::size_t si:sectionIndexes) if (si<plan_.scheduleSections.size()) {
        for (auto& t:plan_.scheduleSections[si].tracks) if (t.trackId==trackId) {
            t.cardCode=cardCode; t.noteCode=tone; t.volume=static_cast<std::uint8_t>(volume);
        }
    }
    if (trackId==0) { plan_.leadCard=cardCode; plan_.leadTone=tone; }
    if (status) status(L"INT26 tk"+std::to_wstring(trackId)+L" 修改完成");
    return true;
}

bool C2Controller::ApplyTrackToneVolumeForTone(std::uint8_t trackId,
    const std::string& matchCardCode,const std::string& matchTone,
    const std::string& cardCode,const std::string& tone,int volume,
    std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (!uploaded_.load()) { error=L"尚未向 C2 上传当前 JSON；INT26 只能修改已驻留的 sheet"; return false; }
    volume=std::max<int>(0,std::min<int>(100,volume));

    std::vector<std::vector<std::uint8_t>> pages;
    std::vector<std::size_t> sectionIndexes;
    std::string encErr;
    if (!C2MusicEncoder::BuildTrackAmendPayloadsMatchingTone(plan_,trackId,matchCardCode,matchTone,
        cardCode,tone,volume,pages,sectionIndexes,encErr)) {
        error=Widen(encErr); return false;
    }

    const bool toneChanged=(matchCardCode!=cardCode || matchTone!=tone);
    if (toneChanged && trackId==0) {
        std::vector<std::uint8_t> preview;
        if (!BuildTonePayload(cardCode,tone,preview,error)) return false;
        if (!SendString("set_lead_preview",preview,error,status,12)) return false;
    }
    if (status) status(std::wstring(L"TX INT26 tone-group tk")+std::to_wstring(trackId)+
        L" match="+Widen(matchCardCode)+L":"+Widen(matchTone)+
        L" -> "+Widen(cardCode)+L":"+Widen(tone)+L" volume="+std::to_wstring(volume)+
        L" sections="+std::to_wstring(sectionIndexes.size()));
    for (std::size_t i=0;i<pages.size();++i) {
        if (!Send(C2CmdId::SET_AMEND_TRACK,pages[i],error,{},14)) return false;
    }

    for (std::size_t si:sectionIndexes) if (si<plan_.scheduleSections.size()) {
        for (auto& t:plan_.scheduleSections[si].tracks) if (t.trackId==trackId &&
            (matchCardCode.empty() || t.cardCode==matchCardCode) && t.noteCode==matchTone) {
            t.cardCode=cardCode; t.noteCode=tone; t.volume=static_cast<std::uint8_t>(volume);
        }
    }
    if (status) status(L"INT26 tone-group 修改完成");
    return true;
}

bool C2Controller::SetAutoPlayState(int type,int state,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (type<1 || type>7 || (state!=0 && state!=1)) { error=L"SET_AUTO_PLAY 支持 wire type=1..7, state=0/1"; return false; }
    const std::vector<std::uint8_t> payload={static_cast<std::uint8_t>(type),static_cast<std::uint8_t>(state)};
    if (!Send(C2CmdId::SET_AUTO_PLAY,payload,error,status,18)) return false;
    if (status) {
        wchar_t hexbuf[32]{}; wsprintfW(hexbuf,L"%02X %02X",type,state);
        std::wstring note;
        if (type==2) note=state?L"；鼓机自动挂挡许可=开" :L"；鼓机自动挂挡许可=关（不是鼓通道硬静音）";
        else if (type==3) note=state?L"；自动转调=开" :L"；自动转调=关";
        else if (type==6) note=state?L"；聪明模式=开" :L"；聪明模式=关";
        else if (type==4) note=L"；type04 尚未完成真机语义标定";
        status(L"SET_AUTO_PLAY 0x10 payload="+std::wstring(hexbuf)+note);
    }

    // Device-center write is followed by GET_AUTO_PLAY readback so the functional
    // labels reflect C2 rather than merely the button the PC clicked.
    C2DecodedPacket reply;
    std::wstring qerr;
    if (Send(C2CmdId::GET_AUTO_PLAY,{},qerr,{},10) && ReadExpectedInt(C2CmdId::GET_AUTO_PLAY,reply,qerr,status,5)) {
        int got=-1;
        {
            std::lock_guard<std::mutex> stateLock(stateMutex_);
            if (!reply.data.empty()) {
                const std::size_t count=reply.data[0];
                for (std::size_t i=0;i<count && 2+2*i<reply.data.size();++i) {
                    const int t=reply.data[1+2*i], v=reply.data[2+2*i];
                    if (t>=0 && t<static_cast<int>(deviceState_.autoPlay.size()))
                        deviceState_.autoPlay[static_cast<std::size_t>(t)]=v;
                    if (t==type) got=v;
                }
            }
            deviceState_.rawRepliesText+=L"[GET_AUTO_PLAY 0x0F]\r\n"+PayloadSummary(reply.data)+L"\r\n";
        }
        if (got>=0 && got!=state) {
            error=L"SET_AUTO_PLAY 回读不一致：type="+std::to_wstring(type)+L" target="+std::to_wstring(state)+L" got="+std::to_wstring(got);
            return false;
        }
        if (status) status(L"GET_AUTO_PLAY 回读 type="+std::to_wstring(type)+L" state="+std::to_wstring(got));
    } else if (status) {
        status(L"SET_AUTO_PLAY 已写入；GET_AUTO_PLAY 回读未确认："+qerr);
    }
    return true;
}

bool C2Controller::SetStyleSetting(int type,int value,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (type<1 || type>31 || value<0 || value>255) { error=L"StyleSetting type/value 无效"; return false; }
    if (!SendString("set_style_settings",{static_cast<std::uint8_t>(type),static_cast<std::uint8_t>(value)},error,status,16)) return false;
    C2DecodedPacket reply;
    std::wstring qerr;
    if (SendString("get_style_settings",{},qerr,{},8) && ReadExpectedString("get_style_settings",reply,qerr,status,4)) {
        const C2DeviceState st=DeviceState();
        if (type<static_cast<int>(st.styleSettings.size()) && st.styleSettings[static_cast<std::size_t>(type)]>=0 &&
            st.styleSettings[static_cast<std::size_t>(type)]!=value) {
            error=L"set_style_settings 回读不一致：type="+std::to_wstring(type)+L" target="+
                std::to_wstring(value)+L" got="+std::to_wstring(st.styleSettings[static_cast<std::size_t>(type)]);
            return false;
        }
    }
    if (status) status(L"C2 演奏偏好/StyleSetting raw type="+std::to_wstring(type)+L" value="+std::to_wstring(value));
    return true;
}

bool C2Controller::ApplyJsonConfigPack(const MDSSong& song,int bpmOverride,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    C2UploadPlan temp;
    std::string encErr;
    if (!C2MusicEncoder::Build(song,bpmOverride,temp,encErr)) {
        error=L"无法从当前 JSON 生成 configV2Pack: "+Widen(encErr);
        return false;
    }
    if (temp.configV2PackPayload.empty()) {
        error=L"当前 JSON 没有可下发的 baseConfig.configPack/configV2Pack";
        return false;
    }
    if (!SendString("set_config_v2pack",temp.configV2PackPayload,error,status,20)) return false;
    if (status) status(L"当前 JSON 风格包已下发：set_config_v2pack "+std::to_wstring(temp.configV2PackPayload.size())+L" bytes");
    return true;
}

bool C2Controller::SetMainMelodyMode(int mode,std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    if (!uploaded_.load()) { error=L"尚未向 C2 上传当前 JSON 曲谱"; return false; }
    float beat=plan_.initialBeat;
    std::wstring queryError;
    if (!QuerySheetBeat(beat,queryError,{})) {
        if (status) status(L"提示：GET_SHEET_BEAT 失败，主旋律切换使用最近起始 beat="+std::to_wstring(beat));
    }
    return SendMainMelodyMode(mode,beat,error,status);
}

bool C2Controller::CloseSheet(std::wstring& error,StatusFn status) {
    std::lock_guard<std::mutex> lock(opMutex_);
    error.clear();
    if (!ble_.IsConnected()) { error=L"C2 未连接"; return false; }
    // Explicitly leave the new 3.7.6 track scheduler before closing the sheet.
    // These two writes are best-effort so CLOSE_SHEET remains the authoritative
    // user-visible operation.
    std::wstring resetErr;
    if (!Send(C2CmdId::SET_TRACK_ENABLE,{0x00},resetErr,{},20) && status)
        status(L"关闭前 SET_TRACK_ENABLE=0 未确认："+resetErr);
    resetErr.clear();
    if (!Send(C2CmdId::SET_AUTO_PLAY,{0x02,0x00},resetErr,{},20) && status)
        status(L"关闭前 SET_AUTO type2=0 未确认："+resetErr);
    if (!Send(C2CmdId::CLOSE_SHEET,{},error,status,45)) return false;
    deviceSheetResident_.store(false);
    uploaded_.store(false); armed_.store(false);
    appliedPreLevel_.store(-1); pendingPreLevel_.store(-1); positionQueryRunning_.store(false); positionQueryPending_.store(false); stageReady29_.store(false);
    if (status) status(L"C2 当前曲谱已关闭；实体按键演奏态已退出。");
    return true;
}

