﻿#include "C2MusicEncoder.h"
#include "C2OfficialCaptureProfiles.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>
#include <set>
#include <sstream>
#include <tuple>

namespace {
constexpr std::uint8_t TRACK_LEAD = 1;
constexpr std::uint8_t TRACK_CHORD = 2;
constexpr std::uint8_t TRACK_SUBLEAD = 3;
constexpr std::uint8_t TRACK_PAD = 4;
constexpr std::uint8_t TRACK_EVENT = 5;
constexpr std::uint8_t TRACK_EFFECT = 6;

struct Item {
    std::uint8_t type = 0;
    std::uint8_t tkid = 0;
    std::uint16_t noteIndex = 0;
    std::vector<std::uint8_t> raw;
    float startBeat = 0.0f;
    float endBeat = 0.0f;
};

struct TrackRange {
    float start = 0.0f;
    float end = 0.0f;
};
struct ScheduleTrack {
    std::uint8_t trackId = 0;
    std::uint8_t index = 0;
    std::uint8_t mute = 0;
    std::uint8_t volume = 0;
    std::string cardCode;
    std::string noteCode;
    std::vector<TrackRange> ranges;
};
struct ScheduleSection {
    std::uint8_t type = 0;
    float start = 0.0f;
    float end = 0.0f;
    std::vector<ScheduleTrack> tracks;
};
struct NaturalSection {
    std::uint8_t type = 0;
    float start = 0.0f;
    float end = 0.0f;
};
struct LeadScheduleEvent {
    float start = 0.0f;
    float end = 0.0f;
    std::uint8_t index = 0;
    std::uint8_t mute = 0;
    std::uint8_t volume = 0;
    std::string cardCode;
    std::string noteCode;
};

static void PutU16(std::vector<std::uint8_t>& b, std::uint16_t v) {
    b.push_back(static_cast<std::uint8_t>(v & 0xFF)); b.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
}
static void PutU32(std::vector<std::uint8_t>& b, std::uint32_t v) {
    for (int i=0;i<4;++i) b.push_back(static_cast<std::uint8_t>((v >> (8*i)) & 0xFF));
}
static void PutU64(std::vector<std::uint8_t>& b, std::uint64_t v) {
    for (int i=0;i<8;++i) b.push_back(static_cast<std::uint8_t>((v >> (8*i)) & 0xFF));
}
static void PutFloat(std::vector<std::uint8_t>& b, float v) {
    std::uint32_t u=0; static_assert(sizeof(float)==4,"float32 required"); std::memcpy(&u,&v,4);
    for (int i=0;i<4;++i) b.push_back(static_cast<std::uint8_t>((u >> (8*i)) & 0xFF));
}
static int ToneNumber1Based(const std::string& s) {
    if (s.empty()) return 1;
    if (s=="C" || s=="#B") return 1;
    if (s=="#C" || s=="Db" || s=="bD") return 2;
    if (s=="D") return 3;
    if (s=="#D" || s=="Eb" || s=="bE") return 4;
    if (s=="E" || s=="Fb" || s=="bF") return 5;
    if (s=="F" || s=="#E") return 6;
    if (s=="#F" || s=="Gb" || s=="bG") return 7;
    if (s=="G") return 8;
    if (s=="#G" || s=="Ab" || s=="bA") return 9;
    if (s=="A") return 10;
    if (s=="#A" || s=="Bb" || s=="bB") return 11;
    if (s=="B" || s=="Cb" || s=="bC") return 12;
    return 1;
}
static int ChordLevel(const std::string& s) { return ToneNumber1Based(s)-1; }
static int ChordType(const std::string& s) {
    if (s.empty()) return 0;
    if (s=="m") return 1;
    // Values beyond major/minor have not yet been proven by the current C2 capture set.
    return 0;
}
static std::uint8_t ExtraC2Type(int jsonType) {
    switch(jsonType) { case 0:return TRACK_LEAD; case 1:return TRACK_PAD; case 2:return TRACK_SUBLEAD; case 3:return TRACK_EFFECT; default:return TRACK_PAD; }
}
static float BeatLengthUnit(const std::string& beat) {
    const std::size_t slash=beat.find('/');
    if (slash==std::string::npos) return 4.0f;
    try { const int den=std::stoi(beat.substr(slash+1)); if (den>0) return 16.0f/static_cast<float>(den); } catch(...) {}
    return 4.0f;
}
static int BnumFromBeat(const std::string& beat, std::vector<std::string>& warnings) {
    if (beat=="4/4") return 1;
    // Only 4/4 (bnum=1) is proven by the available C2 captures. Keep a conservative mapping for 6/8.
    if (beat=="6/8") { warnings.push_back("6/8 的 C2 bnum 尚无真机抓包验证，V2.1 暂按 bnum=2 编码；首次请先用 4/4 曲目验证蓝牙链路。"); return 2; }
    warnings.push_back("未知拍号 " + beat + "，C2 bnum 暂按 1 编码。"); return 1;
}
static std::uint64_t SongUid(const MDSSong& song) {
    // Official C2 upload uses the public songId (not the local database row id).
    if (!song.songId.empty()) { try { return static_cast<std::uint64_t>(std::stoull(song.songId)); } catch(...) {} }
    if (song.id>0) return static_cast<std::uint64_t>(song.id);
    return 1;
}
static std::string InstrumentOf(const MDSTrackConfig& tc) {
    if (!tc.assetNotes.empty()) {
        const auto& a=tc.assetNotes.front();
        if (!a.timbreCardCode.empty() && !a.noteCode.empty()) return a.timbreCardCode+":"+a.noteCode;
    }
    if (!tc.noteCode.empty()) return std::string("scard_01:")+tc.noteCode;
    return {};
}
static int ByteInt(const std::string& s,int def=0) {
    if (s.empty()) return def;
    try { return std::max<int>(0,std::min<int>(255,std::stoi(s))); } catch(...) { return def; }
}
static bool AppendConfigV2Entry(std::vector<std::uint8_t>& out,const MDSConfigEntry& e,
    std::uint8_t group,int originalBpm,std::vector<std::string>& warnings) {
    const std::string name=e.cardCode.empty()?e.nameCode:(e.cardCode+":"+e.nameCode);
    if (name.empty()) return false;
    if (name.size()>255) { warnings.push_back("configPack 音色字符串过长，已跳过: "+name); return false; }
    out.push_back(static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,e.pickType))));
    out.push_back(group);
    out.push_back(static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,e.pickAction))));
    out.push_back(static_cast<std::uint8_t>(name.size()));
    out.insert(out.end(),name.begin(),name.end());
    // 2026-08-20 capture: this byte is the *original* JSON BPM, even when
    // CREATE_SHEET is played with a live BPM override (70 vs JSON 84).
    out.push_back(static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,originalBpm))));
    out.push_back(0x01);
    return true;
}

static bool HasVisibleText(const std::string& value) {
    return std::any_of(value.begin(),value.end(),[](unsigned char ch){ return ch>0x20; });
}
static void SplitInstrument(const std::string& value,std::string& card,std::string& note) {
    const std::size_t colon=value.find(':');
    if (colon==std::string::npos) { card.clear(); note=value; return; }
    card=value.substr(0,colon); note=value.substr(colon+1);
}
static std::vector<TrackRange> MergeRanges(std::vector<TrackRange> v) {
    v.erase(std::remove_if(v.begin(),v.end(),[](const TrackRange& r){ return !(r.end>r.start); }),v.end());
    std::sort(v.begin(),v.end(),[](const TrackRange& a,const TrackRange& b){
        if (a.start!=b.start) return a.start<b.start;
        return a.end<b.end;
    });
    std::vector<TrackRange> out;
    constexpr float eps=0.000001f;
    for (const auto& r:v) {
        if (out.empty() || r.start>out.back().end+eps) out.push_back(r);
        else out.back().end=std::max<float>(out.back().end,r.end);
    }
    return out;
}
static std::vector<TrackRange> SubtractGaps(const std::vector<TrackRange>& src,const std::vector<TrackRange>& gaps) {
    std::vector<TrackRange> current=src;
    for (const auto& gap:gaps) {
        std::vector<TrackRange> next;
        for (const auto& r:current) {
            if (r.end<=gap.start || r.start>=gap.end) { next.push_back(r); continue; }
            if (r.start<gap.start) next.push_back({r.start,std::min<float>(r.end,gap.start)});
            if (r.end>gap.end) next.push_back({std::max<float>(r.start,gap.end),r.end});
        }
        current.swap(next);
    }
    return current;
}
static std::vector<TrackRange> ClipRanges(const std::vector<TrackRange>& src,float start,float end) {
    std::vector<TrackRange> out;
    for (const auto& r:src) {
        const float a=std::max<float>(r.start,start), b=std::min<float>(r.end,end);
        if (b>a) out.push_back({a,b});
    }
    return out;
}
static int TrackTypeRank(int jsonType) {
    if (jsonType==1) return 0; // PAD first in official INT25
    if (jsonType==2) return 1; // then SUBLEAD
    return 2;
}
static bool SameBeat(float a,float b,float eps=0.001f) { return std::fabs(a-b)<=eps; }

// Reconstructs the section boundaries used by BLE_MSG_SET_TRACK_CREATE (int25).
// Most songs use lyrics[] boundaries directly. 3.7.6 type=14 may move a boundary
// by one beat because it is the authoritative tk0 lead/mute schedule. The only
// currently observed type=15 sample spans a phrase block; the official Ulaan capture
// shows that extra-track activation is delayed to the lyric-line boundary after that
// block. The logic below is data-driven and deliberately does not inspect songId.
static void BuildScheduleGeometry(const MDSContent& content,float unit,
    std::vector<NaturalSection>& natural,std::vector<float>& bounds,
    std::vector<TrackRange>& extraTrackDeadGaps,std::vector<LeadScheduleEvent>& leadEvents,
    float& maxMusicEnd,std::vector<std::string>& warnings) {
    natural.clear(); bounds.clear(); extraTrackDeadGaps.clear(); leadEvents.clear(); maxMusicEnd=0.0f;
    std::vector<float> newLineEnds;
    struct Type15Span { float start=0.0f; float end=0.0f; };
    std::vector<Type15Span> type15;
    float absBeat=0.0f;
    for (const auto& seg:content.lyrics) {
        NaturalSection ns; ns.type=static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,seg.type))); ns.start=absBeat;
        for (const auto& bar:seg.bars) {
            for (const auto& beat:bar.beats) {
                for (const auto& n:beat.notes) {
                    const float st=absBeat+static_cast<float>(n.start)/unit;
                    const float en=st+static_cast<float>(n.length)/unit;
                    maxMusicEnd=std::max<float>(maxMusicEnd,en);
                }
                for (const auto& et:beat.extraTracks) for (const auto& n:et.notes) {
                    const float st=absBeat+static_cast<float>(n.start)/unit;
                    const float en=st+static_cast<float>(n.length)/unit;
                    maxMusicEnd=std::max<float>(maxMusicEnd,en);
                }
                for (const auto& w:beat.words) if (w.newLine && HasVisibleText(w.word)) {
                    const float en=absBeat+static_cast<float>(w.start+w.length)/unit;
                    newLineEnds.push_back(en);
                }
                for (const auto& e:beat.extensions) {
                    const float st=absBeat+static_cast<float>(e.start)/unit;
                    if (e.type=="14" && e.length>0.0 && !e.assetNotes.empty()) {
                        const float en=st+static_cast<float>(e.length)/unit;
                        LeadScheduleEvent le; le.start=st; le.end=en;
                        le.mute=static_cast<std::uint8_t>(e.mute?1:0);
                        le.volume=static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,e.volume)));
                        le.index=static_cast<std::uint8_t>(e.mute?0:1);
                        le.cardCode=e.assetNotes.front().timbreCardCode;
                        le.noteCode=e.assetNotes.front().noteCode;
                        leadEvents.push_back(std::move(le)); maxMusicEnd=std::max<float>(maxMusicEnd,en);
                    } else if (e.type=="15" && e.length>0.0) {
                        type15.push_back({st,st+static_cast<float>(e.length)/unit});
                    }
                }
                absBeat+=1.0f;
            }
        }
        ns.end=absBeat; natural.push_back(ns);
    }
    if (natural.empty()) return;
    bounds.resize(natural.size()+1);
    bounds[0]=natural.front().start;
    for (std::size_t i=1;i<natural.size();++i) bounds[i]=natural[i].start;
    bounds.back()=natural.back().end;

    // Explicit type14 changes are authoritative when they sit on/within one beat
    // of a lyrics[] transition. This yields Ulaan 20->19 and 68->67 without IDs.
    for (std::size_t i=1;i<natural.size();++i) {
        const float original=bounds[i];
        float best=original, bestDist=1.001f;
        for (const auto& e:leadEvents) {
            const float d=std::fabs(e.start-original);
            if (d<bestDist) { best=e.start; bestDist=d; }
        }
        if (bestDist<=1.0001f) bounds[i]=best;
    }

    // type15 has only one known 3.7.6 corpus example. Preserve the empirically
    // confirmed Ulaan behavior as a generic type15 rule, and report it visibly.
    if (!leadEvents.empty()) for (const auto& span:type15) {
        for (std::size_t i=1;i<natural.size();++i) {
            const float original=natural[i].start;
            if (SameBeat(original,span.start)) {
                float candidate=original;
                for (float e:newLineEnds) if (e<=original && e>=original-4.0f) candidate=std::max<float>(candidate==original?-1.0f:candidate,e);
                if (candidate>=0.0f && candidate<original) bounds[i]=candidate;
            }
            if (SameBeat(original,span.end)) {
                float candidate=0.0f;
                for (float e:newLineEnds) if (e>=original && e<=original+4.0f && (candidate==0.0f || e<candidate)) candidate=e;
                if (candidate>original) {
                    bounds[i]=candidate;
                    extraTrackDeadGaps.push_back({original,candidate});
                }
            }
        }
        warnings.push_back("检测到 extension type=15：按 3.7.6 已知抓包规则对 INT25 section/extra-track 激活边界做歌词行对齐；该规则需更多 type15 样本继续验证。");
    }

    // Captured advanced Our Time contains two trailing empty beats: its official
    // int25 ends at the last musical note (370), while SECTION remains 372.
    if (leadEvents.empty() && maxMusicEnd>bounds[bounds.size()-2] && maxMusicEnd<bounds.back()) bounds.back()=maxMusicEnd;
    for (std::size_t i=1;i<bounds.size();++i) {
        if (bounds[i]<bounds[i-1]) bounds[i]=bounds[i-1];
    }
}

static bool BuildGenericInt25(const MDSContent& content,float unit,C2UploadPlan& plan,std::string& error) {
    std::vector<NaturalSection> natural;
    std::vector<float> bounds;
    std::vector<TrackRange> deadGaps;
    std::vector<LeadScheduleEvent> leadEvents;
    float maxMusicEnd=0.0f;
    BuildScheduleGeometry(content,unit,natural,bounds,deadGaps,leadEvents,maxMusicEnd,plan.warnings);
    if (natural.empty() || bounds.size()!=natural.size()+1) return true;

    // Gather actual extra-track audible ranges from notes; zero-duration notes remain
    // in FILL/CREATE counts but do not create an audible scheduling range.
    std::map<int,std::vector<TrackRange>> rangesByJsonIndex;
    float absBeat=0.0f;
    for (const auto& seg:content.lyrics) for (const auto& bar:seg.bars) for (const auto& beat:bar.beats) {
        for (const auto& et:beat.extraTracks) for (const auto& n:et.notes) {
            const float st=absBeat+static_cast<float>(n.start)/unit;
            const float en=st+static_cast<float>(n.length)/unit;
            if (en>st) rangesByJsonIndex[et.index].push_back({st,en});
        }
        absBeat+=1.0f;
    }
    for (auto& kv:rangesByJsonIndex) {
        kv.second=MergeRanges(std::move(kv.second));
        if (!deadGaps.empty()) kv.second=SubtractGaps(kv.second,deadGaps);
    }
    bool haveExtraSchedule=false;
    for (const auto& kv:rangesByJsonIndex) if (!kv.second.empty()) { haveExtraSchedule=true; break; }

    // 01_mds_base / 02_mds_multilevel_style commonly carry a real LEAD track in
    // beat.notes while melodicNote and trackConfigs are both null.  V2.3.10 used
    // melodicNote as the prerequisite for tk0 INT25, so CREATE/FILL contained the
    // notes but C2 had no runtime timbre/range schedule and only the chord engine
    // was audible.  Treat actual beat.notes as the authoritative presence test.
    bool haveLeadNotes=false;
    std::string type13LeadCard,type13LeadNote;
    for (const auto& seg:content.lyrics) for (const auto& bar:seg.bars) for (const auto& beat:bar.beats) {
        if (!beat.notes.empty()) haveLeadNotes=true;
        for (const auto& e:beat.extensions) {
            if (e.type=="13" && !e.cardCode.empty() && !e.code.empty()) {
                // type13 is a model-specific sustained instrument/timbre range.
                // When melodicNote is absent, prefer the first C2 resource as
                // the default tk0 timbre; this matches base-score JSON such as
                // 虫儿飞 (sound_c2:PianoStudio).
                const bool c2Resource=e.cardCode.rfind("sound_c2",0)==0 || e.cardCode.rfind("scard_",0)==0;
                if (c2Resource && type13LeadCard.empty()) { type13LeadCard=e.cardCode; type13LeadNote=e.code; }
            }
        }
    }
    if (leadEvents.empty() && !haveLeadNotes && !haveExtraSchedule) return true;

    // DEX CmdCreateTrackDataBean.index + Ulaan btsnoop show that this is an
    // ordinal within the same JSON trackConfig.type, not trackConfig.index itself.
    std::map<int,std::uint8_t> ordinalByJsonIndex;
    std::map<int,int> nextOrdinal;
    for (const auto& tc:content.trackConfigs) {
        const int ord=nextOrdinal[tc.type]++;
        ordinalByJsonIndex[tc.index]=static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,ord)));
    }
    std::vector<const MDSTrackConfig*> orderedConfigs;
    for (const auto& tc:content.trackConfigs) orderedConfigs.push_back(&tc);
    std::stable_sort(orderedConfigs.begin(),orderedConfigs.end(),[](const MDSTrackConfig* a,const MDSTrackConfig* b){
        return TrackTypeRank(a->type)<TrackTypeRank(b->type);
    });

    std::string defaultLeadCard,defaultLeadNote;
    SplitInstrument(content.melodicNote,defaultLeadCard,defaultLeadNote);
    // V2.3.18b dual-main-melody correction.  Some C2 scores (notably
    // 月亮代表我的心) have the normal beat.notes melody rendered by the device
    // lead layer (normally PianoStudio) AND a second scheduled lead timbre from
    // extension type13 (for the captured score this is Violin).  The INT25/26
    // tk0 schedule must therefore keep the C2 type13 timbre when present; the UI
    // exposes the base PianoStudio layer separately as 主旋律01.
    if (defaultLeadCard.empty() && defaultLeadNote.empty()) {
        if (!type13LeadCard.empty() && !type13LeadNote.empty()) {
            defaultLeadCard=type13LeadCard; defaultLeadNote=type13LeadNote;
            if (haveLeadNotes) plan.warnings.push_back("检测到双主旋律结构：beat.notes 基础旋律 + extension type13 C2 调度旋律；tk0 schedule 保留 "+defaultLeadCard+":"+defaultLeadNote+"。");
        } else {
            defaultLeadCard="sound_c2"; defaultLeadNote="PianoStudio";
            if (haveLeadNotes) plan.warnings.push_back("检测到 beat.notes 主旋律但无明确 C2 扩展主旋律：tk0 使用 sound_c2:PianoStudio。");
        }
    }
    // Keep the exact default LEAD resource for tk0 INT25 generation and for the
    // optional manual set_pre_lead protocol-test buttons. Normal V2.3.13 sheet
    // startup does not use set_pre_lead as a melody enable command.
    plan.hasLeadNotes=haveLeadNotes;
    plan.leadCard=defaultLeadCard.empty()?"sound_c2":defaultLeadCard;
    plan.leadTone=defaultLeadNote.empty()?"PianoStudio":defaultLeadNote;

    std::vector<ScheduleSection> sections;
    for (std::size_t si=0;si<natural.size();++si) {
        const float ss=bounds[si], se=bounds[si+1];
        if (!(se>ss)) continue;
        ScheduleSection sec; sec.type=natural[si].type; sec.start=ss; sec.end=se;

        if (!leadEvents.empty()) {
            for (const auto& le:leadEvents) {
                auto clipped=ClipRanges({TrackRange{le.start,le.end}},ss,se);
                if (clipped.empty()) continue;
                ScheduleTrack t; t.trackId=0; t.index=le.index; t.mute=le.mute; t.volume=le.volume;
                t.cardCode=le.cardCode.empty()?defaultLeadCard:le.cardCode;
                t.noteCode=le.noteCode.empty()?defaultLeadNote:le.noteCode;
                t.ranges=std::move(clipped); sec.tracks.push_back(std::move(t));
            }
        } else if (haveLeadNotes) {
            // No type14 authoritative mute/volume schedule: keep tk0 available
            // across every natural section that belongs to this lead score.
            // This is the missing C2 runtime schedule for base/multilevel JSONs.
            ScheduleTrack t; t.trackId=0; t.index=0; t.mute=0; t.volume=80;
            t.cardCode=defaultLeadCard; t.noteCode=defaultLeadNote; t.ranges.push_back({ss,se});
            sec.tracks.push_back(std::move(t));
        }

        for (const MDSTrackConfig* tc:orderedConfigs) {
            const auto it=rangesByJsonIndex.find(tc->index);
            if (it==rangesByJsonIndex.end()) continue;
            auto clipped=ClipRanges(it->second,ss,se);
            if (clipped.empty()) continue;
            std::string card,note;
            if (!tc->assetNotes.empty()) { card=tc->assetNotes.front().timbreCardCode; note=tc->assetNotes.front().noteCode; }
            if (card.empty() && note.empty()) SplitInstrument(InstrumentOf(*tc),card,note);
            if (card.size()>255 || note.size()>255) { error="INT25 音色代码长度超过255"; return false; }
            if (clipped.size()>255) { error="INT25 单 section/track range 数超过255，需增加分段策略"; return false; }
            ScheduleTrack t;
            t.trackId=static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,tc->index+2)));
            t.index=ordinalByJsonIndex[tc->index]; t.mute=static_cast<std::uint8_t>(tc->mute?1:0);
            t.volume=static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,tc->volume)));
            t.cardCode=std::move(card); t.noteCode=std::move(note); t.ranges=std::move(clipped);
            sec.tracks.push_back(std::move(t));
        }
        if (sec.tracks.size()>255) { error="INT25 section track 数超过255"; return false; }
        sections.push_back(std::move(sec));
    }
    if (sections.empty()) return true;
    if (sections.size()>255) { error="INT25 section 数超过255"; return false; }

    // V2.3.17: retain the exact generated INT25 geometry so runtime melody
    // edits can construct the same section/track schema as factory INT26.
    plan.scheduleSections.clear();
    plan.scheduleSections.reserve(sections.size());
    for (const auto& sec:sections) {
        C2ScheduleSection outSec; outSec.type=sec.type; outSec.start=sec.start; outSec.end=sec.end;
        outSec.tracks.reserve(sec.tracks.size());
        for (const auto& t:sec.tracks) {
            C2ScheduleTrack outTrack;
            outTrack.trackId=t.trackId; outTrack.index=t.index; outTrack.mute=t.mute; outTrack.volume=t.volume;
            outTrack.cardCode=t.cardCode; outTrack.noteCode=t.noteCode;
            outTrack.ranges.reserve(t.ranges.size());
            for (const auto& r:t.ranges) outTrack.ranges.push_back({r.start,r.end});
            outSec.tracks.push_back(std::move(outTrack));
        }
        plan.scheduleSections.push_back(std::move(outSec));
    }

    std::vector<std::uint8_t> body;
    body.push_back(static_cast<std::uint8_t>(sections.size()));
    for (const auto& sec:sections) {
        body.push_back(sec.type); PutFloat(body,sec.start); PutFloat(body,sec.end);
        body.push_back(static_cast<std::uint8_t>(sec.tracks.size()));
        for (const auto& t:sec.tracks) {
            body.push_back(t.trackId); body.push_back(t.index); body.push_back(t.mute); body.push_back(t.volume);
            body.push_back(static_cast<std::uint8_t>(t.cardCode.size())); body.push_back(static_cast<std::uint8_t>(t.noteCode.size()));
            body.push_back(static_cast<std::uint8_t>(t.ranges.size()));
            body.insert(body.end(),t.cardCode.begin(),t.cardCode.end()); body.insert(body.end(),t.noteCode.begin(),t.noteCode.end());
            for (const auto& r:t.ranges) { PutFloat(body,r.start); PutFloat(body,r.end); }
        }
    }

    constexpr std::size_t kPageData=457; // 3.7.6 capture: 469-byte int25 data incl. 12-byte page header
    const std::size_t pageCount=(body.size()+kPageData-1)/kPageData;
    if (pageCount==0 || pageCount>255 || body.size()>0xFFFFFFFFu) { error="INT25 body/page 数超出协议范围"; return false; }
    plan.int25Payloads.clear(); plan.int25Payloads.reserve(pageCount);
    for (std::size_t page=0;page<pageCount;++page) {
        const std::size_t off=page*kPageData, len=std::min<std::size_t>(kPageData,body.size()-off);
        std::vector<std::uint8_t> payload;
        payload.push_back(static_cast<std::uint8_t>(pageCount)); PutU32(payload,static_cast<std::uint32_t>(body.size()));
        payload.push_back(static_cast<std::uint8_t>(page)); PutU32(payload,static_cast<std::uint32_t>(len)); PutU16(payload,0);
        payload.insert(payload.end(),body.begin()+static_cast<std::ptrdiff_t>(off),body.begin()+static_cast<std::ptrdiff_t>(off+len));
        plan.int25Payloads.push_back(std::move(payload));
    }
    plan.int25BodyBytes=body.size(); plan.int25SectionCount=sections.size(); plan.int25Generated=true;
    return true;
}

static Item MakeNote(std::uint8_t type,std::uint8_t tkid,std::uint16_t idx,int pitch,int vel,float beat,float dur) {
    Item it; it.type=type; it.tkid=tkid; it.noteIndex=idx; it.startBeat=beat; it.endBeat=beat+dur;
    it.raw.push_back(tkid); PutU16(it.raw,idx); it.raw.push_back(static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,pitch))));
    it.raw.push_back(static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(127,vel)))); PutFloat(it.raw,beat); PutFloat(it.raw,dur); return it;
}
static Item MakeChord(std::uint16_t idx,const MDSChord& c,float beat,float unit,std::vector<std::string>& warnings) {
    Item it; it.type=TRACK_CHORD; it.tkid=1; it.noteIndex=idx; it.startBeat=beat; const float dur=static_cast<float>(c.length)/unit; it.endBeat=beat+dur;
    it.raw.push_back(1); PutU16(it.raw,idx); it.raw.push_back(static_cast<std::uint8_t>(ChordLevel(c.mainKey)));
    const int ct=ChordType(c.attachKey); it.raw.push_back(static_cast<std::uint8_t>(ct)); it.raw.push_back(0); it.raw.push_back(0); PutFloat(it.raw,beat); PutFloat(it.raw,dur);
    if (!c.attachKey.empty() && c.attachKey!="m") warnings.push_back("和弦类型 '"+c.attachKey+"' 尚未在当前抓包中确认，暂按大三和弦 type=0 编码。");
    if (!c.transKey.empty()) warnings.push_back("转位和弦 transKey='"+c.transKey+"' 尚未编码，暂按 NONE。");
    return it;
}
static Item MakeEvent(std::uint16_t idx,const MDSExtension& e,float beat,float unit) {
    Item it; it.type=TRACK_EVENT; it.tkid=2; it.noteIndex=idx; const float eventBeat=beat+static_cast<float>(e.start)/unit; it.startBeat=eventBeat; it.endBeat=eventBeat;
    it.raw.push_back(2); PutU16(it.raw,idx); PutFloat(it.raw,eventBeat);
    if (e.type=="3") {
        it.raw.push_back(1); it.raw.push_back(3);
        int pos=e.position;
        if (e.switchType==0) { if (pos!=4 && pos!=5) pos=4; }
        else if (e.switchType==1) { if (pos<1 || pos>3) pos=3; }
        it.raw.push_back(static_cast<std::uint8_t>(e.switchType)); it.raw.push_back(static_cast<std::uint8_t>(pos)); it.raw.push_back(static_cast<std::uint8_t>(e.pick));
    } else {
        it.raw.push_back(2); it.raw.push_back(1); it.raw.push_back(static_cast<std::uint8_t>(e.pickType));
    }
    return it;
}
}

bool C2MusicEncoder::Build(const MDSSong& song, int bpmOverride, C2UploadPlan& plan, std::string& error) {
    plan=C2UploadPlan{}; error.clear();
    const auto& content=song.content;
    if (content.lyrics.empty()) { error="JSON 没有 content.lyrics"; return false; }
    const float unit=BeatLengthUnit(content.beat.empty()?content.baseConfig.beat:content.beat);
    if (unit<=0.0f) { error="无效拍号"; return false; }
    plan.encodedBpm=std::max<int>(20,std::min<int>(255,bpmOverride>0?bpmOverride:content.tempo));
    plan.encodedKey=ChordLevel(content.originalTone);
    plan.encodedBnum=BnumFromBeat(content.beat,plan.warnings);

    // tkid 0=lead, 1=chord, 2=event; JSON extra track index N -> C2 tkid N+2.
    std::map<int,C2TrackDescriptor> desc;
    desc[0]={0,TRACK_LEAD,0,0}; desc[1]={1,TRACK_CHORD,0,0}; desc[2]={2,TRACK_EVENT,0,0};
    for (const auto& tc:content.trackConfigs) desc[tc.index+2]={static_cast<std::uint8_t>(tc.index+2),ExtraC2Type(tc.type),0,0};
    std::map<int,std::uint16_t> nextIdx;
    std::map<int,std::vector<C2TrackPositionPoint>> positionPoints;
    int originalToneNo=ChordLevel(content.originalTone);
    float absBeat=0.0f;
    bool haveInitialBeat=false;

    // Official string command set_config_v2pack. For 《我们的时光》 this
    // produces the exact 100-byte captured payload:
    // [tone][JSON bpm][count] + [pickType][group][pickAction][len][card:name][bpm][01]...
    if (content.baseConfig.configPack.parsed) {
        std::vector<std::uint8_t> body;
        body.push_back(static_cast<std::uint8_t>(ByteInt(content.baseConfig.tone,plan.encodedKey)));
        const int configBpm=content.baseConfig.bpm>0?content.baseConfig.bpm:(content.tempo>0?content.tempo:plan.encodedBpm);
        body.push_back(static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,configBpm))));
        body.push_back(0); // patched with entry count below
        std::uint8_t count=0;
        auto add=[&](const MDSConfigEntry& e,std::uint8_t group) {
            if (AppendConfigV2Entry(body,e,group,configBpm,plan.warnings)) {
                ++count;
                if (plan.channelVolumePayloads.size()<4) {
                    const int vol=e.hasPickVolume?e.pickVolume:100;
                    plan.channelVolumePayloads.push_back({static_cast<std::uint8_t>(0x09+plan.channelVolumePayloads.size()),
                        static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(100,vol)))});
                }
            }
        };
        for (const auto& e:content.baseConfig.configPack.chords) add(e,1);
        for (const auto& e:content.baseConfig.configPack.drums) add(e,2);
        for (const auto& e:content.baseConfig.configPack.instrument) add(e,3);
        body[2]=count;
        if (count>0) plan.configV2PackPayload=std::move(body);
    }

    // SET_SECTION_RANGE payload: count + [segmentType, startBeat(f32), endBeat(f32),
    // minLeadPitch, maxLeadPitch] for every lyrics[] segment. This layout is
    // byte-for-byte confirmed against the captured Ulaanbaatar upload.
    plan.sectionRangePayload.push_back(static_cast<std::uint8_t>(std::min<std::size_t>(255, content.lyrics.size())));
    float sectionStart = 0.0f;
    for (const auto& seg : content.lyrics) {
        float segmentBeatCount = 0.0f;
        int minPitch = 255, maxPitch = 0;
        for (const auto& bar : seg.bars) {
            for (const auto& b : bar.beats) {
                for (const auto& n : b.notes) {
                    const int pitch = (n.note - originalToneNo) + 59 + n.upOctave * 12;
                    minPitch = std::min<int>(minPitch, pitch);
                    maxPitch = std::max<int>(maxPitch, pitch);
                }
                segmentBeatCount += 1.0f;
            }
        }
        const float sectionEnd = sectionStart + segmentBeatCount;
        plan.sectionRangePayload.push_back(static_cast<std::uint8_t>(seg.type));
        PutFloat(plan.sectionRangePayload, sectionStart);
        PutFloat(plan.sectionRangePayload, sectionEnd);
        if (minPitch == 255) { minPitch = 0; maxPitch = 0; }
        plan.sectionRangePayload.push_back(static_cast<std::uint8_t>(std::max<int>(0, std::min<int>(127, minPitch))));
        plan.sectionRangePayload.push_back(static_cast<std::uint8_t>(std::max<int>(0, std::min<int>(127, maxPitch))));
        sectionStart = sectionEnd;
    }

    for (const auto& seg:content.lyrics) {
        (void)seg;
        for (const auto& bar:seg.bars) {
            (void)bar;
            for (const auto& b:bar.beats) {
                std::vector<Item> group;
                if (b.hasChord) {
                    if (plan.firstChordLevel<0) {
                        plan.firstChordLevel=ChordLevel(b.chord.mainKey);
                        plan.firstChordType=ChordType(b.chord.attachKey);
                        plan.firstChordTrans12=0;
                        plan.initialBeat=absBeat;
                        haveInitialBeat=true;
                    }
                    group.push_back(MakeChord(nextIdx[1]++,b.chord,absBeat,unit,plan.warnings));
                }
                const bool beatHasVisibleLyric=std::any_of(b.words.begin(),b.words.end(),[](const MDSWord& w) {
                    return std::any_of(w.word.begin(),w.word.end(),[](unsigned char ch){ return ch>0x20; });
                });
                for (const auto& n:b.notes) {
                    const float st=absBeat+static_cast<float>(n.start)/unit, dur=static_cast<float>(n.length)/unit;
                    int pitch=(n.note-originalToneNo)+59+n.upOctave*12;
                    // Official C2 FILL uses bit7 for guide/instrumental lead notes.
                    // Usually this follows the whole beat, but mixed lyric beats can
                    // explicitly attach a blank/stretch word to one note.
                    bool blankWordAtNote=false;
                    for (const auto& w:b.words) {
                        const bool visible=std::any_of(w.word.begin(),w.word.end(),[](unsigned char ch){ return ch>0x20; });
                        if (!visible && std::fabs(w.start-n.start)<0.001) { blankWordAtNote=true; break; }
                    }
                    if (!beatHasVisibleLyric || blankWordAtNote) pitch |= 0x80;
                    group.push_back(MakeNote(TRACK_LEAD,0,nextIdx[0]++,pitch,n.velocity,st,dur));
                }
                for (const auto& e:b.extensions) {
                    if (e.type=="10") {
                        const float cueBeat=absBeat+static_cast<float>(e.start)/unit;
                        plan.preLevelCues.push_back({cueBeat,static_cast<std::uint8_t>(std::max<int>(0,std::min<int>(255,e.level)))});
                    } else if (e.type=="3" || e.type=="7") {
                        group.push_back(MakeEvent(nextIdx[2]++,e,absBeat,unit));
                    }
                }
                for (const auto& ex:b.extraTracks) {
                    const int tk=ex.index+2;
                    if (!desc.count(tk)) { desc[tk]={static_cast<std::uint8_t>(tk),TRACK_PAD,0,0}; plan.warnings.push_back("extraTracks index="+std::to_string(ex.index)+" 未在 trackConfigs 中找到，按 PAD 建轨。"); }
                    for (const auto& n:ex.notes) {
                        const float st=absBeat+static_cast<float>(n.start)/unit, dur=static_cast<float>(n.length)/unit;
                        const int pitch=(n.note-originalToneNo)+59+n.upOctave*12;
                        group.push_back(MakeNote(desc[tk].type,static_cast<std::uint8_t>(tk),nextIdx[tk]++,pitch,n.velocity,st,dur));
                    }
                }
                if (!group.empty()) {
                    if (group.size()>255) { error="单个 beat 的 C2 item 数超过 255"; return false; }
                    std::vector<std::uint8_t> fill; fill.push_back(static_cast<std::uint8_t>(group.size()));
                    for (const auto& it:group) fill.push_back(it.type);
                    for (const auto& it:group) {
                        fill.insert(fill.end(),it.raw.begin(),it.raw.end());
                        positionPoints[it.tkid].push_back({it.startBeat,it.noteIndex});
                        auto& d=desc[it.tkid];
                        d.noteCount=static_cast<std::uint16_t>(d.noteCount+1);
                        d.maxBeat=std::max<float>(d.maxBeat,it.endBeat);
                    }
                    plan.fillPayloads.push_back(std::move(fill));
                }
                absBeat+=1.0f;
            }
        }
    }
    plan.totalBeats=absBeat;
    if (!haveInitialBeat) plan.initialBeat=0.0f;
    std::sort(plan.preLevelCues.begin(),plan.preLevelCues.end(),[](const C2PreLevelCue& a,const C2PreLevelCue& b){ return a.beat<b.beat; });
    // Official create descriptor order is tkid ascending.
    plan.hasLeadNotes = desc[0].noteCount > 0;
    for (auto& kv:desc) plan.descriptors.push_back(kv.second);
    if (plan.descriptors.size()>255) { error="C2 track count >255"; return false; }

    // App DEX C2MusicCmdDataTransformer.findPosition(beatNo) selects, for each
    // C2 track, the first item's noteid whose beat >= requested beat. Keep the
    // same lookup table so arbitrary red-line seeks can build a real SET_BEAT
    // payload instead of always sending noteIndex=0 for every track.
    plan.positionTables.clear();
    for (const auto& d:plan.descriptors) {
        C2TrackPositionTable table; table.tkid=d.tkid;
        const auto pit=positionPoints.find(static_cast<int>(d.tkid));
        if (pit!=positionPoints.end()) table.points=pit->second;
        std::stable_sort(table.points.begin(),table.points.end(),[](const C2TrackPositionPoint& a,const C2TrackPositionPoint& b) {
            if (a.beat!=b.beat) return a.beat<b.beat;
            return a.noteIndex<b.noteIndex;
        });
        plan.positionTables.push_back(std::move(table));
    }

    std::vector<std::uint8_t> create;
    PutU64(create,SongUid(song)); create.push_back(static_cast<std::uint8_t>(plan.encodedKey)); create.push_back(static_cast<std::uint8_t>(plan.encodedBpm));
    create.push_back(static_cast<std::uint8_t>(plan.encodedBnum)); create.push_back(static_cast<std::uint8_t>(plan.descriptors.size()));
    for (const auto& d:plan.descriptors) { create.push_back(d.tkid); create.push_back(d.type); PutU16(create,d.noteCount); PutFloat(create,d.maxBeat); }
    plan.createPayload=std::move(create);
    for (const auto& tc:content.trackConfigs) plan.trackSetup.push_back({static_cast<std::uint8_t>(tc.index+2),tc.volume,InstrumentOf(tc)});

    if (!BuildGenericInt25(content,unit,plan,error)) return false;
    C2OfficialCaptureProfiles::Apply(song,plan); // V2.3.8a: selects known flow only; no longer replaces generated song data.
    std::sort(plan.warnings.begin(),plan.warnings.end());
    plan.warnings.erase(std::unique(plan.warnings.begin(),plan.warnings.end()),plan.warnings.end());
    return true;
}

std::vector<std::uint8_t> C2MusicEncoder::BuildPositionPayload(float beat,std::size_t trackCount,const std::vector<std::uint16_t>& noteIndexes) {
    std::vector<std::uint8_t> out; PutFloat(out,beat); out.push_back(static_cast<std::uint8_t>(std::min<std::size_t>(255,trackCount)));
    for (std::size_t i=0;i<trackCount && i<255;++i) PutU16(out,i<noteIndexes.size()?noteIndexes[i]:0);
    return out;
}

std::vector<std::uint8_t> C2MusicEncoder::BuildPositionPayloadForPlan(float beat,const C2UploadPlan& plan) {
    const float target=std::max<float>(0.0f,std::min<float>(plan.totalBeats,beat));
    std::vector<std::uint16_t> indexes;
    indexes.reserve(plan.descriptors.size());
    for (const auto& d:plan.descriptors) {
        std::uint16_t idx=0;
        const auto tableIt=std::find_if(plan.positionTables.begin(),plan.positionTables.end(),[&](const C2TrackPositionTable& t) { return t.tkid==d.tkid; });
        if (tableIt!=plan.positionTables.end()) {
            const auto it=std::lower_bound(tableIt->points.begin(),tableIt->points.end(),target,
                [](const C2TrackPositionPoint& p,float v) { return p.beat<v; });
            if (it!=tableIt->points.end()) idx=it->noteIndex;
        }
        indexes.push_back(idx);
    }
    return BuildPositionPayload(target,plan.descriptors.size(),indexes);
}

bool C2MusicEncoder::BuildTrackAmendPayloads(const C2UploadPlan& plan,std::uint8_t trackId,float beat,bool allSections,
    const std::string& cardCode,const std::string& toneCode,int volume,
    std::vector<std::vector<std::uint8_t>>& payloads,
    std::vector<std::size_t>& sectionIndexes,std::string& error) {
    payloads.clear(); sectionIndexes.clear(); error.clear();
    if (cardCode.empty() || toneCode.empty()) { error="INT26 轨道音色 card/tone 不能为空"; return false; }
    if (cardCode.size()>255 || toneCode.size()>255) { error="INT26 轨道音色代码长度超过255"; return false; }
    if (volume<0 || volume>100) { error="INT26 轨道音量必须为 0..100"; return false; }
    if (plan.scheduleSections.empty()) { error="当前上传计划没有可编辑的 INT25 schedule"; return false; }

    auto hasTrack=[trackId](const C2ScheduleSection& sec) {
        return std::any_of(sec.tracks.begin(),sec.tracks.end(),[trackId](const C2ScheduleTrack& t){ return t.trackId==trackId; });
    };
    if (allSections) {
        for (std::size_t i=0;i<plan.scheduleSections.size();++i)
            if (hasTrack(plan.scheduleSections[i])) sectionIndexes.push_back(i);
    } else {
        const float target=std::isfinite(beat)?beat:plan.initialBeat;
        for (std::size_t i=0;i<plan.scheduleSections.size();++i) {
            const auto& sec=plan.scheduleSections[i];
            if (!hasTrack(sec)) continue;
            if (target+0.001f>=sec.start && target<sec.end) { sectionIndexes.push_back(i); break; }
        }
        if (sectionIndexes.empty()) {
            // Boundary/fallback: choose the nearest lead section instead of guessing a lyric section.
            float best=1.0e30f; std::size_t bestIndex=static_cast<std::size_t>(-1);
            for (std::size_t i=0;i<plan.scheduleSections.size();++i) {
                const auto& sec=plan.scheduleSections[i]; if (!hasTrack(sec)) continue;
                float d=0.0f;
                if (target<sec.start) d=sec.start-target; else if (target>sec.end) d=target-sec.end;
                if (d<best) { best=d; bestIndex=i; }
            }
            if (bestIndex!=static_cast<std::size_t>(-1)) sectionIndexes.push_back(bestIndex);
        }
    }
    if (sectionIndexes.empty()) { error="找不到目标轨道 schedule section"; return false; }
    if (sectionIndexes.size()>255) { error="INT26 section 数超过255"; return false; }

    std::vector<std::uint8_t> body;
    body.push_back(static_cast<std::uint8_t>(sectionIndexes.size()));
    for (std::size_t si:sectionIndexes) {
        const auto& sec=plan.scheduleSections[si];
        std::vector<const C2ScheduleTrack*> targetTracks;
        for (const auto& t:sec.tracks) if (t.trackId==trackId) targetTracks.push_back(&t);
        if (targetTracks.empty() || targetTracks.size()>255) { error="INT26 目标轨道结构无效"; return false; }
        body.push_back(sec.type); PutFloat(body,sec.start); PutFloat(body,sec.end);
        body.push_back(static_cast<std::uint8_t>(targetTracks.size()));
        for (const auto* tp:targetTracks) {
            const auto& t=*tp;
            if (t.ranges.size()>255) { error="INT26 轨道 range 数超过255"; return false; }
            body.push_back(t.trackId); body.push_back(t.index); body.push_back(t.mute);
            body.push_back(static_cast<std::uint8_t>(volume));
            body.push_back(static_cast<std::uint8_t>(cardCode.size()));
            body.push_back(static_cast<std::uint8_t>(toneCode.size()));
            body.push_back(static_cast<std::uint8_t>(t.ranges.size()));
            body.insert(body.end(),cardCode.begin(),cardCode.end());
            body.insert(body.end(),toneCode.begin(),toneCode.end());
            for (const auto& r:t.ranges) { PutFloat(body,r.start); PutFloat(body,r.end); }
        }
    }

    constexpr std::size_t kPageData=457;
    const std::size_t pageCount=(body.size()+kPageData-1)/kPageData;
    if (pageCount==0 || pageCount>255 || body.size()>0xFFFFFFFFu) { error="INT26 body/page 数超出协议范围"; return false; }
    payloads.reserve(pageCount);
    for (std::size_t page=0;page<pageCount;++page) {
        const std::size_t off=page*kPageData, len=std::min<std::size_t>(kPageData,body.size()-off);
        std::vector<std::uint8_t> payload;
        payload.push_back(static_cast<std::uint8_t>(pageCount)); PutU32(payload,static_cast<std::uint32_t>(body.size()));
        payload.push_back(static_cast<std::uint8_t>(page)); PutU32(payload,static_cast<std::uint32_t>(len)); PutU16(payload,0);
        payload.insert(payload.end(),body.begin()+static_cast<std::ptrdiff_t>(off),body.begin()+static_cast<std::ptrdiff_t>(off+len));
        payloads.push_back(std::move(payload));
    }
    return true;
}

bool C2MusicEncoder::BuildTrackAmendPayloadsMatchingTone(const C2UploadPlan& plan,std::uint8_t trackId,
    const std::string& matchCardCode,const std::string& matchToneCode,
    const std::string& cardCode,const std::string& toneCode,int volume,
    std::vector<std::vector<std::uint8_t>>& payloads,
    std::vector<std::size_t>& sectionIndexes,std::string& error) {
    payloads.clear(); sectionIndexes.clear(); error.clear();
    if (matchToneCode.empty() || cardCode.empty() || toneCode.empty()) { error="INT26 tone-group card/tone 不能为空"; return false; }
    if (cardCode.size()>255 || toneCode.size()>255) { error="INT26 轨道音色代码长度超过255"; return false; }
    if (volume<0 || volume>100) { error="INT26 轨道音量必须为 0..100"; return false; }
    if (plan.scheduleSections.empty()) { error="当前上传计划没有可编辑的 INT25 schedule"; return false; }

    auto matches=[&](const C2ScheduleTrack& t) {
        if (t.trackId!=trackId) return false;
        if (!matchCardCode.empty() && t.cardCode!=matchCardCode) return false;
        return t.noteCode==matchToneCode;
    };
    for (std::size_t i=0;i<plan.scheduleSections.size();++i) {
        const auto& sec=plan.scheduleSections[i];
        if (std::any_of(sec.tracks.begin(),sec.tracks.end(),matches)) sectionIndexes.push_back(i);
    }
    if (sectionIndexes.empty()) { error="找不到指定音色组的 tk0 schedule section"; return false; }
    if (sectionIndexes.size()>255) { error="INT26 section 数超过255"; return false; }

    std::vector<std::uint8_t> body;
    body.push_back(static_cast<std::uint8_t>(sectionIndexes.size()));
    for (std::size_t si:sectionIndexes) {
        const auto& sec=plan.scheduleSections[si];
        std::vector<const C2ScheduleTrack*> targetTracks;
        for (const auto& t:sec.tracks) if (matches(t)) targetTracks.push_back(&t);
        if (targetTracks.empty() || targetTracks.size()>255) { error="INT26 tone-group 目标轨道结构无效"; return false; }
        body.push_back(sec.type); PutFloat(body,sec.start); PutFloat(body,sec.end);
        body.push_back(static_cast<std::uint8_t>(targetTracks.size()));
        for (const auto* tp:targetTracks) {
            const auto& t=*tp;
            if (t.ranges.size()>255) { error="INT26 轨道 range 数超过255"; return false; }
            body.push_back(t.trackId); body.push_back(t.index); body.push_back(t.mute);
            body.push_back(static_cast<std::uint8_t>(volume));
            body.push_back(static_cast<std::uint8_t>(cardCode.size()));
            body.push_back(static_cast<std::uint8_t>(toneCode.size()));
            body.push_back(static_cast<std::uint8_t>(t.ranges.size()));
            body.insert(body.end(),cardCode.begin(),cardCode.end());
            body.insert(body.end(),toneCode.begin(),toneCode.end());
            for (const auto& r:t.ranges) { PutFloat(body,r.start); PutFloat(body,r.end); }
        }
    }

    constexpr std::size_t kPageData=457;
    const std::size_t pageCount=(body.size()+kPageData-1)/kPageData;
    if (pageCount==0 || pageCount>255 || body.size()>0xFFFFFFFFu) { error="INT26 body/page 数超出协议范围"; return false; }
    payloads.reserve(pageCount);
    for (std::size_t page=0;page<pageCount;++page) {
        const std::size_t off=page*kPageData, len=std::min<std::size_t>(kPageData,body.size()-off);
        std::vector<std::uint8_t> payload;
        payload.push_back(static_cast<std::uint8_t>(pageCount)); PutU32(payload,static_cast<std::uint32_t>(body.size()));
        payload.push_back(static_cast<std::uint8_t>(page)); PutU32(payload,static_cast<std::uint32_t>(len)); PutU16(payload,0);
        payload.insert(payload.end(),body.begin()+static_cast<std::ptrdiff_t>(off),body.begin()+static_cast<std::ptrdiff_t>(off+len));
        payloads.push_back(std::move(payload));
    }
    return true;
}

bool C2MusicEncoder::SelfTestUlaan(const MDSSong& song,std::string& report) {
    C2UploadPlan p; std::string e;
    if (!Build(song,84,p,e)) { report="encoder build failed: "+e; return false; }
    std::ostringstream os;
    bool ok=true;
    if (p.officialFlowProfile!=C2OfficialFlowProfile::UlaanAdvanced20260821) { ok=false; os<<"official capture profile not selected\n"; }
    if (p.createPayload.size()!=100 || p.createPayload.size()<12 || p.createPayload[11]!=11) { ok=false; os<<"CREATE must be 100 bytes / 11 tracks\n"; }
    if (p.sectionRangePayload.size()!=67) { ok=false; os<<"SECTION must be 67 bytes\n"; }
    if (p.fillPayloads.size()!=175) { ok=false; os<<"FILL packets="<<p.fillPayloads.size()<<" expected175\n"; }
    if (!p.int25Generated) { ok=false; os<<"INT25 was not generated\n"; }
    if (p.int25Payloads.size()!=8 || p.int25BodyBytes!=3212 || p.int25SectionCount!=6) {
        ok=false; os<<"INT25 pages/body/sections="<<p.int25Payloads.size()<<"/"<<p.int25BodyBytes<<"/"<<p.int25SectionCount<<" expected 8/3212/6\n";
    }
    std::vector<std::vector<std::uint8_t>> goldenInt25;
    C2OfficialCaptureProfiles::GetUlaanInt25Golden(goldenInt25);
    if (p.int25Payloads!=goldenInt25) { ok=false; os<<"generated INT25 differs from official 2026-08-21 golden capture\n"; }
    else os<<"INT25 byte-for-byte golden match: 3212 body bytes / 8 pages\n";
    if (p.descriptors.size()!=11) { ok=false; os<<"tracks="<<p.descriptors.size()<<" expected11\n"; }
    const std::uint16_t expectedCounts[11]={234,94,9,16,101,304,10,98,44,55,679};
    if (p.descriptors.size()==11) {
        for (std::size_t i=0;i<11;++i) if (p.descriptors[i].noteCount!=expectedCounts[i]) {
            ok=false; os<<"tk"<<i<<" count="<<p.descriptors[i].noteCount<<" expected"<<expectedCounts[i]<<"\n";
        }
    }
    os<<"createBytes="<<p.createPayload.size()<<" sectionBytes="<<p.sectionRangePayload.size()
      <<" fillPackets="<<p.fillPayloads.size()<<" descriptors="<<p.descriptors.size()
      <<" int25="<<p.int25Payloads.size()<<"\n";
    for (const auto& d:p.descriptors) os<<"tk"<<(int)d.tkid<<" type"<<(int)d.type<<" count"<<d.noteCount<<" max"<<d.maxBeat<<"\n";
    report=os.str(); return ok;
}
