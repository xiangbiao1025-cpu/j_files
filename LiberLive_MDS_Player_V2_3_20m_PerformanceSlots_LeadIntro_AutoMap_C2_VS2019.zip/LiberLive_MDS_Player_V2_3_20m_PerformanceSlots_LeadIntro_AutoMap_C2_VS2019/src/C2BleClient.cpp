﻿#include "C2BleClient.h"
#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <fstream>
#include <cwctype>
#include <iomanip>
#include <map>
#include <sstream>
#include <thread>
#include <utility>

#include <winrt/base.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Storage.Streams.h>

namespace {
using namespace winrt;
using namespace winrt::Windows::Devices::Bluetooth;
using namespace winrt::Windows::Devices::Bluetooth::Advertisement;
using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
using namespace winrt::Windows::Devices::Enumeration;
using namespace winrt::Windows::Storage::Streams;

// Verified LiberLive C2 UUIDs.
static const guid kServiceUuid{ 0x000000ff, 0x0000, 0x1000,{ 0x80,0x00,0x00,0x80,0x5f,0x9b,0x34,0xfb } };
static const guid kNotifyUuid { 0x0000a101, 0x0000, 0x1000,{ 0x80,0x00,0x00,0x80,0x5f,0x9b,0x34,0xfb } };
static const guid kReadUuid   { 0x0000a102, 0x0000, 0x1000,{ 0x80,0x00,0x00,0x80,0x5f,0x9b,0x34,0xfb } };
static const guid kWriteUuid  { 0x0000a103, 0x0000, 0x1000,{ 0x80,0x00,0x00,0x80,0x5f,0x9b,0x34,0xfb } };

static bool HasC2ServiceUuid(BluetoothLEAdvertisement const& ad) {
    try {
        for (auto const& u : ad.ServiceUuids()) {
            if (u == kServiceUuid) return true;
        }
    } catch (...) {
    }
    return false;
}

static std::wstring HResultText(winrt::hresult_error const& e) {
    std::wostringstream os;
    os << L"HRESULT=0x" << std::hex << std::uppercase
       << static_cast<std::uint32_t>(e.code()) << L" " << e.message().c_str();
    return os.str();
}
}

C2BleClient::C2BleClient() = default;
C2BleClient::~C2BleClient() { Disconnect(); }

void C2BleClient::Log(const std::wstring& s) const {
    if (log_) log_(s);
}

std::wstring C2BleClient::AddressToString(std::uint64_t address) {
    std::wstringstream ss;
    ss << std::uppercase << std::hex << std::setfill(L'0')
       << std::setw(2) << ((address >> 40) & 0xFF) << L":"
       << std::setw(2) << ((address >> 32) & 0xFF) << L":"
       << std::setw(2) << ((address >> 24) & 0xFF) << L":"
       << std::setw(2) << ((address >> 16) & 0xFF) << L":"
       << std::setw(2) << ((address >> 8) & 0xFF) << L":"
       << std::setw(2) << (address & 0xFF);
    return ss.str();
}

bool C2BleClient::ContainsNoCase(const std::wstring& s, const std::wstring& needle) {
    if (needle.empty()) return true;
    std::wstring a=s, b=needle;
    for (auto& ch:a) ch=static_cast<wchar_t>(std::towlower(ch));
    for (auto& ch:b) ch=static_cast<wchar_t>(std::towlower(ch));
    return a.find(b)!=std::wstring::npos;
}

std::vector<C2BleClient::Candidate> C2BleClient::ScanAdvertisements(int maxMilliseconds) {
    // V2.3.20b: use the scanner proven by C2SingleResourceAuditioner.
    // Do not require a particular advertised name.  Keep every named BLE device
    // plus every advertisement that exposes Service FF, then merge Windows-known
    // BLE devices as a fallback.  Candidates are ranked so LiberLive/C2/FF still
    // come first, while differently named C2 firmware can still be reached.
    std::map<std::uint64_t,Candidate> byAddress;
    std::mutex dataMutex,waitMutex;
    std::condition_variable cv;
    std::atomic<bool> preferredSeen{false};
    const int boundedMs=std::max<int>(1200,std::min<int>(8000,maxMilliseconds));

    Log(L"BLE scan: active advertisement scan, max " + std::to_wstring(boundedMs) + L" ms (C2SingleResourceAuditioner mode)...");
    try {
        BluetoothLEAdvertisementWatcher watcher;
        watcher.ScanningMode(BluetoothLEScanningMode::Active);
        const auto token=watcher.Received([&](BluetoothLEAdvertisementWatcher const&, BluetoothLEAdvertisementReceivedEventArgs const& args) {
            const auto addr=args.BluetoothAddress();
            auto ad=args.Advertisement();
            std::wstring name=ad.LocalName().c_str();
            const bool hasService=HasC2ServiceUuid(ad);
            const bool nameHit=ContainsNoCase(name,L"liberlive") || ContainsNoCase(name,L"c2");
            if (name.empty() && !hasService) return;
            {
                std::lock_guard<std::mutex> lk(dataMutex);
                auto& d=byAddress[addr];
                d.address=addr;
                if (!name.empty()) d.name=name;
                d.rssi=args.RawSignalStrengthInDBm();
                d.hasC2Service=d.hasC2Service || hasService;
            }
            if (nameHit || hasService) {
                preferredSeen.store(true);
                cv.notify_all();
            }
        });
        watcher.Start();
        {
            std::unique_lock<std::mutex> lk(waitMutex);
            const bool got=cv.wait_for(lk,std::chrono::milliseconds(boundedMs),[&]{return preferredSeen.load();});
            if (got) cv.wait_for(lk,std::chrono::milliseconds(700)); // collect scan response/local name
        }
        watcher.Stop();
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        try { watcher.Received(token); } catch (...) {}
    } catch (winrt::hresult_error const& e) {
        Log(L"BLE active scan exception; continue with Windows-known BLE fallback: " + HResultText(e));
    } catch (...) {
        Log(L"BLE active scan exception; continue with Windows-known BLE fallback.");
    }

    // Same fallback as C2SingleResourceAuditioner: merge DeviceInformation so a
    // C2 that omits its local name/service UUID in the current advertisement can
    // still be connected by Windows device id.
    try {
        auto all=DeviceInformation::FindAllAsync(BluetoothLEDevice::GetDeviceSelector()).get();
        for (auto const& di:all) {
            std::wstring name=di.Name().c_str();
            if (name.empty()) continue;
            bool merged=false;
            {
                std::lock_guard<std::mutex> lk(dataMutex);
                for (auto& kv:byAddress) {
                    if (kv.second.name==name) {
                        kv.second.id=di.Id().c_str();
                        merged=true;
                        break;
                    }
                }
                if (!merged) {
                    std::uint64_t pseudo=0x1000000000000ULL + byAddress.size();
                    Candidate d;
                    d.name=name;
                    d.id=di.Id().c_str();
                    byAddress[pseudo]=std::move(d); // d.address remains zero
                }
            }
        }
    } catch (...) {
        Log(L"Windows-known BLE fallback enumeration failed; advertisement candidates remain usable.");
    }

    std::vector<Candidate> out;
    {
        std::lock_guard<std::mutex> lk(dataMutex);
        for (auto const& kv:byAddress) {
            Candidate d=kv.second;
            if (d.name.empty() && d.address) d.name=L"BLE "+AddressToString(d.address);
            out.push_back(std::move(d));
        }
    }
    std::sort(out.begin(),out.end(),[](Candidate const& a,Candidate const& b) {
        auto score=[](Candidate const& x) {
            int s=0;
            if (x.hasC2Service) s+=10000;
            if (ContainsNoCase(x.name,L"liberlive")) s+=5000;
            if (ContainsNoCase(x.name,L"c2")) s+=1000;
            s+=x.rssi+127;
            return s;
        };
        return score(a)>score(b);
    });
    Log(L"BLE scan done: " + std::to_wstring(out.size()));
    return out;
}

bool C2BleClient::LoadCachedAddress(std::uint64_t& address) const {
    address=0;
    try {
        std::wifstream f(L"c2_last_device.txt");
        std::wstring text;
        if (!f || !std::getline(f,text)) return false;
        text.erase(std::remove_if(text.begin(),text.end(),[](wchar_t ch) {
            return ch==L':' || ch==L'-' || std::iswspace(ch)!=0;
        }),text.end());
        if (text.empty()) return false;
        address=std::stoull(text,nullptr,16);
        return address!=0;
    } catch (...) {
        address=0;
        return false;
    }
}

void C2BleClient::SaveCachedAddress(std::uint64_t address) const {
    if (!address) return;
    try {
        std::wofstream f(L"c2_last_device.txt",std::ios::trunc);
        if (f) f << AddressToString(address) << L"\n";
    } catch (...) {
    }
}

bool C2BleClient::Connect(std::wstring& error,LogFn log,NotifyFn notify) {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto connectStarted=std::chrono::steady_clock::now();
    const auto elapsedMs=[&]() -> long long {
        return std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now()-connectStarted).count();
    };
    error.clear();
    log_=std::move(log);
    if (device_ && writeChar_) {
        notifyFn_=std::move(notify);
        return true;
    }
    CloseUnlocked();
    notifyFn_=std::move(notify);

    // V2.3.9 fast path: remember the last successful C2 address. On later app
    // starts/reconnects, try it immediately and only scan if direct GATT fails.
    if (!lastAddress_) LoadCachedAddress(lastAddress_);
    if (lastAddress_) {
        std::wstring directError;
        Log(L"C2 快速重连：先尝试上次设备 " + AddressToString(lastAddress_));
        if (ConnectByAddress(lastAddress_,directError)) {
            devicePath_=L"BLE " + AddressToString(lastAddress_);
            if (!deviceName_.empty()) devicePath_ += L"  " + deviceName_;
            Log(L"C2 快速重连成功: " + devicePath_ + L" / FF / A101 / A102 / A103，耗时 " +
                std::to_wstring(elapsedMs()) + L" ms");
            return true;
        }
        Log(L"快速重连未成功，转主动扫描: " + directError);
        CloseUnlocked();
    }

    // Normal first connection follows C2SingleResourceAuditioner: active scan
    // returns shortly after a preferred LiberLive/C2/Service-FF advertisement,
    // then Windows-known BLE devices are merged as a fallback.
    auto candidates=ScanAdvertisements(5000);
    if (candidates.empty()) {
        error=L"BLE 扫描没有发现可尝试设备。请确认 C2 已开机、靠近电脑，并让手机官方 App/其它 BLE 工具先断开 C2。";
        return false;
    }

    std::wstring lastError;
    auto preferred=[](Candidate const& c) {
        return c.hasC2Service || ContainsNoCase(c.name,L"liberlive") || ContainsNoCase(c.name,L"c2");
    };
    auto tryCandidate=[&](Candidate const& c)->bool {
        std::wstring label=c.name.empty()?L"(unnamed BLE)":c.name;
        if (c.address) label+=L"  "+AddressToString(c.address);
        Log(L"尝试连接 BLE 候选: "+label);
        bool ok=false;
        if (c.address) ok=ConnectByAddress(c.address,lastError);
        else if (!c.id.empty()) ok=ConnectById(c.id,lastError);
        else lastError=L"候选没有 address 或 Windows device id";
        if (!ok) {
            Log(L"候选不是可用 C2 / 连接失败: "+lastError);
            CloseUnlocked();
            return false;
        }
        if (c.address) {
            lastAddress_=c.address;
            SaveCachedAddress(lastAddress_);
        }
        devicePath_=c.address ? (L"BLE "+AddressToString(c.address)) : L"BLE DeviceInformation";
        if (!deviceName_.empty()) devicePath_+=L"  "+deviceName_;
        Log(L"Connected: "+(deviceName_.empty()?label:deviceName_)+L" (A101+A102+A103 ready), elapsed "+
            std::to_wstring(elapsedMs())+L" ms");
        return true;
    };

    // First pass: normal C2 signatures. Second pass: differently named devices
    // from the SingleResourceAuditioner fallback; BindGatt itself is the final
    // authority because it requires Service FF + A101/A102/A103.
    for (const auto& c:candidates) if (preferred(c) && tryCandidate(c)) return true;
    Log(L"未在常规 LiberLive/C2 名称中建立连接，尝试其它已发现 BLE 名称（以 Service FF/A101/A102/A103 最终判定）...");
    int fallbackTried=0;
    for (const auto& c:candidates) {
        if (preferred(c)) continue;
        if (++fallbackTried>20) break;
        if (tryCandidate(c)) return true;
    }

    error=L"BLE 扫描完成，但没有找到同时具备 Service FF / A101 / A102 / A103 的 C2。最后错误: " + lastError +
          L"。请确认手机 App/其它 BLE 工具没有占用 C2。";
    return false;
}

bool C2BleClient::ConnectByAddress(std::uint64_t address,std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth;
    try {
        device_=BluetoothLEDevice::FromBluetoothAddressAsync(address).get();
        if (!device_) {
            error=L"BluetoothLEDevice::FromBluetoothAddressAsync 返回空对象";
            return false;
        }
        deviceName_=device_.Name().c_str();
        return ResolveGattAndCharacteristics(error);
    } catch (winrt::hresult_error const& e) {
        error=L"按 BLE 地址连接失败: " + HResultText(e);
        return false;
    } catch (...) {
        error=L"按 BLE 地址连接发生未知异常";
        return false;
    }
}


bool C2BleClient::ConnectById(const std::wstring& id,std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth;
    if (id.empty()) { error=L"Windows BLE device id 为空"; return false; }
    try {
        device_=BluetoothLEDevice::FromIdAsync(id).get();
        if (!device_) { error=L"BluetoothLEDevice::FromIdAsync 返回空对象"; return false; }
        deviceName_=device_.Name().c_str();
        return ResolveGattAndCharacteristics(error);
    } catch (winrt::hresult_error const& e) {
        error=L"按 Windows BLE device id 连接失败: " + HResultText(e);
        return false;
    } catch (...) {
        error=L"按 Windows BLE device id 连接发生未知异常";
        return false;
    }
}

bool C2BleClient::ResolveGattAndCharacteristics(std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth;
    using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
    if (!device_) { error=L"C2 BLE 对象为空"; return false; }
    try {
        // C2SingleResourceAuditioner uses uncached GATT discovery.  Keep that
        // behavior here so stale Windows GATT caches from another C2 revision do
        // not hide/reuse characteristics from a previous device/firmware.
        auto serviceResult=device_.GetGattServicesForUuidAsync(kServiceUuid,BluetoothCacheMode::Uncached).get();
        if (serviceResult.Status()!=GattCommunicationStatus::Success || serviceResult.Services().Size()==0) {
            error=L"Service 000000FF not found，status="+std::to_wstring(static_cast<int>(serviceResult.Status()));
            return false;
        }
        service_=serviceResult.Services().GetAt(0);

        auto notifyResult=service_.GetCharacteristicsForUuidAsync(kNotifyUuid,BluetoothCacheMode::Uncached).get();
        if (notifyResult.Status()!=GattCommunicationStatus::Success || notifyResult.Characteristics().Size()==0) {
            error=L"A101 Notify characteristic not found，status="+std::to_wstring(static_cast<int>(notifyResult.Status()));
            return false;
        }
        notifyChar_=notifyResult.Characteristics().GetAt(0);

        auto readResult=service_.GetCharacteristicsForUuidAsync(kReadUuid,BluetoothCacheMode::Uncached).get();
        if (readResult.Status()!=GattCommunicationStatus::Success || readResult.Characteristics().Size()==0) {
            error=L"A102 Read characteristic not found，status="+std::to_wstring(static_cast<int>(readResult.Status()));
            return false;
        }
        readChar_=readResult.Characteristics().GetAt(0);

        auto writeResult=service_.GetCharacteristicsForUuidAsync(kWriteUuid,BluetoothCacheMode::Uncached).get();
        if (writeResult.Status()!=GattCommunicationStatus::Success || writeResult.Characteristics().Size()==0) {
            error=L"A103 Write characteristic not found，status="+std::to_wstring(static_cast<int>(writeResult.Status()));
            return false;
        }
        writeChar_=writeResult.Characteristics().GetAt(0);

        // V2.3.20i WR-Pack TEST: verify the A103 mode used by the existing
        // WritePacket implementation. Official C2 captures use ATT 0x52 Write
        // Command (WriteWithoutResponse) for the streaming part of an upload.
        {
            const auto props=writeChar_.CharacteristicProperties();
            const bool wnr=(props & GattCharacteristicProperties::WriteWithoutResponse)!=GattCharacteristicProperties::None;
            const bool wr =(props & GattCharacteristicProperties::Write)!=GattCharacteristicProperties::None;
            writeWithoutResponse_.store(wnr);
            Log(std::wstring(L"A103: WriteWithoutResponse=")+(wnr?L"YES":L"NO")+
                L", WriteWithResponse="+(wr?L"YES":L"NO"));
        }

        // Windows negotiates ATT MTU internally. We only observe MaxPduSize;
        // unlike Android there is no RequestMtu call here. The official C2 path
        // was observed at MTU=500, i.e. up to 497 bytes of ATT value.
        try {
            gattSession_=GattSession::FromDeviceIdAsync(device_.BluetoothDeviceId()).get();
            if (gattSession_) {
                try { gattSession_.MaintainConnection(true); } catch (...) {}
                for (int i=0;i<6;++i) {
                    const auto pdu=gattSession_.MaxPduSize();
                    maxPduSize_.store(pdu);
                    if (pdu>23) break;
                    std::this_thread::sleep_for(std::chrono::milliseconds(50));
                }
                const auto pdu=maxPduSize_.load();
                Log(L"GattSession MaxPduSize="+std::to_wstring(pdu)+
                    L" (ATT value max="+std::to_wstring(pdu>3?pdu-3:0)+L"B)");
            }
        } catch (winrt::hresult_error const& e) {
            gattSession_=nullptr; maxPduSize_.store(0);
            Log(L"GattSession MaxPduSize read failed (non-fatal): "+HResultText(e));
        } catch (...) {
            gattSession_=nullptr; maxPduSize_.store(0);
            Log(L"GattSession MaxPduSize read failed (non-fatal)");
        }

        std::wstring notifyError;
        if (!SubscribeNotify(notifyError)) {
            error=notifyError;
            return false;
        }
        return true;
    } catch (winrt::hresult_error const& e) {
        error=L"枚举 C2 GATT 失败: " + HResultText(e);
        return false;
    } catch (...) {
        error=L"枚举 C2 GATT 发生未知异常";
        return false;
    }
}

bool C2BleClient::SubscribeNotify(std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
    error.clear();
    if (!notifyChar_) { error=L"A101 Notify 未准备好"; return false; }
    try {
        if (!notifyAttached_) {
            notifyToken_=notifyChar_.ValueChanged([this](GattCharacteristic const&,GattValueChangedEventArgs const& args) {
                const auto n=++notifyCount_;
                if (n==1) Log(L"C2 A101 Notify 已收到数据，双向 BLE 通道正常。");
                try {
                    DataReader reader=DataReader::FromBuffer(args.CharacteristicValue());
                    const std::uint32_t count=reader.UnconsumedBufferLength();
                    std::vector<std::uint8_t> raw(static_cast<std::size_t>(count));
                    if (count>0) {
                        reader.ReadBytes(winrt::array_view<std::uint8_t>(raw.data(),raw.data()+raw.size()));
                        // notifyFn_ is installed before Notify subscription and remains unchanged
                        // for the lifetime of this connection.
                        if (notifyFn_) notifyFn_(raw);
                    }
                } catch (...) {
                    // Never allow a malformed/late notification to tear down the WinRT callback.
                }
            });
            notifyAttached_=true;
        }
        const auto status=notifyChar_.WriteClientCharacteristicConfigurationDescriptorAsync(
            GattClientCharacteristicConfigurationDescriptorValue::Notify).get();
        if (status!=GattCommunicationStatus::Success) {
            error=L"启用 A101 Notify 失败，status=" + std::to_wstring(static_cast<int>(status));
            return false;
        }
        Log(L"C2 A101 Notify 已启用。");
        return true;
    } catch (winrt::hresult_error const& e) {
        error=L"启用 A101 Notify 异常: " + HResultText(e);
        return false;
    }
}

bool C2BleClient::BeginWritePacket(const std::vector<std::uint8_t>& packet,
    AsyncWriteOperation& operation,std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
    using namespace winrt::Windows::Storage::Streams;
    error.clear();
    operation=nullptr;
    if (packet.empty()) { error=L"空 BLE packet"; return false; }
    try {
        // Hold the object mutex only while snapshotting/starting the operation.
        // Do NOT hold it while awaiting completion; otherwise a depth-2 window
        // would collapse back into the old fully-serial WriteValueAsync().get().
        std::lock_guard<std::mutex> lock(mutex_);
        if (!device_ || !writeChar_) { error=L"C2 未连接 / A103 未准备好"; return false; }
        DataWriter writer;
        writer.WriteBytes(winrt::array_view<const std::uint8_t>(packet.data(),packet.data()+packet.size()));
        auto buffer=writer.DetachBuffer();
        const auto props=writeChar_.CharacteristicProperties();
        const auto option=(props & GattCharacteristicProperties::WriteWithoutResponse)!=GattCharacteristicProperties::None
            ? GattWriteOption::WriteWithoutResponse : GattWriteOption::WriteWithResponse;
        operation=writeChar_.WriteValueAsync(buffer,option);
        if (!operation) { error=L"A103 WriteValueAsync 未返回有效操作"; return false; }
        return true;
    } catch (winrt::hresult_error const& e) {
        error=L"A103 异步提交异常: " + HResultText(e);
        operation=nullptr;
        return false;
    } catch (...) {
        error=L"A103 异步提交发生未知异常";
        operation=nullptr;
        return false;
    }
}

bool C2BleClient::FinishWritePacket(AsyncWriteOperation& operation,std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
    using namespace winrt::Windows::Foundation;
    error.clear();
    if (!operation) { error=L"A103 异步写操作为空"; return false; }
    try {
        // A rare real-device log stopped exactly at the first CrossSongReset
        // write. Do not allow a wedged Windows GATT IAsyncOperation to block the
        // upload thread forever. Normal writes complete in ~50 ms on this PC.
        const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(3);
        while (operation.Status()==AsyncStatus::Started &&
               std::chrono::steady_clock::now()<deadline) {
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        if (operation.Status()==AsyncStatus::Started) {
            try { operation.Cancel(); } catch (...) {}
            operation=nullptr;
            error=L"A103 Write 超时 (>3000ms)，已取消本次Windows GATT操作";
            return false;
        }
        const auto status=operation.get();
        operation=nullptr;
        if (status!=GattCommunicationStatus::Success) {
            error=L"A103 Write 失败，status=" + std::to_wstring(static_cast<int>(status));
            return false;
        }
        return true;
    } catch (winrt::hresult_error const& e) {
        operation=nullptr;
        error=L"A103 异步完成异常: " + HResultText(e);
        return false;
    } catch (...) {
        operation=nullptr;
        error=L"A103 异步完成发生未知异常";
        return false;
    }
}

bool C2BleClient::WritePacket(const std::vector<std::uint8_t>& packet,std::wstring& error) {
    AsyncWriteOperation operation{nullptr};
    if (!BeginWritePacket(packet,operation,error)) return false;
    return FinishWritePacket(operation,error);
}

bool C2BleClient::ReadPacket(std::vector<std::uint8_t>& packet,std::wstring& error) {
    using namespace winrt::Windows::Devices::Bluetooth;
    using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
    using namespace winrt::Windows::Storage::Streams;
    std::lock_guard<std::mutex> lock(mutex_);
    packet.clear();
    error.clear();
    if (!device_ || !readChar_) { error=L"C2 未连接 / A102 未准备好"; return false; }
    try {
        const auto result=readChar_.ReadValueAsync(BluetoothCacheMode::Uncached).get();
        if (result.Status()!=GattCommunicationStatus::Success) {
            error=L"A102 Read 失败，status=" + std::to_wstring(static_cast<int>(result.Status()));
            return false;
        }
        DataReader reader=DataReader::FromBuffer(result.Value());
        const std::uint32_t count=reader.UnconsumedBufferLength();
        packet.resize(static_cast<std::size_t>(count));
        if (count>0) reader.ReadBytes(winrt::array_view<std::uint8_t>(packet.data(),packet.data()+packet.size()));
        if (packet.empty()) { error=L"A102 Read 返回空数据"; return false; }
        return true;
    } catch (winrt::hresult_error const& e) {
        error=L"A102 读取异常: " + HResultText(e);
        return false;
    } catch (...) {
        error=L"A102 读取发生未知异常";
        return false;
    }
}

void C2BleClient::CloseUnlocked() {
    try {
        if (notifyAttached_ && notifyChar_) {
            try { notifyChar_.ValueChanged(notifyToken_); } catch (...) {}
        }
        notifyAttached_=false;
        notifyToken_={};
        notifyCount_.store(0);
        notifyChar_=nullptr;
        readChar_=nullptr;
        writeChar_=nullptr;
        gattSession_=nullptr;
        maxPduSize_.store(0);
        writeWithoutResponse_.store(false);
        if (service_) { try { service_.Close(); } catch (...) {} service_=nullptr; }
        if (device_) { try { device_.Close(); } catch (...) {} device_=nullptr; }
    } catch (...) {
        notifyChar_=nullptr; readChar_=nullptr; writeChar_=nullptr; gattSession_=nullptr; service_=nullptr; device_=nullptr;
        notifyAttached_=false;
        maxPduSize_.store(0); writeWithoutResponse_.store(false);
    }
    deviceName_.clear();
    devicePath_.clear();
}

void C2BleClient::Disconnect() {
    std::lock_guard<std::mutex> lock(mutex_);
    CloseUnlocked();
}

bool C2BleClient::IsConnected() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return device_ && writeChar_;
}

std::wstring C2BleClient::DevicePath() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return devicePath_;
}
